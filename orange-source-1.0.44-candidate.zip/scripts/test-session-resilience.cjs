'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../main.js'),'utf8');
function loadSitesFixture(failAt){
 const originalSites=new Map([['gmail','https://mail.google.com/']]);
 const ctx={authGeneration:1,currentWorkSiteRows:[],currentProfile:{id:'user-a',role:'employee',plan:'advanced'},currentPermissions:{platform_gmail:true},MANAGED_SITE_PERMISSION_CODES:{gmail:'platform_gmail'},managedSiteAllowedByPermission:()=>true,allowedSites:originalSites,siteProxyConfigs:new Map(),fixedSiteProxies:new Map(),siteAdapters:{},proxiedSiteIds:new Set(['gmail']),proxiedSiteHosts:new Set(['mail.google.com']),fixedRouteHostsForSite:()=>[],URL,Map,Set,Error,console};
 ctx.supabase={from(table){const response=table==='work_sites'?{data:[{id:'g',site_key:'gmail',display_name:'Google 邮箱',url:'https://mail.google.com/',proxy_mode:'automatic'}]}:{data:[{site_id:'g',allowed:true}]};if(failAt===table){response.error={message:'fetch failed'};response.data=null;}const builder={select(){return builder},eq(){return builder},order(){return Promise.resolve(response)},then(resolve,reject){return Promise.resolve(response).then(resolve,reject)}};return builder}};
 vm.createContext(ctx);vm.runInContext(source.slice(source.indexOf('async function loadWorkSites()'),source.indexOf('function getExtensionPath()')),ctx);return ctx;
}
(async()=>{
 for(const table of ['work_sites','user_site_access']){
  const c=loadSitesFixture(table);await assert.rejects(c.loadWorkSites(),e=>e.code==='WORK_SITES_UNAVAILABLE');assert.equal(c.allowedSites.get('gmail'),'https://mail.google.com/');assert.ok(c.proxiedSiteIds.has('gmail'),'A read outage must not silently bypass proxy routing');
 }
 const c=loadSitesFixture();const rows=await c.loadWorkSites();assert.equal(rows[0].id,'gmail');assert.equal(c.currentWorkSiteRows[0].name,'Google 邮箱');
 let handler;
 const statusCtx={currentSession:{user:{id:'u'}},currentProfile:{id:'u'},currentPermissions:{platform_gmail:true},currentFeatureFlags:{},currentWorkSiteRows:[{id:'gmail'}],loadWorkSites:async()=>{throw Error('fetch failed')},console:{error(){}},ipcMain:{handle(name,fn){handler=fn}}};
 vm.createContext(statusCtx);const a=source.indexOf('ipcMain.handle("auth:status"'),b=source.indexOf('  ipcMain.handle("features:get"',a);vm.runInContext(source.slice(a,b).replace(/,\s*$/,';'),statusCtx);
 const status=await handler();assert.equal(status.authenticated,true);assert.equal(status.networkDegraded,true);assert.equal(status.sites[0].id,'gmail');statusCtx.currentSession=null;assert.equal((await handler()).authenticated,false);
 let tick,signouts=0;
 const heartbeatCtx={authGeneration:2,heartbeatTimer:null,heartbeatRunning:false,currentSession:{user:{id:'u'}},currentDeviceHash:'d',heartbeatFailureCount:0,currentProfile:{id:'u'},currentPermissions:{},managedTranslationProxy:null,tnBackgroundWindows:new Map(),mainWindow:{webContents:{send(){}}},setInterval:fn=>{tick=fn;return 1},clearInterval(){},invokeFunction:async()=>{throw Object.assign(Error('invalid jwt at gateway'),{status:401,code:'AUTH_GATEWAY_RETRYABLE'})},supabase:{auth:{signOut:async()=>{signouts++},stopAutoRefresh(){}}},stopMessagingRealtime:async()=>{},destroyTnBackground(){},closeDetachedSiteWindows(){},applyTranslationProxy:async()=>{},console:{warn(){},error(){}},session:{fromPartition:()=>({})},workPartition:'test',ensureWorkExtensionLoaded:async()=>({}),syncExtensionAuth:async()=>{},syncFeatureFlagsToLoadedExtensions:async()=>{}};
 vm.createContext(heartbeatCtx);const h=source.indexOf('function startHeartbeat()');vm.runInContext(source.slice(h,source.indexOf('\n}',h)+2),heartbeatCtx);heartbeatCtx.startHeartbeat();await tick();assert.equal(signouts,0);assert.ok(heartbeatCtx.currentSession);
 let rejectOld;
 heartbeatCtx.invokeFunction=()=>new Promise((_,reject)=>{rejectOld=reject});const pending=tick();heartbeatCtx.authGeneration++;rejectOld(Object.assign(Error('old session expired'),{code:'INVALID_SESSION'}));await pending;assert.equal(signouts,0,'An old request must not revoke a newly signed-in account');
 let callback;const tokenCtx={currentSession:{access_token:'old'},currentProfile:{id:'u'},supabase:{auth:{onAuthStateChange:fn=>{callback=fn}}}};vm.createContext(tokenCtx);const start=source.indexOf('supabase.auth.onAuthStateChange(');vm.runInContext(source.slice(start,source.indexOf('const FEATURE_FLAG_DEFAULTS',start)),tokenCtx);callback('TOKEN_REFRESHED',{access_token:'new',user:{id:'u'}});assert.equal(tokenCtx.currentSession.access_token,'new');callback('TOKEN_REFRESHED',{access_token:'other',user:{id:'v'}});assert.equal(tokenCtx.currentSession.access_token,'new');
 assert.ok(!source.includes('supabase.auth.signOut()'),'Desktop logout must not revoke other devices globally');
 console.log('PASS: read outages retain authorized sites/proxy, renderer stays signed in, ambiguous gateway errors retry, stale requests ignored, SDK token rotation followed, logout limited to this device.');
})().catch(e=>{console.error(e);process.exitCode=1});
