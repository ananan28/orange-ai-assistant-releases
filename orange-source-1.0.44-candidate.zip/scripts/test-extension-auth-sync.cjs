'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../main.js'),'utf8');
let windows=0,writes=[],delayedResolve;
class Window {
 constructor(){windows++;this.webContents={executeJavaScript:async code=>writes.push(code)};this.destroyed=false;}
 async loadURL(){if(delayedResolve)await new Promise(resolve=>{delayedResolve=resolve})}
 isDestroyed(){return this.destroyed}destroy(){this.destroyed=true}
}
const ctx={WeakMap,BrowserWindow:Window,URL,authGeneration:1,currentSession:{access_token:'first'},currentProfile:{id:'u',role:'employee'},config:{supabaseUrl:'http://local',supabasePublishableKey:'test'},effectiveExtensionPermissions:()=>({translate:true}),currentFeatureFlags:{},allowedSites:new Map([['gmail','https://mail.google.com']]),siteAdapters:{},tnSharedAppearanceStorageValues:()=>({})};
vm.createContext(ctx);const start=source.indexOf('const extensionAuthSnapshots');vm.runInContext(source.slice(start,source.indexOf('function effectiveExtensionPermissions',start)),ctx);
(async()=>{
 const main={},detached={};
 await ctx.syncExtensionAuth(main,{id:'ext'});await ctx.syncExtensionAuth(detached,{id:'ext'});assert.equal(writes.length,2);
 await ctx.syncExtensionAuth(main,{id:'ext'});assert.equal(windows,2,'Unchanged auth must not create another hidden browser window');
 ctx.currentSession={access_token:'rotated'};await ctx.syncExtensionAuth(main,{id:'ext'});await ctx.syncExtensionAuth(detached,{id:'ext'});assert.equal(writes.length,4);assert.ok(writes[3].includes('rotated'));
 ctx.currentSession={access_token:'stale'};delayedResolve=true;const pending=ctx.syncExtensionAuth(main,{id:'ext'});ctx.authGeneration++;ctx.currentSession=null;delayedResolve();await pending;assert.equal(writes.length,4,'Logout during hidden page loading must not restore stale credentials');
 console.log('PASS: independent sessions receive rotated auth; unchanged state opens no hidden windows; pending old sync cannot restore signed-out credentials.');
})().catch(error=>{console.error(error);process.exitCode=1});
