'use strict';
// Actual pinned Supabase SDK against a local HTTP fixture; no production credentials.
const http = require('node:http');
const assert = require('node:assert/strict');
const {createClient} = require('@supabase/supabase-js');
const b64 = value => Buffer.from(JSON.stringify(value)).toString('base64url');
const user = {id:'00000000-0000-4000-8000-000000000001',aud:'authenticated',role:'authenticated',email:'fixture@example.test'};
const token = n => `${b64({alg:'HS256',typ:'JWT'})}.${b64({sub:user.id,aud:'authenticated',role:'authenticated',exp:Math.floor(Date.now()/1000)+3600,iat:Math.floor(Date.now()/1000),fixture:n})}.fixture`;
let mode='ok', rotations=0, calls=0;
const server=http.createServer((req,res)=>{
 res.setHeader('Content-Type','application/json');
 res.setHeader('X-Supabase-Api-Version','2024-01-01');
 if(req.url.startsWith('/auth/v1/token')) {
  calls++;
  if(mode==='unavailable'){res.writeHead(503);res.end(JSON.stringify({message:'temporary outage'}));return;}
  if(mode==='revoked'){res.writeHead(400);res.end(JSON.stringify({code:'refresh_token_not_found',msg:'Refresh token not found'}));return;}
  rotations++;res.end(JSON.stringify({access_token:token(rotations),refresh_token:`refresh-${rotations}`,expires_in:3600,token_type:'bearer',user}));return;
 }
 res.end(JSON.stringify(user));
});
(async()=>{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 console.log('Local HTTP fixture listening');
 const client=createClient(`http://127.0.0.1:${server.address().port}`,'local-fixture-key',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
 try {
  console.log('Initializing session');
  const initial=await client.auth.setSession({access_token:token(0),refresh_token:'refresh-0'});assert.ifError(initial.error);
  let changes=0;client.auth.onAuthStateChange(event=>{if(event==='TOKEN_REFRESHED')changes++});
  for(let i=0;i<3;i++){
   const next=await client.auth.refreshSession();assert.ifError(next.error);assert.equal(next.data.session.refresh_token,`refresh-${i+1}`);
  }
  assert.equal(changes,3);
  mode='unavailable';const before=(await client.auth.getSession()).data.session;
  const failed=await client.auth.refreshSession();assert.ok(failed.error);assert.equal(failed.error.name,'AuthRetryableFetchError');
  assert.equal((await client.auth.getSession()).data.session.refresh_token,before.refresh_token,'Temporary outage must preserve the SDK session');
  mode='ok';
  const cooldown=await client.auth.refreshSession();assert.ok(cooldown.error,'SDK cooldown must be treated as retryable');
  console.log('Outage retained session; waiting for the real SDK retry cooldown.');
  await new Promise(resolve=>setTimeout(resolve,30500));
  await new Promise(resolve=>setTimeout(resolve,30500));
  const recovered=await client.auth.refreshSession();assert.ifError(recovered.error);assert.equal(recovered.data.session.refresh_token,'refresh-4');
  mode='revoked';const revoked=await client.auth.refreshSession();assert.equal(revoked.error.code,'refresh_token_not_found');// This SDK retains its cached session for some API errors; the application must enforce explicit revocation itself.
  const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
  const source=fs.readFileSync(path.join(__dirname,'../main.js'),'utf8');
  const ctx={Error,Set};vm.createContext(ctx);vm.runInContext(source.slice(source.indexOf('function classifyRefreshFailure'),source.indexOf('async function refreshCurrentAuthSession')),ctx);
  assert.equal(ctx.classifyRefreshFailure(revoked.error).code,'INVALID_SESSION','Application must recognize explicit revocation even when SDK retains its cached session');
  console.log(`PASS: real Supabase SDK HTTP integration: repeated rotation, 503 outage, preserved session, recovery, confirmed revocation (${calls} requests).`);
 } finally {client.auth.stopAutoRefresh();await new Promise(resolve=>server.close(resolve));}
})().catch(error=>{console.error(error);server.close();process.exitCode=1});
