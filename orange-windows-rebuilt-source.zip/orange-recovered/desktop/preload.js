const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("orangeApp", {
  login: (e) => ipcRenderer.invoke("auth:login", e),
  logout: () => ipcRenderer.invoke("auth:logout"),
  status: () => ipcRenderer.invoke("auth:status"),
  changePassword: (e) => ipcRenderer.invoke("auth:change-password", e),
  getRememberedLogin: () => ipcRenderer.invoke("secure:get-login"),
  saveRememberedLogin: (e) => ipcRenderer.invoke("secure:save-login", e),
  getSiteCredential: (e) => ipcRenderer.invoke("secure:get-site", e),
  saveSiteCredential: (e) => ipcRenderer.invoke("secure:save-site", e),
  getProxy: () => ipcRenderer.invoke("proxy:get"),
  saveProxy: (e) => ipcRenderer.invoke("proxy:save", e),
  testManagedProxy: (e) => ipcRenderer.invoke("proxy:test-managed", e),
  openExternal: (e) => ipcRenderer.invoke("external:open", e),
  getUpdateState: () => ipcRenderer.invoke("update:get-state"),
  checkForUpdates: () => ipcRenderer.invoke("update:check"),
  downloadUpdate: () => ipcRenderer.invoke("update:download"),
  installUpdate: () => ipcRenderer.invoke("update:install"),
  adminInvoke: (e) => ipcRenderer.invoke("admin:invoke", e),
  listAdminSites: () => ipcRenderer.invoke("sites:admin-list"),
  saveAdminSite: (e) => ipcRenderer.invoke("sites:admin-save", e),
  aiInvoke: (e) => ipcRenderer.invoke("ai:invoke", e),
  openSite: (e) => ipcRenderer.invoke("site:open", e),
  openSiteAccount: (e) => ipcRenderer.invoke("site:open-account", e),
  listManagedSiteAccounts: (e) =>
    ipcRenderer.invoke("site:list-managed-accounts", e),
  createManagedSiteAccount: (e) =>
    ipcRenderer.invoke("site:create-managed-account", e),
  updateManagedSiteAccount: (e) =>
    ipcRenderer.invoke("site:update-managed-account", e),
  openManagedSiteAccount: (e) =>
    ipcRenderer.invoke("site:open-managed-account", e),
  deleteSiteAccountData: (e) =>
    ipcRenderer.invoke("site:delete-account-data", e),
  chooseSiteWallpaper: (e) => ipcRenderer.invoke("site:choose-wallpaper", e),
  getSiteWallpaper: (e) => ipcRenderer.invoke("site:get-wallpaper", e),
  setSiteAccountProxy: (e) => ipcRenderer.invoke("site:set-account-proxy", e),
  showMain: () => ipcRenderer.invoke("workbench:show-main"),
  showPlatformPicker: () => ipcRenderer.invoke("workbench:choose-platform"),
  listPlatforms: () => ipcRenderer.invoke("workbench:list-platforms"),
  openDetachedTab: (e) => ipcRenderer.invoke("workbench:detach-tab", e),
  getWorkspaceState: () => ipcRenderer.invoke("workbench:get-state"),
  getFeatureFlags: () => ipcRenderer.invoke("features:get"),
  getRestoreSummary: () => ipcRenderer.invoke("workbench:get-restore-summary"),
  restoreLastWindow: () => ipcRenderer.invoke("workbench:restore-last-window"),
  saveWorkspaceState: (e) => ipcRenderer.invoke("workbench:save-state", e),
  saveWorkspaceStateSync: (e) =>
    ipcRenderer.sendSync("workbench:save-state-sync", e),
  listTnAccounts: () => ipcRenderer.invoke("tn:list"),
  testTnDom: (e) => ipcRenderer.invoke("tn:test-dom", e),
  testTnSend: (e) => ipcRenderer.invoke("tn:test-send", e),
  sendTnMessage: (e) => ipcRenderer.invoke("tn:send-one", e),
  listAdminTnCounts: () => ipcRenderer.invoke("tn:admin-counts"),
  inspectTnCookies: (e) => ipcRenderer.invoke("tn:inspect-cookies", e),
  listTnGroups: () => ipcRenderer.invoke("tn:list-groups"),
  addTnAccount: (e) => ipcRenderer.invoke("tn:add", e),
  updateTnAccount: (e) => ipcRenderer.invoke("tn:update", e),
  importTnCookies: (e) => ipcRenderer.invoke("tn:import-cookies", e),
  clearTnCookies: (e) => ipcRenderer.invoke("tn:clear-cookies", e),
  deleteTnAccount: (e) => ipcRenderer.invoke("tn:delete", e),
  openTnAccount: (e) => ipcRenderer.invoke("tn:open", e),
  importBeta6TnState: () => ipcRenderer.invoke("tn:import-beta6-state"),
  setTnTabVisibility: (e) => ipcRenderer.invoke("tn:tab-visibility", e),
  getSavedTnLocalProxy: () => ipcRenderer.invoke("tn:local-proxy-get"),
  saveTnLocalProxy: (e) => ipcRenderer.invoke("tn:local-proxy-save", e),
  deleteTnLocalProxy: (e) => ipcRenderer.invoke("tn:local-proxy-delete", e),
  getMessagingSnapshot: () => ipcRenderer.invoke("messaging:snapshot"),
  sendInternalMessage: (e) => ipcRenderer.invoke("messaging:send", e),
  sendInternalAttachment: (e) =>
    ipcRenderer.invoke("messaging:send-attachment", e),
  openInternalAttachment: (e) =>
    ipcRenderer.invoke("messaging:open-attachment", e),
  markConversationRead: (e) => ipcRenderer.invoke("messaging:mark-read", e),
  clearConversation: (e) =>
    ipcRenderer.invoke("messaging:clear-conversation", e),
  clearAllMessages: () => ipcRenderer.invoke("messaging:clear-all"),
  markAnnouncementRead: (e) =>
    ipcRenderer.invoke("messaging:announcement-read", e),
  createAnnouncement: (e) =>
    ipcRenderer.invoke("messaging:announcement-create", e),
  updateAnnouncement: (e) =>
    ipcRenderer.invoke("messaging:announcement-update", e),
  deleteAnnouncement: (e) =>
    ipcRenderer.invoke("messaging:announcement-delete", e),
  onTnAccountsChanged: (e) =>
    ipcRenderer.on("tn:accounts-changed", (o, n) => e(n)),
  onOpenWorkTab: (e) => ipcRenderer.on("workbench:open-tab", (o, n) => e(n)),
  onSwitchWorkTab: (e) =>
    ipcRenderer.on("workbench:switch-tab", (o, n) => e(n)),
  onActivateAccount: (e) =>
    ipcRenderer.on("workbench:activate-account", (o, n) => e(n)),
  onShowPlatformPicker: (e) => ipcRenderer.on("main:show-platform", () => e()),
  onShowMessages: (e) => ipcRenderer.on("main:show-messages", (o, n) => e(n)),
  onMessagingChanged: (e) =>
    ipcRenderer.on("messaging:changed", (o, n) => e(n)),
  onRevoked: (e) => ipcRenderer.on("auth:revoked", (o, n) => e(n)),
  onNetworkWarning: (e) =>
    ipcRenderer.on("auth:network-warning", (o, n) => e(n)),
  onManagedProxyState: (e) =>
    ipcRenderer.on("proxy:managed-state", (o, n) => e(n)),
  onFeatureFlagsChanged: (e) =>
    ipcRenderer.on("features:changed", (o, n) => e(n)),
  onPermissionsChanged: (e) =>
    ipcRenderer.on("permissions:changed", (o, n) => e(n)),
  onTnAccessRevoked: (e) =>
    ipcRenderer.on("workbench:revoke-tn-access", (o, n) => e(n || {})),
  onUpdateState: (e) => ipcRenderer.on("update:state", (o, n) => e(n)),
});
