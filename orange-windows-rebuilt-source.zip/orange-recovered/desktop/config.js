module.exports = Object.freeze({
  supabaseUrl: "https://wqyzdzxixpvxeeiwuney.supabase.co",
  supabasePublishableKey: "sb_publishable_itRbJ1FfegwC1gbpikEanw_FLuDztVg",
  internalEmailDomain: "orange.internal",
});
