const { ipcRenderer } = require("electron"),
  isOpenAiLoginHost = /(^|\.)(chatgpt\.com|openai\.com)$/i.test(
    location.hostname,
  ),
  isTextNowHost = /(^|\.)textnow\.com$/i.test(location.hostname),
  isDetachedWindow = process.argv.includes("--orange-detached-window=1"),
  isChineseGuardHost = !0;
let blockChineseSending = !1;
function editorText(e) {
  const n =
    e?.closest?.("textarea,input,[contenteditable='true'],[role='textbox']") ||
    document.activeElement?.closest?.(
      "textarea,input,[contenteditable='true'],[role='textbox']",
    ) ||
    document.querySelector(
      "footer [contenteditable='true'],#main footer [role='textbox'],[contenteditable='true'][data-lexical-editor='true'],[contenteditable='true'][data-tab='10'],textarea",
    );
  return n
    ? String("value" in n ? n.value : n.innerText || n.textContent || "")
    : "";
}
function showChineseGuardNotice() {
  let e = document.getElementById("orange-chinese-send-guard");
  (e ||
    ((e = document.createElement("div")),
    (e.id = "orange-chinese-send-guard"),
    (e.style.cssText =
      "position:fixed;left:50%;bottom:84px;transform:translateX(-50%);z-index:2147483647;padding:11px 18px;border-radius:10px;background:#b42318;color:#fff;box-shadow:0 8px 28px #0005;font:700 14px Microsoft YaHei,sans-serif;pointer-events:none"),
    document.documentElement.appendChild(e)),
    (e.textContent =
      "\u5DF2\u7981\u6B62\u53D1\u9001\uFF1A\u6D88\u606F\u4E2D\u5305\u542B\u4E2D\u6587"),
    (e.hidden = !1),
    clearTimeout(showChineseGuardNotice.timer),
    (showChineseGuardNotice.timer = setTimeout(() => {
      e.hidden = !0;
    }, 2200)));
}
function shouldBlockChineseSend(e) {
  if (!blockChineseSending || !isChineseGuardHost) return !1;
  const n =
      e.type === "keydown" &&
      e.key === "Enter" &&
      !e.shiftKey &&
      !e.ctrlKey &&
      !e.altKey &&
      !e.metaKey,
    i =
      e.type === "submit" ||
      ((e.type === "click" || e.type === "pointerdown") &&
        !!e.target?.closest?.(
          "button[type='submit'],button[aria-label*='Send' i],button[aria-label*='\u53D1\u9001' i],button[data-testid*='send' i],[data-testid='compose-btn-send'],[role='button'][aria-label*='Send' i],[role='button'][aria-label*='\u53D1\u9001' i]",
        ));
  return (n || i) && /[\u3400-\u9fff\uf900-\ufaff]/u.test(editorText(e.target));
}
function interceptChineseSend(e) {
  shouldBlockChineseSend(e) &&
    (e.preventDefault(),
    e.stopImmediatePropagation(),
    showChineseGuardNotice());
}
isChineseGuardHost &&
  (ipcRenderer.on("orange:set-send-policy", (e, n) => {
    blockChineseSending = n?.blockChinese === !0;
  }),
  addEventListener("keydown", interceptChineseSend, !0),
  addEventListener("submit", interceptChineseSend, !0),
  addEventListener("pointerdown", interceptChineseSend, !0),
  addEventListener("click", interceptChineseSend, !0));
function installDetachedWindowControls() {
  if (
    !isDetachedWindow ||
    document.getElementById("orange-detached-window-controls")
  )
    return;
  const e = document.createElement("div");
  ((e.id = "orange-detached-window-controls"),
    (e.style.cssText =
      "position:fixed;left:10px;top:10px;z-index:2147483647;display:flex;gap:5px;padding:5px;border:1px solid #ff9a45;border-radius:10px;background:#fffaf5ee;box-shadow:0 6px 22px #0003;font:12px Microsoft YaHei,sans-serif"),
    (e.innerHTML =
      '<button data-main type="button" style="border:0;border-radius:7px;padding:6px 9px;background:#ff7318;color:white;cursor:pointer">\u8FD4\u56DE\u4E3B\u5DE5\u4F5C\u53F0</button><button data-close type="button" style="border:0;border-radius:7px;padding:6px 9px;background:#efe5dd;color:#603921;cursor:pointer">\u5173\u95ED\u6B64\u7A97\u53E3</button>'),
    e
      .querySelector("[data-main]")
      .addEventListener("click", () =>
        ipcRenderer.send("workbench:focus-from-detached"),
      ),
    e
      .querySelector("[data-close]")
      .addEventListener("click", () =>
        ipcRenderer.send("workbench:close-detached"),
      ),
    document.documentElement.appendChild(e));
}
window.addEventListener("message", async (e) => {
  const n = e.data;
  if (e.source !== window || n?.source !== "orange-ai-extension") return;
  if (n.type === "tn:new-message") {
    ipcRenderer.send("tn:new-message", n.payload || {});
    return;
  }
  if (n.type === "tn:appearance-changed") {
    ipcRenderer.send("tn:appearance-changed", n.payload || {});
    return;
  }
  if (!n.requestId) return;
  if (n.type === "translation:request") {
    let t;
    try {
      t = await ipcRenderer.invoke("translation:translate", n.payload || {});
    } catch (l) {
      t = {
        ok: !1,
        message: l?.message || "\u804A\u5929\u7FFB\u8BD1\u5931\u8D25",
      };
    }
    window.postMessage(
      { source: "orange-ai-app", requestId: n.requestId, result: t },
      "*",
    );
    return;
  }
  if (!["proxy:get", "proxy:set"].includes(n.type)) return;
  let i;
  try {
    i =
      n.type === "proxy:get"
        ? await ipcRenderer.invoke("proxy:get")
        : await ipcRenderer.invoke("proxy:save", {
            enabled: n.payload?.enabled === !0,
          });
  } catch (t) {
    i = {
      ok: !1,
      message: t?.message || "\u7FFB\u8BD1IP\u8BBE\u7F6E\u5931\u8D25",
    };
  }
  window.postMessage(
    { source: "orange-ai-app", requestId: n.requestId, result: i },
    "*",
  );
});
function visible(e) {
  return e && e.offsetParent !== null && !e.disabled;
}
function loginFields() {
  const e = [...document.querySelectorAll("input[type='password']")].find(
    visible,
  );
  return e
    ? {
        username: [
          ...document.querySelectorAll(
            "input[type='text'],input[type='email'],input:not([type])",
          ),
        ]
          .filter(visible)
          .find((n) => n !== e),
        password: e,
      }
    : null;
}
function setInput(e, n) {
  if (!e || !n) return;
  const i = Object.getOwnPropertyDescriptor(
    HTMLInputElement.prototype,
    "value",
  )?.set;
  (i ? i.call(e, n) : (e.value = n),
    e.dispatchEvent(new Event("input", { bubbles: !0 })),
    e.dispatchEvent(new Event("change", { bubbles: !0 })));
}
async function installCredentialPanel() {
  if (document.getElementById("orange-site-credential-panel")) return !0;
  const e = loginFields();
  if (!e) return !1;
  const n = await ipcRenderer.invoke("secure:get-site-by-url", location.href);
  if (!n?.ok) return !1;
  const i = Array.isArray(n.accounts) ? n.accounts : [];
  i.length === 1 &&
    (setInput(e.username, i[0].username), setInput(e.password, i[0].password));
  const t = document.createElement("div");
  ((t.id = "orange-site-credential-panel"),
    (t.style.cssText =
      "position:fixed;z-index:2147483646;background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:8px;box-shadow:0 10px 30px #0002;color:#202124;font:13px Microsoft YaHei,sans-serif;display:none;gap:7px;min-width:238px;max-width:min(320px,calc(100vw - 16px))"),
    (t.innerHTML =
      '<div data-drag style="display:flex;align-items:center;justify-content:space-between;gap:12px;cursor:move;user-select:none"><strong>\u9009\u62E9\u767B\u5F55\u8D26\u53F7</strong><button data-close type="button" aria-label="\u6536\u8D77" title="\u6536\u8D77" style="border:0;background:transparent;color:#5f6368;font-size:18px;line-height:1;cursor:pointer;padding:0 2px">\xD7</button></div><select data-account style="width:100%;padding:8px;border:1px solid #dadce0;border-radius:7px;background:white"><option value="">\uFF0B \u4F7F\u7528\u65B0\u8D26\u53F7</option></select><div style="display:flex;gap:12px;flex-wrap:wrap"><label><input data-remember-user type="checkbox" checked> \u4FDD\u5B58\u8D26\u53F7</label><label><input data-remember-password type="checkbox" checked> \u4FDD\u5B58\u5BC6\u7801</label></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><button data-save type="button" style="border:0;border-radius:7px;padding:7px;background:#1a73e8;color:white;cursor:pointer">\u4FDD\u5B58\u5F53\u524D\u8D26\u53F7</button><button data-delete type="button" style="border:1px solid #dadce0;border-radius:7px;padding:7px;background:white;color:#b3261e;cursor:pointer">\u5220\u9664\u6240\u9009</button></div><small style="color:#5f6368">\u9009\u62E9\u8D26\u53F7\u540E\u81EA\u52A8\u586B\u5165</small>'));
  const l = t.querySelector("[data-account]");
  i.forEach((a) => {
    const s = document.createElement("option");
    ((s.value = a.id),
      (s.textContent =
        a.label || a.username || "\u672A\u547D\u540D\u8D26\u53F7"),
      l.appendChild(s));
  });
  const m = document.createElement("button");
  ((m.id = "orange-site-credential-toggle"),
    (m.type = "button"),
    (m.title = "\u7F51\u7AD9\u8D26\u53F7\u5BC6\u7801"),
    (m.textContent = "\u{1F510}"),
    (m.style.cssText =
      "position:fixed;z-index:2147483646;width:30px;height:30px;border:1px solid #ff9a45;border-radius:9px;background:#fffaf5;box-shadow:0 4px 14px #0003;cursor:pointer;font-size:15px;display:grid;place-items:center"));
  let y = null;
  const f = () => {
      const a = loginFields() || e,
        s = a.username || a.password;
      if (!s) return;
      const d = s.getBoundingClientRect();
      ((m.style.left = `${Math.max(6, Math.min(innerWidth - 36, d.right - 34))}px`),
        (m.style.top = `${Math.max(6, Math.min(innerHeight - 36, d.top + (d.height - 30) / 2))}px`));
      const p = Math.max(260, Math.min(360, d.width));
      if (((t.style.width = `${p}px`), y)) {
        ((t.style.left = `${y.left}px`), (t.style.top = `${y.top}px`));
        return;
      }
      const w = d.right + 12,
        v = d.left - p - 12;
      t.style.left = `${w + p <= innerWidth - 6 ? w : Math.max(6, v)}px`;
      const r = t.offsetHeight || 250;
      t.style.top = `${Math.max(6, Math.min(innerHeight - r - 6, d.top))}px`;
    },
    E = () => {
      ((t.style.display = "none"), (m.style.display = "grid"), f());
    },
    g = () => {
      ((m.style.display = "none"), (t.style.display = "grid"), f());
    };
  (t.querySelector("[data-close]").addEventListener("click", E),
    m.addEventListener("click", (a) => {
      (a.stopPropagation(), g());
    }));
  const D = () => {
    const a = i.find((d) => d.id === l.value);
    if (!a) return;
    const s = loginFields() || e;
    (setInput(s.username, a.username),
      setInput(s.password, a.password),
      (t.querySelector("small").textContent =
        `\u5DF2\u586B\u5165\uFF1A${a.label || a.username}`));
  };
  return (
    l.addEventListener("change", () => {
      l.value ? D() : (loginFields()?.username || e.username)?.focus();
    }),
    t.querySelector("[data-save]").addEventListener("click", async () => {
      const a = loginFields() || e,
        s = await ipcRenderer.invoke("secure:save-site-by-url", {
          url: location.href,
          username: a.username?.value || "",
          password: a.password?.value || "",
          credentialId: l.value,
          label: a.username?.value || "",
          rememberUsername: t.querySelector("[data-remember-user]").checked,
          rememberPassword: t.querySelector("[data-remember-password]").checked,
        });
      if (s?.ok) {
        (i.splice(
          0,
          i.length,
          ...(Array.isArray(s.accounts) ? s.accounts : []),
        ),
          l.replaceChildren(
            new Option("\uFF0B \u4F7F\u7528\u65B0\u8D26\u53F7", ""),
          ),
          i.forEach((p) =>
            l.add(
              new Option(
                p.label || p.username || "\u672A\u547D\u540D\u8D26\u53F7",
                p.id,
              ),
            ),
          ));
        const d = i.find((p) => p.username === (a.username?.value || ""));
        d && (l.value = d.id);
      }
      t.querySelector("small").textContent = s?.ok
        ? "\u5DF2\u52A0\u5BC6\u4FDD\u5B58\u5230\u8D26\u53F7\u5217\u8868"
        : s?.message || "\u4FDD\u5B58\u5931\u8D25";
    }),
    t.querySelector("[data-delete]").addEventListener("click", async () => {
      const a = i.find((p) => p.id === l.value);
      if (!a) {
        t.querySelector("small").textContent =
          "\u8BF7\u5148\u9009\u62E9\u8981\u5220\u9664\u7684\u8D26\u53F7";
        return;
      }
      if (
        !confirm(
          `\u786E\u5B9A\u5220\u9664\u8D26\u53F7\u201C${a.label || a.username}\u201D\u5417\uFF1F`,
        )
      )
        return;
      const s = await ipcRenderer.invoke("secure:save-site-by-url", {
        url: location.href,
        credentialId: a.id,
        clear: !0,
      });
      if (!s?.ok) {
        t.querySelector("small").textContent =
          s?.message || "\u5220\u9664\u5931\u8D25";
        return;
      }
      const d = i.findIndex((p) => p.id === a.id);
      (d >= 0 && i.splice(d, 1),
        l.querySelector(`option[value="${CSS.escape(a.id)}"]`)?.remove(),
        (l.value = ""),
        (t.querySelector("small").textContent =
          "\u8D26\u53F7\u5DF2\u5220\u9664"));
    }),
    e.username?.addEventListener("focus", g),
    e.password?.addEventListener("focus", g),
    t.querySelector("[data-drag]")?.addEventListener("pointerdown", (a) => {
      if (a.target.closest("button")) return;
      const s = t.getBoundingClientRect(),
        d = a.clientX - s.left,
        p = a.clientY - s.top,
        w = (r) => {
          ((y = {
            left: Math.max(
              6,
              Math.min(innerWidth - t.offsetWidth - 6, r.clientX - d),
            ),
            top: Math.max(
              6,
              Math.min(innerHeight - t.offsetHeight - 6, r.clientY - p),
            ),
          }),
            f());
        },
        v = () => {
          (removeEventListener("pointermove", w),
            removeEventListener("pointerup", v));
        };
      (addEventListener("pointermove", w),
        addEventListener("pointerup", v, { once: !0 }));
    }),
    addEventListener("resize", f),
    addEventListener("scroll", f, !0),
    document.addEventListener("keydown", (a) => {
      a.key === "Escape" && t.style.display !== "none" && E();
    }),
    document.addEventListener("pointerdown", (a) => {
      t.style.display === "none" ||
        t.contains(a.target) ||
        m.contains(a.target) ||
        E();
    }),
    document.documentElement.append(t, m),
    f(),
    !0
  );
}
async function startCredentialUi() {
  if (
    (installDetachedWindowControls(),
    isOpenAiLoginHost || isTextNowHost || (await installCredentialPanel()))
  )
    return;
  const e = new MutationObserver(() => {
    installCredentialPanel();
  });
  (e.observe(document.documentElement, { childList: !0, subtree: !0 }),
    setTimeout(() => e.disconnect(), 12e4));
}
const pageTranslation = (() => {
  const e = new WeakMap(),
    n = new Set(),
    i = new Map();
  let t = !1,
    l = null,
    m = !1,
    y = null,
    f = 0;
  const E = [
    "script",
    "style",
    "noscript",
    "code",
    "pre",
    "textarea",
    "input",
    "select",
    "option",
    "[contenteditable='true']",
    "[role='textbox']",
    "#orange-site-credential-panel",
    "#orange-site-credential-toggle",
    "#orange-detached-window-controls",
    "#orange-page-translation-toast",
  ].join(",");
  function g(r, c = !1) {
    let o = document.getElementById("orange-page-translation-toast");
    (o ||
      ((o = document.createElement("div")),
      (o.id = "orange-page-translation-toast"),
      (o.style.cssText =
        "position:fixed;right:18px;bottom:18px;z-index:2147483647;max-width:360px;padding:11px 16px;border-radius:10px;color:#fff;box-shadow:0 8px 28px #0005;font:600 13px Microsoft YaHei,sans-serif;pointer-events:none;transition:opacity .18s"),
      document.documentElement.appendChild(o)),
      (o.textContent = r),
      (o.style.background = c ? "#b42318" : "#202124"),
      (o.style.opacity = "1"),
      clearTimeout(g.timer),
      (g.timer = setTimeout(() => (o.style.opacity = "0"), 2200)));
  }
  function D(r) {
    if (!t || !r || r.nodeType !== Node.TEXT_NODE || !r.isConnected) return !1;
    const c = r.parentElement;
    if (!c || c.closest(E)) return !1;
    const o = String(r.nodeValue || "").trim();
    return (
      o.length > 1 &&
      o.length <= 1200 &&
      /[A-Za-z\u00c0-\u024f\u0370-\u052f\u0590-\u0e7f\u3040-\u30ff\uac00-\ud7af]/u.test(
        o,
      ) &&
      !/^(?:https?:\/\/|www\.)\S+$/i.test(o)
    );
  }
  function a(r = document.body) {
    if (!r) return [];
    if (r.nodeType === Node.TEXT_NODE) return D(r) ? [r] : [];
    if (r.nodeType !== Node.ELEMENT_NODE || r.matches?.(E)) return [];
    const c = document.createTreeWalker(r, NodeFilter.SHOW_TEXT),
      o = [];
    let u;
    for (; (u = c.nextNode());) D(u) && o.push(u);
    return o;
  }
  async function s(r, c) {
    if (!D(r) || c !== f) return;
    const o = String(r.nodeValue || ""),
      u = o.trim(),
      b = o.slice(0, o.indexOf(u)),
      h = o.slice(o.indexOf(u) + u.length),
      F = e.get(r);
    if (F?.translated === u) return;
    const x = F && u === F.original ? F.original : u;
    let k = i.get(x);
    if (!k) {
      const B = await ipcRenderer.invoke("translation:translate", {
        featureCode: "page_translate",
        text: x,
        sourceLanguage: "auto",
        targetLanguage: "zh-CN",
      });
      if (!B?.ok || !String(B.translated || "").trim())
        throw new Error(B?.message || "\u7F51\u9875\u7FFB\u8BD1\u5931\u8D25");
      ((k = String(B.translated).trim()), i.set(x, k));
    }
    !t ||
      c !== f ||
      !r.isConnected ||
      (e.set(r, { original: x, translated: k, leading: b, trailing: h }),
      n.add(r),
      (r.nodeValue = `${b}${k}${h}`));
  }
  async function d(r, c = !1) {
    if (!t || m) return;
    m = !0;
    const o = f,
      u = [...new Set(r.flatMap((x) => a(x)))];
    c &&
      g(
        `\u6B63\u5728\u7FFB\u8BD1\u7F51\u9875\uFF08${u.length}\u5904\u6587\u5B57\uFF09\u2026`,
      );
    let b = 0,
      h = 0;
    const F = async () => {
      for (; t && o === f;) {
        const x = u[b++];
        if (!x) break;
        try {
          await s(x, o);
        } catch {
          h += 1;
        }
      }
    };
    (await Promise.all(Array.from({ length: Math.min(6, u.length) }, F)),
      (m = !1),
      c &&
        o === f &&
        g(
          h === u.length && u.length
            ? "\u7F51\u9875\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7FFB\u8BD1\u6743\u9650\u6216\u7F51\u7EDC"
            : "\u7F51\u9875\u5DF2\u7FFB\u8BD1\u4E3A\u7B80\u4F53\u4E2D\u6587",
          h === u.length && u.length > 0,
        ));
  }
  function p(r) {
    (clearTimeout(y), (y = setTimeout(() => d(r), 180)));
  }
  async function w(r = !1) {
    (r && v(!0),
      (t = !0),
      (f += 1),
      ipcRenderer.send("page-translation:status", { enabled: !0 }),
      l?.disconnect(),
      (l = new MutationObserver((c) => {
        if (!t) return;
        const o = [];
        for (const u of c)
          if (u.type === "characterData") {
            const b = e.get(u.target),
              h = String(u.target.nodeValue || "").trim();
            if (b?.translated === h) continue;
            (e.delete(u.target), n.delete(u.target), o.push(u.target));
          } else for (const b of u.addedNodes) o.push(b);
        o.length && p(o);
      })),
      l.observe(document.documentElement, {
        childList: !0,
        characterData: !0,
        subtree: !0,
      }),
      await d([document.body || document.documentElement], !0));
  }
  function v(r = !1) {
    ((t = !1), (f += 1), clearTimeout(y), l?.disconnect(), (l = null));
    for (const c of n) {
      const o = e.get(c);
      c.isConnected &&
        o &&
        String(c.nodeValue || "").trim() === o.translated &&
        (c.nodeValue = `${o.leading}${o.original}${o.trailing}`);
    }
    (n.clear(),
      ipcRenderer.send("page-translation:status", { enabled: !1 }),
      r || g("\u5DF2\u6062\u590D\u7F51\u9875\u539F\u6587"));
  }
  return { start: w, restore: v };
})();
(ipcRenderer.on("page-translation:set", (e, n) =>
  pageTranslation.start(n?.refresh === !0),
),
  ipcRenderer.on("page-translation:restore", () => pageTranslation.restore()),
  addEventListener(
    "contextmenu",
    (e) => {
      const n = e.target;
      (e.preventDefault(),
        ipcRenderer.send("page-context-menu:open", {
          editable: !!n?.closest?.(
            "textarea,input,[contenteditable='true'],[role='textbox']",
          ),
          selectionText: getSelection()?.toString() || "",
        }));
    },
    !0,
  ),
  document.readyState === "loading"
    ? addEventListener("DOMContentLoaded", startCredentialUi, { once: !0 })
    : startCredentialUi());
