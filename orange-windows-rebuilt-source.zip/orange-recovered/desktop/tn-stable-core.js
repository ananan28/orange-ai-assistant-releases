"use strict";
const TN_STABLE_BASE = Object.freeze({
  sourceVersion: "0.7.0-beta.6",
  partitionPrefix: "persist:orange-beta-tn-",
  messagingUrl: "https://www.textnow.com/messaging",
  backgroundWindow: Object.freeze({ width: 900, height: 700 }),
  webPreferences: Object.freeze({
    contextIsolation: !0,
    nodeIntegration: !1,
    sandbox: !0,
    backgroundThrottling: !1,
  }),
  allowedPermissions: Object.freeze(["notifications"]),
});
function partitionFor(e) {
  const r = String(e || "").trim();
  if (!r) throw new Error("TN\u8D26\u53F7ID\u4E0D\u80FD\u4E3A\u7A7A");
  return `${TN_STABLE_BASE.partitionPrefix}${r}`;
}
function backgroundWebPreferences(e, r) {
  return { partition: e, preload: r, ...TN_STABLE_BASE.webPreferences };
}
function permissionAllowed(e) {
  return TN_STABLE_BASE.allowedPermissions.includes(String(e || ""));
}
module.exports = Object.freeze({
  TN_STABLE_BASE,
  partitionFor,
  backgroundWebPreferences,
  permissionAllowed,
});
