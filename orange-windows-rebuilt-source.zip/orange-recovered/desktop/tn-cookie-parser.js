"use strict";
const DEFAULT_HOST = "www.textnow.com",
  DEFAULT_DOMAIN = ".textnow.com",
  WRAPPER_KEYS = [
    "cookies",
    "cookie",
    "cookieData",
    "data",
    "items",
    "entries",
  ];
function cleanCookieText(e) {
  let t = String(e || "").trim();
  const n = t.match(/(?:^|\s)(?:-b|--cookie)\s+(["'])([\s\S]*?)\1/i),
    i = t.match(/(?:^|\s)(?:-H|--header)\s+(["'])Cookie:\s*([\s\S]*?)\1/i),
    r = t.match(/^Cookie\s*:\s*(.+)$/im);
  n ? (t = n[2]) : i ? (t = i[2]) : r && (t = r[1]);
  const o = t.match(/document\.cookie\s*=\s*(["'])([\s\S]*?)\1/i);
  return (o && (t = o[2]), (t = t.replace(/^\s*Cookie\s*:\s*/i, "")), t.trim());
}
function isTextNowHost(e) {
  const t = String(e || "")
    .replace(/^\./, "")
    .toLowerCase();
  return t === "textnow.com" || t.endsWith(".textnow.com");
}
function normalizedHost(e) {
  let t = String(e || DEFAULT_DOMAIN)
    .trim()
    .toLowerCase();
  try {
    /^https?:\/\//i.test(t) && (t = new URL(t).hostname);
  } catch {}
  return (
    (t = t.replace(/^\./, "").split(/[/:]/)[0]),
    isTextNowHost(t) ? t : ""
  );
}
function sameSiteValue(e) {
  const t = String(e || "")
    .toLowerCase()
    .replace(/[-_ ]/g, "");
  return t === "strict"
    ? "strict"
    : t === "lax"
      ? "lax"
      : t === "none" || t === "norestriction"
        ? "no_restriction"
        : "unspecified";
}
function expirationSeconds(e) {
  if (e == null || e === "" || e === 0 || e === "0") return null;
  let t = Number(e);
  return (
    Number.isFinite(t) || (t = Date.parse(String(e)) / 1e3),
    Number.isFinite(t) ? (t > 1e12 ? t / 1e3 : t) : null
  );
}
function cookieLike(e) {
  return !!(
    e &&
    typeof e == "object" &&
    !Array.isArray(e) &&
    typeof (e.name ?? e.Name) == "string" &&
    (Object.prototype.hasOwnProperty.call(e, "value") ||
      Object.prototype.hasOwnProperty.call(e, "Value"))
  );
}
function rowsFromJson(e, t = {}) {
  if (typeof e == "string")
    try {
      return rowsFromJson(JSON.parse(e), t);
    } catch {
      return rowsFromHeader(e);
    }
  if (Array.isArray(e)) return e.flatMap((r) => rowsFromJson(r, t));
  if (!e || typeof e != "object") return [];
  if (cookieLike(e))
    return [{ ...t, ...e, name: e.name ?? e.Name, value: e.value ?? e.Value }];
  if (Array.isArray(e?.log?.entries))
    return e.log.entries.flatMap((r) => [
      ...rowsFromJson(r?.request?.cookies || [], t),
      ...rowsFromJson(r?.response?.cookies || [], t),
    ]);
  for (const r of WRAPPER_KEYS) {
    if (!Object.prototype.hasOwnProperty.call(e, r)) continue;
    const o = e[r];
    if (typeof o == "string")
      try {
        return rowsFromJson(JSON.parse(o), { ...t, ...e });
      } catch {
        return rowsFromHeader(o);
      }
    return rowsFromJson(o, { ...t, ...e });
  }
  const n = Object.entries(e),
    i = n.filter(([r, o]) => isTextNowHost(r) && o && typeof o == "object");
  return i.length
    ? i.flatMap(([r, o]) => rowsFromJson(o, { ...t, domain: r }))
    : n.length &&
        n.every(([, r]) => ["string", "number", "boolean"].includes(typeof r))
      ? n.map(([r, o]) => ({ ...t, name: r, value: String(o) }))
      : n.flatMap(([r, o]) => {
          if (!o || typeof o != "object") return [];
          const a = isTextNowHost(r) ? { ...t, domain: r } : t;
          return rowsFromJson(o, a);
        });
}
function rowsFromSetCookie(e) {
  return String(e || "")
    .split(/\r?\n/)
    .map((t) => t.trim())
    .filter((t) => /^Set-Cookie\s*:/i.test(t))
    .map((t) => {
      const n = t.replace(/^Set-Cookie\s*:\s*/i, "").split(/;\s*/),
        i = n.shift() || "",
        r = i.indexOf("=");
      if (r < 1) return null;
      const o = {
        name: i.slice(0, r).trim(),
        value: i.slice(r + 1),
        domain: DEFAULT_HOST,
        hostOnly: !0,
        path: "/",
      };
      for (const a of n) {
        const u = a.indexOf("="),
          l = (u < 0 ? a : a.slice(0, u)).trim().toLowerCase(),
          p = u < 0 ? "" : a.slice(u + 1).trim();
        l === "domain"
          ? ((o.domain = p), (o.hostOnly = !1))
          : l === "path"
            ? (o.path = p)
            : l === "expires"
              ? (o.expires = p)
              : l === "max-age" && Number.isFinite(Number(p))
                ? (o.expirationDate = Math.floor(Date.now() / 1e3) + Number(p))
                : l === "samesite"
                  ? (o.sameSite = p)
                  : l === "secure"
                    ? (o.secure = !0)
                    : l === "httponly" && (o.httpOnly = !0);
      }
      return o;
    })
    .filter(Boolean);
}
function rowsFromHeader(e) {
  let t = cleanCookieText(e);
  return (
    (t = t
      .split(/\r?\n/)
      .map((n) => n.trim())
      .filter(Boolean)
      .reduce((n, i) => (n ? `${n}${/;\s*$/.test(n) ? " " : ""}${i}` : i), "")
      .trim()),
    t
      .split(/;\s*/)
      .map((n) => {
        const i = n.indexOf("=");
        if (i < 1) return null;
        const r = n.slice(0, i).trim();
        return !r ||
          /^(?:path|domain|expires|max-age|samesite|secure|httponly)$/i.test(r)
          ? null
          : {
              name: r,
              value: n.slice(i + 1).trim(),
              domain: DEFAULT_DOMAIN,
              hostOnly: !1,
              path: "/",
              secure: !0,
              sourceFormat: "header",
            };
      })
      .filter(Boolean)
  );
}
function rowsFromLooseText(e) {
  const t = [],
    n = String(e || "")
      .split(/\r?\n/)
      .map((i) => i.trim())
      .filter(Boolean);
  for (const i of n) {
    const r = i.split("	"),
      o = r.length > 1 ? r : [i];
    for (const a of o) {
      const u = cleanCookieText(a).replace(
          /^\s*(?:cookies?|ck)\s*[=:]\s*/i,
          "",
        ),
        l = rowsFromHeader(u);
      if (l.length) {
        t.push(...l);
        break;
      }
    }
  }
  return t;
}
function rowsFromNetscape(e) {
  const t = [];
  for (const n of String(e || "").split(/\r?\n/)) {
    const i = n.trim();
    if (!i || (i.startsWith("#") && !i.startsWith("#HttpOnly_"))) continue;
    const r = i.replace(/^#HttpOnly_/, "").split("	");
    r.length < 7 ||
      t.push({
        domain: r[0],
        hostOnly: String(r[1]).toUpperCase() !== "TRUE",
        path: r[2] || "/",
        secure: String(r[3]).toUpperCase() === "TRUE",
        expirationDate: r[4],
        name: r[5],
        value: r.slice(6).join("	"),
        httpOnly: i.startsWith("#HttpOnly_"),
      });
  }
  return t;
}
function splitDelimitedLine(e, t) {
  if (t === "	") return e.split("	");
  const n = [];
  let i = "",
    r = !1;
  for (let o = 0; o < e.length; o += 1) {
    const a = e[o];
    a === '"'
      ? r && e[o + 1] === '"'
        ? ((i += '"'), (o += 1))
        : (r = !r)
      : a === t && !r
        ? (n.push(i), (i = ""))
        : (i += a);
  }
  return (n.push(i), n);
}
function rowsFromDevtools(e) {
  const t = String(e || "")
      .split(/\r?\n/)
      .filter((r) => r.trim()),
    n = t[0]?.includes("	") ? "	" : t[0]?.includes(",") ? "," : "";
  if (t.length < 2 || !/\bname\b/i.test(t[0]) || !/\bvalue\b/i.test(t[0]) || !n)
    return [];
  const i = splitDelimitedLine(t[0], n).map((r) =>
    r.trim().toLowerCase().replace(/\s+/g, ""),
  );
  return t
    .slice(1)
    .map((r) => {
      const o = splitDelimitedLine(r, n),
        a = {};
      return (
        i.forEach((u, l) => {
          a[u] = o[l] ?? "";
        }),
        {
          name: a.name,
          value: a.value,
          domain: a.domain,
          path: a.path || "/",
          expirationDate: a.expires || a.expirationdate,
          httpOnly: /^(true|✓|yes)$/i.test(a.httponly),
          secure: /^(true|✓|yes)$/i.test(a.secure),
          sameSite: a.samesite,
        }
      );
    })
    .filter((r) => r.name);
}
function normalizeCookieRow(e) {
  const t = String(e?.name ?? e?.Name ?? "").trim(),
    n = String(e?.value ?? e?.Value ?? "");
  if (!t || /[\x00-\x20();<>@,:\\"/\[\]?={}]/.test(t)) return null;
  const i = String(e?.url || e?.URL || "").trim();
  let r = "",
    o = "";
  try {
    const f = new URL(i);
    ((r = f.hostname), (o = f.pathname));
  } catch {}
  const a = normalizedHost(e?.domain || e?.host || r || DEFAULT_DOMAIN);
  if (!a) return null;
  const u = String(e?.path || o || "/"),
    l = u.startsWith("/") ? u : "/",
    p = e?.hostOnly === !0 || e?.host_only === !0 || t.startsWith("__Host-"),
    y =
      t.startsWith("__Secure-") || t.startsWith("__Host-")
        ? !0
        : e?.secure !== !1,
    s = sameSiteValue(e?.sameSite ?? e?.same_site),
    c = expirationSeconds(
      e?.expirationDate ?? e?.expires ?? e?.expiry ?? e?.expiration,
    );
  if (c !== null && c <= Date.now() / 1e3) return null;
  const m = {
    url: `${y ? "https" : "http"}://${a}${l}`,
    name: t,
    value: n,
    path: l,
    secure: y,
    httpOnly: e?.httpOnly === !0 || e?.http_only === !0,
    sameSite: s === "no_restriction" && !y ? "unspecified" : s,
  };
  return (
    p || (m.domain = `.${a.replace(/^\./, "")}`),
    c !== null && (m.expirationDate = c),
    m
  );
}
function parseTnCookiePayload(e) {
  const t = String(e || "").trim();
  if (!t) throw new Error("\u8BF7\u7C98\u8D34Cookie");
  let n = [];
  if (
    t.startsWith("[") ||
    t.startsWith("{") ||
    (t.startsWith('"') && t.endsWith('"'))
  )
    try {
      const r = JSON.parse(t);
      n = rowsFromJson(r);
    } catch {
      throw new Error("Cookie JSON\u683C\u5F0F\u4E0D\u6B63\u786E");
    }
  else
    /^#\s*Netscape HTTP Cookie File/im.test(t) ||
    /^(?:#HttpOnly_)?[^\t]+\t(?:TRUE|FALSE)\t/im.test(t)
      ? (n = rowsFromNetscape(t))
      : /^Set-Cookie\s*:/im.test(t)
        ? (n = rowsFromSetCookie(t))
        : ((n = rowsFromDevtools(t)), n.length || (n = rowsFromHeader(t)));
  let i = n.map(normalizeCookieRow).filter(Boolean);
  if (
    (!i.length &&
      !(t.startsWith("[") || t.startsWith("{")) &&
      (i = rowsFromLooseText(t).map(normalizeCookieRow).filter(Boolean)),
    !i.length)
  )
    throw new Error(
      "\u6CA1\u6709\u627E\u5230\u6709\u6548\u7684TextNow Cookie\uFF1B\u683C\u5F0F\u4E0D\u652F\u6301\u3001\u57DF\u540D\u4E0D\u6B63\u786E\u6216Cookie\u5DF2\u8FC7\u671F",
    );
  return i.slice(0, 500);
}
function splitTnCookiePayloads(e) {
  const t = String(e || "").trim();
  if (!t) return [""];
  const n = (s) =>
      JSON.stringify(s?.cookies ?? s?.cookie ?? s?.cookieData ?? s),
    i = (s) =>
      s &&
      typeof s == "object" &&
      !Array.isArray(s) &&
      WRAPPER_KEYS.some(
        (c) => Array.isArray(s[c]) || (s[c] && typeof s[c] == "object"),
      ),
    r = (s) =>
      Array.isArray(s?.accounts)
        ? s.accounts.map(n)
        : Array.isArray(s?.profiles)
          ? s.profiles.map(n)
          : Array.isArray(s) && s.length && s.every(Array.isArray)
            ? s.map(JSON.stringify)
            : Array.isArray(s) && s.length && s.every(i)
              ? s.map(n)
              : [JSON.stringify(s)];
  try {
    return r(JSON.parse(t));
  } catch {}
  const o = t
    .split(/\r?\n\s*-{3,}\s*\r?\n|\r?\n\s*={3,}\s*\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (o.length > 1) return o.flatMap((s) => splitTnCookiePayloads(s));
  const a = [];
  if (/^[\[{]/.test(t)) {
    let s = -1,
      c = 0,
      m = !1,
      f = !1;
    for (let g = 0; g < t.length; g += 1) {
      const h = t[g];
      if (m) {
        f ? (f = !1) : h === "\\" ? (f = !0) : h === '"' && (m = !1);
        continue;
      }
      if (h === '"') {
        m = !0;
        continue;
      }
      if (h === "[" || h === "{") (c === 0 && (s = g), (c += 1));
      else if (
        (h === "]" || h === "}") &&
        c > 0 &&
        ((c -= 1), c === 0 && s >= 0)
      ) {
        try {
          a.push(...r(JSON.parse(t.slice(s, g + 1))));
        } catch {}
        s = -1;
      }
    }
  }
  if (a.length) return a;
  const u = (s) => {
      let c = String(s || "").trim();
      return (
        c.startsWith('"') &&
          c.endsWith('"') &&
          (c = c.slice(1, -1).replace(/""/g, '"')),
        c
      );
    },
    l = (s) => {
      const c = u(s),
        m = c.match(/(?:^|;\s*)[^\s=;\t]{1,80}=/g)?.length || 0,
        f =
          /(?:^|;\s*)(?:connect\.sid|ppid|_cfuvid|xsrf-token|_csrf|g_state|_px\w*|_ga\w*|pptz|pxcts)=/i.test(
            c,
          );
      return m + (f ? 5 : 0);
    },
    p = t
      .split(/\r?\n/)
      .map(
        (s) =>
          s
            .split("	")
            .map(u)
            .sort((c, m) => l(m) - l(c))[0] || "",
      )
      .filter((s) => l(s) >= 3);
  if (p.length >= 2) return p;
  const y = t
    .split(/\r?\n\s*\r?\n+/)
    .map((s) => s.trim())
    .filter(Boolean);
  return y.length > 1 ? y : [t];
}
function inspectTnCookiePayloads(e) {
  const t = splitTnCookiePayloads(e),
    n = [],
    i = [];
  return (
    t.forEach((r, o) => {
      try {
        n.push({
          index: o + 1,
          batch: r,
          cookieCount: parseTnCookiePayload(r).length,
        });
      } catch (a) {
        i.push({ index: o + 1, message: a?.message || "CK\u65E0\u6548" });
      }
    }),
    { detected: t.length, valid: n, invalid: i }
  );
}
module.exports = {
  parseTnCookiePayload,
  splitTnCookiePayloads,
  inspectTnCookiePayloads,
};
