const path = require("node:path"),
  fs = require("node:fs"),
  crypto = require("node:crypto"),
  os = require("node:os"),
  {
    app,
    BrowserWindow,
    ipcMain,
    session,
    shell,
    dialog,
    safeStorage,
    Tray,
    Menu,
    net,
    webContents,
    screen,
    Notification,
  } = require("electron"),
  { autoUpdater } = require("electron-updater"),
  { createClient } = require("@supabase/supabase-js"),
  config = require("./config"),
  {
    TN_STABLE_BASE,
    partitionFor,
    backgroundWebPreferences,
    permissionAllowed: tnStablePermissionAllowed,
  } = require("./tn-stable-core"),
  { TN_DOM_SELECTORS, normalizeTnPhone } = require("./tn-dom-locator"),
  {
    parseTnCookiePayload,
    inspectTnCookiePayloads,
  } = require("./tn-cookie-parser"),
  supabase = createClient(config.supabaseUrl, config.supabasePublishableKey, {
    auth: { persistSession: !1, autoRefreshToken: !0 },
  });
let currentSession = null,
  currentProfile = null,
  currentDeviceHash = null,
  currentPermissions = {},
  authRefreshPromise = null,
  heartbeatTimer = null,
  heartbeatFailureCount = 0,
  featureFlagTimer = null;
const FEATURE_FLAG_DEFAULTS = Object.freeze({
    module_tn: !1,
    tn_accounts: !1,
    tn_sender: !1,
    tn_dom_test: !1,
    tn_live_test: !1,
    module_messaging: !0,
    messaging_text: !0,
    messaging_attachments: !0,
    messaging_announcements: !0,
    module_translation: !0,
    chat_translate: !0,
    page_translate: !0,
    input_translate: !0,
    module_ai: !0,
    ai_reply: !0,
    reengage: !0,
    personal_groq_key: !0,
    public_groq_pool: !0,
    module_privacy: !0,
    phone_mask: !0,
    phone_mask_custom_text: !0,
    phone_mask_custom_color: !0,
    module_visuals: !0,
    custom_background: !0,
    bubble_effect: !0,
    module_proxy: !0,
    proxy_pool: !0,
    area_lookup: !0,
  }),
  FEATURE_FLAG_PARENTS = Object.freeze({
    tn_accounts: "module_tn",
    tn_sender: "module_tn",
    tn_dom_test: "module_tn",
    tn_live_test: "module_tn",
    messaging_text: "module_messaging",
    messaging_attachments: "module_messaging",
    messaging_announcements: "module_messaging",
    chat_translate: "module_translation",
    page_translate: "module_translation",
    input_translate: "module_translation",
    ai_reply: "module_ai",
    reengage: "module_ai",
    personal_groq_key: "module_ai",
    public_groq_pool: "module_ai",
    phone_mask: "module_privacy",
    phone_mask_custom_text: "module_privacy",
    phone_mask_custom_color: "module_privacy",
    custom_background: "module_visuals",
    bubble_effect: "module_visuals",
    proxy_pool: "module_proxy",
    area_lookup: "module_proxy",
  });
let currentFeatureFlags = { ...FEATURE_FLAG_DEFAULTS },
  mainWindow = null,
  workbenchWindow = null;
const detachedSiteWindows = new Map();
function closeDetachedSiteWindows(n = () => !0) {
  for (const [e, t] of [...detachedSiteWindows])
    !n(t) || e.isDestroyed() || (e.close(), detachedSiteWindows.delete(e));
}
let workbenchMayRestoreOnNextLoad = !1,
  tray = null,
  isQuitting = !1,
  updateState = {
    status: "idle",
    currentVersion: app.getVersion(),
    availableVersion: "",
    percent: 0,
    message: "",
  };
const workPartition = "persist:orange-work",
  sitePartitionPrefix = "persist:orange-site-",
  allowedSitePartitions = new Map(),
  siteAccountProxies = new Map(),
  tnPartitionPrefix = TN_STABLE_BASE.partitionPrefix,
  extensionLoadPromises = new Map(),
  tnStableExtensionLoadPromises = new Map(),
  tnBackgroundWindows = new Map(),
  tnVisibleAccounts = new Set(),
  tnRuntimeStates = new Map(),
  tnAccountProxies = new Map(),
  tnSessionConfigPromises = new Map(),
  tnAdBlockInstalled = new Set(),
  tnGuestAccounts = new Map();
let tnCountPublishTimer = null,
  managedTranslationProxy = null,
  messagingChannel = null,
  messagingReconnectTimer = null,
  proxyRefreshPromise = null,
  assignedProxyHealthTimer = null,
  poolHealthTimer = null,
  poolHealthScanRunning = !1,
  translationProxyObserversInstalled = !1,
  lastProxyFailureAt = 0,
  lastProxySuccessReportAt = 0;
const managedHttpFailureWindows = new Map(),
  managedTargetCooldowns = new Map(),
  proxyTestCredentials = new Map();
let allowedSites = new Map([
  ["opensms", "https://www.opensms.xin/#/index/cha"],
  ["skt1", "https://skt1.net/"],
  ["xhsim", "https://client.xhsim.ai/"],
  ["xinghan", "https://xinghansms.net/"],
  ["c2c", "https://c2csms.com/"],
]);
const BUILTIN_ACCOUNT_SITES = new Map([
  ["whatsapp", "https://web.whatsapp.com/"],
  ["telegram", "https://web.telegram.org/"],
  ["gmail", "https://mail.google.com/"],
]);
function siteUrlFor(n) {
  const e = String(n || "").toLowerCase();
  return (
    allowedSites.get(e) ||
    (currentProfile?.role === "admin" ? BUILTIN_ACCOUNT_SITES.get(e) : "") ||
    ""
  );
}
function fixedRouteHostsForSite(n) {
  const e = String(n || "").toLowerCase();
  return /(^|\.)(chatgpt\.com|openai\.com)$/.test(e)
    ? [
        "chatgpt.com",
        "openai.com",
        "auth.openai.com",
        "oaistatic.com",
        "oaiusercontent.com",
      ]
    : e
      ? [e]
      : [];
}
let proxiedSiteIds = new Set(),
  proxiedSiteHosts = new Set(),
  siteProxyConfigs = new Map(),
  siteAdapters = {};
const fixedSiteProxies = new Map(),
  hasSingleInstanceLock = app.requestSingleInstanceLock();
(hasSingleInstanceLock
  ? app.on("second-instance", () => {
      showMainWindow();
    })
  : app.quit(),
  (autoUpdater.autoDownload = !1),
  (autoUpdater.autoInstallOnAppQuit = !0),
  (autoUpdater.allowPrerelease = !1));
let updatePromptedVersion = "",
  updatePromptedAt = 0,
  downloadedPromptedVersion = "";
function readableReleaseNotes(n = {}) {
  const e = n.releaseNotes;
  return (
    Array.isArray(e)
      ? e.map((t) => (typeof t == "string" ? t : t?.note)).filter(Boolean)
          .join(`
`)
      : String(e || "")
  )
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 1800);
}
function sendUpdateState(n = {}) {
  return (
    (updateState = { ...updateState, ...n, currentVersion: app.getVersion() }),
    mainWindow &&
      !mainWindow.isDestroyed() &&
      mainWindow.webContents.send("update:state", updateState),
    updateState
  );
}
function friendlyUpdateError(n, e = "\u66F4\u65B0\u68C0\u67E5\u5931\u8D25") {
  const t = String(n?.message || n || "")
    .replace(/\s+/g, " ")
    .trim();
  return /app-update\.yml/i.test(t) &&
    /(?:ENOENT|no such file|cannot find|not found)/i.test(t)
    ? `${e}\uFF1A\u5F53\u524D\u5B89\u88C5\u5305\u7F3A\u5C11\u66F4\u65B0\u914D\u7F6E\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u91CD\u65B0\u53D1\u5E03\u5B8C\u6574\u5B89\u88C5\u5305\uFF1B\u8D26\u53F7\u8BBE\u7F6E\u4E0D\u4F1A\u4E22\u5931`
    : /latest\.yml/i.test(t) && /(?:404|cannot find|not found)/i.test(t)
      ? `${e}\uFF1A\u6700\u65B0\u7248\u5B89\u88C5\u6587\u4EF6\u5C1A\u672A\u53D1\u5E03\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5B8C\u6210\u53D1\u5E03`
      : /(?:401|403|authentication token|permission denied)/i.test(t)
        ? `${e}\uFF1A\u66F4\u65B0\u670D\u52A1\u5668\u62D2\u7EDD\u8BBF\u95EE\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u68C0\u67E5\u53D1\u5E03\u6743\u9650`
        : /(?:ENOTFOUND|ECONNREFUSED|ETIMEDOUT|network|socket|internet)/i.test(
              t,
            )
          ? `${e}\uFF1A\u6682\u65F6\u65E0\u6CD5\u8FDE\u63A5\u66F4\u65B0\u670D\u52A1\u5668\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5`
          : `${e}\uFF1A${t.slice(0, 180) || "\u672A\u77E5\u9519\u8BEF"}`;
}
(autoUpdater.on("checking-for-update", () =>
  sendUpdateState({
    status: "checking",
    message: "\u6B63\u5728\u68C0\u67E5\u66F4\u65B0\u2026",
    percent: 0,
  }),
),
  autoUpdater.on("update-available", (n) => {
    const e = readableReleaseNotes(n);
    sendUpdateState({
      status: "available",
      availableVersion: n.version,
      releaseNotes: e,
      message: `\u53D1\u73B0\u65B0\u7248\u672C ${n.version}\uFF0C\u8BF7\u9009\u62E9\u662F\u5426\u7ACB\u5373\u66F4\u65B0`,
    });
    const t = Date.now();
    (updatePromptedVersion === n.version &&
      t - updatePromptedAt < 360 * 60 * 1e3) ||
      ((updatePromptedVersion = n.version),
      (updatePromptedAt = t),
      !(!mainWindow || mainWindow.isDestroyed()) &&
        dialog
          .showMessageBox(mainWindow, {
            type: "info",
            title: "\u6A58\u5B50AI\u52A9\u624B\u53D1\u73B0\u65B0\u7248\u672C",
            message: `\u53D1\u73B0\u65B0\u7248\u672C ${n.version}`,
            detail: e
              ? `\u672C\u6B21\u66F4\u65B0\uFF1A
${e}`
              : "\u5EFA\u8BAE\u66F4\u65B0\u5230\u6700\u65B0\u7248\u672C\uFF0C\u4EE5\u83B7\u5F97\u6700\u65B0\u529F\u80FD\u548C\u7A33\u5B9A\u6027\u4FEE\u590D\u3002",
            buttons: [
              "\u7ACB\u5373\u4E0B\u8F7D\u66F4\u65B0",
              "\u7A0D\u540E\u63D0\u9192",
            ],
            defaultId: 0,
            cancelId: 1,
            noLink: !0,
          })
          .then((r) => {
            r.response === 0 &&
              (sendUpdateState({
                status: "downloading",
                message: `\u6B63\u5728\u4E0B\u8F7D\u7248\u672C ${n.version}\u2026`,
              }),
              autoUpdater
                .downloadUpdate()
                .catch((u) =>
                  sendUpdateState({
                    status: "error",
                    message: friendlyUpdateError(
                      u,
                      "\u4E0B\u8F7D\u66F4\u65B0\u5931\u8D25",
                    ),
                  }),
                ));
          })
          .catch(() => {}));
  }),
  autoUpdater.on("update-not-available", () =>
    sendUpdateState({
      status: "latest",
      availableVersion: "",
      message: "\u5F53\u524D\u5DF2\u662F\u6700\u65B0\u7248\u672C",
    }),
  ),
  autoUpdater.on("download-progress", (n) =>
    sendUpdateState({
      status: "downloading",
      percent: Math.round(n.percent || 0),
      message: `\u6B63\u5728\u4E0B\u8F7D ${Math.round(n.percent || 0)}%`,
    }),
  ),
  autoUpdater.on("update-downloaded", (n) => {
    (sendUpdateState({
      status: "downloaded",
      availableVersion: n.version,
      percent: 100,
      message:
        "\u66F4\u65B0\u5DF2\u4E0B\u8F7D\uFF1B\u53EF\u7ACB\u5373\u91CD\u542F\uFF0C\u6216\u9000\u51FA\u8F6F\u4EF6\u65F6\u81EA\u52A8\u5B89\u88C5",
    }),
      downloadedPromptedVersion !== n.version &&
        ((downloadedPromptedVersion = n.version),
        !(!mainWindow || mainWindow.isDestroyed()) &&
          dialog
            .showMessageBox(mainWindow, {
              type: "info",
              title: "\u6A58\u5B50AI\u52A9\u624B\u66F4\u65B0\u5B8C\u6210",
              message: `\u65B0\u7248\u672C ${n.version} \u5DF2\u5728\u540E\u53F0\u4E0B\u8F7D\u5B8C\u6210`,
              detail:
                "\u73B0\u5728\u91CD\u542F\u5373\u53EF\u5B8C\u6210\u66F4\u65B0\uFF1B\u9009\u62E9\u7A0D\u540E\u65F6\uFF0C\u9000\u51FA\u8F6F\u4EF6\u4E5F\u4F1A\u81EA\u52A8\u5B89\u88C5\u3002",
              buttons: ["\u7ACB\u5373\u91CD\u542F\u66F4\u65B0", "\u7A0D\u540E"],
              defaultId: 0,
              cancelId: 1,
              noLink: !0,
            })
            .then((e) => {
              e.response === 0 &&
                ((isQuitting = !0), autoUpdater.quitAndInstall(!1, !0));
            })
            .catch(() => {})));
  }),
  autoUpdater.on("error", (n) =>
    sendUpdateState({ status: "error", message: friendlyUpdateError(n) }),
  ),
  ipcMain.handle("update:get-state", () => updateState),
  ipcMain.handle("update:check", async () => {
    if (!app.isPackaged)
      return sendUpdateState({
        status: "development",
        message: "\u5F00\u53D1\u73AF\u5883\u4E0D\u68C0\u67E5\u66F4\u65B0",
      });
    try {
      return (await autoUpdater.checkForUpdates(), updateState);
    } catch (n) {
      return sendUpdateState({
        status: "error",
        message: friendlyUpdateError(n),
      });
    }
  }),
  ipcMain.handle("update:download", async () => {
    try {
      return (
        sendUpdateState({
          status: "downloading",
          message: `\u6B63\u5728\u4E0B\u8F7D\u7248\u672C ${updateState.availableVersion || "\u6700\u65B0\u7248\u672C"}\u2026`,
        }),
        await autoUpdater.downloadUpdate(),
        updateState
      );
    } catch (n) {
      return sendUpdateState({
        status: "error",
        message: friendlyUpdateError(n, "\u4E0B\u8F7D\u66F4\u65B0\u5931\u8D25"),
      });
    }
  }),
  ipcMain.handle(
    "update:install",
    () => (
      updateState.status !== "downloaded" ||
        ((isQuitting = !0),
        setImmediate(() => autoUpdater.quitAndInstall(!1, !0))),
      updateState
    ),
  ));
function publishMessagingChanged(n = {}) {
  mainWindow &&
    !mainWindow.isDestroyed() &&
    mainWindow.webContents.send("messaging:changed", n);
}
async function stopMessagingRealtime() {
  if (
    (messagingReconnectTimer && clearTimeout(messagingReconnectTimer),
    (messagingReconnectTimer = null),
    !messagingChannel)
  )
    return;
  const n = messagingChannel;
  ((messagingChannel = null), await supabase.removeChannel(n).catch(() => {}));
}
async function startMessagingRealtime() {
  if ((await stopMessagingRealtime(), !currentSession || !currentProfile))
    return;
  supabase.realtime.setAuth(currentSession.access_token);
  const n = currentProfile.id,
    e = supabase
      .channel(`orange-messaging-${n}-${Date.now()}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "internal_messages" },
        (t) => {
          publishMessagingChanged({ type: "message", eventType: t.eventType });
          const r = t.new || {};
          if (
            t.eventType !== "INSERT" ||
            r.recipient_id !== n ||
            !Notification.isSupported()
          )
            return;
          const u =
              r.message_type === "image"
                ? "\u6536\u5230\u4E00\u5F20\u56FE\u7247"
                : r.message_type === "file"
                  ? `\u6536\u5230\u6587\u4EF6\uFF1A${r.attachment_name || "\u9644\u4EF6"}`
                  : String(
                      r.body ||
                        "\u6536\u5230\u4E00\u6761\u7AD9\u5185\u6D88\u606F",
                    ).slice(0, 160),
            o = new Notification({
              title:
                "\u6A58\u5B50\u6D88\u606F\u4E2D\u5FC3 \xB7 \u65B0\u6D88\u606F",
              body: u,
            });
          (o.on("click", () => {
            (showMainWindow(),
              mainWindow?.webContents.send("main:show-messages", {
                peerId: r.sender_id,
              }));
          }),
            o.show());
        },
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "app_announcements" },
        (t) => {
          publishMessagingChanged({
            type: "announcement",
            eventType: t.eventType,
          });
        },
      )
      .subscribe((t) => {
        e === messagingChannel &&
          ["CHANNEL_ERROR", "TIMED_OUT", "CLOSED"].includes(t) &&
          (messagingReconnectTimer && clearTimeout(messagingReconnectTimer),
          (messagingReconnectTimer = setTimeout(() => {
            currentSession && currentProfile && startMessagingRealtime();
          }, 1800)));
      });
  messagingChannel = e;
}
async function refreshMessagingSession() {
  const { data: n } = await supabase.auth.getSession();
  (n?.session && (currentSession = n.session),
    currentSession?.access_token &&
      supabase.realtime.setAuth(currentSession.access_token));
}
const MESSAGE_ATTACHMENT_BUCKET = "internal-message-attachments",
  MESSAGE_ATTACHMENT_MAX = 20 * 1024 * 1024,
  MESSAGE_ATTACHMENT_MIMES = new Set([
    "image/png",
    "image/jpeg",
    "image/webp",
    "image/gif",
    "application/pdf",
    "text/plain",
    "text/csv",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-powerpoint",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/zip",
    "application/x-zip-compressed",
    "application/x-7z-compressed",
    "application/vnd.rar",
    "application/x-rar-compressed",
    "application/octet-stream",
  ]),
  BLOCKED_ATTACHMENT_EXTENSIONS = new Set([
    "exe",
    "msi",
    "bat",
    "cmd",
    "com",
    "scr",
    "ps1",
    "vbs",
    "js",
    "jse",
    "jar",
    "reg",
    "lnk",
    "htm",
    "html",
    "svg",
  ]);
function safeAttachmentName(n) {
  const e =
      path
        .basename(String(n || "\u9644\u4EF6"))
        .replace(/[\u0000-\u001f<>:"/\\|?*]+/g, "_")
        .slice(0, 180) || "\u9644\u4EF6",
    t = path.extname(e).slice(1).toLowerCase();
  if (BLOCKED_ATTACHMENT_EXTENSIONS.has(t))
    throw new Error(
      "\u4E3A\u5B89\u5168\u8D77\u89C1\uFF0C\u7AD9\u5185\u6D88\u606F\u4E0D\u80FD\u53D1\u9001\u53EF\u6267\u884C\u7A0B\u5E8F\u6216\u811A\u672C\u6587\u4EF6",
    );
  return { name: e, extension: t };
}
function messageSelectFields() {
  return "id,sender_id,recipient_id,body,message_type,attachment_path,attachment_name,attachment_mime,attachment_size,created_at,read_at";
}
async function attachSignedMessageUrls(n) {
  const e = [...new Set(n.map((o) => o.attachment_path).filter(Boolean))];
  if (!e.length) return n;
  const { data: t, error: r } = await supabase.storage
    .from(MESSAGE_ATTACHMENT_BUCKET)
    .createSignedUrls(e, 3600);
  if (r) throw r;
  const u = new Map(
    (t || [])
      .filter((o) => o?.path && o?.signedUrl)
      .map((o) => [o.path, o.signedUrl]),
  );
  return n.map((o) =>
    o.attachment_path
      ? { ...o, attachment_url: u.get(o.attachment_path) || "" }
      : o,
  );
}
(ipcMain.handle("messaging:snapshot", async () => {
  try {
    if (!featureEnabled("module_messaging"))
      return featureDisabledResult("module_messaging");
    if (!currentSession || !currentProfile)
      throw new Error("\u8BF7\u5148\u767B\u5F55");
    await refreshMessagingSession();
    let n = supabase
      .from("app_announcement_reads")
      .select("announcement_id,user_id,read_at");
    currentProfile.role !== "admin" && (n = n.eq("user_id", currentProfile.id));
    const [e, t, r, u] = await Promise.all([
        supabase.rpc("list_internal_contacts"),
        supabase
          .from("internal_messages")
          .select(messageSelectFields())
          .order("created_at", { ascending: !0 })
          .limit(1500),
        supabase
          .from("app_announcements")
          .select(
            "id,title,body,target_user_id,pinned,published_at,expires_at,created_by",
          )
          .order("pinned", { ascending: !1 })
          .order("published_at", { ascending: !1 })
          .limit(200),
        n,
      ]),
      o = e.error || t.error || r.error || u.error;
    if (o) throw o;
    return {
      ok: !0,
      currentUser: {
        id: currentProfile.id,
        username: currentProfile.username,
        displayName: currentProfile.display_name || currentProfile.username,
        role: currentProfile.role,
      },
      contacts: e.data || [],
      messages: await attachSignedMessageUrls(t.data || []),
      announcements: featureEnabled("messaging_announcements")
        ? r.data || []
        : [],
      reads: u.data || [],
    };
  } catch (n) {
    return {
      ok: !1,
      message: errorText(n, "\u6D88\u606F\u4E2D\u5FC3\u8BFB\u53D6\u5931\u8D25"),
    };
  }
}),
  ipcMain.handle("messaging:send", async (n, e) => {
    try {
      if (!featureEnabled("messaging_text"))
        return featureDisabledResult("messaging_text");
      if (!currentSession || !currentProfile)
        throw new Error("\u8BF7\u5148\u767B\u5F55");
      await refreshMessagingSession();
      const t = String(e?.recipientId || ""),
        r = String(e?.body || "").trim();
      if (!t || t === currentProfile.id)
        throw new Error("\u8BF7\u9009\u62E9\u5BF9\u8BDD\u5458\u5DE5");
      if (!r) throw new Error("\u8BF7\u8F93\u5165\u6D88\u606F\u5185\u5BB9");
      if (r.length > 4e3)
        throw new Error(
          "\u5355\u6761\u6D88\u606F\u4E0D\u80FD\u8D85\u8FC74000\u5B57",
        );
      const { data: u, error: o } = await supabase
        .from("internal_messages")
        .insert({
          sender_id: currentProfile.id,
          recipient_id: t,
          body: r,
          message_type: "text",
        })
        .select(messageSelectFields())
        .single();
      if (o) throw o;
      return { ok: !0, message: u };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u6D88\u606F\u53D1\u9001\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("messaging:send-attachment", async (n, e) => {
    let t = "";
    try {
      if (!featureEnabled("messaging_attachments"))
        return featureDisabledResult("messaging_attachments");
      if (!currentSession || !currentProfile)
        throw new Error("\u8BF7\u5148\u767B\u5F55");
      await refreshMessagingSession();
      const r = String(e?.recipientId || ""),
        u = String(e?.body || "")
          .trim()
          .slice(0, 4e3);
      if (!r || r === currentProfile.id)
        throw new Error("\u8BF7\u9009\u62E9\u5BF9\u8BDD\u5458\u5DE5");
      const { name: o, extension: a } = safeAttachmentName(e?.name),
        s = Buffer.from(e?.bytes || []);
      if (!s.length) throw new Error("\u6587\u4EF6\u5185\u5BB9\u4E3A\u7A7A");
      if (s.length > MESSAGE_ATTACHMENT_MAX)
        throw new Error("\u5355\u4E2A\u6587\u4EF6\u4E0D\u80FD\u8D85\u8FC720MB");
      const i = String(e?.mime || "application/octet-stream").toLowerCase();
      if (!MESSAGE_ATTACHMENT_MIMES.has(i))
        throw new Error(
          "\u6682\u4E0D\u652F\u6301\u8FD9\u79CD\u6587\u4EF6\u683C\u5F0F",
        );
      const c = i.startsWith("image/"),
        l = a ? `.${a}` : "";
      t = `${currentProfile.id}/${r}/${crypto.randomUUID()}${l}`;
      const d = await supabase.storage
        .from(MESSAGE_ATTACHMENT_BUCKET)
        .upload(t, s, { contentType: i, upsert: !1 });
      if (d.error) throw d.error;
      const m = {
          sender_id: currentProfile.id,
          recipient_id: r,
          body: u,
          message_type: c ? "image" : "file",
          attachment_path: t,
          attachment_name: o,
          attachment_mime: i,
          attachment_size: s.length,
        },
        p = await supabase
          .from("internal_messages")
          .insert(m)
          .select(messageSelectFields())
          .single();
      if (p.error) throw p.error;
      const [h] = await attachSignedMessageUrls([p.data]);
      return { ok: !0, message: h };
    } catch (r) {
      return (
        t &&
          (await supabase.storage
            .from(MESSAGE_ATTACHMENT_BUCKET)
            .remove([t])
            .catch(() => {})),
        {
          ok: !1,
          message: errorText(r, "\u9644\u4EF6\u53D1\u9001\u5931\u8D25"),
        }
      );
    }
  }),
  ipcMain.handle("messaging:open-attachment", async (n, e) => {
    try {
      if (!featureEnabled("messaging_attachments"))
        return featureDisabledResult("messaging_attachments");
      const t = new URL(String(e || "")),
        r = new URL(config.supabaseUrl).hostname;
      if (
        t.protocol !== "https:" ||
        t.hostname !== r ||
        !t.pathname.includes(`/object/sign/${MESSAGE_ATTACHMENT_BUCKET}/`)
      )
        throw new Error(
          "\u9644\u4EF6\u5730\u5740\u65E0\u6548\u6216\u5DF2\u8FC7\u671F",
        );
      return (await shell.openExternal(t.toString()), { ok: !0 });
    } catch (t) {
      return {
        ok: !1,
        message: t?.message || "\u65E0\u6CD5\u6253\u5F00\u9644\u4EF6",
      };
    }
  }),
  ipcMain.handle("messaging:mark-read", async (n, e) => {
    try {
      const { data: t, error: r } = await supabase.rpc(
        "mark_internal_conversation_read",
        { peer_id: String(e || "") },
      );
      if (r) throw r;
      return { ok: !0, changed: Number(t || 0) };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(
          t,
          "\u5DF2\u8BFB\u72B6\u6001\u66F4\u65B0\u5931\u8D25",
        ),
      };
    }
  }),
  ipcMain.handle("messaging:clear-conversation", async (n, e) => {
    try {
      const { data: t, error: r } = await supabase.rpc(
        "clear_internal_conversation",
        { peer_id: String(e || "") },
      );
      if (r) throw r;
      return { ok: !0, changed: Number(t || 0) };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u6E05\u7A7A\u5BF9\u8BDD\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("messaging:clear-all", async () => {
    try {
      const { data: n, error: e } = await supabase.rpc(
        "clear_all_internal_messages",
      );
      if (e) throw e;
      return { ok: !0, changed: Number(n || 0) };
    } catch (n) {
      return {
        ok: !1,
        message: errorText(n, "\u6E05\u7A7A\u6D88\u606F\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("messaging:announcement-read", async (n, e) => {
    try {
      if (!currentProfile) throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = {
          announcement_id: String(e || ""),
          user_id: currentProfile.id,
        },
        r = await supabase
          .from("app_announcement_reads")
          .select("announcement_id")
          .match(t)
          .maybeSingle();
      if (r.error) throw r.error;
      if (!r.data) {
        const u = await supabase.from("app_announcement_reads").insert(t);
        if (u.error) throw u.error;
      }
      return { ok: !0 };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(
          t,
          "\u516C\u544A\u5DF2\u8BFB\u72B6\u6001\u66F4\u65B0\u5931\u8D25",
        ),
      };
    }
  }),
  ipcMain.handle("messaging:announcement-create", async (n, e) => {
    try {
      if (!featureEnabled("messaging_announcements"))
        return featureDisabledResult("messaging_announcements");
      if (currentProfile?.role !== "admin")
        throw new Error(
          "\u4EC5\u7BA1\u7406\u5458\u53EF\u4EE5\u53D1\u5E03\u516C\u544A",
        );
      const t = String(e?.title || "").trim(),
        r = String(e?.body || "").trim();
      if (!t || !r)
        throw new Error(
          "\u8BF7\u586B\u5199\u516C\u544A\u6807\u9898\u548C\u5185\u5BB9",
        );
      const u = {
          title: t,
          body: r,
          created_by: currentProfile.id,
          target_user_id: e?.targetUserId ? String(e.targetUserId) : null,
          pinned: e?.pinned === !0,
          expires_at: e?.expiresAt ? new Date(e.expiresAt).toISOString() : null,
        },
        { data: o, error: a } = await supabase
          .from("app_announcements")
          .insert(u)
          .select()
          .single();
      if (a) throw a;
      return { ok: !0, announcement: o };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u516C\u544A\u53D1\u5E03\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("messaging:announcement-update", async (n, e) => {
    try {
      if (!featureEnabled("messaging_announcements"))
        return featureDisabledResult("messaging_announcements");
      if (currentProfile?.role !== "admin")
        throw new Error(
          "\u4EC5\u7BA1\u7406\u5458\u53EF\u4EE5\u7F16\u8F91\u516C\u544A",
        );
      const t = String(e?.announcementId || ""),
        r = String(e?.title || "").trim(),
        u = String(e?.body || "").trim();
      if (!t)
        throw new Error(
          "\u516C\u544A\u4E0D\u5B58\u5728\u6216\u5DF2\u88AB\u5220\u9664",
        );
      if (!r || !u)
        throw new Error(
          "\u8BF7\u586B\u5199\u516C\u544A\u6807\u9898\u548C\u5185\u5BB9",
        );
      const o = {
          title: r,
          body: u,
          target_user_id: e?.targetUserId ? String(e.targetUserId) : null,
          pinned: e?.pinned === !0,
          expires_at: e?.expiresAt ? new Date(e.expiresAt).toISOString() : null,
        },
        { data: a, error: s } = await supabase
          .from("app_announcements")
          .update(o)
          .eq("id", t)
          .select()
          .single();
      if (s) throw s;
      return { ok: !0, announcement: a };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u516C\u544A\u7F16\u8F91\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("messaging:announcement-delete", async (n, e) => {
    try {
      if (!featureEnabled("messaging_announcements"))
        return featureDisabledResult("messaging_announcements");
      if (currentProfile?.role !== "admin")
        throw new Error(
          "\u4EC5\u7BA1\u7406\u5458\u53EF\u4EE5\u5220\u9664\u516C\u544A",
        );
      const { error: t } = await supabase
        .from("app_announcements")
        .delete()
        .eq("id", String(e || ""));
      if (t) throw t;
      return { ok: !0 };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u516C\u544A\u5220\u9664\u5931\u8D25"),
      };
    }
  }));
const MANAGED_SITE_PERMISSION_CODES = Object.freeze({
  whatsapp: "platform_whatsapp",
  telegram: "platform_telegram",
  gmail: "platform_gmail",
});
function managedSiteAllowedByPermission(n) {
  if (currentProfile?.role === "admin") return !0;
  const e = MANAGED_SITE_PERMISSION_CODES[String(n || "").toLowerCase()];
  return !e || currentPermissions?.[e] === !0;
}
async function loadWorkSites() {
  let { data: n, error: e } = await supabase
    .from("work_sites")
    .select(
      "id,site_key,display_name,url,icon_url,host_label,sort_order,minimum_plan,proxy_required,proxy_mode,fixed_proxy_id,chat_container_selector,message_selector,input_selector,phone_selector",
    )
    .eq("enabled", !0)
    .order("sort_order", { ascending: !0 });
  if (e) {
    const t = await supabase
      .from("work_sites")
      .select(
        "id,site_key,display_name,url,icon_url,host_label,sort_order,minimum_plan,proxy_required,proxy_mode,fixed_proxy_id",
      )
      .eq("enabled", !0)
      .order("sort_order", { ascending: !0 });
    ((n = t.data), (e = t.error));
  }
  if (!e && Array.isArray(n) && n.length) {
    let t = n.filter(
      (o) =>
        currentProfile?.role === "admin" ||
        o.minimum_plan !== "advanced" ||
        currentProfile?.plan === "advanced",
    );
    if (currentProfile?.role !== "admin" && currentProfile?.id) {
      const o = await supabase
        .from("user_site_access")
        .select("site_id,allowed")
        .eq("user_id", currentProfile.id);
      if (!o.error && Array.isArray(o.data) && o.data.length) {
        const a = new Map(
          o.data.map((s) => [String(s.site_id), s.allowed === !0]),
        );
        t = t.filter((s) => {
          const i =
              MANAGED_SITE_PERMISSION_CODES[
                String(s.site_key || "").toLowerCase()
              ],
            c = a.get(String(s.id));
          return i
            ? typeof c == "boolean"
              ? c
              : managedSiteAllowedByPermission(s.site_key)
            : c === !0;
        });
      } else
        o.error
          ? o.error &&
            String(o.error.code || "") !== "42P01" &&
            (console.warn(
              "Unable to read per-user site access; hiding employee sites",
              o.error.message || o.error,
            ),
            (t = []))
          : (t = t.filter((a) => managedSiteAllowedByPermission(a.site_key)));
    }
    ((allowedSites = new Map(t.map((o) => [o.site_key, o.url]))),
      (siteProxyConfigs = new Map(
        t.map((o) => [
          o.site_key,
          {
            mode: String(
              o.proxy_mode || (o.proxy_required ? "automatic" : "direct"),
            ),
            fixedProxyId: String(o.fixed_proxy_id || ""),
            host: new URL(o.url).hostname.toLowerCase(),
          },
        ]),
      )),
      (siteAdapters = Object.fromEntries(
        t.map((o) => [
          new URL(o.url).hostname.toLowerCase(),
          {
            chatContainerSelector: String(o.chat_container_selector || ""),
            messageSelector: String(o.message_selector || ""),
            inputSelector: String(o.input_selector || ""),
            phoneSelector: String(o.phone_selector || ""),
          },
        ]),
      )));
    const r = new Set(
      [...siteProxyConfigs.values()]
        .filter((o) => o.mode === "fixed")
        .flatMap((o) => fixedRouteHostsForSite(o.host)),
    );
    for (const o of [...fixedSiteProxies.keys()])
      r.has(o) || fixedSiteProxies.delete(o);
    const u = (o) =>
      String(o.proxy_mode || (o.proxy_required ? "automatic" : "direct")) ===
      "automatic";
    return (
      (proxiedSiteIds = new Set(t.filter(u).map((o) => o.site_key))),
      (proxiedSiteHosts = new Set(
        t.filter(u).map((o) => new URL(o.url).hostname.toLowerCase()),
      )),
      t.map((o) => ({
        id: o.site_key,
        name: o.display_name,
        host: o.host_label || new URL(o.url).hostname,
        iconUrl: o.icon_url || "",
        proxyRequired: u(o),
        proxyMode: siteProxyConfigs.get(o.site_key)?.mode || "direct",
      }))
    );
  }
  return (
    (proxiedSiteIds = new Set()),
    (proxiedSiteHosts = new Set()),
    Array.from(allowedSites.entries()).map(([t, r]) => ({
      id: t,
      name:
        {
          opensms: "OpenSMS",
          skt1: "SKT1",
          xhsim: "\u661F\u6CB3",
          xinghan: "\u661F\u701A",
          c2c: "C2C",
        }[t] || t,
      host: new URL(r).hostname,
    }))
  );
}
function getExtensionPath() {
  return app.isPackaged
    ? path.join(process.resourcesPath, "extension-source")
    : path.join(__dirname, "extension-source");
}
function getTnStableExtensionPath() {
  return app.isPackaged
    ? path.join(process.resourcesPath, "tn-beta-extension-source")
    : path.join(__dirname, "tn-beta-extension-source");
}
async function ensureWorkExtensionLoaded(n) {
  const e = String(n.getStoragePath?.() || workPartition);
  if (!extensionLoadPromises.has(e)) {
    const t = n
      .loadExtension(getExtensionPath(), { allowFileAccess: !0 })
      .catch((r) => {
        throw (extensionLoadPromises.delete(e), r);
      });
    extensionLoadPromises.set(e, t);
  }
  return extensionLoadPromises.get(e);
}
async function prepareWorkExtensionWithoutBlockingPage(n) {
  try {
    const e = await ensureWorkExtensionLoaded(n);
    return (await syncExtensionAuth(n, e), { loaded: !0, extension: e });
  } catch (e) {
    return (
      console.error(
        "AI extension initialization failed; continuing with website load",
        e?.message || e,
      ),
      { loaded: !1, error: e?.message || String(e) }
    );
  }
}
async function ensureTnStableExtensionLoaded(n) {
  const e = String(n.getStoragePath?.() || "tn-beta");
  if (!tnStableExtensionLoadPromises.has(e)) {
    const t = n
      .loadExtension(getTnStableExtensionPath(), { allowFileAccess: !0 })
      .catch((r) => {
        throw (tnStableExtensionLoadPromises.delete(e), r);
      });
    tnStableExtensionLoadPromises.set(e, t);
  }
  return tnStableExtensionLoadPromises.get(e);
}
async function syncExtensionAuth(n, e) {
  if (!currentSession?.access_token || !e?.id) return;
  const t = new BrowserWindow({
    show: !1,
    webPreferences: { session: n, contextIsolation: !1, nodeIntegration: !1 },
  });
  try {
    await t.loadURL(`chrome-extension://${e.id}/popup.html`);
    const r = {
      orangeSupabaseUrl: config.supabaseUrl,
      orangeSupabasePublishableKey: config.supabasePublishableKey,
      orangeSupabaseAccessToken: currentSession.access_token,
      orangePermissions: effectiveExtensionPermissions(),
      orangeFeatureFlags: currentFeatureFlags,
      orangeIsAdmin: currentProfile?.role === "admin",
      orangeAllowedHosts: Array.from(allowedSites.values())
        .map((u) => {
          try {
            return new URL(u).hostname;
          } catch {
            return "";
          }
        })
        .filter(Boolean),
      orangeSiteAdapters: siteAdapters,
      ...tnSharedAppearanceStorageValues(),
    };
    await t.webContents.executeJavaScript(
      `chrome.storage.local.set(${JSON.stringify(r)})`,
    );
  } finally {
    t.isDestroyed() || t.destroy();
  }
}
function effectiveExtensionPermissions() {
  const n = { ...currentPermissions };
  for (const [e, t] of Object.entries(currentFeatureFlags)) t || (n[e] = !1);
  for (const [e, t] of Object.entries(FEATURE_FLAG_PARENTS))
    (!featureEnabled(e) || !featureEnabled(t)) && (n[e] = !1);
  return (
    (!featureEnabled("module_tn") || !featureEnabled("tn_accounts")) &&
      (n.tn_assistant = !1),
    n
  );
}
async function syncFeatureFlagsToLoadedExtensions() {
  if (!currentSession) return;
  const n = [
    { value: session.fromPartition(workPartition), tn: !1 },
    ...[...allowedSitePartitions.keys()].map((e) => ({
      value: session.fromPartition(e),
      tn: !1,
    })),
    ...listTnAccounts().map((e) => ({
      value: session.fromPartition(tnPartition(e.id)),
      tn: !0,
    })),
  ];
  await Promise.allSettled(
    n.map(async (e) => {
      const t = e.value,
        r = e.tn
          ? await ensureTnStableExtensionLoaded(t)
          : await ensureWorkExtensionLoaded(t);
      await syncExtensionAuth(t, r);
    }),
  );
}
function secureSettingsPath() {
  return path.join(app.getPath("userData"), "secure-settings.json");
}
function readSecureSettings() {
  try {
    return JSON.parse(fs.readFileSync(secureSettingsPath(), "utf8"));
  } catch {
    return { login: {}, sites: {}, proxy: {} };
  }
}
function writeSecureSettings(n) {
  (fs.mkdirSync(path.dirname(secureSettingsPath()), { recursive: !0 }),
    fs.writeFileSync(secureSettingsPath(), JSON.stringify(n), {
      encoding: "utf8",
      mode: 384,
    }));
}
function tnSharedAppearanceStorageValues() {
  const n = currentTnOwnerKey();
  if (!n) return {};
  const e = readSecureSettings()?.tnAppearanceByUser?.[n];
  if (!e || typeof e != "object") return {};
  const t = "www.textnow.com",
    r = {};
  return (
    e.background &&
      typeof e.background == "object" &&
      (r[`aiBtCustomBackground:${t}`] = e.background),
    typeof e.translationColor == "string" &&
      (r[`aiBtTranslationColor:${t}`] = e.translationColor),
    typeof e.bubbleLightColor == "string" &&
      (r[`aiBtBubbleLightColor:${t}`] = e.bubbleLightColor),
    Number.isFinite(Number(e.bubbleLightWidth)) &&
      (r[`aiBtBubbleLightWidth:${t}`] = Number(e.bubbleLightWidth)),
    typeof e.bubbleLightEnabled == "boolean" &&
      (r[`aiBtBubbleLightEnabled:${t}`] = e.bubbleLightEnabled),
    r
  );
}
function normalizeTnAppearanceChange(n) {
  const e = String(n?.kind || ""),
    t = n?.value;
  if (e === "translationColor" || e === "bubbleLightColor") {
    const r = String(t || "").toLowerCase();
    if (r && !/^#[0-9a-f]{6}$/.test(r))
      throw new Error("\u989C\u8272\u683C\u5F0F\u65E0\u6548");
    return { kind: e, value: r };
  }
  if (e === "bubbleLightWidth")
    return { kind: e, value: Math.max(4, Math.min(10, Number(t) || 7)) };
  if (e === "bubbleLightEnabled") return { kind: e, value: t !== !1 };
  if (e === "background") {
    if (!t || typeof t != "object" || Array.isArray(t))
      throw new Error("\u80CC\u666F\u8BBE\u7F6E\u65E0\u6548");
    const r = String(t.imageDataUrl || "");
    if (
      r &&
      (!/^data:image\/[a-z0-9.+-]+;base64,/i.test(r) ||
        r.length > 16 * 1024 * 1024)
    )
      throw new Error(
        "\u80CC\u666F\u56FE\u7247\u683C\u5F0F\u6216\u5927\u5C0F\u65E0\u6548",
      );
    return {
      kind: e,
      value: {
        schemaVersion: Number(t.schemaVersion || 3),
        enabled: !!t.enabled,
        imageDataUrl: r,
        imageOpacity: Math.max(0.15, Math.min(1, Number(t.imageOpacity) || 1)),
        panelOpacity: Math.max(
          0.06,
          Math.min(0.72, Number(t.panelOpacity) || 0.22),
        ),
        groupPanelOpacity: Math.max(
          0.35,
          Math.min(0.98, Number(t.groupPanelOpacity) || 0.9),
        ),
        blur: Math.max(0, Math.min(12, Number(t.blur) || 0)),
        brightness: Math.max(55, Math.min(145, Number(t.brightness) || 100)),
        glassBlur: Math.max(0, Math.min(10, Number(t.glassBlur) || 4)),
      },
    };
  }
  throw new Error("\u4E0D\u652F\u6301\u7684TN\u5916\u89C2\u8BBE\u7F6E");
}
async function broadcastTnAppearance() {
  for (const n of listTnAccounts())
    try {
      const e = session.fromPartition(tnPartition(n.id)),
        t = await ensureTnStableExtensionLoaded(e);
      await syncExtensionAuth(e, t);
    } catch (e) {
      console.warn("Unable to sync TN appearance", n.id, e?.message || e);
    }
}
function tnAccountsPath() {
  return path.join(app.getPath("userData"), "tn-accounts.json");
}
function beta6UserDataPath() {
  return path.join(app.getPath("appData"), "Orange AI Assistant Beta");
}
function beta6MigrationRequestPath() {
  return path.join(app.getPath("userData"), "tn-beta6-migration.json");
}
function beta6MigrationResultPath() {
  return path.join(app.getPath("userData"), "tn-beta6-migration-result.json");
}
function currentTnOwnerKey() {
  return String(currentProfile?.id || "");
}
function currentTnOwnerScope() {
  const n = currentTnOwnerKey();
  return n
    ? crypto.createHash("sha256").update(n).digest("hex").slice(0, 20)
    : "signed-out";
}
function readWholeTnStore() {
  try {
    const n = JSON.parse(fs.readFileSync(tnAccountsPath(), "utf8"));
    return n && typeof n == "object" ? n : { users: {} };
  } catch {
    return { users: {} };
  }
}
function readTnStore() {
  const n = currentTnOwnerKey();
  if (!n) return { accounts: [] };
  const e = readWholeTnStore();
  return {
    accounts: Array.isArray(e?.users?.[n]?.accounts) ? e.users[n].accounts : [],
  };
}
function writeJsonAtomic(n, e) {
  fs.mkdirSync(path.dirname(n), { recursive: !0 });
  const t = `${n}.tmp`;
  (fs.writeFileSync(t, JSON.stringify(e), { encoding: "utf8", mode: 384 }),
    fs.renameSync(t, n));
}
function normalizeTnAccount(n = {}) {
  const e = String(n.id || "").toLowerCase();
  return /^[a-f0-9-]{36}$/.test(e)
    ? {
        id: e,
        name:
          String(n.name || "TN\u8D26\u53F7")
            .trim()
            .slice(0, 60) || "TN\u8D26\u53F7",
        groupName:
          String(n.groupName || "\u9ED8\u8BA4\u5206\u7EC4")
            .trim()
            .slice(0, 60) || "\u9ED8\u8BA4\u5206\u7EC4",
        proxyGroupId: String(n.proxyGroupId || ""),
        proxyMode: n.proxyMode === "local" ? "local" : "managed",
        localProxyEncrypted: String(n.localProxyEncrypted || ""),
        localProxyKey: String(n.localProxyKey || ""),
        localProxyLimit: Math.max(
          1,
          Math.min(1e3, Number(n.localProxyLimit || 30)),
        ),
        partitionScope: n.partitionScope === "legacy" ? "legacy" : "scoped",
        keepAlive: n.keepAlive !== !1,
        createdAt: String(n.createdAt || new Date().toISOString()),
        updatedAt: String(n.updatedAt || new Date().toISOString()),
      }
    : null;
}
function listTnAccounts() {
  return readTnStore().accounts.map(normalizeTnAccount).filter(Boolean);
}
function saveTnAccounts(n) {
  const e = currentTnOwnerKey();
  if (!e) throw new Error("\u8BF7\u5148\u767B\u5F55");
  const t = readWholeTnStore();
  ((t.users = t.users && typeof t.users == "object" ? t.users : {}),
    (t.users[e] = {
      accounts: n.map(normalizeTnAccount).filter(Boolean),
      updatedAt: new Date().toISOString(),
    }),
    delete t.accounts,
    writeJsonAtomic(tnAccountsPath(), t),
    scheduleOwnTnAccountCount(n.length));
}
function scheduleOwnTnAccountCount(n) {
  clearTimeout(tnCountPublishTimer);
  const e = String(currentProfile?.id || "");
  if (!e || !currentSession) return;
  const t = Math.max(0, Math.min(1e3, Number(n) || 0));
  tnCountPublishTimer = setTimeout(async () => {
    if (!currentSession || currentProfile?.id !== e) return;
    const { error: r } = await supabase.rpc("set_my_tn_account_count", {
      new_count: t,
    });
    r && console.warn("Unable to publish TN account count", r.message || r);
  }, 350);
}
function tnRecipientFingerprint(n) {
  const e = normalizeTnPhone(n);
  return crypto
    .createHash("sha256")
    .update(`${currentProfile?.id || ""}:${e}`)
    .digest("hex");
}
function readTnSentFingerprints() {
  if (!currentProfile?.id) return [];
  const n = readSecureSettings().tnSentFingerprintsByUser?.[currentProfile.id];
  return Array.isArray(n)
    ? n
        .filter((e) => typeof e == "string" && /^[a-f0-9]{64}$/.test(e))
        .slice(-1e5)
    : [];
}
function hasTnSentFingerprint(n) {
  return readTnSentFingerprints().includes(String(n || ""));
}
function recordTnSentFingerprint(n) {
  if (!currentProfile?.id || !/^[a-f0-9]{64}$/.test(String(n || ""))) return;
  const e = readSecureSettings();
  e.tnSentFingerprintsByUser =
    e.tnSentFingerprintsByUser && typeof e.tnSentFingerprintsByUser == "object"
      ? e.tnSentFingerprintsByUser
      : {};
  const t = new Set(
    Array.isArray(e.tnSentFingerprintsByUser[currentProfile.id])
      ? e.tnSentFingerprintsByUser[currentProfile.id]
      : [],
  );
  (t.add(n),
    (e.tnSentFingerprintsByUser[currentProfile.id] = [...t].slice(-1e5)),
    writeSecureSettings(e));
}
function tnAccountById(n) {
  return listTnAccounts().find((e) => e.id === String(n || "")) || null;
}
function tnPartition(n) {
  const e = tnAccountById(n);
  if (!e) throw new Error("TN\u8D26\u53F7\u4E0D\u5B58\u5728");
  return partitionFor(e.id);
}
function processPendingBeta6Migration() {
  const n = beta6MigrationRequestPath();
  if (!fs.existsSync(n)) return;
  let e = {
    ok: !1,
    count: 0,
    message: "Beta.6 TN\u72B6\u6001\u5BFC\u5165\u5931\u8D25",
  };
  try {
    const t = JSON.parse(fs.readFileSync(n, "utf8")),
      r = Array.isArray(t?.items) ? t.items : [],
      u = path.resolve(beta6UserDataPath()),
      o = path.resolve(app.getPath("userData"));
    let a = 0;
    for (const i of r) {
      const c = String(i?.sourceId || "").toLowerCase(),
        l = String(i?.targetPartition || "");
      if (!/^[a-f0-9-]{36}$/.test(c) || !l.startsWith(tnPartitionPrefix))
        continue;
      const d = path.resolve(u, "Partitions", `orange-beta-tn-${c}`),
        m = path.resolve(o, "Partitions", l.replace(/^persist:/, ""));
      if (!(
        !d.startsWith(`${u}${path.sep}`) ||
        !m.startsWith(`${o}${path.sep}`) ||
        !fs.existsSync(d)
      )) {
        if (fs.existsSync(m)) {
          const p = `${m}.before-beta6-${Date.now()}`;
          fs.renameSync(m, p);
        }
        (fs.mkdirSync(path.dirname(m), { recursive: !0 }),
          fs.cpSync(d, m, { recursive: !0, force: !0, errorOnExist: !1 }),
          (a += 1));
      }
    }
    if (!a)
      throw new Error(
        "\u6CA1\u6709\u627E\u5230\u53EF\u590D\u5236\u7684Beta.6\u8D26\u53F7\u73AF\u5883\uFF1B\u8BF7\u786E\u8BA4Beta.6\u5DF2\u5173\u95ED\u4E14TN\u540D\u79F0\u76F8\u540C",
      );
    e = {
      ok: !0,
      count: a,
      message: `\u5DF2\u5BFC\u5165 ${a} \u4E2ABeta.6 TN\u8D26\u53F7\u72B6\u6001`,
    };
    const s = String(t?.ownerId || "");
    if (s) {
      const i = readSecureSettings();
      ((i.beta6FullProfileImportedByUser =
        i.beta6FullProfileImportedByUser &&
        typeof i.beta6FullProfileImportedByUser == "object"
          ? i.beta6FullProfileImportedByUser
          : {}),
        (i.beta6FullProfileImportedByUser[s] = {
          count: a,
          importedAt: new Date().toISOString(),
        }),
        writeSecureSettings(i));
    }
  } catch (t) {
    e = {
      ok: !1,
      count: 0,
      message: errorText(t, "Beta.6 TN\u72B6\u6001\u5BFC\u5165\u5931\u8D25"),
    };
  }
  try {
    fs.unlinkSync(n);
  } catch {}
  try {
    writeJsonAtomic(beta6MigrationResultPath(), e);
  } catch {}
}
function prepareBeta6FullProfileMigration({ automatic: n = !1 } = {}) {
  if (!currentProfile?.id) throw new Error("\u8BF7\u5148\u767B\u5F55");
  const e = path.join(beta6UserDataPath(), "tn-accounts.json");
  if (!fs.existsSync(e)) {
    if (n) return { count: 0 };
    throw new Error(
      "\u8FD9\u53F0\u7535\u8111\u6CA1\u6709\u627E\u5230Beta.6 TN\u8D44\u6599",
    );
  }
  const t = JSON.parse(fs.readFileSync(e, "utf8")),
    r = Array.isArray(t?.accounts) ? t.accounts : [],
    u = listTnAccounts();
  if (!r.length || !u.length) {
    if (n) return { count: 0 };
    throw new Error(
      "Beta.6\u6216\u6B63\u5F0F\u7248\u5C1A\u672A\u5EFA\u7ACBTN\u8D26\u53F7",
    );
  }
  const o = readSecureSettings(),
    a = String(o.beta6TnMigrationOwnerId || "");
  if (a && a !== currentProfile.id)
    throw new Error(
      "Beta.6 TN\u8D44\u6599\u5DF2\u7ED1\u5B9A\u7ED9\u8FD9\u53F0\u7535\u8111\u4E0A\u7684\u53E6\u4E00\u4E2A\u5458\u5DE5\uFF0C\u5DF2\u963B\u6B62\u8DE8\u5458\u5DE5\u5BFC\u5165",
    );
  if (n && o.beta6FullProfileImportedByUser?.[currentProfile.id])
    return { count: 0 };
  const s = new Set(),
    i = [];
  for (const c of u) {
    const l = String(c.name || "")
      .trim()
      .toLowerCase();
    let d = r.find(
      (h) =>
        !s.has(String(h?.id || "")) &&
        String(h?.name || "")
          .trim()
          .toLowerCase() === l,
    );
    if (
      (!d && r.length === 1 && u.length === 1 && (d = r[0]),
      !d || !/^[a-f0-9-]{36}$/i.test(String(d.id || "")))
    )
      continue;
    const m = String(d.id).toLowerCase(),
      p = path.join(beta6UserDataPath(), "Partitions", `orange-beta-tn-${m}`);
    fs.existsSync(p) &&
      (s.add(String(d.id)),
      i.push({
        sourceId: m,
        targetPartition: tnPartition(c.id),
        name: c.name,
      }));
  }
  if (!i.length) {
    if (n) return { count: 0 };
    throw new Error(
      "\u6CA1\u6709\u627E\u5230\u53EF\u5B89\u5168\u5339\u914D\u7684\u8D26\u53F7\u73AF\u5883\uFF1B\u591A\u8D26\u53F7\u65F6\u8BF7\u4FDD\u6301Beta.6\u548C\u6B63\u5F0F\u7248TN\u540D\u79F0\u4E00\u81F4",
    );
  }
  return (
    (o.beta6TnMigrationOwnerId = currentProfile.id),
    writeSecureSettings(o),
    writeJsonAtomic(beta6MigrationRequestPath(), {
      ownerId: currentProfile.id,
      items: i,
      createdAt: new Date().toISOString(),
      automatic: n,
    }),
    { count: i.length }
  );
}
function migrateLegacyTnDataForCurrentUser() {
  const n = currentTnOwnerKey();
  if (!n) return;
  const e = readWholeTnStore();
  ((e.users = e.users && typeof e.users == "object" ? e.users : {}),
    !e.users[n] &&
      Array.isArray(e.accounts) &&
      e.accounts.length &&
      (e.users[n] = {
        accounts: e.accounts.map((r) => ({ ...r, partitionScope: "legacy" })),
        migratedAt: new Date().toISOString(),
      }),
    delete e.accounts,
    writeJsonAtomic(tnAccountsPath(), e));
  const t = readSecureSettings();
  if (
    ((t.tnLocalProxiesByUser =
      t.tnLocalProxiesByUser && typeof t.tnLocalProxiesByUser == "object"
        ? t.tnLocalProxiesByUser
        : {}),
    !t.tnLocalProxiesByUser[n])
  ) {
    const r = Array.isArray(t.tnLocalProxies) ? t.tnLocalProxies : [];
    r.length
      ? (t.tnLocalProxiesByUser[n] = r)
      : t.tnLocalProxy?.encryptedProxy &&
        (t.tnLocalProxiesByUser[n] = [
          {
            id: "",
            encryptedProxy: t.tnLocalProxy.encryptedProxy,
            limit: t.tnLocalProxy.limit,
            updatedAt: t.tnLocalProxy.updatedAt,
          },
        ]);
  }
  (delete t.tnLocalProxies, delete t.tnLocalProxy, writeSecureSettings(t));
}
function publicTnAccount(n) {
  const e = tnRuntimeStates.get(n.id) || {},
    { localProxyEncrypted: t, ...r } = n;
  let u = "";
  if (n.proxyMode === "local")
    try {
      u = decryptLocalProxy(n).label || "";
    } catch {}
  return {
    ...r,
    status: e.status || "saved",
    statusText: e.statusText || "\u767B\u5F55\u72B6\u6001\u5DF2\u4FDD\u5B58",
    lastUrl: e.lastUrl || "",
    exitIp: e.exitIp || "",
    proxyLabel: e.proxyLabel || u,
  };
}
function errorText(n, e = "\u64CD\u4F5C\u5931\u8D25") {
  if (!n) return e;
  if (typeof n == "string") return n;
  if (n instanceof Error && n.message) return errorText(n.message, e);
  if (typeof n == "object") {
    const t = n.message || n.error || n.msg || n.details || n.hint || n.code;
    if (t) return errorText(t, e);
    try {
      const r = JSON.stringify(n);
      if (r && r !== "{}") return r;
    } catch {}
    return e;
  }
  return String(n) || e;
}
function parseEmployeeProxy(n) {
  let e = String(n || "").trim();
  if (!e)
    throw new Error(
      "\u8BF7\u8F93\u5165\u5458\u5DE5\u81EA\u7528\u56FA\u5B9AIP\uFF0C\u4F8B\u5982 host:port:user:pass",
    );
  let t = "http",
    r = "",
    u = 0,
    o = "",
    a = "";
  const s = e.match(/^([^:\s]+):(\d{1,5}):([^:\s]+):(.+)$/);
  if (s) ((r = s[1].trim()), (u = Number(s[2])), (o = s[3]), (a = s[4]));
  else {
    /^[a-z][a-z0-9+.-]*:\/\//i.test(e) || (e = `http://${e}`);
    let i;
    try {
      i = new URL(e);
    } catch {
      throw new Error(
        "\u56FA\u5B9AIP\u683C\u5F0F\u65E0\u6CD5\u8BC6\u522B\uFF0C\u652F\u6301 host:port\u3001host:port:user:pass \u6216 protocol://user:pass@host:port",
      );
    }
    ((t = i.protocol.replace(":", "").toLowerCase()),
      (r = i.hostname),
      (u = Number(i.port || { http: 80, https: 443, socks5: 1080 }[t] || 0)),
      (o = decodeURIComponent(i.username || "")),
      (a = decodeURIComponent(i.password || "")));
  }
  if (!r)
    throw new Error("\u56FA\u5B9AIP\u7684\u4E3B\u673A\u4E0D\u80FD\u4E3A\u7A7A");
  if (!Number.isInteger(u) || u < 1 || u > 65535)
    throw new Error(
      "\u56FA\u5B9AIP\u7AEF\u53E3\u5FC5\u987B\u57281\u523065535\u4E4B\u95F4",
    );
  if (!["http", "https", "socks5"].includes(t))
    throw new Error(
      "\u53EA\u652F\u6301 http\u3001https \u6216 socks5 \u56FA\u5B9AIP",
    );
  return {
    id: `local-${crypto.createHash("sha256").update(`${t}|${r}|${u}|${o}`).digest("hex").slice(0, 16)}`,
    protocol: t,
    host: r,
    port: u,
    username: o,
    password: a,
    label: `\u5458\u5DE5\u56FA\u5B9AIP \xB7 ${r}:${u}`,
  };
}
function encryptLocalProxy(n) {
  const e = JSON.stringify(n);
  return safeStorage.isEncryptionAvailable()
    ? safeStorage.encryptString(e).toString("base64")
    : Buffer.from(e).toString("base64");
}
function decryptLocalProxy(n) {
  try {
    const e = Buffer.from(String(n?.localProxyEncrypted || ""), "base64"),
      t = safeStorage.isEncryptionAvailable()
        ? safeStorage.decryptString(e)
        : e.toString("utf8");
    return JSON.parse(t);
  } catch {
    throw new Error(
      "\u5458\u5DE5\u56FA\u5B9AIP\u8D44\u6599\u65E0\u6CD5\u8BFB\u53D6\uFF0C\u8BF7\u91CD\u65B0\u4FDD\u5B58\u8BE5\u8D26\u53F7",
    );
  }
}
function publishTnAccounts() {
  const n = listTnAccounts().map(publicTnAccount);
  return (
    mainWindow &&
      !mainWindow.isDestroyed() &&
      mainWindow.webContents.send("tn:accounts-changed", n),
    n
  );
}
function workspaceStatePath() {
  return path.join(app.getPath("userData"), "workspace-state.json");
}
function normalizeSiteInstanceId(n) {
  const e = String(n || "")
    .trim()
    .toLowerCase();
  return /^[a-f0-9-]{16,64}$/.test(e) ? e : "";
}
function sitePartitionFor(n, e) {
  const t = normalizeSiteInstanceId(e);
  if (!currentProfile?.id || !n || !t)
    throw new Error("\u7F51\u7AD9\u8D26\u53F7\u5B9E\u4F8B\u65E0\u6548");
  const r = crypto
      .createHash("sha256")
      .update(
        `${currentProfile.id}
${String(n)}
${t}`,
      )
      .digest("hex")
      .slice(0, 32),
    u = `${sitePartitionPrefix}${r}`;
  return (
    allowedSitePartitions.set(u, { siteId: String(n), instanceId: t }),
    u
  );
}
function siteAccountProxyOwnerKey() {
  return String(currentProfile?.id || currentProfile?.username || "anonymous");
}
function savedSiteAccountProxy(n) {
  const e =
    readSecureSettings().siteAccountProxiesByUser?.[
      siteAccountProxyOwnerKey()
    ]?.[normalizeSiteInstanceId(n)];
  if (!e) return null;
  try {
    return JSON.parse(unprotect(e));
  } catch {
    return null;
  }
}
function saveSiteAccountProxy(n, e) {
  const t = normalizeSiteInstanceId(n),
    r = readSecureSettings();
  r.siteAccountProxiesByUser =
    r.siteAccountProxiesByUser && typeof r.siteAccountProxiesByUser == "object"
      ? r.siteAccountProxiesByUser
      : {};
  const u = siteAccountProxyOwnerKey();
  if (
    ((r.siteAccountProxiesByUser[u] =
      r.siteAccountProxiesByUser[u] &&
      typeof r.siteAccountProxiesByUser[u] == "object"
        ? r.siteAccountProxiesByUser[u]
        : {}),
    String(e || "").trim())
  ) {
    const o = parseEmployeeProxy(e);
    ((r.siteAccountProxiesByUser[u][t] = protect(JSON.stringify(o))),
      siteAccountProxies.set(t, o));
  } else
    (delete r.siteAccountProxiesByUser[u][t], siteAccountProxies.delete(t));
  writeSecureSettings(r);
}
function deleteSiteAccountProxy(n) {
  const e = normalizeSiteInstanceId(n),
    t = readSecureSettings(),
    r = t.siteAccountProxiesByUser?.[siteAccountProxyOwnerKey()];
  (r && typeof r == "object" && delete r[e],
    writeSecureSettings(t),
    siteAccountProxies.delete(e));
}
const MANAGED_WEB_PLATFORMS = new Set(["whatsapp", "telegram", "gmail"]);
function managedSiteAccountsPath() {
  return path.join(app.getPath("userData"), "managed-site-accounts.json");
}
function readManagedSiteAccountsStore() {
  try {
    const n = JSON.parse(fs.readFileSync(managedSiteAccountsPath(), "utf8"));
    return n && typeof n == "object" ? n : { users: {} };
  } catch {
    return { users: {} };
  }
}
function managedSiteAccountRows(n = "") {
  const e = siteAccountProxyOwnerKey(),
    t = readManagedSiteAccountsStore().users?.[e],
    r = new Set(
      getCurrentWorkspaceState()
        .tabs.filter((u) => u.siteInstanceId)
        .map(
          (u) => `${String(u.siteId || "").toLowerCase()}:${u.siteInstanceId}`,
        ),
    );
  return (Array.isArray(t) ? t : [])
    .filter((u) => !n || u.siteId === n)
    .map((u) => ({
      ...u,
      hasFixedProxy: !!savedSiteAccountProxy(u.id),
      isOpen: r.has(`${String(u.siteId || "").toLowerCase()}:${u.id}`),
    }));
}
function writeManagedSiteAccountRows(n) {
  const e = readManagedSiteAccountsStore();
  ((e.users = e.users && typeof e.users == "object" ? e.users : {}),
    (e.users[siteAccountProxyOwnerKey()] = n),
    writeJsonAtomic(managedSiteAccountsPath(), e));
}
function saveManagedSiteAccount(n) {
  const e = managedSiteAccountRows().map(
      ({ hasFixedProxy: a, isOpen: s, ...i }) => i,
    ),
    t = e.findIndex((a) => a.id === n.id),
    { hasFixedProxy: r, isOpen: u, ...o } = n;
  return (
    t >= 0 ? (e[t] = o) : e.push(o),
    writeManagedSiteAccountRows(e),
    {
      ...o,
      hasFixedProxy: !!savedSiteAccountProxy(o.id),
      isOpen: getCurrentWorkspaceState().tabs.some(
        (a) => a.siteId === o.siteId && a.siteInstanceId === o.id,
      ),
    }
  );
}
function removeManagedSiteAccount(n) {
  const e = managedSiteAccountRows()
    .filter((t) => t.id !== n)
    .map(({ hasFixedProxy: t, isOpen: r, ...u }) => u);
  writeManagedSiteAccountRows(e);
}
function requireManagedPlatform(n) {
  const e = String(n || "")
    .trim()
    .toLowerCase();
  if (!MANAGED_WEB_PLATFORMS.has(e))
    throw new Error("\u5E73\u53F0\u8D26\u53F7\u7C7B\u578B\u65E0\u6548");
  return e;
}
function isMultiAccountWebSite(n, e = "") {
  const t = String(n || "").toLowerCase();
  let r = "";
  try {
    r = new URL(String(e || allowedSites.get(n) || "")).hostname.toLowerCase();
  } catch {}
  return (
    /(?:^|[-_])(whatsapp|telegram|gmail)(?:$|[-_])/.test(t) ||
    /(^|\.)(web\.whatsapp\.com|web\.telegram\.org|mail\.google\.com)$/.test(r)
  );
}
async function configuredProxyForSiteAccount(n) {
  const e = savedSiteAccountProxy(n);
  if (e?.host && e?.port) return { proxy: e, source: "account" };
  if (
    currentProfile?.role !== "admin" &&
    employeeProxyEnabled() &&
    currentSession
  ) {
    if (
      !managedTranslationProxy &&
      (await acquireUsableManagedProxy("assignment").catch(() => null))
        ?.mode === "denied"
    )
      return { proxy: null, source: "denied" };
    if (managedTranslationProxy?.host && managedTranslationProxy?.port)
      return { proxy: managedTranslationProxy, source: "remote" };
  }
  return { proxy: null, source: "direct" };
}
async function configureSiteAccountSession(n, e, t = {}) {
  const r = sitePartitionFor(n, e),
    u = session.fromPartition(r),
    { proxy: o, source: a } = await configuredProxyForSiteAccount(e);
  return (
    String(n || "").toLowerCase() === "whatsapp" &&
      u.setUserAgent(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
        "en-US,en;q=0.9",
      ),
    o?.host && o?.port
      ? (siteAccountProxies.set(normalizeSiteInstanceId(e), o),
        await u.setProxy({
          proxyRules: `${o.protocol || "http"}://${o.host}:${Number(o.port)}`,
          proxyBypassRules: "<-loopback>",
        }),
        await u.closeAllConnections?.(),
        t.verifyProxy === !0 &&
          (await (async () => {
            const s = await probeProxyThroughSession(u, o, 8e3);
            if (!s.healthy)
              throw (
                await u.setProxy({ mode: "direct" }).catch(() => {}),
                await u.closeAllConnections?.(),
                new Error(
                  `${a === "remote" ? "\u7BA1\u7406\u5458\u8FDC\u7A0B\u5206\u914DIP" : "\u8D26\u53F7\u56FA\u5B9AIP"}\u8FDE\u63A5\u5931\u8D25\uFF1A${s.error || "\u4EE3\u7406\u65E0\u54CD\u5E94"}`,
                )
              );
          })()))
      : (await u.setProxy({ mode: "direct" }), await u.closeAllConnections?.()),
    await prepareWorkExtensionWithoutBlockingPage(u),
    { partition: r, accountSession: u, proxySource: a }
  );
}
function siteWallpaperDirectory(n) {
  const e = crypto
    .createHash("sha256")
    .update(siteAccountProxyOwnerKey())
    .digest("hex")
    .slice(0, 24);
  return path.join(
    app.getPath("userData"),
    "site-wallpapers",
    e,
    normalizeSiteInstanceId(n),
  );
}
function siteWallpaperData(n) {
  const e = siteWallpaperDirectory(n);
  if (!fs.existsSync(e)) return "";
  const t = fs
    .readdirSync(e)
    .map((r) => path.join(e, r))
    .find((r) => fs.statSync(r).isFile());
  return t
    ? `data:${{ ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif" }[path.extname(t).toLowerCase()] || "image/png"};base64,${fs.readFileSync(t).toString("base64")}`
    : "";
}
function readWorkspaceStore() {
  try {
    const n = JSON.parse(fs.readFileSync(workspaceStatePath(), "utf8"));
    return n && typeof n == "object" ? n : { users: {}, windows: {} };
  } catch {
    return { users: {}, windows: {} };
  }
}
function writeWorkspaceStore(n) {
  writeJsonAtomic(workspaceStatePath(), n);
}
function currentWorkspaceUserKey() {
  return String(currentProfile?.id || "");
}
function sanitizeWorkspaceState(n = {}) {
  const e = Array.isArray(n.tabs)
      ? n.tabs.slice(0, 50).flatMap((r) => {
          const u = String(r?.siteId || ""),
            o = String(r?.accountId || ""),
            a = normalizeSiteInstanceId(r?.siteInstanceId),
            s = u === "textnow" ? tnAccountById(o) : null,
            i = u.toLowerCase() === "signal" && !!a;
          if (u.toLowerCase() === "signal") return [];
          let c = i
            ? "orange-signal://embedded"
            : s
              ? "https://www.textnow.com/messaging"
              : allowedSites.get(u);
          if (!c && u === "custom")
            if (String(r?.url || "") === "about:blank") c = "about:blank";
            else
              try {
                const p = new URL(String(r?.url || ""));
                ["http:", "https:"].includes(p.protocol) && (c = p.href);
              } catch {}
          if (!c) return [];
          let l = c;
          try {
            if (i) throw new Error("native-signal");
            const p = new URL(String(r?.url || c)),
              h = new URL(c),
              g =
                p.hostname === h.hostname ||
                p.hostname.endsWith(`.${h.hostname}`);
            ["http:", "https:"].includes(p.protocol) && g && (l = p.href);
          } catch {}
          const d = !i && a && isMultiAccountWebSite(u, c),
            m = d ? sitePartitionFor(u, a) : "";
          return [
            {
              siteId: u,
              url: l,
              title: String(r?.title || u).slice(0, 120),
              zoom: Math.max(0.5, Math.min(2, Number(r?.zoom || 1))),
              blockChinese: r?.blockChinese === !0,
              ...(s ? { accountId: s.id } : {}),
              ...(i ? { siteInstanceId: a, nativeKind: "signal" } : {}),
              ...(d ? { siteInstanceId: a, partition: m } : {}),
            },
          ];
        })
      : [],
    t = Number(n.activeIndex);
  return {
    tabs: e,
    activeIndex: e.length
      ? Math.max(0, Math.min(e.length - 1, Number.isFinite(t) ? t : 0))
      : 0,
    updatedAt: new Date().toISOString(),
  };
}
function getCurrentWorkspaceState() {
  const n = currentWorkspaceUserKey();
  return n
    ? sanitizeWorkspaceState(readWorkspaceStore().users?.[n] || {})
    : { tabs: [], activeIndex: 0 };
}
function saveCurrentWorkspaceState(n) {
  const e = currentWorkspaceUserKey();
  if (!e) return { ok: !1, message: "\u8BF7\u5148\u767B\u5F55" };
  const t = readWorkspaceStore();
  return (
    (t.users = t.users && typeof t.users == "object" ? t.users : {}),
    (t.users[e] = sanitizeWorkspaceState(n)),
    writeWorkspaceStore(t),
    { ok: !0 }
  );
}
function savedWindowState(n) {
  const e = readWorkspaceStore().windows?.[n],
    t = e?.bounds;
  if (!t || ![t.width, t.height].every(Number.isFinite)) return null;
  const r = Number.isFinite(t.x) ? t.x : void 0,
    u = Number.isFinite(t.y) ? t.y : void 0,
    o =
      Number.isFinite(r) &&
      Number.isFinite(u) &&
      screen.getAllDisplays().some((a) => {
        const s = a.workArea;
        return (
          r < s.x + s.width - 80 &&
          u < s.y + s.height - 80 &&
          r + t.width > s.x + 80 &&
          u + t.height > s.y + 40
        );
      });
  return {
    x: o ? r : void 0,
    y: o ? u : void 0,
    width: Math.max(920, Math.min(5e3, t.width)),
    height: Math.max(640, Math.min(3e3, t.height)),
    maximized: e.maximized === !0,
  };
}
function saveWindowState(n, e) {
  if (!e || e.isDestroyed()) return;
  const t = readWorkspaceStore();
  ((t.windows = t.windows && typeof t.windows == "object" ? t.windows : {}),
    (t.windows[n] = {
      bounds: e.getNormalBounds(),
      maximized: e.isMaximized(),
    }),
    writeWorkspaceStore(t));
}
function installWindowStateMemory(n, e) {
  let t = null;
  const r = () => {
    (clearTimeout(t), (t = setTimeout(() => saveWindowState(n, e), 250)));
  };
  (e.on("resize", r),
    e.on("move", r),
    e.on("maximize", r),
    e.on("unmaximize", r),
    e.on("close", () => {
      (clearTimeout(t), saveWindowState(n, e));
    }));
}
function protect(n) {
  if (!n) return "";
  if (!safeStorage.isEncryptionAvailable())
    throw new Error(
      "Windows\u5B89\u5168\u5B58\u50A8\u5F53\u524D\u4E0D\u53EF\u7528",
    );
  return safeStorage.encryptString(String(n)).toString("base64");
}
function unprotect(n) {
  if (!n || !safeStorage.isEncryptionAvailable()) return "";
  try {
    return safeStorage.decryptString(Buffer.from(n, "base64"));
  } catch {
    return "";
  }
}
function proxyAuthKey(n, e) {
  return `${String(n || "").toLowerCase()}:${Number(e || 0)}`;
}
function employeeProxyEnabled() {
  return readSecureSettings().proxy?.employeeEnabled !== !1;
}
function managedProxyState(n = {}) {
  const e = employeeProxyEnabled(),
    t = proxiedSiteHosts.size > 0 || fixedSiteProxies.size > 0,
    r =
      ((e || proxiedSiteHosts.size > 0) && !!managedTranslationProxy) ||
      fixedSiteProxies.size > 0;
  return {
    managed: !0,
    enabled: e,
    active: r,
    siteProxyEnabled: t,
    label: (r && managedTranslationProxy?.label) || "",
    endpoint: r
      ? `${managedTranslationProxy.host}:${managedTranslationProxy.port}`
      : "",
    protocol: (r && managedTranslationProxy?.protocol) || "",
    message:
      !e && !t
        ? "\u7FFB\u8BD1IP\u5DF2\u5173\u95ED\uFF0C\u5F53\u524D\u4F7F\u7528\u672C\u673A\u7F51\u7EDC"
        : r
          ? e && t
            ? "Google\u7FFB\u8BD1\u548C\u6307\u5B9A\u7F51\u7AD9\u6B63\u5728\u4F7F\u7528\u7FFB\u8BD1IP\u6C60"
            : t
              ? "\u6307\u5B9A\u7F51\u7AD9\u6B63\u5728\u4F7F\u7528\u7FFB\u8BD1IP\u6C60\uFF1BGoogle\u7FFB\u8BD1\u4F7F\u7528\u672C\u673A\u7F51\u7EDC"
              : "Google\u7FFB\u8BD1\u6B63\u5728\u4F7F\u7528\u7FFB\u8BD1IP\u6C60"
          : "\u9700\u8981IP\u7684\u529F\u80FD\u5DF2\u5F00\u542F\uFF0C\u4F46\u4EE3\u7406\u6C60\u6682\u65F6\u6CA1\u6709\u53EF\u7528\u7EBF\u8DEF",
    ...n,
  };
}
function sendManagedProxyState(n = {}) {
  const e = managedProxyState(n);
  return (
    mainWindow &&
      !mainWindow.isDestroyed() &&
      mainWindow.webContents.send("proxy:managed-state", e),
    e
  );
}
app.on("login", (n, e, t, r, u) => {
  if (!r?.isProxy) return;
  const o = proxyAuthKey(r.host, r.port),
    a = proxyTestCredentials.get(o),
    s =
      managedTranslationProxy &&
      o ===
        proxyAuthKey(managedTranslationProxy.host, managedTranslationProxy.port)
        ? managedTranslationProxy
        : null,
    i =
      [...fixedSiteProxies.values()].find(
        (m) => o === proxyAuthKey(m.host, m.port),
      ) || null,
    c =
      [...siteAccountProxies.values()].find(
        (m) => o === proxyAuthKey(m.host, m.port),
      ) || null,
    l =
      [...tnAccountProxies.values()].find(
        (m) => o === proxyAuthKey(m.host, m.port),
      ) || null,
    d = a || s || i || c || l;
  d &&
    (n.preventDefault(), u(String(d.username || ""), String(d.password || "")));
});
function proxyRoutingRequired() {
  return employeeProxyEnabled() || proxiedSiteHosts.size > 0;
}
function translationPacScript(n) {
  const e =
      n?.protocol === "socks5"
        ? `SOCKS5 ${n.host}:${n.port}`
        : n?.protocol === "https"
          ? `HTTPS ${n.host}:${n.port}`
          : n?.host
            ? `PROXY ${n.host}:${n.port}`
            : "DIRECT",
    t = employeeProxyEnabled()
      ? [
          "translate.googleapis.com",
          "translate.google.com",
          "translate.google.co.th",
        ]
      : [],
    r = [
      ...new Set([
        ...t,
        ...proxiedSiteHosts,
        "api.ipify.org",
        "api64.ipify.org",
        "icanhazip.com",
      ]),
    ]
      .map((o) => JSON.stringify(String(o).toLowerCase()))
      .join(","),
    u = [...fixedSiteProxies.entries()]
      .map(([o, a]) => {
        const s =
          a.protocol === "socks5"
            ? `SOCKS5 ${a.host}:${a.port}`
            : a.protocol === "https"
              ? `HTTPS ${a.host}:${a.port}`
              : `PROXY ${a.host}:${a.port}`;
        return `{host:${JSON.stringify(o)},directive:${JSON.stringify(s)}}`;
      })
      .join(",");
  return `function FindProxyForURL(url, host) {
    var routed = [${r}];
    var fixed = [${u}];
    host = String(host || "").toLowerCase();
    for (var f = 0; f < fixed.length; f++) {
      if (host === fixed[f].host || dnsDomainIs(host, "." + fixed[f].host)) return fixed[f].directive;
    }
    for (var i = 0; i < routed.length; i++) {
      if (host === routed[i] || dnsDomainIs(host, "." + routed[i])) return "${e}";
    }
    return "DIRECT";
  }`;
}
async function applyTranslationProxy() {
  const n = session.fromPartition(workPartition);
  installTranslationProxyObservers(n);
  const e = proxyRoutingRequired() || fixedSiteProxies.size > 0,
    t = [
      n,
      ...[...allowedSitePartitions.keys()].map((u) => session.fromPartition(u)),
    ],
    r = [...new Set(t)];
  await Promise.allSettled(
    r.map(async (u) => {
      if (
        !e ||
        ((!managedTranslationProxy?.host || !managedTranslationProxy?.port) &&
          fixedSiteProxies.size === 0)
      )
        await u.setProxy({ mode: "direct" });
      else {
        const o = translationPacScript(managedTranslationProxy),
          a = `data:application/x-ns-proxy-autoconfig;base64,${Buffer.from(o, "utf8").toString("base64")}`;
        await u.setProxy({ mode: "pac_script", pacScript: a });
      }
      await u.closeAllConnections?.();
    }),
  );
}
async function refreshManagedProxy(n = "assignment", e = "", t = !1, r = []) {
  return proxyRoutingRequired()
    ? currentSession
      ? proxyRefreshPromise ||
        ((proxyRefreshPromise = (async () => {
          const u = managedTranslationProxy?.id || "",
            o = await invokeFunction("proxy-control", {
              action: n,
              proxyId: u || void 0,
              reason: String(e || "").slice(0, 500),
              forceSwitch: t === !0,
              excludedProxyIds: Array.isArray(r) ? r.slice(0, 500) : [],
            });
          ((managedTranslationProxy = o.proxy || null),
            await applyTranslationProxy());
          const a = { mode: o.mode || "automatic", switched: !!o.switched };
          return (
            o.mode === "denied" &&
              (a.message =
                "\u7BA1\u7406\u5458\u672A\u5F00\u653E\u6B64\u8D26\u53F7\u4F7F\u7528\u7FFB\u8BD1IP"),
            sendManagedProxyState(a),
            o
          );
        })().finally(() => {
          proxyRefreshPromise = null;
        })),
        proxyRefreshPromise)
      : { proxy: null, mode: "none" }
    : ((managedTranslationProxy = null),
      await applyTranslationProxy(),
      sendManagedProxyState({ mode: "direct" }),
      { proxy: null, mode: "direct", employeeEnabled: !1 });
}
const proxyProbeTargets = [
  { url: "https://api.ipify.org?format=json", json: !0 },
  { url: "https://api64.ipify.org?format=json", json: !0 },
  { url: "https://icanhazip.com/", json: !1 },
];
function requestProxyProbe(n, e, t, r) {
  return new Promise((u) => {
    let o = !1;
    const a = (c) => {
        o || ((o = !0), clearTimeout(i), u(c));
      },
      s = net.request({
        method: "GET",
        url: t.url,
        session: n,
        credentials: "include",
        cache: "no-store",
        redirect: "follow",
      }),
      i = setTimeout(() => {
        (s.abort(), a({ healthy: !1, error: "\u68C0\u6D4B\u8D85\u65F6" }));
      }, r);
    (s.on("login", (c, l) => {
      if (!c?.isProxy) return l();
      l(String(e.username || ""), String(e.password || ""));
    }),
      s.on("response", (c) => {
        const l = [];
        (c.on("data", (d) => l.push(Buffer.from(d))),
          c.on("error", (d) =>
            a({ healthy: !1, error: d?.message || String(d) }),
          ),
          c.on("end", () => {
            if (c.statusCode < 200 || c.statusCode >= 300)
              return a({
                healthy: !1,
                error: `\u5065\u5EB7\u68C0\u6D4B HTTP ${c.statusCode}`,
              });
            try {
              const d = Buffer.concat(l).toString("utf8").trim(),
                m = t.json
                  ? String(JSON.parse(d)?.ip || "")
                  : d.split(/\s+/)[0];
              if (!m)
                return a({
                  healthy: !1,
                  error:
                    "\u68C0\u6D4B\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u51FA\u53E3IP",
                });
              a({ healthy: !0, exitIp: m, target: new URL(t.url).hostname });
            } catch {
              a({
                healthy: !1,
                error: "\u5065\u5EB7\u68C0\u6D4B\u8FD4\u56DE\u5F02\u5E38",
              });
            }
          }));
      }),
      s.on("error", (c) => a({ healthy: !1, error: c?.message || String(c) })),
      s.end());
  });
}
async function probeProxyThroughSession(n, e, t = 6e3) {
  const r = [];
  for (const u of proxyProbeTargets) {
    const o = await requestProxyProbe(n, e, u, t);
    if (o.healthy) return o;
    r.push(
      `${new URL(u.url).hostname}: ${o.error || "\u68C0\u6D4B\u5931\u8D25"}`,
    );
  }
  return {
    healthy: !1,
    error:
      `\u4E09\u4E2A\u68C0\u6D4B\u70B9\u5747\u5931\u8D25 \xB7 ${r.join("\uFF1B")}`.slice(
        0,
        500,
      ),
  };
}
async function probeCurrentManagedProxy(n = 6e3) {
  return managedTranslationProxy
    ? probeProxyThroughSession(
        session.fromPartition(workPartition),
        { ...managedTranslationProxy },
        n,
      )
    : { healthy: !1, error: "\u6CA1\u6709\u5DF2\u5206\u914D\u7EBF\u8DEF" };
}
function requestTextThroughSession(n, e, t = 1e4) {
  return new Promise((r, u) => {
    let o = !1;
    const a = (c, l = "") => {
        o || ((o = !0), clearTimeout(i), c ? u(c) : r(l));
      },
      s = net.request({
        method: "GET",
        url: n,
        session: e,
        credentials: "include",
        cache: "no-store",
        redirect: "follow",
      }),
      i = setTimeout(() => {
        (s.abort(), a(new Error("\u7FFB\u8BD1\u8BF7\u6C42\u8D85\u65F6")));
      }, t);
    (s.on("login", (c, l) => {
      if (!c?.isProxy || !managedTranslationProxy) return l();
      l(
        String(managedTranslationProxy.username || ""),
        String(managedTranslationProxy.password || ""),
      );
    }),
      s.on("response", (c) => {
        const l = [];
        (c.on("data", (d) => l.push(Buffer.from(d))),
          c.on("error", (d) => a(d)),
          c.on("end", () => {
            if (c.statusCode < 200 || c.statusCode >= 300)
              return a(new Error(`\u7FFB\u8BD1 HTTP ${c.statusCode}`));
            a(null, Buffer.concat(l).toString("utf8"));
          }));
      }),
      s.on("error", (c) => a(c)),
      s.end());
  });
}
async function translateForEmbeddedPage(n = {}) {
  const e = String(n.text || "")
    .trim()
    .slice(0, 1200);
  if (!e) throw new Error("\u6CA1\u6709\u53EF\u7FFB\u8BD1\u6587\u5B57");
  const t = String(n.sourceLanguage || "en").slice(0, 12),
    r = String(n.targetLanguage || "zh-CN").slice(0, 12),
    u = /^zh/i.test(r) ? "Simplified Chinese" : "natural American English",
    o = /^zh/i.test(t) ? "Chinese" : "English";
  if (n.forceAi === !0) {
    const d = String(n.context || "")
        .trim()
        .slice(0, 5e3),
      m = await invokeFunction("ai-gateway", {
        action: "generate",
        messages: [
          {
            role: "system",
            content: `You are a precise conversational translator. Translate the target message from ${o} to ${u}. Use the nearby conversation only to resolve slang, abbreviations, omitted subjects, pronouns, references and spelling mistakes. Preserve names, phone numbers, dates, amounts and intent. Return only the translation; never answer the message.${n.alternative === !0 ? " This is a requested second translation: actively correct literal or awkward wording and, when equally accurate, choose a clearer natural phrasing." : ""}`,
          },
          ...(d
            ? [
                {
                  role: "user",
                  content: `Nearby conversation:
${d}`,
                },
              ]
            : []),
          ...(n.previousTranslation
            ? [
                {
                  role: "user",
                  content: `Previous translation to review:
${String(n.previousTranslation).slice(0, 1800)}`,
                },
              ]
            : []),
          {
            role: "user",
            content: `Target message:
${e}`,
          },
        ],
        temperature: 0.1,
        maxTokens: 1800,
      }),
      p = String(m?.content || "").trim();
    if (!p)
      throw new Error(
        "AI\u91CD\u65B0\u7FFB\u8BD1\u6CA1\u6709\u8FD4\u56DE\u5185\u5BB9",
      );
    return p;
  }
  employeeProxyEnabled() &&
    !managedTranslationProxy &&
    (await acquireUsableManagedProxy("assignment").catch(() => {}));
  const a = `?client=gtx&sl=${encodeURIComponent(t)}&tl=${encodeURIComponent(r)}&dt=t&q=${encodeURIComponent(e)}`,
    s = [
      "https://translate.googleapis.com/translate_a/single",
      "https://translate.google.com/translate_a/single",
      "https://translate.google.co.th/translate_a/single",
    ];
  let i = null;
  for (const d of s)
    try {
      const m = await requestTextThroughSession(
          d + a,
          session.fromPartition(workPartition),
        ),
        p = JSON.parse(m),
        h = Array.isArray(p?.[0])
          ? p[0]
              .map((g) => g?.[0] || "")
              .join("")
              .trim()
          : "";
      if (h) return h;
    } catch (m) {
      i = m;
    }
  const c = await invokeFunction("ai-gateway", {
      action: "generate",
      messages: [
        {
          role: "system",
          content: `Translate from ${o} to ${u}. Return only the translation. Preserve names, phone numbers, punctuation and meaning.`,
        },
        { role: "user", content: e },
      ],
      temperature: 0.1,
      maxTokens: 1800,
    }).catch((d) => {
      throw new Error(
        `Google\u4E0E\u5907\u7528\u7FFB\u8BD1\u5747\u5931\u8D25\uFF1A${errorText(i, "Google\u5931\u8D25")}\uFF1B${errorText(d, "AI\u5931\u8D25")}`,
      );
    }),
    l = String(c?.content || "").trim();
  if (!l)
    throw new Error(
      "\u7FFB\u8BD1\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u5185\u5BB9",
    );
  return l;
}
async function translateVariantsForEmbeddedPage(n) {
  const e = String(n || "")
    .trim()
    .slice(0, 1200);
  if (!e) throw new Error("\u6CA1\u6709\u53EF\u7FFB\u8BD1\u6587\u5B57");
  const t = await translateForEmbeddedPage({
    text: e,
    sourceLanguage: "zh-CN",
    targetLanguage: "en",
  });
  if (/^(你好|您好|嗨|哈喽)[!！。.，,\s]*$/.test(e))
    return [
      {
        style: "direct",
        text: /^hello[.!]?$/i.test(t) ? t : "Hello.",
        chinese: e,
      },
      { style: "natural", text: "Hi.", chinese: e },
      { style: "business", text: "Hello.", chinese: e },
      { style: "chat", text: "Hey!", chinese: e },
    ];
  let r;
  try {
    r = await invokeFunction("ai-gateway", {
      action: "generate",
      messages: [
        {
          role: "system",
          content:
            "Rewrite a verified English translation into idiomatic American workplace/chat English. Return ONLY a strict JSON array with exactly 3 objects. Styles must be natural, business, chat. Each object is {style:'natural'|'business'|'chat', text:'English only', chinese:'concise Simplified Chinese meaning'}. Preserve every name, phone number, URL, emoji, date, time, amount and fact. Apply American punctuation, spacing, quotation marks, contractions, month/day date style, US money style and natural emoji placement when appropriate. Do not invent information and do not put Chinese in text.",
        },
        {
          role: "user",
          content: `Chinese source:
${e}

Verified English:
${t}`,
        },
      ],
      temperature: 0.35,
      maxTokens: 1400,
    });
  } catch {
    return [{ style: "direct", text: t, chinese: e }];
  }
  const u = String(r?.content || "")
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "");
  let o;
  try {
    o = JSON.parse(u);
  } catch {
    return [{ style: "direct", text: t, chinese: e }];
  }
  const a = Array.isArray(o)
    ? o
        .slice(0, 3)
        .map((s, i) => ({
          style: String(s?.style || ["natural", "business", "chat"][i]),
          text: String(s?.text || "")
            .trim()
            .replace(/[\u3400-\u9fff].*$/s, "")
            .trim(),
          chinese: String(s?.chinese || e).trim(),
        }))
        .filter((s) => s.text)
    : [];
  return [{ style: "direct", text: t, chinese: e }, ...a];
}
function singlePreciseTranslationSender(n) {
  try {
    const e = new URL(n?.sender?.getURL?.() || "").hostname.toLowerCase();
    return /(^|\.)(web\.whatsapp\.com|web\.telegram\.org|mail\.google\.com)$/.test(
      e,
    );
  } catch {
    return !1;
  }
}
async function translateWithDeepLPreferred(n = {}) {
  const e = String(n.text || "")
    .trim()
    .slice(0, 12e3);
  if (!e) throw new Error("\u6CA1\u6709\u53EF\u7FFB\u8BD1\u6587\u5B57");
  const t = /^zh/i.test(String(n.sourceLanguage || ""))
      ? "ZH"
      : /^en/i.test(String(n.sourceLanguage || ""))
        ? "EN"
        : "auto",
    r = /^en/i.test(String(n.targetLanguage || ""))
      ? "EN-US"
      : /^zh/i.test(String(n.targetLanguage || ""))
        ? "ZH"
        : String(n.targetLanguage || "ZH").toUpperCase(),
    u = await invokeFunction("ai-gateway", {
      action: "translate",
      text: e,
      sourceLanguage: t,
      targetLanguage: r,
      preferredProvider: "deepl",
    }),
    o = String(u?.content || "").trim();
  if (!o)
    throw new Error(
      "DeepL\u53CA\u5907\u7528\u6A21\u578B\u5747\u672A\u8FD4\u56DE\u8BD1\u6587",
    );
  return r.startsWith("EN") &&
    /[\u3400-\u9fff]/u.test(e) &&
    (!/[A-Za-z]/.test(o) || o === e)
    ? translateForEmbeddedPage({
        text: e,
        sourceLanguage: "zh-CN",
        targetLanguage: "en",
      })
    : o;
}
async function translateInputFast(n = {}) {
  const e = String(n.text || "")
    .trim()
    .slice(0, 1200);
  if (!e) throw new Error("\u6CA1\u6709\u53EF\u7FFB\u8BD1\u6587\u5B57");
  const t = `?client=gtx&sl=zh-CN&tl=en&dt=t&q=${encodeURIComponent(e)}`,
    r = [
      "https://translate.googleapis.com/translate_a/single",
      "https://translate.google.com/translate_a/single",
      "https://translate.google.co.th/translate_a/single",
    ],
    u = async (o) => {
      const a = await requestTextThroughSession(
          o + t,
          session.fromPartition(workPartition),
          4500,
        ),
        s = JSON.parse(a),
        i = Array.isArray(s?.[0])
          ? s[0]
              .map((c) => c?.[0] || "")
              .join("")
              .trim()
          : "";
      if (!i || i === e || !/[A-Za-z]/.test(i))
        throw new Error("\u7FFB\u8BD1\u7ED3\u679C\u65E0\u6548");
      return i;
    };
  try {
    return await Promise.any([
      translateWithDeepLPreferred(n).then((o) => {
        if (!o || o === e || !/[A-Za-z]/.test(o))
          throw new Error("DeepL\u7FFB\u8BD1\u7ED3\u679C\u65E0\u6548");
        return o;
      }),
      ...r.map(u),
    ]);
  } catch {
    return translateForEmbeddedPage(n);
  }
}
ipcMain.handle("translation:translate", async (n, e) => {
  try {
    const t = ["chat_translate", "page_translate", "input_translate"].includes(
      String(e?.featureCode || ""),
    )
      ? String(e.featureCode)
      : "chat_translate";
    if (!featureAllowed(t)) return featureDisabledResult(t);
    if (tnAccountForSender(n.sender) && !tnFeatureAllowed("tn_accounts"))
      return featureDisabledResult("tn_accounts");
    const r = t === "input_translate" && singlePreciseTranslationSender(n);
    return e?.variants === !0 && t === "input_translate"
      ? r
        ? {
            ok: !0,
            variants: [
              {
                style: "precise",
                text: await translateWithDeepLPreferred(e),
                chinese: String(e?.text || "").trim(),
              },
            ],
          }
        : { ok: !0, variants: await translateVariantsForEmbeddedPage(e.text) }
      : {
          ok: !0,
          translated: r
            ? await translateInputFast(e)
            : await translateForEmbeddedPage(e),
        };
  } catch (t) {
    return {
      ok: !1,
      message: errorText(t, "\u804A\u5929\u7FFB\u8BD1\u5931\u8D25"),
    };
  }
});
const pageTranslationState = new Map();
(ipcMain.on("page-translation:status", (n, e) => {
  pageTranslationState.set(n.sender.id, e?.enabled === !0);
}),
  ipcMain.on("page-context-menu:open", (n, e = {}) => {
    const t = n.sender;
    if (!t || t.isDestroyed()) return;
    const r = e.editable === !0,
      u = String(e.selectionText || "").trim().length > 0,
      o = pageTranslationState.get(t.id) === !0,
      a = [
        ...(r
          ? [
              { label: "\u64A4\u9500", role: "undo" },
              { label: "\u91CD\u505A", role: "redo" },
              { type: "separator" },
              { label: "\u526A\u5207", role: "cut" },
              { label: "\u590D\u5236", role: "copy" },
              { label: "\u7C98\u8D34", role: "paste" },
              { label: "\u5168\u9009", role: "selectAll" },
              { type: "separator" },
            ]
          : u
            ? [{ label: "\u590D\u5236", role: "copy" }, { type: "separator" }]
            : []),
        {
          label: o
            ? "\u91CD\u65B0\u7FFB\u8BD1\u6210\u4E2D\u6587\uFF08\u7B80\u4F53\uFF09"
            : "\u7FFB\u8BD1\u6210\u4E2D\u6587\uFF08\u7B80\u4F53\uFF09",
          enabled: featureAllowed("page_translate"),
          click: () =>
            !t.isDestroyed() &&
            t.send("page-translation:set", {
              enabled: !0,
              targetLanguage: "zh-CN",
              refresh: o,
            }),
        },
        {
          label: "\u6062\u590D\u7F51\u9875\u539F\u6587",
          enabled: o,
          click: () => !t.isDestroyed() && t.send("page-translation:restore"),
        },
        { type: "separator" },
        {
          label: "\u91CD\u65B0\u52A0\u8F7D",
          click: () => !t.isDestroyed() && t.reload(),
        },
      ];
    Menu.buildFromTemplate(a).popup({
      window: BrowserWindow.fromWebContents(t) || void 0,
    });
  }),
  app.on("web-contents-created", (n, e) => {
    e.once("destroyed", () => pageTranslationState.delete(e.id));
  }));
async function acquireUsableManagedProxy(n = "assignment", e = "") {
  let t = n,
    r = e;
  const u = new Set();
  for (let a = 0; a < 500; a += 1) {
    const s = await refreshManagedProxy(t, r, !1, [...u]);
    if (s?.mode === "denied" || !managedTranslationProxy) return s;
    if (u.has(managedTranslationProxy.id)) break;
    u.add(managedTranslationProxy.id);
    const i = await probeCurrentManagedProxy();
    if (i.healthy)
      return (
        await invokeFunction("proxy-control", {
          action: "report_success",
          proxyId: managedTranslationProxy.id,
        }).catch(() => {}),
        sendManagedProxyState({
          mode: s.mode || "automatic",
          active: !0,
          message: `IP\u7EBF\u8DEF\u53EF\u7528${i.exitIp ? ` \xB7 \u51FA\u53E3 ${i.exitIp}` : ""}${a ? ` \xB7 \u5DF2\u81EA\u52A8\u66F4\u6362${a}\u6B21` : ""}`,
        }),
        { ...s, healthy: !0, exitIp: i.exitIp, attempts: a + 1 }
      );
    ((r = i.error || "\u81EA\u52A8\u5065\u5EB7\u68C0\u6D4B\u5931\u8D25"),
      (t = "report_failure"));
  }
  ((managedTranslationProxy = null), await applyTranslationProxy());
  const o = String(r || "\u672A\u77E5\u539F\u56E0").slice(0, 160);
  return (
    sendManagedProxyState({
      active: !1,
      message: `\u5DF2\u68C0\u6D4B ${u.size} \u6761\u7EBF\u8DEF\uFF0C\u6682\u65F6\u6CA1\u6709\u53EF\u7528IP \xB7 ${o}`,
    }),
    {
      proxy: null,
      mode: "automatic",
      healthy: !1,
      attempts: u.size,
      message: `\u5DF2\u68C0\u6D4B ${u.size} \u6761\u7EBF\u8DEF\uFF0C\u6682\u65F6\u6CA1\u6709\u53EF\u7528IP\uFF1B\u6700\u540E\u7ED3\u679C\uFF1A${o}`,
    }
  );
}
async function handleTranslationProxyFailure(n, e = 0, t = !1) {
  if (!(
    !proxyRoutingRequired() ||
    !managedTranslationProxy ||
    Date.now() - lastProxyFailureAt < 2e3
  )) {
    lastProxyFailureAt = Date.now();
    try {
      if (
        (await acquireUsableManagedProxy("report_failure", n))?.healthy &&
        t &&
        e
      ) {
        const r = webContents.fromId(Number(e));
        r && !r.isDestroyed() && r.reload();
      }
    } catch (r) {
      console.warn("Unable to switch translation proxy", r?.message || r);
    }
  }
}
function installTranslationProxyObservers(n) {
  if (translationProxyObserversInstalled) return;
  translationProxyObserversInstalled = !0;
  const e = { urls: ["<all_urls>"] },
    t = (o) => {
      try {
        const a = new URL(o).hostname.toLowerCase();
        return [...proxiedSiteHosts].some((s) => a === s || a.endsWith(`.${s}`))
          ? !0
          : employeeProxyEnabled() &&
              [
                "translate.googleapis.com",
                "translate.google.com",
                "translate.google.co.th",
              ].includes(a);
      } catch {
        return !1;
      }
    },
    r = (o) => {
      try {
        const a = new URL(o).hostname.toLowerCase();
        return [...proxiedSiteHosts].some(
          (s) => a === s || a.endsWith(`.${s}`),
        );
      } catch {
        return !1;
      }
    },
    u = (o) => {
      try {
        const a = new URL(o);
        return `${a.origin}${a.pathname}`.slice(0, 300);
      } catch {
        return "\u53D7\u7BA1\u8BF7\u6C42";
      }
    };
  (n.webRequest.onErrorOccurred(e, (o) => {
    t(o.url) &&
      ["mainFrame", "subFrame", "xhr", "fetch", "webSocket"].includes(
        String(o.resourceType || ""),
      ) &&
      handleTranslationProxyFailure(
        `${o.error || "\u7F51\u7EDC\u9519\u8BEF"} \xB7 ${u(o.url)}`,
        o.webContentsId,
        r(o.url),
      );
  }),
    n.webRequest.onCompleted(e, (o) => {
      if (!t(o.url)) return;
      const a = Number(o.statusCode || 0);
      if (
        !["mainFrame", "subFrame", "xhr", "fetch", "webSocket"].includes(
          String(o.resourceType || ""),
        ) &&
        a >= 400
      )
        return;
      const s = (() => {
          try {
            return new URL(o.url).hostname.toLowerCase();
          } catch {
            return "";
          }
        })(),
        i = `${managedTranslationProxy?.id || "none"}:${s}`,
        c = `${i}:${a}`,
        l = managedHttpFailureWindows.get(c) || { count: 0, at: 0 },
        d = Date.now() - l.at <= 3e4 ? l.count + 1 : 1;
      managedHttpFailureWindows.set(c, { count: d, at: Date.now() });
      const m = [403, 429].includes(a) && d >= 2;
      if (a === 407 || m) {
        if ((managedHttpFailureWindows.delete(c), m)) {
          if (Number(managedTargetCooldowns.get(c) || 0) > Date.now()) return;
          managedTargetCooldowns.set(c, Date.now() + 600 * 1e3);
        }
        handleTranslationProxyFailure(
          `\u4EE3\u7406\u8BF7\u6C42 HTTP ${a} \xB7 ${u(o.url)}`,
          o.webContentsId,
          r(o.url),
        );
        return;
      }
      a >= 200 &&
        a < 400 &&
        managedTranslationProxy &&
        Date.now() - lastProxySuccessReportAt > 3e5 &&
        (managedHttpFailureWindows.delete(`${i}:403`),
        managedHttpFailureWindows.delete(`${i}:429`),
        managedTargetCooldowns.delete(`${i}:403`),
        managedTargetCooldowns.delete(`${i}:429`),
        (lastProxySuccessReportAt = Date.now()),
        invokeFunction("proxy-control", {
          action: "report_success",
          proxyId: managedTranslationProxy.id,
        }).catch((p) =>
          console.warn(
            "Unable to report translation proxy success",
            p?.message || p,
          ),
        ));
    }));
}
async function showLoadFailure(n, e, t, r) {
  if (!n || n.isDestroyed()) return;
  const u = await dialog.showMessageBox(n, {
    type: "warning",
    title: "\u7F51\u7AD9\u6253\u5F00\u5931\u8D25",
    message:
      "\u5F53\u524D\u7F51\u7AD9\u65E0\u6CD5\u5728\u6A58\u5B50AI\u52A9\u624B\u4E2D\u6253\u5F00",
    detail: `${e}
${r || "\u7F51\u7EDC\u8FDE\u63A5\u5931\u8D25"}\uFF08${t}\uFF09`,
    buttons: [
      "\u91CD\u8BD5",
      "\u4F7F\u7528\u7CFB\u7EDF\u6D4F\u89C8\u5668\u6253\u5F00",
      "\u5173\u95ED",
    ],
    defaultId: 0,
    cancelId: 2,
  });
  (u.response === 0 && !n.isDestroyed() && (await n.loadURL(e)),
    u.response === 1 && (await shell.openExternal(e)),
    u.response === 2 && !n.isDestroyed() && n.close());
}
function siteCredentialRows(n, e) {
  const t = n?.sites?.[String(e)];
  return Array.isArray(t)
    ? t.filter((r) => r && typeof r == "object")
    : t && typeof t == "object" && (t.username || t.password)
      ? [
          {
            id: "legacy",
            label: String(t.username || "\u8D26\u53F7 1"),
            username: String(t.username || ""),
            password: t.password || "",
          },
        ]
      : [];
}
function publicSiteCredentialRows(n, e) {
  return siteCredentialRows(n, e).map((t) => ({
    id: String(t.id || ""),
    label: String(t.label || t.username || "\u672A\u547D\u540D\u8D26\u53F7"),
    username: String(t.username || ""),
    password: unprotect(t.password),
  }));
}
async function autofillSiteLogin(n, e) {
  const t = siteCredentialRows(readSecureSettings(), e);
  if (t.length !== 1) return;
  const r = t[0] || {},
    u = String(r.username || ""),
    o = unprotect(r.password);
  if (!u && !o) return;
  const a = JSON.stringify({ username: u, password: o });
  await n.webContents.executeJavaScript(
    `(() => { const c=${a}; const visible=e=>e&&e.offsetParent!==null&&!e.disabled; const user=[...document.querySelectorAll('input[type="text"],input[type="email"],input:not([type])')].find(visible); const pass=[...document.querySelectorAll('input[type="password"]')].find(visible); const set=(e,v)=>{if(!e||!v)return; const s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set; s?s.call(e,v):e.value=v; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));}; set(user,c.username); set(pass,c.password); return Boolean(user||pass); })()`,
  );
}
function installReloadShortcuts(n) {
  n.webContents.on("before-input-event", (e, t) => {
    if (t.type !== "keyDown") return;
    const r = String(t.key || "").toLowerCase(),
      u = r === "f5" || (t.control && r === "r" && !t.shift),
      o = t.control && t.shift && r === "r";
    (!u && !o) ||
      (e.preventDefault(),
      o ? n.webContents.reloadIgnoringCache() : n.webContents.reload());
  });
}
function normalizeUsername(n) {
  const e = String(n || "")
    .trim()
    .normalize("NFKC")
    .toLowerCase();
  if (!/^[\p{L}\p{N}][\p{L}\p{N}_.-]{1,31}$/u.test(e))
    throw new Error(
      "\u8D26\u53F7\u9700\u4E3A2-32\u4F4D\u4E2D\u6587\u3001\u5B57\u6BCD\u6216\u6570\u5B57\uFF0C\u53EF\u5305\u542B._-",
    );
  return e;
}
function internalEmailForUsername(n) {
  return /^[a-z0-9][a-z0-9_.-]{2,31}$/.test(n)
    ? `${n}@${config.internalEmailDomain}`
    : `u_${crypto.createHash("sha256").update(n, "utf8").digest("hex").slice(0, 30)}@${config.internalEmailDomain}`;
}
function featureEnabled(n) {
  const e = String(n || ""),
    t = FEATURE_FLAG_PARENTS[e];
  return currentFeatureFlags[e] === !0 && (!t || currentFeatureFlags[t] === !0);
}
function featureDisabledResult(n) {
  return {
    ok: !1,
    code: "FEATURE_DISABLED",
    message: `${n} \u5DF2\u7531\u7BA1\u7406\u5458\u4E34\u65F6\u505C\u7528`,
  };
}
function permissionAllowed(n) {
  const e = String(n || "");
  return currentProfile?.role === "admin" || currentPermissions[e] === !0;
}
function featureAllowed(n) {
  return featureEnabled(n) ? permissionAllowed(n) : !1;
}
function tnFeatureAllowed(n = "tn_accounts") {
  const e = String(n || "tn_accounts");
  return !featureEnabled("module_tn") ||
    !featureEnabled("tn_accounts") ||
    !permissionAllowed("tn_accounts")
    ? !1
    : e === "tn_accounts"
      ? !0
      : permissionAllowed("tn_assistant")
        ? featureEnabled(e) && permissionAllowed(e)
        : !1;
}
function enforceTnAccessState() {
  if (!tnFeatureAllowed("tn_accounts")) {
    for (const n of [...tnBackgroundWindows.keys()]) destroyTnBackground(n);
    (tnVisibleAccounts.clear(),
      workbenchWindow &&
        !workbenchWindow.isDestroyed() &&
        workbenchWindow.webContents.send("workbench:revoke-tn-access", {
          reason:
            "TN\u6743\u9650\u5DF2\u5173\u95ED\u6216\u5DF2\u88AB\u7BA1\u7406\u5458\u6536\u56DE",
        }),
      closeDetachedSiteWindows((n) => n.siteId === "textnow"));
  }
}
async function refreshFeatureFlags() {
  if (!currentSession) return currentFeatureFlags;
  const { data: n, error: e } = await supabase
    .from("app_feature_flags")
    .select("feature_key,enabled");
  if (e)
    return (
      console.warn(
        "Unable to refresh feature flags; risky TN functions remain fail-closed",
        e.message || e,
      ),
      currentFeatureFlags
    );
  const t = { ...FEATURE_FLAG_DEFAULTS };
  for (const o of n || [])
    Object.hasOwn(t, o.feature_key) && (t[o.feature_key] = o.enabled === !0);
  const r = JSON.stringify(t) !== JSON.stringify(currentFeatureFlags);
  currentFeatureFlags = t;
  const u = { ...currentFeatureFlags };
  return (
    mainWindow?.webContents.send("features:changed", u),
    workbenchWindow?.webContents.send("features:changed", u),
    r && (enforceTnAccessState(), syncFeatureFlagsToLoadedExtensions()),
    u
  );
}
function startFeatureFlagPolling() {
  (featureFlagTimer && clearInterval(featureFlagTimer),
    (featureFlagTimer = setInterval(() => {
      refreshFeatureFlags();
    }, 15e3)));
}
function getInstallationId() {
  const n = path.join(app.getPath("userData"), "installation-id");
  let e = "";
  try {
    e = fs.readFileSync(n, "utf8").trim();
  } catch {}
  return (
    /^[a-f0-9-]{36}$/.test(e) ||
      ((e = crypto.randomUUID()),
      fs.mkdirSync(path.dirname(n), { recursive: !0 }),
      fs.writeFileSync(n, e, { encoding: "utf8", mode: 384 })),
    e
  );
}
function getDeviceHash() {
  return crypto
    .createHash("sha256")
    .update(`orange-ai:${getInstallationId()}`)
    .digest("hex");
}
async function loadAccess(n) {
  const { data: e, error: t } = await supabase
    .from("profiles")
    .select(
      "id,username,display_name,role,plan,account_status,valid_from,valid_until,device_limit",
    )
    .eq("id", n)
    .single();
  if (t) throw new Error("\u65E0\u6CD5\u8BFB\u53D6\u8D26\u53F7\u6743\u9650");
  return e;
}
async function refreshCurrentAuthSession() {
  return (
    authRefreshPromise ||
      (authRefreshPromise = supabase.auth
        .refreshSession()
        .then(({ data: n, error: e }) => {
          if (e || !n?.session)
            throw new Error(
              e?.message || "\u767B\u5F55\u4F1A\u8BDD\u5237\u65B0\u5931\u8D25",
            );
          return (
            (currentSession = n.session),
            supabase.realtime.setAuth(currentSession.access_token),
            currentSession
          );
        })
        .finally(() => {
          authRefreshPromise = null;
        })),
    authRefreshPromise
  );
}
async function invokeFunction(n, e) {
  const { data: t } = await supabase.auth.getSession();
  if (
    (t?.session &&
      ((currentSession = t.session),
      supabase.realtime.setAuth(currentSession.access_token)),
    !currentSession)
  )
    throw new Error("\u8BF7\u5148\u767B\u5F55");
  const r = () =>
    supabase.functions.invoke(n, {
      body: e,
      headers: { Authorization: `Bearer ${currentSession.access_token}` },
    });
  let { data: u, error: o } = await r();
  if (Number(o?.context?.status || 0) === 401)
    try {
      (await refreshCurrentAuthSession(), ({ data: u, error: o } = await r()));
    } catch (a) {
      const s = new Error(
        a?.message || "\u767B\u5F55\u4F1A\u8BDD\u5DF2\u5931\u6548",
      );
      throw ((s.status = 401), (s.code = "AUTH_REFRESH_FAILED"), s);
    }
  if (o) {
    let a = u?.message;
    const s = o?.context;
    if (!a && s && typeof s.clone == "function")
      try {
        const c = await s.clone().json();
        a = c?.message || c?.error || c?.msg;
      } catch {}
    const i = new Error(
      errorText(a || o.message, "\u670D\u52A1\u5668\u8BF7\u6C42\u5931\u8D25"),
    );
    throw (
      (i.status = Number(s?.status || 0)),
      (i.code = String(u?.code || "")),
      i
    );
  }
  if (!u?.ok)
    throw new Error(
      errorText(u?.message || u?.error, "\u64CD\u4F5C\u5931\u8D25"),
    );
  return u;
}
async function registerDevice() {
  return (
    (currentDeviceHash = getDeviceHash()),
    invokeFunction("session-control", {
      action: "register",
      deviceHash: currentDeviceHash,
      deviceName: os.hostname(),
      platform: `Windows ${os.release()}`,
    })
  );
}
function startHeartbeat() {
  (heartbeatTimer && clearInterval(heartbeatTimer),
    (heartbeatTimer = setInterval(async () => {
      if (!(!currentSession || !currentDeviceHash)) {
        try {
          const n = await invokeFunction("session-control", {
              action: "heartbeat",
              deviceHash: currentDeviceHash,
            }),
            e = [...allowedSites.keys()].sort().join("|"),
            t = n.permissions || {},
            r = currentProfile?.plan,
            u = JSON.stringify(t) !== JSON.stringify(currentPermissions);
          currentPermissions = t;
          const o = !!(n.profilePlan && currentProfile && n.profilePlan !== r);
          (o &&
            currentProfile?.id &&
            (currentProfile = await loadAccess(currentProfile.id)),
            (u || o) &&
              (mainWindow?.webContents.send("permissions:changed", {
                ...currentPermissions,
              }),
              enforceTnAccessState(),
              syncFeatureFlagsToLoadedExtensions()),
            o
              ? (workbenchWindow &&
                  !workbenchWindow.isDestroyed() &&
                  workbenchWindow.close(),
                await loadWorkSites(),
                closeDetachedSiteWindows(
                  (a) => a.siteId !== "textnow" && !allowedSites.has(a.siteId),
                ),
                mainWindow &&
                  !mainWindow.isDestroyed() &&
                  mainWindow.webContents.reload())
              : (await loadWorkSites(),
                [...allowedSites.keys()].sort().join("|") !== e &&
                  (workbenchWindow &&
                    !workbenchWindow.isDestroyed() &&
                    workbenchWindow.close(),
                  closeDetachedSiteWindows(
                    (a) =>
                      a.siteId !== "textnow" && !allowedSites.has(a.siteId),
                  ),
                  mainWindow &&
                    !mainWindow.isDestroyed() &&
                    mainWindow.webContents.reload())),
            (heartbeatFailureCount = 0));
        } catch (n) {
          const e = String(n?.code || "").toUpperCase(),
            t = String(n?.message || ""),
            r = new Set([
              "INVALID_SESSION",
              "FORCE_LOGOUT",
              "ACCOUNT_DISABLED",
              "DISABLED",
              "PAUSED",
              "EXPIRED",
              "DEVICE_REVOKED",
              "PROFILE_NOT_FOUND",
              "MEMBERSHIP_GRACE_EXPIRED",
            ]),
            u =
              /invalid jwt|jwt expired|账号已(?:失效|停用|暂停|到期)|强制.*(?:下线|登录)|设备.*(?:解绑|撤销)|profile.*not found/i.test(
                t,
              );
          if (r.has(e) || n?.status === 401 || (n?.status === 403 && u) || u) {
            await stopMessagingRealtime();
            for (const o of [...tnBackgroundWindows.keys()])
              destroyTnBackground(o);
            (supabase.auth.stopAutoRefresh(),
              await supabase.auth.signOut().catch(() => {}),
              (currentSession = null),
              (currentProfile = null),
              (currentPermissions = {}),
              (managedTranslationProxy = null),
              closeDetachedSiteWindows(),
              await applyTranslationProxy().catch(() => {}),
              (heartbeatFailureCount = 0),
              mainWindow?.webContents.send(
                "auth:revoked",
                t || "\u8D26\u53F7\u5DF2\u5931\u6548",
              ));
            return;
          }
          ((heartbeatFailureCount += 1),
            console.warn(
              `Heartbeat temporarily failed (${heartbeatFailureCount})`,
              t,
            ),
            mainWindow?.webContents.send("auth:network-warning", {
              failures: heartbeatFailureCount,
              message:
                "\u7F51\u7EDC\u6682\u65F6\u4E0D\u7A33\u5B9A\uFF0C\u6B63\u5728\u81EA\u52A8\u91CD\u8BD5\uFF0C\u8D26\u53F7\u4E0D\u4F1A\u9000\u51FA",
            }));
        }
        try {
          const n = session.fromPartition(workPartition),
            e = await ensureWorkExtensionLoaded(n);
          await syncExtensionAuth(n, e);
        } catch (n) {
          console.error("Unable to refresh extension authentication", n);
        }
      }
    }, 60 * 1e3)));
}
(ipcMain.handle("auth:login", async (n, e) => {
  try {
    const t = normalizeUsername(e?.username),
      r = String(e?.password || "");
    if (!r) throw new Error("\u8BF7\u8F93\u5165\u5BC6\u7801");
    const { data: u, error: o } = await supabase.auth.signInWithPassword({
      email: internalEmailForUsername(t),
      password: r,
    });
    if (o || !u.session)
      throw new Error("\u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF");
    ((currentSession = u.session),
      supabase.auth.startAutoRefresh(),
      (currentProfile = await loadAccess(u.user.id)),
      migrateLegacyTnDataForCurrentUser());
    const a = prepareBeta6FullProfileMigration({ automatic: !0 });
    if (a.count)
      return (
        setTimeout(() => {
          ((isQuitting = !0), app.relaunch(), app.exit(0));
        }, 700),
        {
          ok: !0,
          restarting: !0,
          migrationCount: a.count,
          profile: currentProfile,
          permissions: {},
          featureFlags: { ...currentFeatureFlags },
          sites: [],
          proxyState: {
            active: !1,
            message:
              "\u6B63\u5728\u63A5\u7BA1\u5185\u6D4B\u7248\u5B8C\u6574TN\u72B6\u6001\u5E76\u91CD\u542F",
          },
        }
      );
    (scheduleOwnTnAccountCount(listTnAccounts().length),
      (currentPermissions = (await registerDevice()).permissions || {}),
      (currentProfile = await loadAccess(u.user.id)),
      await refreshFeatureFlags(),
      startFeatureFlagPolling());
    const s = await loadWorkSites();
    (startHeartbeat(), startMessagingRealtime());
    let i = managedProxyState({
      active: !1,
      message:
        "\u767B\u5F55\u6210\u529F\uFF0C\u6B63\u5728\u540E\u53F0\u83B7\u53D6\u53EF\u7528IP",
    });
    return (
      proxyRoutingRequired()
        ? acquireUsableManagedProxy("assignment").catch((c) => {
            (console.warn(
              "Managed translation proxy unavailable",
              c?.message || c,
            ),
              sendManagedProxyState({
                active: !1,
                message:
                  "\u4EE3\u7406\u6C60\u6682\u65F6\u4E0D\u53EF\u7528\uFF0C\u767B\u5F55\u4E0D\u53D7\u5F71\u54CD",
              }));
          })
        : ((managedTranslationProxy = null), await applyTranslationProxy()),
      startProxyHealthSchedulers(),
      setTimeout(() => {
        restoreTnBackgrounds();
      }, 1200),
      {
        ok: !0,
        profile: currentProfile,
        permissions: currentPermissions,
        featureFlags: { ...currentFeatureFlags },
        sites: s,
        proxyState: i,
      }
    );
  } catch (t) {
    return (
      supabase.auth.stopAutoRefresh(),
      await supabase.auth.signOut().catch(() => {}),
      (currentSession = null),
      (currentProfile = null),
      { ok: !1, message: t.message || "\u767B\u5F55\u5931\u8D25" }
    );
  }
}),
  ipcMain.handle("auth:logout", async () => {
    await stopMessagingRealtime();
    for (const n of [...tnBackgroundWindows.keys()]) destroyTnBackground(n);
    return (
      fixedSiteProxies.clear(),
      tnAccountProxies.clear(),
      tnSessionConfigPromises.clear(),
      tnVisibleAccounts.clear(),
      tnRuntimeStates.clear(),
      tnGuestAccounts.clear(),
      supabase.auth.stopAutoRefresh(),
      await supabase.auth.signOut().catch(() => {}),
      (currentSession = null),
      (currentProfile = null),
      (currentPermissions = {}),
      (currentDeviceHash = null),
      (currentFeatureFlags = { ...FEATURE_FLAG_DEFAULTS }),
      featureFlagTimer && clearInterval(featureFlagTimer),
      (featureFlagTimer = null),
      (managedTranslationProxy = null),
      await applyTranslationProxy().catch(() => {}),
      allowedSitePartitions.clear(),
      heartbeatTimer && clearInterval(heartbeatTimer),
      (heartbeatTimer = null),
      assignedProxyHealthTimer && clearInterval(assignedProxyHealthTimer),
      poolHealthTimer && clearInterval(poolHealthTimer),
      (assignedProxyHealthTimer = null),
      (poolHealthTimer = null),
      workbenchWindow &&
        !workbenchWindow.isDestroyed() &&
        workbenchWindow.close(),
      closeDetachedSiteWindows(),
      { ok: !0 }
    );
  }),
  ipcMain.handle("auth:status", async () => {
    if (!currentSession || !currentProfile) return { authenticated: !1 };
    try {
      const n = await loadWorkSites();
      return {
        authenticated: !0,
        profile: currentProfile,
        permissions: currentPermissions,
        featureFlags: { ...currentFeatureFlags },
        sites: n,
      };
    } catch (n) {
      return (
        console.error("Unable to restore renderer session", n),
        {
          authenticated: !1,
          message:
            "\u767B\u5F55\u72B6\u6001\u6062\u590D\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55",
        }
      );
    }
  }),
  ipcMain.handle("features:get", async () => {
    try {
      await refreshFeatureFlags();
    } catch {}
    return { ok: !0, flags: { ...currentFeatureFlags } };
  }),
  ipcMain.handle("auth:change-password", async (n, e) => {
    try {
      if (!currentSession) throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = String(e?.oldPassword || ""),
        r = String(e?.newPassword || "");
      if (r.length < 6)
        throw new Error(
          "\u65B0\u5BC6\u7801\u81F3\u5C116\u4F4D\uFF0C\u53EF\u4F7F\u7528\u7EAF\u6570\u5B57",
        );
      const u = internalEmailForUsername(
        normalizeUsername(currentProfile.username),
      );
      if (
        (await supabase.auth.signInWithPassword({ email: u, password: t }))
          .error
      )
        throw new Error("\u65E7\u5BC6\u7801\u4E0D\u6B63\u786E");
      const { error: o } = await supabase.auth.updateUser({ password: r });
      if (o) throw o;
      return { ok: !0 };
    } catch (t) {
      return {
        ok: !1,
        message: t.message || "\u4FEE\u6539\u5BC6\u7801\u5931\u8D25",
      };
    }
  }),
  ipcMain.handle("secure:get-login", async () => {
    const n = readSecureSettings().login || {};
    return {
      username: n.username || "",
      password: unprotect(n.password),
      rememberUsername: !!n.username,
      rememberPassword: !!n.password,
    };
  }),
  ipcMain.handle("secure:save-login", async (n, e) => {
    const t = readSecureSettings();
    return (
      (t.login = e?.rememberUsername
        ? {
            username: String(e.username || ""),
            password: e?.rememberPassword ? protect(e.password) : "",
          }
        : {}),
      writeSecureSettings(t),
      { ok: !0 }
    );
  }),
  ipcMain.handle("secure:get-site", async (n, e) => {
    const t = publicSiteCredentialRows(readSecureSettings(), e);
    return { accounts: t, ...(t[0] || { username: "", password: "" }) };
  }),
  ipcMain.handle("secure:save-site", async (n, e) => {
    const t = readSecureSettings();
    t.sites ||= {};
    const r = String(e?.siteId || "");
    if (!allowedSites.has(r)) throw new Error("\u7F51\u7AD9\u4E0D\u5B58\u5728");
    let u = siteCredentialRows(t, r);
    const o = String(e?.credentialId || "");
    if (e?.clear) u = o ? u.filter((a) => String(a.id || "") !== o) : [];
    else {
      const a = String(e?.username || "").trim(),
        s = {
          id: o || crypto.randomUUID(),
          label: String(e?.label || a || `\u8D26\u53F7 ${u.length + 1}`).trim(),
          username: a,
          password: protect(e?.password),
        },
        i = u.findIndex((c) => String(c.id || "") === s.id);
      i >= 0 ? (u[i] = s) : u.push(s);
    }
    return (
      u.length ? (t.sites[r] = u) : delete t.sites[r],
      writeSecureSettings(t),
      { ok: !0, accounts: publicSiteCredentialRows(t, r) }
    );
  }),
  ipcMain.handle("secure:get-site-by-url", async (n, e) => {
    const t = siteIdForUrl(e);
    if (!t)
      return { ok: !1, message: "\u5F53\u524D\u7F51\u7AD9\u672A\u767B\u8BB0" };
    const r = publicSiteCredentialRows(readSecureSettings(), t);
    return {
      ok: !0,
      siteId: t,
      accounts: r,
      ...(r[0] || { username: "", password: "" }),
    };
  }),
  ipcMain.handle("secure:save-site-by-url", async (n, e) => {
    const t = siteIdForUrl(e?.url);
    if (!t)
      return { ok: !1, message: "\u5F53\u524D\u7F51\u7AD9\u672A\u767B\u8BB0" };
    const r = readSecureSettings();
    r.sites ||= {};
    let u = siteCredentialRows(r, t);
    const o = String(e?.username || "").trim(),
      a = String(e?.credentialId || "");
    if (!e?.rememberUsername && !e?.rememberPassword)
      u = a
        ? u.filter((s) => String(s.id || "") !== a)
        : u.filter((s) => String(s.username || "") !== o);
    else {
      const s = u.findIndex((l) =>
          a
            ? String(l.id || "") === a
            : String(l.username || "").toLowerCase() === o.toLowerCase(),
        ),
        i = s >= 0 ? u[s] : null,
        c = {
          id: String(i?.id || a || crypto.randomUUID()),
          label: String(
            e?.label || i?.label || o || `\u8D26\u53F7 ${u.length + 1}`,
          ),
          username: e?.rememberUsername || e?.rememberPassword ? o : "",
          password: e?.rememberPassword ? protect(e.password) : "",
        };
      s >= 0 ? (u[s] = c) : u.push(c);
    }
    return (
      u.length ? (r.sites[t] = u) : delete r.sites[t],
      writeSecureSettings(r),
      { ok: !0, accounts: publicSiteCredentialRows(r, t) }
    );
  }));
function savedTnLocalProxyRows() {
  const n = readSecureSettings(),
    e = currentTnOwnerKey();
  return (
    Array.isArray(n.tnLocalProxiesByUser?.[e])
      ? [...n.tnLocalProxiesByUser[e]]
      : []
  ).flatMap((t) => {
    try {
      const r = unprotect(t.encryptedProxy),
        u = parseEmployeeProxy(r);
      return [
        {
          id: String(t.id || u.id),
          raw: r,
          label: u.label,
          endpoint: `${u.host}:${u.port}`,
          limit: Math.max(1, Math.min(1e3, Number(t.limit || 30))),
          updatedAt: String(t.updatedAt || ""),
        },
      ];
    } catch {
      return [];
    }
  });
}
function publicSavedTnLocalProxies() {
  const n = listTnAccounts();
  return savedTnLocalProxyRows().map((e) => ({
    ...e,
    usageCount: n.filter(
      (t) => t.proxyMode === "local" && t.localProxyKey === e.id,
    ).length,
  }));
}
(ipcMain.handle("tn:local-proxy-get", async () =>
  tnFeatureAllowed("tn_accounts")
    ? { ok: !0, proxies: publicSavedTnLocalProxies() }
    : featureDisabledResult("tn_accounts"),
),
  ipcMain.handle("tn:local-proxy-save", async (n, e) => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      const t = String(e?.proxy || "").trim(),
        r = parseEmployeeProxy(t),
        u = Math.max(1, Math.min(1e3, Number(e?.limit || 30))),
        o = String(e?.presetId || ""),
        a = readSecureSettings(),
        s = savedTnLocalProxyRows().filter((i) => i.id !== o && i.id !== r.id);
      if (
        (s.push({
          id: r.id,
          raw: t,
          label: r.label,
          endpoint: `${r.host}:${r.port}`,
          limit: u,
          updatedAt: new Date().toISOString(),
        }),
        (a.tnLocalProxiesByUser =
          a.tnLocalProxiesByUser && typeof a.tnLocalProxiesByUser == "object"
            ? a.tnLocalProxiesByUser
            : {}),
        (a.tnLocalProxiesByUser[currentTnOwnerKey()] = s.map((i) => ({
          id: i.id,
          encryptedProxy: protect(i.raw),
          limit: i.limit,
          updatedAt: i.updatedAt,
        }))),
        writeSecureSettings(a),
        o)
      ) {
        const i = listTnAccounts();
        let c = 0;
        for (let l = 0; l < i.length; l += 1)
          i[l].proxyMode !== "local" ||
            i[l].localProxyKey !== o ||
            (destroyTnBackground(i[l].id),
            tnAccountProxies.delete(i[l].id),
            (i[l] = normalizeTnAccount({
              ...i[l],
              localProxyEncrypted: encryptLocalProxy(r),
              localProxyKey: r.id,
              localProxyLimit: u,
              updatedAt: new Date().toISOString(),
            })),
            tnRuntimeStates.set(i[l].id, {
              status: "saved",
              statusText:
                "\u56FA\u5B9AIP\u5DF2\u66F4\u6362\uFF0C\u7B49\u5F85\u91CD\u65B0\u8FDE\u63A5",
            }),
            (c += 1));
        return (
          c &&
            (saveTnAccounts(i),
            publishTnAccounts(),
            i
              .filter((l) => l.keepAlive && l.localProxyKey === r.id)
              .forEach((l) => void ensureTnBackground(l.id).catch(() => {}))),
          { ok: !0, id: r.id, label: r.label, limit: u, changed: c }
        );
      }
      return { ok: !0, id: r.id, label: r.label, limit: u, changed: 0 };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u56FA\u5B9AIP\u4FDD\u5B58\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("tn:local-proxy-delete", async (n, e) => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      const t = String(e || ""),
        r = listTnAccounts().filter(
          (o) => o.proxyMode === "local" && o.localProxyKey === t,
        ).length;
      if (r)
        throw new Error(
          `\u8FD9\u6761IP\u4ECD\u88AB ${r} \u4E2ATN\u8D26\u53F7\u4F7F\u7528\uFF0C\u8BF7\u5148\u7ED9\u8FD9\u4E9B\u8D26\u53F7\u66F4\u6362IP\u540E\u518D\u5220\u9664`,
        );
      const u = readSecureSettings();
      return (
        (u.tnLocalProxiesByUser =
          u.tnLocalProxiesByUser && typeof u.tnLocalProxiesByUser == "object"
            ? u.tnLocalProxiesByUser
            : {}),
        (u.tnLocalProxiesByUser[currentTnOwnerKey()] = savedTnLocalProxyRows()
          .filter((o) => o.id !== t)
          .map((o) => ({
            id: o.id,
            encryptedProxy: protect(o.raw),
            limit: o.limit,
            updatedAt: o.updatedAt,
          }))),
        writeSecureSettings(u),
        { ok: !0 }
      );
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u5220\u9664\u56FA\u5B9AIP\u5931\u8D25"),
      };
    }
  }));
function nextTnDefaultNumber(n) {
  return (
    n.reduce(
      (e, t) =>
        Math.max(
          e,
          Number(/^TN-?(\d+)$/i.exec(String(t.name || ""))?.[1] || 0),
        ),
      0,
    ) + 1
  );
}
async function clearTextNowCookies(n) {
  const e = (await n.cookies.get({})).filter((t) =>
    String(t.domain || "")
      .replace(/^\./, "")
      .toLowerCase()
      .endsWith("textnow.com"),
  );
  for (const t of e) {
    const r = String(t.domain || "textnow.com").replace(/^\./, ""),
      u = t.secure ? "https" : "http";
    await n.cookies.remove(`${u}://${r}${t.path || "/"}`, t.name);
  }
  return e.length;
}
async function writeTextNowCookies(n, e) {
  const t = [];
  for (const o of e)
    try {
      await n.cookies.set(o);
    } catch (a) {
      t.push(`${o.name}\uFF1A${errorText(a, "\u5199\u5165\u5931\u8D25")}`);
    }
  (await n.cookies.flushStore?.(), await n.flushStorageData());
  const r = (await n.cookies.get({})).filter((o) =>
      String(o.domain || "")
        .replace(/^\./, "")
        .toLowerCase()
        .endsWith("textnow.com"),
    ),
    u = e.filter((o) =>
      r.some((a) => a.name === o.name && a.value === o.value),
    );
  if (!u.length)
    throw new Error(t[0] || "Cookie\u5199\u5165\u540E\u672A\u80FD\u4FDD\u5B58");
  if (t.length)
    throw new Error(
      `\u90E8\u5206Cookie\u5199\u5165\u5931\u8D25\uFF08\u6210\u529F${u.length}\u6761\uFF0C\u5931\u8D25${t.length}\u6761\uFF09\uFF1A${t.slice(0, 3).join("\uFF1B")}`,
    );
  return {
    storedCount: u.length,
    totalStoredCount: r.length,
    hasSessionCookie: r.some((o) =>
      /^(?:connect\.sid|session|sessionid|auth|token)$/i.test(o.name),
    ),
  };
}
async function configureTnSessionNow(n) {
  const e = tnAccountById(n);
  if (!e) throw new Error("TN\u8D26\u53F7\u4E0D\u5B58\u5728");
  const t = tnPartition(n),
    r = session.fromPartition(t);
  let u = null;
  if (e.proxyMode === "local") u = decryptLocalProxy(e);
  else {
    if (!e.proxyGroupId)
      throw new Error(
        "\u6B64TN\u8D26\u53F7\u5C1A\u672A\u9009\u62E9\u7BA1\u7406\u5458\u56FA\u5B9AIP\u5206\u7EC4",
      );
    u =
      (
        await invokeFunction("proxy-control", {
          action: "tn_fixed",
          groupId: e.proxyGroupId,
        })
      )?.proxy || null;
  }
  if (!u?.host || !u?.port)
    throw new Error(
      "TN\u56FA\u5B9AIP\u4E0D\u53EF\u7528\uFF1B\u5DF2\u963B\u6B62\u672C\u673A\u76F4\u8FDE",
    );
  const o = tnAccountProxies.get(e.id) || null,
    a =
      !o ||
      o.id !== u.id ||
      o.host !== u.host ||
      Number(o.port) !== Number(u.port);
  if ((tnAccountProxies.set(e.id, u), a)) {
    const c = `${u.protocol || "http"}://${u.host}:${Number(u.port)}`;
    (await r.setProxy({ proxyRules: c, proxyBypassRules: "<-loopback>" }),
      await r.closeAllConnections?.());
  }
  const s = await probeProxyThroughSession(r, u, 8e3);
  if (!s.healthy)
    throw (
      tnRuntimeStates.set(e.id, {
        status: "disconnected",
        statusText: `\u56FA\u5B9AIP\u68C0\u6D4B\u5931\u8D25\uFF1A${s.error || "\u8FDE\u63A5\u5931\u8D25"}`,
        proxyLabel: u.label || u.host,
      }),
      publishTnAccounts(),
      new Error(
        `\u56FA\u5B9AIP\u68C0\u6D4B\u5931\u8D25\uFF0C\u5DF2\u963B\u6B62\u672C\u673A\u76F4\u8FDE\uFF1A${s.error || "\u8FDE\u63A5\u5931\u8D25"}`,
      )
    );
  (tnRuntimeStates.set(e.id, {
    status: "saved",
    statusText: `\u56FA\u5B9AIP\u5DF2\u8FDE\u63A5 \xB7 \u51FA\u53E3 ${s.exitIp}`,
    exitIp: s.exitIp,
    proxyLabel: u.label || u.host,
  }),
    r.setPermissionRequestHandler((c, l, d) => d(tnStablePermissionAllowed(l))),
    installTnAdBlocker(r, t));
  const i = await ensureTnStableExtensionLoaded(r);
  return (
    await syncExtensionAuth(r, i),
    { partition: t, accountSession: r, proxy: u, exitIp: s.exitIp }
  );
}
function installTnAdBlocker(n, e) {
  if (tnAdBlockInstalled.has(e)) return;
  tnAdBlockInstalled.add(e);
  const t =
    /(^|\.)(doubleclick\.net|googlesyndication\.com|googleadservices\.com|amazon-adsystem\.com|adsrvr\.org|adnxs\.com|rubiconproject\.com|pubmatic\.com|criteo\.com|criteo\.net|taboola\.com|outbrain\.com|scorecardresearch\.com)$/i;
  n.webRequest.onBeforeRequest({ urls: ["*://*/*"] }, (r, u) => {
    try {
      u({ cancel: t.test(new URL(r.url).hostname) });
    } catch {
      u({ cancel: !1 });
    }
  });
}
async function configureTnSession(n) {
  const e = String(n || "");
  if (tnSessionConfigPromises.has(e)) return tnSessionConfigPromises.get(e);
  const t = configureTnSessionNow(e).finally(() =>
    tnSessionConfigPromises.delete(e),
  );
  return (tnSessionConfigPromises.set(e, t), t);
}
function destroyTnBackground(n) {
  const e = tnBackgroundWindows.get(n);
  (tnBackgroundWindows.delete(n), e && !e.isDestroyed() && e.destroy());
}
function liveTnBackground(n) {
  const e = tnBackgroundWindows.get(n);
  return e
    ? e.isDestroyed() || e.webContents?.isDestroyed?.()
      ? (tnBackgroundWindows.delete(n), null)
      : e
    : null;
}
async function ensureTnBackground(n, e = 0) {
  const t = tnAccountById(n);
  if (
    isQuitting ||
    !t?.keepAlive ||
    !currentSession ||
    tnVisibleAccounts.has(t.id) ||
    liveTnBackground(t.id) ||
    (e && (await new Promise((a) => setTimeout(a, e))),
    isQuitting ||
      !currentSession ||
      tnVisibleAccounts.has(t.id) ||
      liveTnBackground(t.id) ||
      !tnAccountById(t.id)?.keepAlive)
  )
    return;
  const { partition: r } = await configureTnSession(t.id);
  if (
    isQuitting ||
    !currentSession ||
    tnVisibleAccounts.has(t.id) ||
    liveTnBackground(t.id) ||
    !tnAccountById(t.id)?.keepAlive
  )
    return;
  const u = new BrowserWindow({
    show: !1,
    width: TN_STABLE_BASE.backgroundWindow.width,
    height: TN_STABLE_BASE.backgroundWindow.height,
    title: `TN\u540E\u53F0 - ${t.name}`,
    webPreferences: backgroundWebPreferences(
      r,
      path.join(__dirname, "site-preload.js"),
    ),
  });
  tnBackgroundWindows.set(t.id, u);
  const o = (a, s) => {
    if (u.isDestroyed() || u.webContents.isDestroyed()) return;
    let i = "";
    try {
      i = u.webContents.getURL() || "";
    } catch {}
    (tnRuntimeStates.set(t.id, {
      ...(tnRuntimeStates.get(t.id) || {}),
      status: a,
      statusText: s,
      lastUrl: i,
    }),
      publishTnAccounts());
  };
  (u.webContents.on("did-finish-load", () => {
    const a = u.webContents.getURL();
    o(
      a.includes("/messaging") ? "connected" : "verification",
      a.includes("/messaging")
        ? "\u540E\u53F0\u8FDE\u63A5\u4E2D"
        : "\u9700\u8981\u767B\u5F55\u6216\u9A8C\u8BC1",
    );
  }),
    u.webContents.on("render-process-gone", () =>
      o(
        "disconnected",
        "\u540E\u53F0\u9875\u9762\u5DF2\u4E2D\u65AD\uFF0C\u6B63\u5728\u7B49\u5F85\u6062\u590D",
      ),
    ),
    u.on("closed", () => {
      tnBackgroundWindows.get(t.id) === u && tnBackgroundWindows.delete(t.id);
    }),
    await u.loadURL(TN_STABLE_BASE.messagingUrl).catch((a) => {
      /object has been destroyed/i.test(errorText(a, "")) ||
        o("disconnected", errorText(a, "\u8FDE\u63A5\u5931\u8D25"));
    }));
}
function restoreTnBackgrounds() {
  tnFeatureAllowed("tn_accounts") &&
    listTnAccounts()
      .filter((n) => n.keepAlive)
      .forEach((n, e) => {
        ensureTnBackground(n.id, e * 1500).catch((t) => {
          (tnRuntimeStates.set(n.id, {
            status: "disconnected",
            statusText: t?.message || "\u540E\u53F0\u542F\u52A8\u5931\u8D25",
          }),
            publishTnAccounts());
        });
      });
}
ipcMain.handle("tn:list", () =>
  tnFeatureAllowed("tn_accounts")
    ? { ok: !0, accounts: publishTnAccounts() }
    : featureDisabledResult("tn_accounts"),
);
function tnWebContentsForAccount(n) {
  const e = liveTnBackground(n);
  if (e?.webContents && !e.webContents.isDestroyed()) return e.webContents;
  let t;
  try {
    t = session.fromPartition(tnPartition(n));
  } catch {
    return null;
  }
  return (
    webContents.getAllWebContents().find((r) => {
      if (r.isDestroyed?.()) return !1;
      try {
        return (
          r.session === t &&
          /(^|\.)textnow\.com$/i.test(new URL(r.getURL()).hostname)
        );
      } catch {
        return !1;
      }
    }) || null
  );
}
async function inspectTnDom(n) {
  const e = tnAccountById(n);
  if (!e) throw new Error("TN\u8D26\u53F7\u4E0D\u5B58\u5728");
  let t = tnWebContentsForAccount(e.id);
  if (
    (!t &&
      e.keepAlive &&
      (await ensureTnBackground(e.id), (t = tnWebContentsForAccount(e.id))),
    !t)
  )
    throw new Error("\u8BE5TN\u9875\u9762\u5C1A\u672A\u6253\u5F00");
  const r = JSON.stringify(TN_DOM_SELECTORS),
    u = await t.executeJavaScript(`(() => {
    const selectors=${r};
    const found={};
    for (const [name, selector] of Object.entries(selectors)) found[name]=Boolean(document.querySelector(selector));
    const recipientText=document.querySelector(selectors.recipientNumber)?.textContent || "";
    const digits=String(recipientText).replace(/\\D/g, "");
    const send=document.querySelector(selectors.sendButton);
    const required=["newTextButton","messageInput","sendButton","messageView"];
    return {
      found,
      ready:required.every(name => found[name]),
      newConversationOpen:found.newConversationForm,
      selectedRecipient:digits.length === 11 && digits.startsWith("1") ? digits.slice(1) : digits,
      sendButtonVisible:Boolean(send && getComputedStyle(send).display !== "none" && send.getClientRects().length),
      pageVersion:document.querySelector('meta[name="TN-WEB-VERSION"]')?.content || "",
      url:location.origin + location.pathname
    };
  })()`);
  return { ok: !0, accountId: e.id, accountName: e.name, ...u };
}
ipcMain.handle("tn:test-dom", async (n, e) => {
  try {
    if (!tnFeatureAllowed("tn_dom_test"))
      return featureDisabledResult("tn_dom_test");
    const t = Array.isArray(e?.accountIds) ? e.accountIds.map(String) : [];
    if (!t.length)
      throw new Error(
        "\u8BF7\u9009\u62E9\u81F3\u5C11\u4E00\u4E2ATN\u8D26\u53F7",
      );
    const r = [];
    for (const u of t.slice(0, 100))
      try {
        r.push(await inspectTnDom(u));
      } catch (o) {
        r.push({
          ok: !1,
          accountId: u,
          accountName: tnAccountById(u)?.name || "TN",
          message: errorText(o, "\u5B9A\u4F4D\u6D4B\u8BD5\u5931\u8D25"),
        });
      }
    return { ok: r.every((u) => u.ok && u.ready), results: r };
  } catch (t) {
    return {
      ok: !1,
      message: errorText(t, "TN\u5B9A\u4F4D\u6D4B\u8BD5\u5931\u8D25"),
      results: [],
    };
  }
});
async function performTnSend(n, e = "tn_live_test") {
  try {
    if (!tnFeatureAllowed(e)) return featureDisabledResult(e);
    const t = String(n?.accountId || ""),
      r = normalizeTnPhone(n?.phone),
      u = String(n?.message || "").trim();
    if (!/^\d{10}$/.test(r))
      throw new Error(
        "\u6D4B\u8BD5\u5B9E\u53D1\u4EC5\u63A5\u53D710\u4F4D\u7F8E\u56FD/\u52A0\u62FF\u5927\u53F7\u7801",
      );
    if (!u || u.length > 14e3)
      throw new Error(
        "\u8BDD\u672F\u5FC5\u987B\u4E3A1\u201314000\u4E2A\u5B57\u7B26",
      );
    const o = tnAccountById(t);
    if (!o) throw new Error("TN\u8D26\u53F7\u4E0D\u5B58\u5728");
    const a = tnRecipientFingerprint(r);
    if (hasTnSentFingerprint(a))
      return {
        ok: !1,
        status: "blocked",
        reason: "duplicate_recipient",
        accountId: o.id,
        accountName: o.name,
        fingerprint: a,
        message:
          "\u8BE5\u53F7\u7801\u5DF2\u786E\u8BA4\u53D1\u9001\u8FC7\uFF0C\u5DF2\u963B\u6B62\u91CD\u590D\u53D1\u9001",
      };
    let s = tnWebContentsForAccount(o.id);
    if (
      (!s &&
        o.keepAlive &&
        (await ensureTnBackground(o.id), (s = tnWebContentsForAccount(o.id))),
      !s)
    )
      throw new Error("\u8BE5TN\u9875\u9762\u5C1A\u672A\u6253\u5F00");
    const i = JSON.stringify(TN_DOM_SELECTORS),
      c = JSON.stringify({ phone: r, message: u }),
      l = await s.executeJavaScript(`(async () => {
      const selectors=${i};
      const input=${c};
      const waitFor=async (read, timeout=8000) => {
        const started=Date.now(); let value;
        while (Date.now()-started < timeout) { value=read(); if (value) return value; await new Promise(resolve=>setTimeout(resolve,100)); }
        return null;
      };
      const normalize=value => { const digits=String(value||"").replace(/\\D/g,""); return digits.length===11&&digits.startsWith("1")?digits.slice(1):digits; };
      const setNative=(element,value) => {
        const proto=element instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
        const setter=Object.getOwnPropertyDescriptor(proto,"value")?.set;
        setter?setter.call(element,value):(element.value=value);
        element.dispatchEvent(new InputEvent("input",{bubbles:true,inputType:"insertText",data:value}));
        element.dispatchEvent(new Event("change",{bubbles:true}));
      };
      document.querySelector(selectors.newTextButton)?.click();
      const recipientInput=await waitFor(()=>document.querySelector(selectors.recipientInput));
      if (!recipientInput) return { status:"blocked", reason:"recipient_input_missing" };
      setNative(recipientInput,input.phone);
      recipientInput.focus();
      await new Promise(resolve=>setTimeout(resolve,500));
      recipientInput.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:true}));
      recipientInput.dispatchEvent(new KeyboardEvent("keyup",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:true}));
      const recipientNode=await waitFor(()=>document.querySelector(selectors.recipientNumber));
      if (!recipientNode) return { status:"blocked", reason:"recipient_not_confirmed" };
      const selectedRecipient=normalize(recipientNode.textContent);
      if (selectedRecipient!==input.phone) return { status:"blocked", reason:"recipient_mismatch", selectedRecipient };
      const textarea=await waitFor(()=>document.querySelector(selectors.messageInput));
      if (!textarea) return { status:"blocked", reason:"message_input_missing" };
      const cleanText=node=>{ const clone=node.cloneNode(true); clone.querySelectorAll(".ai-bt-generated").forEach(item=>item.remove()); return String(clone.textContent||"").trim(); };
      const before=[...document.querySelectorAll(selectors.outgoingMessage)].map(cleanText);
      setNative(textarea,input.message);
      const send=await waitFor(()=>{ const node=document.querySelector(selectors.sendButton); return node&&getComputedStyle(node).display!=="none"&&node.getClientRects().length?node:null; });
      if (!send) return { status:"blocked", reason:"send_button_unavailable" };
      send.click();
      const confirmed=await waitFor(()=>{
        const after=[...document.querySelectorAll(selectors.outgoingMessage)].map(cleanText);
        return after.length>before.length && after.slice(before.length).some(text=>text===input.message);
      },15000);
      return confirmed ? { status:"sent", selectedRecipient } : { status:"uncertain", reason:"outgoing_confirmation_timeout", selectedRecipient };
    })()`);
    return (
      l?.status === "sent" && recordTnSentFingerprint(a),
      {
        ok: l?.status === "sent",
        accountId: o.id,
        accountName: o.name,
        fingerprint: a,
        ...l,
      }
    );
  } catch (t) {
    return {
      ok: !1,
      status: "blocked",
      message: errorText(
        t,
        e === "tn_sender"
          ? "TN\u53D1\u9001\u5931\u8D25"
          : "\u6D4B\u8BD5\u53D1\u9001\u5931\u8D25",
      ),
    };
  }
}
(ipcMain.handle("tn:test-send", async (n, e) =>
  performTnSend(e, "tn_live_test"),
),
  ipcMain.handle("tn:send-one", async (n, e) => performTnSend(e, "tn_sender")),
  ipcMain.handle("tn:import-beta6-state", async () => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      const n = prepareBeta6FullProfileMigration({ automatic: !1 });
      return (
        setTimeout(() => {
          ((isQuitting = !0), app.relaunch(), app.exit(0));
        }, 900),
        { ok: !0, count: n.count }
      );
    } catch (n) {
      return {
        ok: !1,
        message: errorText(n, "Beta.6 TN\u72B6\u6001\u5BFC\u5165\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("tn:admin-counts", async () => {
    try {
      if (currentProfile?.role !== "admin")
        throw new Error(
          "\u4EC5\u7BA1\u7406\u5458\u53EF\u67E5\u770BTN\u8D26\u53F7\u6570\u91CF",
        );
      const { data: n, error: e } = await supabase.rpc(
        "list_tn_account_counts",
      );
      if (e) throw e;
      return { ok: !0, counts: Array.isArray(n) ? n : [] };
    } catch (n) {
      return {
        ok: !1,
        message: errorText(
          n,
          "\u8BFB\u53D6TN\u8D26\u53F7\u6570\u91CF\u5931\u8D25",
        ),
      };
    }
  }),
  ipcMain.handle("tn:inspect-cookies", (n, e) => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      const t = inspectTnCookiePayloads(e);
      return {
        ok: !0,
        detected: t.detected,
        valid: t.valid.length,
        invalid: t.invalid.length,
        cookieCounts: t.valid.map((r) => r.cookieCount),
        errors: t.invalid.slice(0, 5),
      };
    } catch (t) {
      return { ok: !1, message: errorText(t, "CK\u8BC6\u522B\u5931\u8D25") };
    }
  }),
  ipcMain.handle("tn:list-groups", async () => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      if (!currentSession) throw new Error("\u8BF7\u5148\u767B\u5F55");
      return await invokeFunction("proxy-control", { action: "tn_groups" });
    } catch (n) {
      return {
        ok: !1,
        message:
          n?.message || "\u8BFB\u53D6TN\u56FA\u5B9AIP\u5206\u7EC4\u5931\u8D25",
      };
    }
  }),
  ipcMain.handle("tn:add", async (n, e) => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      if (!currentSession) throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = String(e?.cookies || "").trim(),
        r = t
          ? inspectTnCookiePayloads(t)
          : { detected: 0, valid: [], invalid: [] };
      if (t && !r.valid.length)
        throw new Error(
          "\u6CA1\u6709\u8BC6\u522B\u5230\u6709\u6548\u7684TextNow CK",
        );
      if (r.invalid.length) {
        const m = r.invalid
          .slice(0, 3)
          .map((p) => `\u7B2C${p.index}\u4EFD\uFF1A${p.message}`)
          .join("\uFF1B");
        throw new Error(
          `\u8BC6\u522B\u5230 ${r.detected} \u4EFDCK\uFF0C\u5176\u4E2D ${r.invalid.length} \u4EFD\u65E0\u6548\u3002${m}`,
        );
      }
      const u = r.valid.length ? r.valid.map((m) => m.batch) : [""],
        o = e?.proxyMode === "local" ? "local" : "managed";
      let a = {},
        s = [];
      if (o === "local") {
        const m = parseEmployeeProxy(e?.localProxy),
          p = m.id,
          h = Math.max(1, Math.min(1e3, Number(e?.localProxyLimit || 30))),
          g = listTnAccounts().filter(
            (F) => F.proxyMode === "local" && F.localProxyKey === p,
          ).length,
          w = h - g;
        if (w < u.length)
          throw new Error(
            `\u8FD9\u6761\u5458\u5DE5\u56FA\u5B9AIP\u53EA\u5269 ${w} \u4E2A\u9875\u9762\u5BB9\u91CF\uFF0C\u672C\u6B21\u6709 ${u.length} \u4EFDCK`,
          );
        a = {
          proxyMode: o,
          groupName: "\u5458\u5DE5\u81EA\u7528IP",
          proxyGroupId: "",
          localProxyEncrypted: encryptLocalProxy(m),
          localProxyKey: p,
          localProxyLimit: h,
        };
      } else {
        const m = (
          (await invokeFunction("proxy-control", { action: "tn_groups" }))
            ?.groups || []
        ).filter((g) => g.proxyEnabled !== !1);
        if (!m.length)
          throw new Error(
            "\u7BA1\u7406\u5458\u5C1A\u672A\u5206\u914D\u53EF\u7528\u7684TN\u56FA\u5B9AIP\u5206\u7EC4",
          );
        const p = String(e?.proxyGroupId || "");
        m.sort((g, w) => +(w.id === p) - +(g.id === p));
        const h = new Map();
        for (const g of listTnAccounts())
          h.set(g.proxyGroupId, (h.get(g.proxyGroupId) || 0) + 1);
        for (let g = 0; g < u.length; g += 1) {
          const w = m.find(
            (F) =>
              F.maxAccounts === null ||
              (h.get(F.id) || 0) < Number(F.maxAccounts),
          );
          if (!w)
            throw new Error(
              `TN\u56FA\u5B9AIP\u603B\u5BB9\u91CF\u4E0D\u8DB3\uFF1A\u672C\u6B21\u7B2C ${g + 1} \u4E2A\u8D26\u53F7\u6CA1\u6709\u53EF\u7528IP\uFF0C\u8BF7\u589E\u52A0\u5206\u7EC4\u6216\u5BB9\u91CF`,
            );
          (s.push({ proxyMode: o, groupName: w.groupName, proxyGroupId: w.id }),
            h.set(w.id, (h.get(w.id) || 0) + 1));
        }
        a = s[0] || {};
      }
      const i = listTnAccounts(),
        c = nextTnDefaultNumber(i),
        l = String(e?.name || "").trim(),
        d = [];
      for (let m = 0; m < u.length; m += 1) {
        const p = l ? (u.length > 1 ? `${l}${m + 1}` : l) : `TN${c + m}`,
          h = (o === "managed" && s[m]) || a,
          g = normalizeTnAccount({
            id: crypto.randomUUID(),
            name: p,
            ...h,
            keepAlive: e?.keepAlive !== !1,
          });
        if ((i.push(g), saveTnAccounts(i), String(u[m] || "").trim())) {
          const w = parseTnCookiePayload(u[m]),
            { accountSession: F } = await configureTnSession(g.id),
            y = await writeTextNowCookies(F, w);
          tnRuntimeStates.set(g.id, {
            status: "saved",
            statusText: `\u5DF2\u5199\u5165 ${y.storedCount} \u6761Cookie\uFF0C\u6B63\u5728\u9A8C\u8BC1\u767B\u5F55`,
          });
        }
        (g.keepAlive && ensureTnBackground(g.id).catch(() => {}),
          d.push(publicTnAccount(g)));
      }
      return {
        ok: !0,
        account: d[0],
        accounts: d,
        count: d.length,
        cookieCounts: r.valid.map((m) => m.cookieCount),
        blank: !t,
      };
    } catch (t) {
      return {
        ok: !1,
        message: t?.message || "\u6DFB\u52A0TN\u8D26\u53F7\u5931\u8D25",
      };
    }
  }),
  ipcMain.handle("tn:update", async (n, e) => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      const t = listTnAccounts(),
        r = t.findIndex((a) => a.id === String(e?.accountId || ""));
      if (r < 0) throw new Error("TN\u8D26\u53F7\u4E0D\u5B58\u5728");
      let u = {};
      const o = e?.proxyMode;
      if (o === "managed") {
        const a = (
          (await invokeFunction("proxy-control", { action: "tn_groups" }))
            ?.groups || []
        ).find((i) => i.id === String(e.proxyGroupId || ""));
        if (!a)
          throw new Error(
            "\u6240\u9009TN\u56FA\u5B9AIP\u5206\u7EC4\u4E0D\u5B58\u5728",
          );
        const s = t.filter((i, c) => c !== r && i.proxyGroupId === a.id).length;
        if (a.maxAccounts !== null && s >= Number(a.maxAccounts))
          throw new Error(
            `\u5206\u7EC4\u5DF2\u6EE1\uFF08\u6700\u591A${a.maxAccounts}\u4E2A\u8D26\u53F7\uFF09`,
          );
        u = {
          proxyMode: "managed",
          groupName: a.groupName,
          proxyGroupId: a.id,
          localProxyEncrypted: "",
          localProxyKey: "",
          localProxyLimit: 30,
        };
      } else if (o === "local" && String(e?.localProxy || "").trim()) {
        const a = parseEmployeeProxy(e.localProxy),
          s = Math.max(1, Math.min(1e3, Number(e.localProxyLimit || 30)));
        if (
          t.filter(
            (i, c) =>
              c !== r && i.proxyMode === "local" && i.localProxyKey === a.id,
          ).length >= s
        )
          throw new Error(
            `\u8FD9\u6761\u5458\u5DE5\u56FA\u5B9AIP\u5DF2\u6EE1\uFF08\u6700\u591A${s}\u4E2A\u8D26\u53F7\uFF09`,
          );
        u = {
          proxyMode: "local",
          groupName: "\u5458\u5DE5\u81EA\u7528IP",
          proxyGroupId: "",
          localProxyEncrypted: encryptLocalProxy(a),
          localProxyKey: a.id,
          localProxyLimit: s,
        };
      } else if (
        e?.proxyGroupId !== void 0 &&
        String(e.proxyGroupId) !== t[r].proxyGroupId
      ) {
        const a = (
          (await invokeFunction("proxy-control", { action: "tn_groups" }))
            ?.groups || []
        ).find((i) => i.id === String(e.proxyGroupId || ""));
        if (!a)
          throw new Error(
            "\u6240\u9009TN\u56FA\u5B9AIP\u5206\u7EC4\u4E0D\u5B58\u5728",
          );
        const s = t.filter((i, c) => c !== r && i.proxyGroupId === a.id).length;
        if (a.maxAccounts !== null && s >= Number(a.maxAccounts))
          throw new Error(
            `\u5206\u7EC4\u5DF2\u6EE1\uFF08\u6700\u591A${a.maxAccounts}\u4E2A\u8D26\u53F7\uFF09`,
          );
        u = {
          proxyMode: "managed",
          groupName: a.groupName,
          proxyGroupId: a.id,
          localProxyEncrypted: "",
          localProxyKey: "",
          localProxyLimit: 30,
        };
      }
      return (
        Object.keys(u).length &&
          (destroyTnBackground(t[r].id),
          tnAccountProxies.delete(t[r].id),
          tnRuntimeStates.set(t[r].id, {
            status: "saved",
            statusText:
              "\u56FA\u5B9AIP\u5DF2\u66F4\u6362\uFF0C\u7B49\u5F85\u91CD\u65B0\u8FDE\u63A5",
          })),
        (t[r] = normalizeTnAccount({
          ...t[r],
          name: e?.name ?? t[r].name,
          keepAlive: e?.keepAlive ?? t[r].keepAlive,
          ...u,
          updatedAt: new Date().toISOString(),
        })),
        saveTnAccounts(t),
        t[r].keepAlive
          ? ensureTnBackground(t[r].id).catch(() => {})
          : destroyTnBackground(t[r].id),
        { ok: !0, account: publicTnAccount(t[r]) }
      );
    } catch (t) {
      return {
        ok: !1,
        message: t?.message || "\u4FDD\u5B58TN\u8D26\u53F7\u5931\u8D25",
      };
    }
  }),
  ipcMain.handle("tn:import-cookies", async (n, e) => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      const t = parseTnCookiePayload(e?.cookies),
        r = String(e?.accountId || "");
      if (!tnAccountById(r))
        throw new Error("TN\u8D26\u53F7\u4E0D\u5B58\u5728");
      destroyTnBackground(r);
      const { accountSession: u } = await configureTnSession(e?.accountId),
        o = await writeTextNowCookies(u, t);
      return (
        tnRuntimeStates.set(r, {
          status: "saved",
          statusText: `\u5DF2\u5199\u5165 ${o.storedCount} \u6761Cookie\uFF0C\u6B63\u5728\u9A8C\u8BC1\u767B\u5F55`,
        }),
        tnAccountById(r)?.keepAlive && ensureTnBackground(r).catch(() => {}),
        { ok: !0, count: o.storedCount, verifying: !0 }
      );
    } catch (t) {
      return {
        ok: !1,
        message: t?.message || "Cookie\u5BFC\u5165\u5931\u8D25",
      };
    }
  }),
  ipcMain.handle("tn:clear-cookies", async (n, e) => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      const t = session.fromPartition(tnPartition(e));
      return (
        await clearTextNowCookies(t),
        await t.cookies.flushStore?.(),
        destroyTnBackground(String(e)),
        tnRuntimeStates.set(String(e), {
          status: "verification",
          statusText:
            "Cookie\u5DF2\u6E05\u9664\uFF0C\u7B49\u5F85\u91CD\u65B0\u5BFC\u5165",
        }),
        { ok: !0 }
      );
    } catch (t) {
      return {
        ok: !1,
        message: t?.message || "\u6E05\u9664Cookie\u5931\u8D25",
      };
    }
  }),
  ipcMain.handle("tn:delete", async (n, e) => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      const t = String(e || ""),
        r = tnPartition(t);
      destroyTnBackground(t);
      const u = session.fromPartition(r);
      return (
        await u.clearStorageData(),
        await u.flushStorageData(),
        saveTnAccounts(listTnAccounts().filter((o) => o.id !== t)),
        tnRuntimeStates.delete(t),
        tnAccountProxies.delete(t),
        tnVisibleAccounts.delete(t),
        { ok: !0 }
      );
    } catch (t) {
      return {
        ok: !1,
        message: t?.message || "\u5220\u9664TN\u8D26\u53F7\u5931\u8D25",
      };
    }
  }),
  ipcMain.handle("tn:open", async (n, e) => {
    try {
      if (!tnFeatureAllowed("tn_accounts"))
        return featureDisabledResult("tn_accounts");
      const t = tnAccountById(e);
      if (!t) throw new Error("TN\u8D26\u53F7\u4E0D\u5B58\u5728");
      const { partition: r } = await configureTnSession(t.id);
      (tnVisibleAccounts.add(t.id), destroyTnBackground(t.id));
      const u =
        workbenchWindow && !workbenchWindow.isDestroyed()
          ? workbenchWindow
          : createWorkbenchWindow();
      return (
        await openWorkbenchTabLike113(u, {
          siteId: "textnow",
          accountId: t.id,
          partition: r,
          url: "https://www.textnow.com/messaging",
          title: `TN \xB7 ${t.name}`,
        }),
        { ok: !0 }
      );
    } catch (t) {
      return {
        ok: !1,
        message: t?.message || "\u6253\u5F00TN\u8D26\u53F7\u5931\u8D25",
      };
    }
  }),
  ipcMain.handle("tn:tab-visibility", async (n, e) => {
    if (!tnFeatureAllowed("tn_accounts"))
      return featureDisabledResult("tn_accounts");
    const t = String(e?.accountId || "");
    return tnAccountById(t)
      ? (e?.open === !0
          ? (tnVisibleAccounts.add(t),
            destroyTnBackground(t),
            tnRuntimeStates.set(t, {
              ...(tnRuntimeStates.get(t) || {}),
              status: "connected",
              statusText: "\u5DF2\u5728\u5DE5\u4F5C\u53F0\u6253\u5F00",
            }),
            publishTnAccounts())
          : (tnVisibleAccounts.delete(t),
            tnRuntimeStates.set(t, {
              ...(tnRuntimeStates.get(t) || {}),
              status: "saved",
              statusText:
                "\u9875\u9762\u5DF2\u5173\u95ED\uFF0C\u767B\u5F55\u72B6\u6001\u5DF2\u4FDD\u7559",
            }),
            publishTnAccounts(),
            tnAccountById(t)?.keepAlive &&
              ensureTnBackground(t).catch((r) => {
                const u = errorText(r, "\u540E\u53F0\u8FDE\u63A5\u5931\u8D25");
                /object has been destroyed/i.test(u) ||
                  (tnRuntimeStates.set(t, {
                    ...(tnRuntimeStates.get(t) || {}),
                    status: "disconnected",
                    statusText: u,
                  }),
                  publishTnAccounts());
              })),
        { ok: !0 })
      : { ok: !1 };
  }),
  ipcMain.handle("proxy:get", async () => managedProxyState()),
  ipcMain.handle("proxy:save", async (n, e) => {
    try {
      if (!currentSession) throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = readSecureSettings();
      if (
        ((t.proxy ||= {}),
        (t.proxy.employeeEnabled = e?.enabled === !0),
        writeSecureSettings(t),
        !t.proxy.employeeEnabled && proxiedSiteHosts.size === 0)
      )
        return (
          (managedTranslationProxy = null),
          await applyTranslationProxy(),
          { ok: !0, ...sendManagedProxyState({ mode: "direct" }) }
        );
      try {
        if ((await acquireUsableManagedProxy("assignment"))?.mode === "denied")
          return {
            ok: !0,
            ...managedProxyState({
              active: !1,
              message:
                "\u7BA1\u7406\u5458\u672A\u5F00\u653E\u6B64\u8D26\u53F7\u4F7F\u7528\u7FFB\u8BD1IP",
            }),
          };
      } catch (r) {
        return (
          console.warn(
            "Managed translation proxy unavailable",
            r?.message || r,
          ),
          {
            ok: !0,
            ...sendManagedProxyState({
              active: !1,
              message:
                "\u7FFB\u8BD1IP\u5DF2\u5F00\u542F\uFF0C\u4F46\u4EE3\u7406\u6C60\u6682\u65F6\u4E0D\u53EF\u7528",
            }),
          }
        );
      }
      return { ok: !0, ...managedProxyState() };
    } catch (t) {
      return {
        ok: !1,
        message:
          t?.message || "\u4FDD\u5B58\u7FFB\u8BD1IP\u8BBE\u7F6E\u5931\u8D25",
      };
    }
  }));
async function testManagedProxy(n) {
  const e = (
    await invokeFunction("admin-users", {
      action: "get_proxy_secret",
      proxyId: n,
    })
  ).proxy;
  if (!e?.host || !e?.port)
    throw new Error("\u4EE3\u7406\u8D44\u6599\u4E0D\u5B8C\u6574");
  const t = session.fromPartition(`orange-proxy-test-${crypto.randomUUID()}`),
    r = `${e.protocol || "http"}://${e.host}:${e.port}`,
    u = Date.now();
  let o;
  try {
    await t.setProxy({ proxyRules: r, proxyBypassRules: "<local>" });
    const a = await probeProxyThroughSession(t, e, 6e3);
    o = a.healthy
      ? {
          healthy: !0,
          latencyMs: Date.now() - u,
          exitIp: String(a.exitIp || "\u672A\u77E5"),
        }
      : {
          healthy: !1,
          latencyMs: Date.now() - u,
          exitIp: "",
          errorMessage: a.error || "\u4EE3\u7406\u68C0\u6D4B\u5931\u8D25",
        };
  } finally {
    (await t.setProxy({ mode: "direct" }).catch(() => {}),
      await t.clearCache().catch(() => {}));
  }
  return (
    await invokeFunction("admin-users", {
      action: "set_proxy_health",
      proxyId: n,
      ...o,
    }),
    o
  );
}
async function runAdminProxyPoolHealthCheck() {
  if (!(
    poolHealthScanRunning ||
    currentProfile?.role !== "admin" ||
    !currentSession
  )) {
    poolHealthScanRunning = !0;
    try {
      const n = await invokeFunction("admin-users", {
          action: "list_proxy_pool",
        }),
        e = (Array.isArray(n.proxies) ? n.proxies : []).filter(
          (u) => u.enabled,
        );
      let t = 0;
      const r = Array.from({ length: Math.min(3, e.length) }, async () => {
        for (; t < e.length && currentSession;) {
          const u = e[t++];
          await testManagedProxy(u.id).catch((o) =>
            console.warn("Automatic proxy test failed", u.id, o?.message || o),
          );
        }
      });
      (await Promise.all(r),
        await invokeFunction("admin-users", {
          action: "repair_proxy_assignments",
        }));
    } catch (n) {
      console.warn("Automatic proxy-pool scan failed", n?.message || n);
    } finally {
      poolHealthScanRunning = !1;
    }
  }
}
async function startProxyHealthSchedulers() {
  (assignedProxyHealthTimer && clearInterval(assignedProxyHealthTimer),
    poolHealthTimer && clearInterval(poolHealthTimer),
    (assignedProxyHealthTimer = setInterval(() => {
      !currentSession ||
        !proxyRoutingRequired() ||
        acquireUsableManagedProxy("assignment").catch((n) =>
          console.warn("Assigned proxy health check failed", n?.message || n),
        );
    }, 120 * 1e3)));
}
(ipcMain.handle("proxy:test-managed", async (n, e) => {
  try {
    if (currentProfile?.role !== "admin")
      throw new Error(
        "\u4EC5\u7BA1\u7406\u5458\u53EF\u4EE5\u6D4B\u8BD5\u4EE3\u7406",
      );
    return { ok: !0, data: await testManagedProxy(String(e || "")) };
  } catch (t) {
    return {
      ok: !1,
      message: t?.message || "\u4EE3\u7406\u6D4B\u8BD5\u5931\u8D25",
    };
  }
}),
  ipcMain.handle("external:open", async (n, e) => {
    const t = String(e || "");
    return new Set([
      "https://platform.openai.com/api-keys",
      "https://console.groq.com/",
      "https://console.groq.com/keys",
      "https://console.groq.com/docs/quickstart",
      "https://aistudio.google.com/api-keys",
    ]).has(t)
      ? (await shell.openExternal(t), { ok: !0 })
      : { ok: !1, message: "\u4E0D\u5141\u8BB8\u6253\u5F00\u6B64\u94FE\u63A5" };
  }),
  ipcMain.handle("admin:invoke", async (n, e) => {
    try {
      if (currentProfile?.role !== "admin")
        throw new Error("\u4EC5\u7BA1\u7406\u5458\u53EF\u4EE5\u64CD\u4F5C");
      const t = await invokeFunction("admin-users", e);
      return (
        e?.action === "save_proxy_settings" && startProxyHealthSchedulers(),
        ["save_site", "delete_site"].includes(e?.action) &&
          (await loadWorkSites(),
          proxyRoutingRequired()
            ? acquireUsableManagedProxy("assignment").catch(() => {})
            : ((managedTranslationProxy = null),
              await applyTranslationProxy())),
        { ok: !0, data: t }
      );
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u7BA1\u7406\u5458\u64CD\u4F5C\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("sites:admin-list", async () => {
    try {
      if (currentProfile?.role !== "admin")
        throw new Error(
          "\u4EC5\u7BA1\u7406\u5458\u53EF\u4EE5\u67E5\u770B\u7F51\u7AD9\u7BA1\u7406",
        );
      let n = await supabase
        .from("work_sites")
        .select(
          "id,site_key,display_name,url,icon_url,host_label,enabled,sort_order,minimum_plan,proxy_required,proxy_mode,fixed_proxy_id,chat_container_selector,message_selector,input_selector,phone_selector",
        )
        .order("sort_order", { ascending: !0 });
      if (
        (n.error &&
          (n = await supabase
            .from("work_sites")
            .select(
              "id,site_key,display_name,url,icon_url,host_label,enabled,sort_order,minimum_plan,proxy_required",
            )
            .order("sort_order", { ascending: !0 })),
        !n.error && Array.isArray(n.data) && n.data.length)
      )
        return {
          ok: !0,
          sites: n.data.map((t) => ({
            ...t,
            proxy_mode:
              t.proxy_mode || (t.proxy_required ? "automatic" : "direct"),
            fixed_proxy_id: t.fixed_proxy_id || null,
          })),
          source: "database",
        };
      const e = await invokeFunction("admin-users", { action: "list_sites" });
      if (!Array.isArray(e?.sites))
        throw (
          n.error ||
          new Error(
            "\u7F51\u7AD9\u6570\u636E\u8FD4\u56DE\u683C\u5F0F\u4E0D\u6B63\u786E",
          )
        );
      return { ok: !0, sites: e.sites, source: "admin-function" };
    } catch (n) {
      return {
        ok: !1,
        message: errorText(n, "\u8BFB\u53D6\u7F51\u7AD9\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("sites:admin-save", async (n, e) => {
    try {
      if (currentProfile?.role !== "admin")
        throw new Error(
          "\u4EC5\u7BA1\u7406\u5458\u53EF\u4EE5\u4FDD\u5B58\u7F51\u7AD9",
        );
      let t = String(e?.siteKey || "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9_-]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 39);
      (t || (t = "site"), /^[a-z]/.test(t) || (t = `site-${t}`.slice(0, 39)));
      const r = String(e?.siteName || "")
        .trim()
        .slice(0, 60);
      let u;
      try {
        u = new URL(String(e?.siteUrl || "").trim());
      } catch {
        throw new Error("HTTPS\u5730\u5740\u683C\u5F0F\u4E0D\u6B63\u786E");
      }
      if (u.protocol !== "https:")
        throw new Error(
          "\u7F51\u7AD9\u5730\u5740\u5FC5\u987B\u4F7F\u7528HTTPS",
        );
      if (!r) throw new Error("\u8BF7\u586B\u5199\u663E\u793A\u540D\u79F0");
      const o = { ...e, siteKey: t, siteName: r, siteUrl: u.href };
      try {
        const a = await invokeFunction("admin-users", {
          action: "save_site",
          ...o,
        });
        return (
          await loadWorkSites(),
          { ok: !0, siteKey: t, source: "admin-function", result: a }
        );
      } catch (a) {
        const s = {
            site_key: t,
            display_name: r,
            url: u.href,
            icon_url: String(e?.siteIconUrl || "").trim() || null,
            host_label: u.hostname,
            enabled: e?.siteEnabled !== !1,
            sort_order: Math.max(0, Math.min(1e4, Number(e?.sortOrder || 100))),
            minimum_plan: e?.minimumPlan === "advanced" ? "advanced" : "basic",
            proxy_required: e?.siteProxyMode === "automatic",
            proxy_mode: ["direct", "automatic", "tn_pool", "fixed"].includes(
              e?.siteProxyMode,
            )
              ? e.siteProxyMode
              : "direct",
            fixed_proxy_id:
              e?.siteProxyMode === "fixed" && e?.siteFixedProxyId
                ? String(e.siteFixedProxyId)
                : null,
            chat_container_selector:
              String(e?.chatContainerSelector || "")
                .trim()
                .slice(0, 500) || null,
            message_selector:
              String(e?.messageSelector || "")
                .trim()
                .slice(0, 500) || null,
            input_selector:
              String(e?.inputSelector || "")
                .trim()
                .slice(0, 500) || null,
            phone_selector:
              String(e?.phoneSelector || "")
                .trim()
                .slice(0, 500) || null,
          },
          i = (l) =>
            e?.siteId
              ? supabase
                  .from("work_sites")
                  .update(l)
                  .eq("id", String(e.siteId))
                  .select("id")
                  .single()
              : supabase.from("work_sites").insert(l).select("id").single();
        let c = await i(s);
        if (c.error) {
          const l = { ...s };
          (delete l.proxy_mode,
            delete l.fixed_proxy_id,
            delete l.chat_container_selector,
            delete l.message_selector,
            delete l.input_selector,
            delete l.phone_selector,
            (c = await i(l)));
        }
        if (c.error)
          throw new Error(
            `${errorText(a, "\u7BA1\u7406\u5458\u51FD\u6570\u4FDD\u5B58\u5931\u8D25")}\uFF1B\u6570\u636E\u5E93\u76F4\u5199\u4E5F\u5931\u8D25\uFF1A${errorText(c.error, "\u6743\u9650\u4E0D\u8DB3")}`,
          );
        return (
          await loadWorkSites(),
          { ok: !0, siteKey: t, source: "database" }
        );
      }
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u7F51\u7AD9\u4FDD\u5B58\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("ai:invoke", async (n, e) => {
    try {
      return featureEnabled("module_ai")
        ? { ok: !0, data: await invokeFunction("ai-gateway", e) }
        : featureDisabledResult("module_ai");
    } catch (t) {
      return {
        ok: !1,
        message: t.message || "AI\u670D\u52A1\u64CD\u4F5C\u5931\u8D25",
      };
    }
  }),
  ipcMain.handle("workbench:get-state", async () => {
    if (!currentSession || !currentProfile)
      return { ok: !1, tabs: [], activeIndex: 0 };
    await loadWorkSites();
    const n = workbenchMayRestoreOnNextLoad;
    return (
      (workbenchMayRestoreOnNextLoad = !0),
      n
        ? { ok: !0, ...getCurrentWorkspaceState() }
        : { ok: !0, tabs: [], activeIndex: 0 }
    );
  }),
  ipcMain.handle("workbench:get-restore-summary", () => {
    if (!currentSession || !currentProfile)
      return { ok: !1, count: 0, tabs: [] };
    const n = getCurrentWorkspaceState();
    return {
      ok: !0,
      count: n.tabs.length,
      tabs: n.tabs
        .map((e) => ({
          title: e.title,
          siteId: e.siteId,
          accountId: e.accountId || "",
        }))
        .slice(0, 12),
    };
  }),
  ipcMain.handle("workbench:restore-last-window", async () => {
    try {
      return getCurrentWorkspaceState().tabs.length
        ? workbenchWindow && !workbenchWindow.isDestroyed()
          ? (workbenchWindow.show(), workbenchWindow.focus(), { ok: !0 })
          : (await restoreRememberedWorkbench(), { ok: !0 })
        : {
            ok: !1,
            message: "\u6CA1\u6709\u53EF\u6062\u590D\u7684\u7F51\u7AD9",
          };
    } catch (n) {
      return { ok: !1, message: n?.message || "\u6062\u590D\u5931\u8D25" };
    }
  }),
  ipcMain.handle("workbench:save-state", async (n, e) =>
    saveCurrentWorkspaceState(e),
  ),
  ipcMain.on("workbench:save-state-sync", (n, e) => {
    n.returnValue = saveCurrentWorkspaceState(e);
  }));
function tnAccountForSender(n) {
  for (const e of listTnAccounts())
    try {
      if (n.session === session.fromPartition(tnPartition(e.id))) return e;
    } catch {}
  return null;
}
ipcMain.on("tn:appearance-changed", (n, e) => {
  if (!(
    !tnFeatureAllowed("tn_accounts") ||
    !tnAccountForSender(n.sender) ||
    !currentProfile?.id
  ))
    try {
      const t = normalizeTnAppearanceChange(e),
        r = readSecureSettings();
      r.tnAppearanceByUser =
        r.tnAppearanceByUser && typeof r.tnAppearanceByUser == "object"
          ? r.tnAppearanceByUser
          : {};
      const u =
        r.tnAppearanceByUser[currentProfile.id] &&
        typeof r.tnAppearanceByUser[currentProfile.id] == "object"
          ? r.tnAppearanceByUser[currentProfile.id]
          : {};
      if (JSON.stringify(u[t.kind]) === JSON.stringify(t.value)) return;
      ((r.tnAppearanceByUser[currentProfile.id] = {
        ...u,
        [t.kind]: t.value,
        updatedAt: new Date().toISOString(),
      }),
        writeSecureSettings(r),
        broadcastTnAppearance());
    } catch (t) {
      console.warn("Rejected TN appearance sync", t?.message || t);
    }
});
const recentTnNotificationSignatures = new Map();
ipcMain.on("tn:new-message", (n, e) => {
  if (!tnFeatureAllowed("tn_accounts")) return;
  const t = tnAccountForSender(n.sender);
  if (!t || !Notification.isSupported()) return;
  const r = `${t?.id || "unknown"}|${String(e?.phone || "")}|${String(e?.text || "").trim()}`,
    u = Date.now();
  for (const [a, s] of recentTnNotificationSignatures)
    u - s > 600 * 1e3 && recentTnNotificationSignatures.delete(a);
  if (!String(e?.text || "").trim() || recentTnNotificationSignatures.has(r))
    return;
  recentTnNotificationSignatures.set(r, u);
  const o = new Notification({
    title: `${t?.name || "TextNow"} \xB7 \u65B0\u6D88\u606F`,
    body: `${String(e?.phone || "\u5F53\u524D\u8054\u7CFB\u4EBA")}\uFF1A${String(e?.text || "\u6536\u5230\u4E00\u6761\u65B0\u6D88\u606F").slice(0, 160)}`,
    silent: !1,
  });
  (o.on("click", () => {
    workbenchWindow &&
      !workbenchWindow.isDestroyed() &&
      (workbenchWindow.show(),
      workbenchWindow.focus(),
      workbenchWindow.webContents.send(
        "workbench:activate-account",
        t?.id || "",
      ));
  }),
    o.show());
});
function siteIdForUrl(n) {
  try {
    const e = new URL(n).hostname.toLowerCase();
    for (const [t, r] of allowedSites) {
      const u = new URL(r).hostname.toLowerCase();
      if (e === u || e.endsWith(`.${u}`) || u.endsWith(`.${e}`)) return t;
    }
  } catch {}
  return "";
}
function createWorkbenchWindow(n = {}) {
  workbenchMayRestoreOnNextLoad = n.restore === !0;
  const e = savedWindowState("workbench"),
    t = new BrowserWindow({
      width: e?.width || 1500,
      height: e?.height || 940,
      ...(Number.isFinite(e?.x) ? { x: e.x } : {}),
      ...(Number.isFinite(e?.y) ? { y: e.y } : {}),
      minWidth: 980,
      minHeight: 680,
      title:
        "\u6A58\u5B50AI\u52A9\u624B - \u591A\u8D26\u53F7\u5DE5\u4F5C\u53F0",
      icon: path.join(__dirname, "extension-source/assets/icon-256.png"),
      webPreferences: {
        preload: path.join(__dirname, "preload.js"),
        contextIsolation: !0,
        nodeIntegration: !1,
        sandbox: !0,
        webviewTag: !0,
      },
    });
  return (
    t.setMenuBarVisibility(!1),
    installWindowStateMemory("workbench", t),
    e?.maximized && t.once("ready-to-show", () => t.maximize()),
    t.webContents.on("will-attach-webview", (r, u, o) => {
      u.preload = path.join(__dirname, "site-preload.js");
      const a = String(o?.partition || u.partition || ""),
        s = String(o?.src || "");
      let i = a.startsWith(tnPartitionPrefix);
      try {
        i ||= /(^|\.)textnow\.com$/i.test(new URL(s).hostname);
      } catch {}
      if (i && !tnFeatureAllowed("tn_accounts")) {
        r.preventDefault();
        return;
      }
      const c =
          a.startsWith(tnPartitionPrefix) &&
          listTnAccounts().some((d) => {
            try {
              return a === tnPartition(d.id);
            } catch {
              return !1;
            }
          }),
        l = a.startsWith(sitePartitionPrefix) && allowedSitePartitions.has(a);
      ((u.partition = c || l ? a : workPartition),
        (u.nodeIntegration = !1),
        (u.contextIsolation = !0),
        (u.sandbox = !0),
        (u.backgroundThrottling = !i));
    }),
    t.webContents.on("did-attach-webview", (r, u) => {
      (u.setWindowOpenHandler(({ url: o }) => {
        if (/^https:\/\/([a-z0-9-]+\.)*textnow\.com\//i.test(o))
          return (u.loadURL(o), { action: "deny" });
        const a = siteIdForUrl(o);
        return a
          ? (t.webContents.send("workbench:open-tab", {
              siteId: a,
              url: o,
              title: a,
            }),
            { action: "deny" })
          : (shell.openExternal(o), { action: "deny" });
      }),
        u.on("did-finish-load", () => {
          const o = siteIdForUrl(u.getURL());
          o &&
            autofillSiteLogin({ webContents: u }, o).catch((a) =>
              console.error("Site credential autofill failed", a),
            );
        }),
        u.on("before-input-event", (o, a) => {
          if (a.type !== "keyDown") return;
          const s = String(a.key || "").toLowerCase();
          if (a.control && s === "tab") {
            (o.preventDefault(),
              t.webContents.send("workbench:switch-tab", a.shift ? -1 : 1));
            return;
          }
          if (
            a.control &&
            (s === "+" ||
              s === "=" ||
              s === "add" ||
              s === "-" ||
              s === "subtract" ||
              s === "0")
          ) {
            o.preventDefault();
            const i = Number(u.getZoomFactor?.() || 1),
              c =
                s === "0"
                  ? 1
                  : Math.min(
                      2,
                      Math.max(
                        0.5,
                        i + (s === "-" || s === "subtract" ? -0.1 : 0.1),
                      ),
                    );
            u.setZoomFactor(Number(c.toFixed(2)));
            return;
          }
          (s !== "f5" && !(a.control && s === "r")) ||
            (o.preventDefault(),
            a.control && a.shift ? u.reloadIgnoringCache() : u.reload());
        }));
    }),
    t.loadFile(path.join(__dirname, "src/workbench.html")),
    (workbenchWindow = t),
    t.on("closed", () => {
      workbenchWindow === t && (workbenchWindow = null);
    }),
    t
  );
}
async function openWorkbenchTabLike113(n, e) {
  (n.webContents.isLoadingMainFrame() &&
    (await new Promise((t) => n.webContents.once("did-finish-load", t))),
    n.show(),
    n.focus(),
    n.webContents.send("workbench:open-tab", e));
}
async function restoreRememberedWorkbench() {
  if (
    !currentSession ||
    !currentProfile ||
    (workbenchWindow && !workbenchWindow.isDestroyed())
  )
    return;
  const n = getCurrentWorkspaceState();
  if (!n.tabs.length) return;
  const e = session.fromPartition(workPartition);
  try {
    if (
      !tnFeatureAllowed("tn_accounts") &&
      ((n.tabs = n.tabs.filter((u) => u.siteId !== "textnow")), !n.tabs.length)
    )
      return;
    for (const u of n.tabs.filter((o) => o.siteId === "textnow" && o.accountId))
      (await configureTnSession(u.accountId), destroyTnBackground(u.accountId));
    for (const u of n.tabs.filter((o) => o.siteInstanceId))
      await configureSiteAccountSession(u.siteId, u.siteInstanceId);
    n.tabs.some((u) => proxiedSiteIds.has(u.siteId)) && !managedTranslationProxy
      ? await acquireUsableManagedProxy("assignment").catch(() => null)
      : await applyTranslationProxy();
    const t = await ensureWorkExtensionLoaded(e);
    await syncExtensionAuth(e, t);
    const r = createWorkbenchWindow({ restore: !0 });
    (await new Promise((u) => r.webContents.once("did-finish-load", u)),
      r.show());
  } catch (t) {
    console.error("Unable to restore remembered workspace", t?.message || t);
  }
}
(ipcMain.handle(
  "workbench:show-main",
  async () => (showMainWindow(), { ok: !0 }),
),
  ipcMain.handle("workbench:list-platforms", async () => {
    if (!currentSession || !currentProfile)
      return { ok: !1, message: "\u8BF7\u5148\u767B\u5F55", sites: [] };
    try {
      return {
        ok: !0,
        sites: (await loadWorkSites())
          .filter((n) => !MANAGED_WEB_PLATFORMS.has(String(n.id).toLowerCase()))
          .map((n) => ({
            ...n,
            multiAccount: isMultiAccountWebSite(n.id, siteUrlFor(n.id)),
          })),
      };
    } catch (n) {
      return {
        ok: !1,
        message:
          n?.message || "\u5E73\u53F0\u5217\u8868\u8BFB\u53D6\u5931\u8D25",
        sites: [],
      };
    }
  }),
  ipcMain.handle("site:choose-wallpaper", async (n, e) => {
    try {
      const t = normalizeSiteInstanceId(e?.siteInstanceId);
      if (!t) throw new Error("\u8D26\u53F7\u5B9E\u4F8B\u65E0\u6548");
      const r = await dialog.showOpenDialog(workbenchWindow || mainWindow, {
        title: "\u9009\u62E9\u8D26\u53F7\u80CC\u666F\u56FE\u7247",
        properties: ["openFile"],
        filters: [
          {
            name: "\u56FE\u7247",
            extensions: ["png", "jpg", "jpeg", "webp", "gif"],
          },
        ],
      });
      if (r.canceled || !r.filePaths[0]) return { ok: !1, canceled: !0 };
      const u = siteWallpaperDirectory(t);
      return (
        fs.rmSync(u, { recursive: !0, force: !0 }),
        fs.mkdirSync(u, { recursive: !0 }),
        fs.copyFileSync(
          r.filePaths[0],
          path.join(
            u,
            `wallpaper${path.extname(r.filePaths[0]).toLowerCase() || ".png"}`,
          ),
        ),
        { ok: !0, dataUrl: siteWallpaperData(t) }
      );
    } catch (t) {
      return {
        ok: !1,
        message: errorText(
          t,
          "\u8D26\u53F7\u80CC\u666F\u4FDD\u5B58\u5931\u8D25",
        ),
      };
    }
  }),
  ipcMain.handle("site:get-wallpaper", async (n, e) => {
    try {
      const t = normalizeSiteInstanceId(e?.siteInstanceId);
      return t
        ? { ok: !0, dataUrl: siteWallpaperData(t) }
        : { ok: !0, dataUrl: "" };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(
          t,
          "\u8D26\u53F7\u80CC\u666F\u8BFB\u53D6\u5931\u8D25",
        ),
      };
    }
  }),
  ipcMain.handle("site:set-account-proxy", async (n, e) => {
    try {
      const t = normalizeSiteInstanceId(e?.siteInstanceId),
        r = String(e?.siteId || "").toLowerCase();
      if (!t || !["whatsapp", "telegram", "gmail"].includes(r))
        throw new Error("\u8D26\u53F7\u5B9E\u4F8B\u65E0\u6548");
      return (
        saveSiteAccountProxy(t, e?.fixedProxy || ""),
        await configureSiteAccountSession(r, t),
        { ok: !0, restartRequired: !1 }
      );
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u56FA\u5B9AIP\u4FDD\u5B58\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("site:list-managed-accounts", async (n, e) => {
    try {
      if (!currentSession || !currentProfile)
        throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = requireManagedPlatform(e?.siteId);
      if ((await loadWorkSites(), !siteUrlFor(t)))
        throw new Error(
          "\u5F53\u524D\u8D26\u53F7\u6CA1\u6709\u8BE5\u5E73\u53F0\u4F7F\u7528\u6743\u9650",
        );
      return { ok: !0, accounts: managedSiteAccountRows(t) };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(
          t,
          "\u8D26\u53F7\u5217\u8868\u8BFB\u53D6\u5931\u8D25",
        ),
        accounts: [],
      };
    }
  }),
  ipcMain.handle("site:create-managed-account", async (n, e) => {
    try {
      if (!currentSession || !currentProfile)
        throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = requireManagedPlatform(e?.siteId);
      if ((await loadWorkSites(), !siteUrlFor(t)))
        throw new Error(
          "\u5F53\u524D\u8D26\u53F7\u6CA1\u6709\u8BE5\u5E73\u53F0\u4F7F\u7528\u6743\u9650",
        );
      const r = crypto.randomUUID(),
        u = String(e?.name || "")
          .trim()
          .slice(0, 60);
      if (!u) throw new Error("\u8BF7\u586B\u5199\u8D26\u53F7\u540D\u79F0");
      String(e?.fixedProxy || "").trim() &&
        saveSiteAccountProxy(r, e.fixedProxy);
      const o = new Date().toISOString();
      return {
        ok: !0,
        account: saveManagedSiteAccount({
          id: r,
          siteId: t,
          name: u,
          note: String(e?.note || "")
            .trim()
            .slice(0, 120),
          enabled: !0,
          createdAt: o,
          updatedAt: o,
        }),
      };
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u8D26\u53F7\u6DFB\u52A0\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("site:update-managed-account", async (n, e) => {
    try {
      if (!currentSession || !currentProfile)
        throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = requireManagedPlatform(e?.siteId),
        r = normalizeSiteInstanceId(e?.id),
        u = managedSiteAccountRows(t).find((a) => a.id === r);
      if (!u) throw new Error("\u8D26\u53F7\u4E0D\u5B58\u5728");
      Object.prototype.hasOwnProperty.call(e || {}, "fixedProxy") &&
        saveSiteAccountProxy(r, e.fixedProxy || "");
      const o = saveManagedSiteAccount({
        ...u,
        name:
          String(e?.name ?? u.name)
            .trim()
            .slice(0, 60) || u.name,
        note: String(e?.note ?? u.note)
          .trim()
          .slice(0, 120),
        enabled: typeof e?.enabled == "boolean" ? e.enabled : u.enabled !== !1,
        updatedAt: new Date().toISOString(),
      });
      return (
        delete o.hasFixedProxy,
        delete o.isOpen,
        {
          ok: !0,
          account: {
            ...o,
            hasFixedProxy: !!savedSiteAccountProxy(r),
            isOpen: managedSiteAccountRows(t).some(
              (a) => a.id === r && a.isOpen,
            ),
          },
        }
      );
    } catch (t) {
      return {
        ok: !1,
        message: errorText(t, "\u8D26\u53F7\u4FDD\u5B58\u5931\u8D25"),
      };
    }
  }),
  ipcMain.handle("site:open-managed-account", async (n, e) => {
    try {
      if (!currentSession || !currentProfile)
        throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = requireManagedPlatform(e?.siteId),
        r = normalizeSiteInstanceId(e?.id),
        u = managedSiteAccountRows(t).find((i) => i.id === r);
      if (!u) throw new Error("\u8D26\u53F7\u4E0D\u5B58\u5728");
      if (u.enabled === !1)
        throw new Error("\u8BE5\u8D26\u53F7\u5DF2\u505C\u7528");
      await loadWorkSites();
      const o = siteUrlFor(t);
      if (!o)
        throw new Error(
          "\u5F53\u524D\u8D26\u53F7\u6CA1\u6709\u8BE5\u5E73\u53F0\u4F7F\u7528\u6743\u9650",
        );
      const { partition: a } = await configureSiteAccountSession(t, r, {
          verifyProxy: !0,
        }),
        s =
          workbenchWindow && !workbenchWindow.isDestroyed()
            ? workbenchWindow
            : createWorkbenchWindow();
      return (
        await openWorkbenchTabLike113(s, {
          siteId: t,
          siteInstanceId: r,
          partition: a,
          url: o,
          title: u.name,
        }),
        { ok: !0, siteInstanceId: r }
      );
    } catch (t) {
      return {
        ok: !1,
        message: errorText(
          t,
          "\u8D26\u53F7\u7A97\u53E3\u6253\u5F00\u5931\u8D25",
        ),
      };
    }
  }),
  ipcMain.handle("site:open-account", async (n, e) => {
    try {
      if (!currentSession || !currentProfile)
        throw new Error("\u8BF7\u5148\u767B\u5F55");
      await loadWorkSites();
      const t = String(e?.siteId || ""),
        r = siteUrlFor(t);
      if (!r)
        throw new Error(
          "\u7F51\u7AD9\u4E0D\u5B58\u5728\u6216\u5F53\u524D\u8D26\u53F7\u65E0\u6743\u8BBF\u95EE",
        );
      if (!isMultiAccountWebSite(t, r))
        throw new Error(
          "\u6B64\u5E73\u53F0\u6682\u672A\u5F00\u542F\u72EC\u7ACB\u8D26\u53F7\u6A21\u5F0F",
        );
      const u = siteProxyConfigs.get(t) || {
        mode: "direct",
        host: new URL(r).hostname.toLowerCase(),
      };
      if (u.mode === "fixed") {
        const d = await invokeFunction("proxy-control", {
          action: "site_fixed",
          siteKey: t,
        }).catch((m) => ({
          proxy: null,
          message: m?.message || "\u56FA\u5B9AIP\u4E0D\u53EF\u7528",
        }));
        if (!d?.proxy)
          throw new Error(
            d?.message ||
              "\u6B64\u7F51\u7AD9\u7ED1\u5B9A\u7684\u56FA\u5B9AIP\u4E0D\u53EF\u7528",
          );
        for (const m of fixedRouteHostsForSite(u.host))
          fixedSiteProxies.set(m, d.proxy);
      } else if (u.mode === "tn_pool") {
        const d = await invokeFunction("proxy-control", {
          action: "site_pool",
          siteKey: t,
          poolKind: "tn",
        }).catch((m) => ({
          proxy: null,
          message: m?.message || "TN IP\u6C60\u4E0D\u53EF\u7528",
        }));
        if (!d?.proxy)
          throw new Error(
            d?.message ||
              "\u6B64\u7F51\u7AD9\u8981\u6C42\u4F7F\u7528TN IP\u6C60\uFF0C\u4F46\u6682\u65F6\u6CA1\u6709\u53EF\u7528\u7EBF\u8DEF",
          );
        for (const m of fixedRouteHostsForSite(u.host))
          fixedSiteProxies.set(m, d.proxy);
      } else if (proxiedSiteIds.has(t) && !managedTranslationProxy) {
        const d = await acquireUsableManagedProxy("assignment").catch((m) => ({
          proxy: null,
          message: m?.message || "IP\u6C60\u6682\u65F6\u4E0D\u53EF\u7528",
        }));
        if (!d?.proxy && !managedTranslationProxy)
          throw new Error(
            d?.message ||
              "\u6B64\u7F51\u7AD9\u8981\u6C42\u4F7F\u7528\u7FFB\u8BD1IP\u6C60\uFF0C\u4F46\u6682\u65F6\u6CA1\u6709\u53EF\u7528\u7EBF\u8DEF",
          );
      }
      const o =
        normalizeSiteInstanceId(e?.siteInstanceId) || crypto.randomUUID();
      String(e?.fixedProxy || "").trim() &&
        saveSiteAccountProxy(o, e.fixedProxy);
      const a = getCurrentWorkspaceState().tabs.filter(
          (d) => d.siteId === t && d.siteInstanceId,
        ).length,
        s = String(e?.baseLabel || t || "\u8D26\u53F7")
          .trim()
          .slice(0, 80),
        i = String(e?.title || `${s} ${a + 1}`)
          .trim()
          .slice(0, 120),
        { partition: c } = await configureSiteAccountSession(t, o, {
          verifyProxy: !0,
        }),
        l =
          workbenchWindow && !workbenchWindow.isDestroyed()
            ? workbenchWindow
            : createWorkbenchWindow();
      return (
        await openWorkbenchTabLike113(l, {
          siteId: t,
          siteInstanceId: o,
          partition: c,
          url: r,
          title: i,
        }),
        { ok: !0, siteInstanceId: o }
      );
    } catch (t) {
      return {
        ok: !1,
        message: errorText(
          t,
          "\u8D26\u53F7\u7A97\u53E3\u6253\u5F00\u5931\u8D25",
        ),
      };
    }
  }),
  ipcMain.handle("site:delete-account-data", async (n, e) => {
    try {
      if (!currentSession || !currentProfile)
        throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = String(e?.siteId || ""),
        r = normalizeSiteInstanceId(e?.siteInstanceId);
      if (!r || !isMultiAccountWebSite(t, siteUrlFor(t)))
        throw new Error("\u8D26\u53F7\u5B9E\u4F8B\u65E0\u6548");
      const u = sitePartitionFor(t, r),
        o = session.fromPartition(u);
      return (
        await o.clearStorageData(),
        await o.clearCache().catch(() => {}),
        await o.closeAllConnections?.(),
        allowedSitePartitions.delete(u),
        deleteSiteAccountProxy(r),
        removeManagedSiteAccount(r),
        fs.rmSync(siteWallpaperDirectory(r), { recursive: !0, force: !0 }),
        { ok: !0 }
      );
    } catch (t) {
      return {
        ok: !1,
        message: errorText(
          t,
          "\u672C\u673A\u8D26\u53F7\u6570\u636E\u5220\u9664\u5931\u8D25",
        ),
      };
    }
  }),
  ipcMain.handle("workbench:detach-tab", async (n, e) => {
    try {
      if (!currentSession || !currentProfile)
        throw new Error("\u8BF7\u5148\u767B\u5F55");
      const t = String(e?.siteId || ""),
        r = String(e?.accountId || "");
      let u = workPartition,
        o = "",
        a = String(e?.title || t || "\u72EC\u7ACB\u7A97\u53E3").slice(0, 120);
      if (t === "textnow") {
        if (!tnFeatureAllowed("tn_accounts"))
          throw new Error(
            "\u5F53\u524D\u8D26\u53F7\u6CA1\u6709TN\u4F7F\u7528\u6743\u9650",
          );
        const c = tnAccountById(r);
        if (!c) throw new Error("TN\u8D26\u53F7\u4E0D\u5B58\u5728");
        (({ partition: u } = await configureTnSession(c.id)),
          (o = "https://www.textnow.com/messaging"),
          (a = `TN \xB7 ${c.name}`),
          tnVisibleAccounts.add(c.id),
          destroyTnBackground(c.id));
      } else {
        if ((await loadWorkSites(), (o = siteUrlFor(t)), !o))
          throw new Error(
            "\u7F51\u7AD9\u4E0D\u5B58\u5728\u6216\u5F53\u524D\u8D26\u53F7\u65E0\u6743\u8BBF\u95EE",
          );
        const c = session.fromPartition(workPartition);
        await prepareWorkExtensionWithoutBlockingPage(c);
      }
      let s = o;
      try {
        const c = new URL(String(e?.url || o)),
          l = new URL(o);
        ["http:", "https:"].includes(c.protocol) &&
          (c.hostname === l.hostname ||
            c.hostname.endsWith(`.${l.hostname}`)) &&
          (s = c.href);
      } catch {}
      const i = new BrowserWindow({
        width: 1120,
        height: 760,
        minWidth: 760,
        minHeight: 520,
        title: a,
        icon: path.join(__dirname, "extension-source/assets/icon-256.png"),
        webPreferences: {
          partition: u,
          preload: path.join(__dirname, "site-preload.js"),
          contextIsolation: !0,
          nodeIntegration: !1,
          sandbox: !0,
          backgroundThrottling: t !== "textnow",
          additionalArguments: ["--orange-detached-window=1"],
        },
      });
      return (
        detachedSiteWindows.set(i, { siteId: t, accountId: r }),
        i.setMenuBarVisibility(!1),
        installReloadShortcuts(i),
        i.webContents.setWindowOpenHandler(({ url: c }) => {
          try {
            const l = new URL(c),
              d = new URL(o);
            if (
              l.hostname === d.hostname ||
              l.hostname.endsWith(`.${d.hostname}`)
            )
              return (i.loadURL(l.href), { action: "deny" });
          } catch {}
          return (shell.openExternal(c), { action: "deny" });
        }),
        i.webContents.on("did-finish-load", () => {
          t !== "textnow" &&
            autofillSiteLogin({ webContents: i.webContents }, t).catch(
              () => {},
            );
        }),
        i.on("closed", () => detachedSiteWindows.delete(i)),
        await i.loadURL(s),
        i.show(),
        { ok: !0 }
      );
    } catch (t) {
      return {
        ok: !1,
        message: errorText(
          t,
          "\u72EC\u7ACB\u7A97\u53E3\u6253\u5F00\u5931\u8D25",
        ),
      };
    }
  }),
  ipcMain.on("workbench:focus-from-detached", (n) => {
    const e = BrowserWindow.fromWebContents(n.sender);
    if (!e || !detachedSiteWindows.has(e)) return;
    const t =
      workbenchWindow && !workbenchWindow.isDestroyed()
        ? workbenchWindow
        : createWorkbenchWindow();
    (t.show(), t.isMinimized() && t.restore(), t.focus());
  }),
  ipcMain.on("workbench:close-detached", (n) => {
    const e = BrowserWindow.fromWebContents(n.sender);
    e && detachedSiteWindows.has(e) && e.close();
  }),
  ipcMain.handle(
    "workbench:choose-platform",
    async () => (
      showMainWindow(),
      !mainWindow || mainWindow.isDestroyed()
        ? { ok: !1, message: "\u4E3B\u7A97\u53E3\u65E0\u6CD5\u6253\u5F00" }
        : (mainWindow.webContents.isLoadingMainFrame() &&
            (await new Promise((n) =>
              mainWindow.webContents.once("did-finish-load", n),
            )),
          mainWindow.webContents.send("main:show-platform"),
          { ok: !0 })
    ),
  ),
  ipcMain.handle("site:open", async (n, e) => {
    if (!currentSession) return { ok: !1, message: "\u8BF7\u5148\u767B\u5F55" };
    await loadWorkSites();
    const t = String(e),
      r = siteUrlFor(t);
    if (!r)
      return {
        ok: !1,
        message:
          "\u7F51\u7AD9\u4E0D\u5B58\u5728\u6216\u5F53\u524D\u8D26\u53F7\u65E0\u6743\u8BBF\u95EE",
      };
    const u = isMultiAccountWebSite(t, r) ? crypto.randomUUID() : "",
      o = session.fromPartition(workPartition),
      a = siteProxyConfigs.get(t) || {
        mode: "direct",
        host: new URL(r).hostname.toLowerCase(),
      };
    if (a.mode === "fixed") {
      const d = await invokeFunction("proxy-control", {
        action: "site_fixed",
        siteKey: t,
      }).catch((m) => ({
        proxy: null,
        message: m?.message || "\u56FA\u5B9AIP\u4E0D\u53EF\u7528",
      }));
      if (!d?.proxy)
        return {
          ok: !1,
          message:
            d?.message ||
            "\u6B64\u7F51\u7AD9\u7ED1\u5B9A\u7684\u56FA\u5B9AIP\u4E0D\u53EF\u7528\uFF1B\u7CFB\u7EDF\u4E0D\u4F1A\u81EA\u52A8\u6362\u7EBF\u6216\u672C\u673A\u76F4\u8FDE",
        };
      for (const m of fixedRouteHostsForSite(a.host))
        fixedSiteProxies.set(m, d.proxy);
      await applyTranslationProxy();
    } else if (a.mode === "tn_pool") {
      const d = await invokeFunction("proxy-control", {
        action: "site_pool",
        siteKey: t,
        poolKind: "tn",
      }).catch((m) => ({
        proxy: null,
        message: m?.message || "TN IP\u6C60\u4E0D\u53EF\u7528",
      }));
      if (!d?.proxy)
        return {
          ok: !1,
          message:
            d?.message ||
            "\u6B64\u7F51\u7AD9\u8981\u6C42\u4F7F\u7528TN IP\u6C60\uFF0C\u4F46\u6682\u65F6\u6CA1\u6709\u53EF\u7528\u7EBF\u8DEF",
        };
      for (const m of fixedRouteHostsForSite(a.host))
        fixedSiteProxies.set(m, d.proxy);
      await applyTranslationProxy();
    } else if (proxiedSiteIds.has(t)) {
      const d = managedTranslationProxy
        ? { proxy: managedTranslationProxy, healthy: !0 }
        : await acquireUsableManagedProxy("assignment").catch((m) => ({
            proxy: null,
            message: m?.message || "IP\u6C60\u6682\u65F6\u4E0D\u53EF\u7528",
          }));
      if (!managedTranslationProxy)
        return {
          ok: !1,
          message:
            d?.message ||
            "\u6B64\u7F51\u7AD9\u8981\u6C42\u4F7F\u7528\u7FFB\u8BD1IP\u6C60\uFF0C\u4F46\u6682\u65F6\u6CA1\u6709\u53EF\u7528\u7EBF\u8DEF",
        };
    } else await applyTranslationProxy();
    let s = "";
    u
      ? ({ partition: s } = await configureSiteAccountSession(t, u))
      : await prepareWorkExtensionWithoutBlockingPage(o);
    const i =
        workbenchWindow && !workbenchWindow.isDestroyed()
          ? workbenchWindow
          : createWorkbenchWindow(),
      c = u
        ? getCurrentWorkspaceState().tabs.filter(
            (d) => d.siteId === t && d.siteInstanceId,
          ).length
        : 0,
      l =
        { whatsapp: "WhatsApp", telegram: "Telegram", gmail: "Gmail" }[
          t.toLowerCase()
        ] || t;
    return (
      await openWorkbenchTabLike113(i, {
        siteId: t,
        url: r,
        title: u ? `${l} ${c + 1}` : t,
        ...(u ? { siteInstanceId: u, partition: s } : {}),
      }),
      { ok: !0 }
    );
  }));
function createWindow() {
  const n = savedWindowState("main"),
    e = new BrowserWindow({
      width: n?.width || 1180,
      height: n?.height || 760,
      ...(Number.isFinite(n?.x) ? { x: n.x } : {}),
      ...(Number.isFinite(n?.y) ? { y: n.y } : {}),
      minWidth: 920,
      minHeight: 640,
      title: "\u6A58\u5B50AI\u52A9\u624B",
      icon: path.join(__dirname, "extension-source/assets/icon-256.png"),
      webPreferences: {
        preload: path.join(__dirname, "preload.js"),
        contextIsolation: !0,
        nodeIntegration: !1,
        sandbox: !0,
      },
    });
  (e.setMenuBarVisibility(!1),
    installWindowStateMemory("main", e),
    n?.maximized && e.once("ready-to-show", () => e.maximize()),
    installReloadShortcuts(e),
    e.loadFile(path.join(__dirname, "src/index.html")),
    (mainWindow = e),
    e.on("close", (t) => {
      isQuitting || (t.preventDefault(), e.hide());
    }),
    e.on("closed", () => {
      mainWindow === e && (mainWindow = null);
    }));
}
function showMainWindow() {
  ((!mainWindow || mainWindow.isDestroyed()) && createWindow(),
    mainWindow.show(),
    mainWindow.isMinimized() && mainWindow.restore(),
    mainWindow.focus());
}
function createTray() {
  tray ||
    ((tray = new Tray(path.join(__dirname, "build/icon.ico"))),
    tray.setToolTip("\u6A58\u5B50AI\u52A9\u624B"),
    tray.setContextMenu(
      Menu.buildFromTemplate([
        {
          label: "\u6253\u5F00\u6A58\u5B50AI\u52A9\u624B",
          click: showMainWindow,
        },
        { type: "separator" },
        {
          label: "\u5B8C\u5168\u9000\u51FA",
          click: () => {
            ((isQuitting = !0), app.quit());
          },
        },
      ]),
    ),
    tray.on("double-click", showMainWindow));
}
(hasSingleInstanceLock &&
  app.whenReady().then(() => {
    if (
      (processPendingBeta6Migration(),
      createWindow(),
      createTray(),
      app.on("activate", showMainWindow),
      app.isPackaged)
    ) {
      const n = () => {
        ["checking", "downloading", "downloaded"].includes(
          updateState.status,
        ) ||
          autoUpdater
            .checkForUpdates()
            .catch((e) =>
              sendUpdateState({
                status: "error",
                message: friendlyUpdateError(
                  e,
                  "\u81EA\u52A8\u68C0\u67E5\u5931\u8D25",
                ),
              }),
            );
      };
      (setTimeout(n, 8e3), setInterval(n, 360 * 60 * 1e3).unref?.());
    }
  }),
  app.on("before-quit", () => {
    (supabase.auth.stopAutoRefresh(), (isQuitting = !0));
  }),
  app.on("window-all-closed", () => {}));
