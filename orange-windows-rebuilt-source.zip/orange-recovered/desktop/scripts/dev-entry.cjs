const { app } = require("electron");
const path = require("node:path");
app.setPath(
  "userData",
  path.join(app.getPath("appData"), "orange-ai-internal-dev"),
);
require("../main.js");
