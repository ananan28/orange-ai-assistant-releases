const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const root = path.resolve(__dirname, "..");
let checked = 0;
for (const name of [
  "main.js",
  "preload.js",
  "site-preload.js",
  "config.js",
  "tn-cookie-parser.js",
  "tn-dom-locator.js",
  "tn-stable-core.js",
  "src/index.html",
  "src/workbench.html",
  "build/icon.ico",
]) {
  if (!fs.existsSync(path.join(root, name))) throw new Error(`Missing ${name}`);
}
function scan(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (["node_modules", "dist"].includes(e.name)) continue;
    const f = path.join(dir, e.name);
    if (e.isDirectory()) scan(f);
    else if (/\.(js|cjs)$/.test(f)) {
      const result = spawnSync(process.execPath, ["--check", f], {
        encoding: "utf8",
      });
      if (result.status !== 0) throw new Error(result.stderr);
      checked++;
    }
  }
}
scan(root);
for (const dir of ["extension-source", "tn-beta-extension-source"]) {
  const manifest = JSON.parse(
    fs.readFileSync(path.join(root, dir, "manifest.json"), "utf8"),
  );
  const files = [
    ...(manifest.background?.service_worker
      ? [manifest.background.service_worker]
      : []),
    ...Object.values(manifest.icons || {}),
    ...manifest.content_scripts.flatMap((s) => [
      ...(s.js || []),
      ...(s.css || []),
    ]),
  ];
  for (const f of files)
    if (!fs.existsSync(path.join(root, dir, f)))
      throw new Error(`Missing extension asset ${dir}/${f}`);
}
console.log(
  `Passed: ${checked} JS syntax checks; required application and manifest assets exist.`,
);
