(() => {
  "use strict";
  const B = "ORANGE_OPE_FORBIDDEN_GUARD",
    m = "orange-ope-forbidden-dialog",
    R = /(^|\.)opensms\.xin$/i,
    b = "orangeOpeForbiddenGuardEnabled",
    T = new WeakMap();
  let r = !0;
  const G = [
      "hi",
      "hello",
      "hell0",
      "hey",
      "oh",
      "work",
      "w0rk",
      "working",
      "job",
      "jobs",
      "j0b",
      "foot",
      "contacts",
      "management",
      "email",
      "office",
      "coffee",
      "usa",
      "america",
      "company",
      "country",
      "phone",
      "number",
      "remember",
      "howdy",
      "whatsapp",
      "crypto",
      "cryptocurrency",
      "bitcoin",
      "usdt",
      "stock",
      "stocks",
      "shares",
      "equity",
      "investment",
      "invest",
      "trading",
      "gambling",
      "casino",
      "politics",
      "political",
      "porn",
      "sexual",
      "sex",
      "hookup",
    ],
    P = [
      "guess who i am",
      "how about you",
      "how are you",
      "how old are you",
      "are you okay",
      "what's your name",
      "do you remember it now",
      "long time no see",
      "long time",
      "how about",
      "how are",
      "extra income",
      "part-time",
      "part time",
      "hook up",
      "government official",
      "public official",
      "apply for official",
    ],
    z = [
      "\u7CBE\u804A",
      "\u517C\u804C",
      "\u80A1\u7968",
      "\u52A0\u5BC6\u8D27\u5E01",
      "\u989D\u5916\u6536\u5165",
      "\u8272\u60C5",
      "\u653F\u6CBB",
      "\u8D4C\u535A",
      "\u56FD\u5BB6\u540D",
      "\u7F8E\u56FD",
      "\u7533\u8BF7\u5B98\u5458",
      "\u7EA6\u70AE",
      "\u53CD\u8BC8",
      "\u53CD\u6B3A\u8BC8",
      "\u8BC8\u9A97",
      "\u53F7\u7801",
      "\u865F\u78BC",
      "\u7535\u8BDD",
      "\u96FB\u8A71",
      "\u901A\u8BAF\u5F55",
      "\u901A\u8A0A\u9304",
    ],
    I = [
      "Afghanistan",
      "Albania",
      "Algeria",
      "Andorra",
      "Angola",
      "Antigua and Barbuda",
      "Argentina",
      "Armenia",
      "Australia",
      "Austria",
      "Azerbaijan",
      "Bahamas",
      "Bahrain",
      "Bangladesh",
      "Barbados",
      "Belarus",
      "Belgium",
      "Belize",
      "Benin",
      "Bhutan",
      "Bolivia",
      "Bosnia and Herzegovina",
      "Botswana",
      "Brazil",
      "Brunei",
      "Bulgaria",
      "Burkina Faso",
      "Burundi",
      "Cabo Verde",
      "Cape Verde",
      "Cambodia",
      "Cameroon",
      "Canada",
      "Central African Republic",
      "Chad",
      "Chile",
      "China",
      "Colombia",
      "Comoros",
      "Congo",
      "Costa Rica",
      "Croatia",
      "Cuba",
      "Cyprus",
      "Czechia",
      "Czech Republic",
      "Denmark",
      "Djibouti",
      "Dominica",
      "Dominican Republic",
      "Ecuador",
      "Egypt",
      "El Salvador",
      "Equatorial Guinea",
      "Eritrea",
      "Estonia",
      "Eswatini",
      "Swaziland",
      "Ethiopia",
      "Fiji",
      "Finland",
      "France",
      "Gabon",
      "Gambia",
      "Georgia",
      "Germany",
      "Ghana",
      "Greece",
      "Grenada",
      "Guatemala",
      "Guinea",
      "Guinea-Bissau",
      "Guyana",
      "Haiti",
      "Honduras",
      "Hungary",
      "Iceland",
      "India",
      "Indonesia",
      "Iran",
      "Iraq",
      "Ireland",
      "Israel",
      "Italy",
      "Ivory Coast",
      "Cote d'Ivoire",
      "Jamaica",
      "Japan",
      "Jordan",
      "Kazakhstan",
      "Kenya",
      "Kiribati",
      "North Korea",
      "South Korea",
      "Kuwait",
      "Kyrgyzstan",
      "Laos",
      "Latvia",
      "Lebanon",
      "Lesotho",
      "Liberia",
      "Libya",
      "Liechtenstein",
      "Lithuania",
      "Luxembourg",
      "Madagascar",
      "Malawi",
      "Malaysia",
      "Maldives",
      "Mali",
      "Malta",
      "Marshall Islands",
      "Mauritania",
      "Mauritius",
      "Mexico",
      "Micronesia",
      "Moldova",
      "Monaco",
      "Mongolia",
      "Montenegro",
      "Morocco",
      "Mozambique",
      "Myanmar",
      "Burma",
      "Namibia",
      "Nauru",
      "Nepal",
      "Netherlands",
      "New Zealand",
      "Nicaragua",
      "Niger",
      "Nigeria",
      "North Macedonia",
      "Macedonia",
      "Norway",
      "Oman",
      "Pakistan",
      "Palau",
      "Palestine",
      "Panama",
      "Papua New Guinea",
      "Paraguay",
      "Peru",
      "Philippines",
      "Poland",
      "Portugal",
      "Qatar",
      "Romania",
      "Russia",
      "Rwanda",
      "Saint Kitts and Nevis",
      "Saint Lucia",
      "Saint Vincent and the Grenadines",
      "Samoa",
      "San Marino",
      "Sao Tome and Principe",
      "Saudi Arabia",
      "Senegal",
      "Serbia",
      "Seychelles",
      "Sierra Leone",
      "Singapore",
      "Slovakia",
      "Slovenia",
      "Solomon Islands",
      "Somalia",
      "South Africa",
      "South Sudan",
      "Spain",
      "Sri Lanka",
      "Sudan",
      "Suriname",
      "Sweden",
      "Switzerland",
      "Syria",
      "Taiwan",
      "Tajikistan",
      "Tanzania",
      "Thailand",
      "Timor-Leste",
      "East Timor",
      "Togo",
      "Tonga",
      "Trinidad and Tobago",
      "Tunisia",
      "Turkey",
      "Turkiye",
      "Turkmenistan",
      "Tuvalu",
      "Uganda",
      "Ukraine",
      "United Arab Emirates",
      "UAE",
      "United Kingdom",
      "UK",
      "United States",
      "United States of America",
      "USA",
      "America",
      "Uruguay",
      "Uzbekistan",
      "Vanuatu",
      "Vatican City",
      "Holy See",
      "Venezuela",
      "Vietnam",
      "Yemen",
      "Zambia",
      "Zimbabwe",
    ],
    O =
      /(?:https?:\/\/|www\.)\S+|\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:com|net|org|io|ai|co|us|cn|me|app|info|biz|xyz|site|link)\b/iu,
    D = /[\u3400-\u9fff]/u,
    H =
      /(?:anti[-\s]?fraud|investment\s+(?:fraud|scam)|recover\s+the\s+funds|victim\s+of\s+investment)/iu;
  function v(e) {
    return String(e || "")
      .normalize("NFKC")
      .replace(/[’‘]/g, "'")
      .replace(/[‐‑‒–—]/g, "-")
      .replace(/\s+/g, " ")
      .trim();
  }
  function K(e) {
    return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function h(e, t) {
    return new RegExp(`(^|[^A-Za-z0-9])${K(t)}(?=$|[^A-Za-z0-9])`, "i").test(e);
  }
  function s(e, t) {
    e.some(
      (a) =>
        a.code === t.code && a.value.toLowerCase() === t.value.toLowerCase(),
    ) || e.push(t);
  }
  function M(e, t = {}) {
    const a = v(e);
    if (!a) return [];
    const n = [];
    if (t.includeForbiddenWords !== !1) {
      for (const o of P)
        h(a, o) &&
          s(n, {
            code: "phrase",
            value: o,
            reason: "\u7981\u7528\u8BDD\u672F",
          });
      for (const o of G)
        h(a, o) &&
          s(n, {
            code: "word",
            value: o,
            reason: "\u7981\u7528\u5173\u952E\u8BCD",
          });
      for (const o of z)
        a.includes(o) &&
          s(n, {
            code: "chinese-keyword",
            value: o,
            reason: "\u4E2D\u6587\u7981\u7528\u5173\u952E\u8BCD",
          });
      const g = I.filter((o) => h(a, o));
      for (const o of g.slice(0, 5))
        s(n, {
          code: "country",
          value: o,
          reason: "\u56FD\u5BB6/\u5730\u533A\u540D\u79F0",
        });
      (H.test(a) &&
        s(n, {
          code: "anti-fraud",
          value: "Anti-Fraud / investment scam",
          reason: "\u53CD\u8BC8\u6216\u8FFD\u56DE\u8D44\u91D1\u8BDD\u672F",
        }),
        O.test(a) &&
          s(n, {
            code: "url",
            value: "\u94FE\u63A5/\u7F51\u5740",
            reason: "\u7981\u6B62\u53D1\u9001\u94FE\u63A5",
          }),
        D.test(a) &&
          s(n, {
            code: "chinese",
            value: "\u4E2D\u6587\u5185\u5BB9",
            reason: "OPE \u7981\u6B62\u53D1\u9001\u4E2D\u6587\u5185\u5BB9",
          }));
    }
    const c = Array.from(a).length;
    return (
      c > 300 &&
        s(n, {
          code: "length",
          value: `${c} \u4E2A\u5B57\u7B26`,
          reason: "\u8D85\u8FC7 300 \u4E2A\u5B57\u7B26\u9650\u5236",
        }),
      n
    );
  }
  function E(e) {
    if (
      !(e instanceof Element) ||
      e.closest(`#${m}, #ai-bt-root, #orange-ai-reply-root`)
    )
      return !1;
    if (e instanceof HTMLTextAreaElement) return !e.disabled && !e.readOnly;
    if (e instanceof HTMLInputElement) {
      const t = String(e.type || "text").toLowerCase();
      return (
        ["text", "search"].includes(t) &&
        !e.disabled &&
        !e.readOnly &&
        t !== "search"
      );
    }
    return !!e.isContentEditable;
  }
  function U(e) {
    return e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement
      ? String(e.value || "")
      : String(e?.innerText || e?.textContent || "");
  }
  function p() {
    return document.querySelector(
      "#v-im-app .main-content .right, #v-im-app .main.content .right, #im-app .main-content .right, #im-app .main_content .right, #v-im-app .right, #im-app .right",
    );
  }
  function f(e = p()) {
    if (!(e instanceof Element)) return null;
    const t = document.activeElement;
    if (E(t) && e.contains(t)) return t;
    const a = [
      ".chat_message_operates textarea",
      ".chat_message_operates input[type='text']",
      ".chat_message_operates [contenteditable='true']",
      ".im-chat-input textarea",
      ".im-chat-input [contenteditable='true']",
      "textarea",
      "[contenteditable='true']",
      "input[type='text']",
    ];
    for (const n of a) {
      const i = Array.from(e.querySelectorAll(n)).filter(E);
      if (i.length) return i[i.length - 1];
    }
    return null;
  }
  function k(e, t) {
    if (!(e instanceof Element) || !t) return !1;
    const a = p();
    if (a && (!a.contains(e) || !a.contains(t))) return !1;
    const n = v(
      [
        e.textContent,
        e.getAttribute("aria-label"),
        e.getAttribute("title"),
        e.getAttribute("name"),
        e.getAttribute("id"),
        e.getAttribute("class"),
      ]
        .filter(Boolean)
        .join(" "),
    ).toLowerCase();
    return /(^|[\s_-])(send|sending|submit|发送|发出)([\s_-]|$)/i.test(n)
      ? !0
      : e.matches("button[type='submit'], input[type='submit']")
        ? !!e.closest("form")?.contains(t)
        : !!(
            t
              .closest(
                "form, .chat_message_operates, .im-chat-input, [class*='message-operate'], [class*='chat-input']",
              )
              ?.contains(e) && /el-button--primary|primary|submit/i.test(n)
          );
  }
  function y() {
    document.getElementById(m)?.remove();
  }
  function q(e, t, a) {
    y();
    const n = document.createElement("div");
    ((n.id = m),
      n.setAttribute("role", "dialog"),
      n.setAttribute("aria-modal", "true"));
    const i = document.createElement("div");
    i.className = "orange-ope-forbidden-card";
    const c = document.createElement("h2");
    c.textContent = "\u26A0\uFE0F OPE \u53D1\u9001\u63D0\u9192";
    const g = document.createElement("p");
    g.textContent =
      "\u672C\u6B21\u6D88\u606F\u547D\u4E2D\u4EE5\u4E0B\u63D0\u9192\uFF0C\u8BF7\u68C0\u67E5\u540E\u9009\u62E9\u662F\u5426\u7EE7\u7EED\u53D1\u9001\uFF1A";
    const o = document.createElement("ul");
    for (const l of e.slice(0, 12)) {
      const _ = document.createElement("li"),
        x = document.createElement("strong");
      ((x.textContent = l.value),
        _.append(x, document.createTextNode(` \u2014 ${l.reason}`)),
        o.appendChild(_));
    }
    if (e.length > 12) {
      const l = document.createElement("li");
      ((l.textContent = `\u53E6\u6709 ${e.length - 12} \u9879\u547D\u4E2D\uFF0C\u8BF7\u7EE7\u7EED\u68C0\u67E5\u539F\u6587\u3002`),
        o.appendChild(l));
    }
    const C = document.createElement("p");
    ((C.className = "orange-ope-forbidden-note"),
      (C.textContent =
        "\u9009\u62E9\u201C\u8FD4\u56DE\u4FEE\u6539\u201D\u4E0D\u4F1A\u6539\u53D8\u8F93\u5165\u5185\u5BB9\uFF1B\u9009\u62E9\u201C\u786E\u5B9A\u53D1\u9001\u201D\u5C06\u6309\u539F\u6587\u7EE7\u7EED\u3002"));
    const w = document.createElement("div");
    w.className = "orange-ope-forbidden-actions";
    const u = document.createElement("button");
    ((u.type = "button"),
      (u.className = "orange-ope-return-edit"),
      (u.textContent = "\u8FD4\u56DE\u4FEE\u6539"),
      u.addEventListener("click", () => {
        (y(), t?.focus?.({ preventScroll: !0 }));
      }));
    const d = document.createElement("button");
    ((d.type = "button"),
      (d.className = "orange-ope-confirm-send"),
      (d.textContent = "\u786E\u5B9A\u53D1\u9001"),
      d.addEventListener("click", () => {
        (T.set(t, Date.now() + 1500), y(), a?.());
      }),
      w.append(u, d),
      i.append(c, g, o, C, w),
      n.appendChild(i),
      n.addEventListener("click", (l) => {
        l.target === n && u.click();
      }),
      document.body.appendChild(n),
      u.focus({ preventScroll: !0 }));
  }
  function S(e, t, a) {
    if (Date.now() < Number(T.get(t) || 0)) return !1;
    const n = M(U(t), { includeForbiddenWords: r });
    return n.length
      ? (e.preventDefault(),
        e.stopPropagation(),
        e.stopImmediatePropagation?.(),
        q(n, t, a),
        !0)
      : !1;
  }
  function A(e) {
    if (!e) return;
    (e.classList.toggle("is-active", r),
      e.setAttribute("aria-pressed", r ? "true" : "false"));
    const t = e.querySelector("small");
    t &&
      (t.textContent = r
        ? "\u5DF2\u5F00\u542F \xB7 \u53D1\u9001\u524D\u63D0\u9192"
        : "\u5DF2\u5173\u95ED \xB7 \u4E0D\u68C0\u67E5\u8FDD\u7981\u8BCD");
  }
  function L() {
    const e = document.querySelector("#ai-bt-root .ai-bt-actions");
    if (!e || e.querySelector("[data-orange-ope-guard-toggle]")) return !1;
    const t = document.createElement("button");
    return (
      (t.type = "button"),
      (t.dataset.orangeOpeGuardToggle = "true"),
      (t.innerHTML =
        '<span class="ai-bt-action-icon">\u{1F6E1}\uFE0F</span><span><strong>\u8FDD\u7981\u8BCD\u63D0\u9192</strong><small></small></span><span class="ai-bt-mode-switch"><i></i></span>'),
      t.addEventListener("click", (a) => {
        (a.preventDefault(),
          a.stopPropagation(),
          (r = !r),
          A(t),
          chrome.storage.local.set({ [b]: r }));
      }),
      e.appendChild(t),
      A(t),
      !0
    );
  }
  function N() {
    if (R.test(location.hostname)) {
      if (
        (chrome.storage.local.get([b], (e) => {
          ((r = e?.[b] !== !1),
            A(document.querySelector("[data-orange-ope-guard-toggle]")));
        }),
        !L())
      ) {
        const e = new MutationObserver(() => {
          L() && e.disconnect();
        });
        (e.observe(document.documentElement, { childList: !0, subtree: !0 }),
          setTimeout(() => e.disconnect(), 3e4));
      }
      (document.addEventListener(
        "keydown",
        (e) => {
          if (
            e.key !== "Enter" ||
            e.shiftKey ||
            e.ctrlKey ||
            e.altKey ||
            e.metaKey ||
            e.isComposing
          )
            return;
          const t = e.target instanceof Element && E(e.target) ? e.target : f(),
            a = p();
          t &&
            a?.contains(t) &&
            S(e, t, () => {
              const i = Array.from(
                a.querySelectorAll(
                  "button, input[type='submit'], [role='button'], .el-button",
                ),
              ).find((c) => k(c, t));
              i
                ? i.click()
                : t.dispatchEvent(
                    new KeyboardEvent("keydown", {
                      key: "Enter",
                      code: "Enter",
                      bubbles: !0,
                      cancelable: !0,
                    }),
                  );
            });
        },
        !0,
      ),
        document.addEventListener(
          "click",
          (e) => {
            const t =
              e.target instanceof Element
                ? e.target.closest(
                    "button, input[type='submit'], [role='button'], .el-button",
                  )
                : null;
            if (!t || t.closest(`#${m}`)) return;
            const a = f();
            k(t, a) && S(e, a, () => t.click());
          },
          !0,
        ),
        document.addEventListener(
          "submit",
          (e) => {
            const t = p();
            if (!t) return;
            const n =
              (e.target instanceof Element && t.contains(e.target)
                ? f(e.target)
                : null) || f(t);
            n &&
              S(e, n, () => {
                typeof e.target.requestSubmit == "function"
                  ? e.target.requestSubmit()
                  : e.target.submit?.();
              });
          },
          !0,
        ));
    }
  }
  ((globalThis[B] = Object.freeze({ detect: M, MAX_MESSAGE_CHARACTERS: 300 })),
    typeof document < "u" &&
      (document.readyState === "loading"
        ? document.addEventListener("DOMContentLoaded", N, { once: !0 })
        : N()));
})();
