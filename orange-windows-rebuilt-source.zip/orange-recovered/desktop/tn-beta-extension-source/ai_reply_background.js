(() => {
  "use strict";
  const G = "orangeGeminiApiKey",
    $ = "orangeGeminiModel",
    M = "gemini-3.5-flash-lite",
    B = "https://generativelanguage.googleapis.com/v1beta/models",
    C = {
      type: "object",
      additionalProperties: !1,
      properties: {
        heat: {
          type: "object",
          additionalProperties: !1,
          properties: {
            level: { type: "integer", minimum: 1, maximum: 5 },
            label: { type: "string" },
            reason: { type: "string" },
          },
          required: ["level", "label", "reason"],
        },
        relationshipStage: { type: "string" },
        topic: { type: "string" },
        reminder: { type: "string" },
        continuation: {
          type: "object",
          additionalProperties: !1,
          properties: {
            signal: {
              type: "string",
              enum: ["open", "polite_close", "temporary_busy", "explicit_stop"],
            },
            strategy: { type: "string" },
          },
          required: ["signal", "strategy"],
        },
        resonance: {
          type: "object",
          additionalProperties: !1,
          properties: {
            primary: { type: "string" },
            secondary: { type: "string" },
            reason: { type: "string" },
          },
          required: ["primary", "secondary", "reason"],
        },
        knownProfile: {
          type: "object",
          additionalProperties: !1,
          properties: {
            name: { type: "string" },
            location: { type: "string" },
            occupation: { type: "string" },
            age: { type: "string" },
            interests: {
              type: "array",
              items: { type: "string" },
              maxItems: 12,
            },
            food: { type: "array", items: { type: "string" }, maxItems: 10 },
            sports: { type: "array", items: { type: "string" }, maxItems: 10 },
            travel: { type: "array", items: { type: "string" }, maxItems: 10 },
            lifestyle: {
              type: "array",
              items: { type: "string" },
              maxItems: 10,
            },
            importantStories: {
              type: "array",
              items: { type: "string" },
              maxItems: 10,
            },
          },
          required: [
            "name",
            "location",
            "occupation",
            "age",
            "interests",
            "food",
            "sports",
            "travel",
            "lifestyle",
            "importantStories",
          ],
        },
        kellyDisclosed: {
          type: "array",
          items: { type: "string" },
          maxItems: 20,
        },
        reciprocalDisclosure: { type: "string" },
        replies: {
          type: "array",
          minItems: 3,
          maxItems: 3,
          items: {
            type: "object",
            additionalProperties: !1,
            properties: {
              style: {
                type: "string",
                enum: ["natural", "warm", "light_humor"],
              },
              label: { type: "string" },
              text: { type: "string" },
              zh: { type: "string" },
            },
            required: ["style", "label", "text", "zh"],
          },
        },
        directions: {
          type: "array",
          minItems: 3,
          maxItems: 4,
          items: {
            type: "object",
            additionalProperties: !1,
            properties: {
              label: { type: "string" },
              priority: { type: "string", enum: ["high", "medium", "low"] },
              reason: { type: "string" },
            },
            required: ["label", "priority", "reason"],
          },
        },
        avoid: { type: "string" },
      },
      required: [
        "heat",
        "relationshipStage",
        "topic",
        "reminder",
        "continuation",
        "resonance",
        "knownProfile",
        "kellyDisclosed",
        "reciprocalDisclosure",
        "replies",
        "directions",
        "avoid",
      ],
    };
  function x(e) {
    return String(e || "")
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, "")
      .trim();
  }
  function H(e) {
    for (const n of Array.isArray(e?.candidates) ? e.candidates : []) {
      const s = (Array.isArray(n?.content?.parts) ? n.content.parts : [])
        .filter((r) => r?.thought !== !0)
        .map((r) => (typeof r?.text == "string" ? r.text : ""))
        .join(
          `
`,
        )
        .trim();
      if (s) return s;
    }
    return "";
  }
  function z(e) {
    const n = String(e || ""),
      o = n.indexOf("{");
    if (o < 0) return "";
    let i = 0,
      s = !1,
      r = !1;
    for (let t = o; t < n.length; t += 1) {
      const l = n[t];
      if (s) {
        r ? (r = !1) : l === "\\" ? (r = !0) : l === '"' && (s = !1);
        continue;
      }
      if (l === '"') {
        s = !0;
        continue;
      }
      if ((l === "{" && (i += 1), l === "}" && ((i -= 1), i === 0)))
        return n.slice(o, t + 1);
    }
    return "";
  }
  function m(e) {
    const n = x(e)
        .replace(/^\uFEFF/, "")
        .trim(),
      o = [];
    n && o.push(n);
    const i = z(n);
    i && i !== n && o.push(i);
    for (const s of o) {
      try {
        const r = JSON.parse(s);
        return typeof r == "string"
          ? m(r)
          : (r && typeof r.content == "string" && !r.replies && m(r.content)) ||
              r;
      } catch {}
      try {
        const r = s.replace(/,\s*([}\]])/g, "$1"),
          t = JSON.parse(r);
        return typeof t == "string"
          ? m(t)
          : (t && typeof t.content == "string" && !t.replies && m(t.content)) ||
              t;
      } catch {}
    }
    return null;
  }
  function a(e, n = 1e3) {
    return String(e ?? "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, n);
  }
  function k(e, n = 160) {
    const o = a(e, n);
    return !o || /^(null|unknown|未知|n\/a)$/i.test(o) ? null : o;
  }
  function y(e, n = 10, o = 140) {
    return (Array.isArray(e) ? e : [])
      .map((i) => a(i, o))
      .filter(Boolean)
      .filter(
        (i, s, r) =>
          r.findIndex((t) => t.toLowerCase() === i.toLowerCase()) === s,
      )
      .slice(0, n);
  }
  function F(e) {
    const n = a(e, 1200);
    if (!n) return "";
    const o = n
        .split(/(?<=[.!?。！？])\s+/)
        .map((r) => r.trim())
        .filter(Boolean),
      i =
        /^(who|what|where|when|why|how|which|whose|do|does|did|are|is|am|was|were|can|could|would|will|have|has|had|should|may|mind|tell me|let me know|share|explain)\b/i;
    return o
      .filter(
        (r) =>
          !(
            /[?？]/.test(r) ||
            i.test(r) ||
            /\b(i wonder|i['’]?d love to know|curious (?:where|what|how|when|if|whether)|tell me|let me know|would love to hear)\b/i.test(
              r,
            )
          ),
      )
      .join(" ")
      .replace(/[?？]/g, ".")
      .replace(/\.{2,}/g, ".")
      .trim();
  }
  function Y(e) {
    const n = Math.max(1, Math.min(5, Number.parseInt(e?.level, 10) || 1));
    return {
      level: n,
      label: a(
        e?.label ||
          [
            "\u964C\u751F/\u8C28\u614E",
            "\u613F\u610F\u804A\u5929",
            "\u5F00\u59CB\u6709\u5171\u540C\u70B9",
            "\u660E\u663E\u719F\u6089",
            "\u670B\u53CB\u5F0F\u4EA4\u6D41",
          ][n - 1],
        60,
      ),
      reason: a(e?.reason, 220),
    };
  }
  function Q(e, n) {
    const o = F(e);
    if (!o || n === "explicit_stop") return o;
    const i =
        /\b(have (?:a |an )?(?:good|great|nice|wonderful) (?:day|evening|night|weekend)|take care|nice (?:talking|chatting) (?:to|with) you|enjoy (?:the )?(?:rest of )?(?:your )?(?:day|evening|night|weekend)|talk (?:to you )?later|catch you later|speak soon|goodbye|bye for now)\b/i,
      r = o
        .split(/(?<=[.!。！])\s+/)
        .map((t) => t.trim())
        .filter(Boolean)
        .filter((t) => !i.test(t));
    return (r.length ? r.join(" ") : o).trim();
  }
  function O(e) {
    const n = [
        "open",
        "polite_close",
        "temporary_busy",
        "explicit_stop",
      ].includes(e?.continuation?.signal)
        ? e.continuation.signal
        : "open",
      o = Array.isArray(e?.replies) ? e.replies : [],
      s = [
        ["natural", "\u81EA\u7136\u5171\u9E23"],
        ["warm", "\u6E29\u6696\u81EA\u7136"],
        ["light_humor", "\u8F7B\u677E\u5E7D\u9ED8"],
      ]
        .map(([t, l], u) => {
          const p = o.find((g) => g?.style === t) || o[u] || {};
          return {
            style: t,
            label: a(p?.label || l, 30) || l,
            text: Q(p?.text, n),
            zh: a(p?.zh, 500),
          };
        })
        .filter((t) => t.text);
    if (s.length < 3 || s.some((t) => !t.zh))
      throw new Error(
        "AI\u8FD4\u56DE\u7684\u4E09\u6761\u53CC\u8BED\u56DE\u590D\u4E0D\u5B8C\u6574",
      );
    const r = (Array.isArray(e?.directions) ? e.directions : [])
      .slice(0, 4)
      .map((t) => ({
        label: a(t?.label, 80),
        priority: ["high", "medium", "low"].includes(t?.priority)
          ? t.priority
          : "medium",
        reason: a(t?.reason, 220),
      }))
      .filter((t) => t.label);
    return {
      heat: Y(e?.heat),
      relationshipStage: a(e?.relationshipStage, 80),
      topic: a(e?.topic, 120),
      reminder: a(e?.reminder, 300),
      continuation: { signal: n, strategy: a(e?.continuation?.strategy, 260) },
      resonance: {
        primary: a(e?.resonance?.primary, 180),
        secondary: a(e?.resonance?.secondary, 180),
        reason: a(e?.resonance?.reason, 280),
      },
      knownProfile: {
        name: k(e?.knownProfile?.name),
        location: k(e?.knownProfile?.location),
        occupation: k(e?.knownProfile?.occupation),
        age: k(e?.knownProfile?.age, 60),
        interests: y(e?.knownProfile?.interests, 12, 90),
        food: y(e?.knownProfile?.food, 10, 90),
        sports: y(e?.knownProfile?.sports, 10, 90),
        travel: y(e?.knownProfile?.travel, 10, 120),
        lifestyle: y(e?.knownProfile?.lifestyle, 10, 120),
        importantStories: y(e?.knownProfile?.importantStories, 10, 180),
      },
      kellyDisclosed: y(e?.kellyDisclosed, 20, 120),
      reciprocalDisclosure: a(e?.reciprocalDisclosure, 220),
      replies: s,
      directions: r,
      avoid: a(e?.avoid, 260),
    };
  }
  async function J() {
    const e = await chrome.storage.local.get([G, $]);
    return {
      apiKey: String(e?.[G] || "").trim(),
      model: String(e?.[$] || M).trim() || M,
    };
  }
  function W(e) {
    return String(e || "")
      .toLowerCase()
      .startsWith("gemini-2.5")
      ? { thinkingBudget: 0 }
      : { thinkingLevel: "minimal", includeThoughts: !1 };
  }
  function V(e) {
    const n = globalThis.ORANGE_AI_CULTURE_KNOWLEDGE || {},
      o = String(e || "").toLowerCase(),
      i = (t, l) => {
        let u = 0;
        for (const g of l) {
          const E = Array.isArray(t?.[g]) ? t[g] : [];
          for (const A of E) {
            const S = String(A || "")
              .toLowerCase()
              .trim();
            S && o.includes(S) && (u += g === "cues" ? 4 : 1);
          }
        }
        const p = String(t?.key || "")
          .toLowerCase()
          .trim();
        return (p && o.includes(p) && (u += 3), u);
      },
      s = (Array.isArray(n.regions) ? n.regions : [])
        .map((t) => ({
          entry: t,
          score: i(t, ["cues", "culture", "food", "interests"]),
        }))
        .filter((t) => t.score > 0)
        .sort((t, l) => l.score - t.score)
        .slice(0, 3)
        .map((t) => t.entry),
      r = (Array.isArray(n.interests) ? n.interests : [])
        .map((t) => {
          const l = String(t?.key || "")
              .toLowerCase()
              .trim(),
            u = l && o.includes(l) ? 5 : i(t, ["resonance"]);
          return { entry: t, score: u };
        })
        .filter((t) => t.score > 0)
        .sort((t, l) => l.score - t.score)
        .slice(0, 6)
        .map((t) => t.entry);
    return !s.length && !r.length
      ? {
          note: "No specific U.S. region or hobby cue detected. Use only explicit conversation facts; do not stereotype.",
        }
      : { regions: s, interests: r };
  }
  async function X(e) {
    const { apiKey: n, model: o } = await J(),
      i = String(e?.context || "").trim();
    if (!i)
      throw new Error(
        "\u6CA1\u6709\u8BFB\u53D6\u5230\u804A\u5929\u5185\u5BB9\uFF0C\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u804A\u5929\u4F1A\u8BDD",
      );
    const s = a(e?.pageTitle, 300),
      r = a(e?.pageHost, 120),
      t = a(e?.localDate, 160),
      l = String(e?.draft || "").trim(),
      u =
        e?.contactMemory && typeof e.contactMemory == "object"
          ? e.contactMemory
          : null,
      p = e?.mode === "reengage" ? "reengage" : "reply",
      g =
        e?.phoneRegionHint && typeof e.phoneRegionHint == "object"
          ? e.phoneRegionHint
          : null,
      E =
        e?.reengagementMeta && typeof e.reengagementMeta == "object"
          ? e.reengagementMeta
          : null,
      A = [
        p === "reengage"
          ? "MODE = REENGAGE. Generate a natural friendship re-engagement after silence, using stored memory and old topics without guilt, pressure, fake coincidence, or a question."
          : "MODE = REPLY. Analyze the full active conversation and return the structured social-copilot JSON requested by the system instruction. Be concise and fast.",
        "The latest message is the immediate context, but use the full history to avoid repeating known facts and to preserve relationship continuity.",
        "Priority: resonance first. Replies must contain no questions. Next-step information-gathering ideas belong only in directions.",
        p === "reengage"
          ? "Re-engagement must feel fresh and easy to answer. Prefer a remembered interest/story/location cue or one authentic Kelly observation. Never mention silence duration unless the person themselves brought it up."
          : "Keep the conversational thread open unless the latest message is an explicit request to stop contact. Do not use routine farewell language in normal/polite-close/busy cases.",
        p === "reengage"
          ? "Do not use: why haven't you replied, haven't heard from you, you disappeared, are you ignoring me, checking in again, or any guilt/urgency language."
          : "When they reveal a meaningful fact, consider one matching Kelly self-disclosure that has not already been disclosed, then extend with a callback or observation.",
        "Bilingual rule: every operator-facing field must be Chinese or bilingual; every replies item must contain English text plus an accurate natural Chinese zh translation.",
        "Reply length rule: each reply should be 2-4 natural sentences (roughly 35-90 English words), with warmth, one concrete callback, and an open conversational hook; do not make it abrupt.",
        "Keep analysis concise and return only 3-4 directions.",
        t ? `Browser local date/time: ${t}` : "",
        r ? `Current site: ${r}` : "",
        s ? `Page title: ${s}` : "",
        g
          ? `PHONE AREA-CODE HINT (weak cue only; not verified residence):
${JSON.stringify(g)}`
          : "",
        p === "reengage" && E
          ? `RE-ENGAGEMENT STATUS (do not invent missing timing):
${JSON.stringify(E)}`
          : "",
        u
          ? `Stored contact memory from earlier interactions (current visible conversation wins on conflict):
${JSON.stringify(u)}`
          : "",
        "",
        "Full current conversation, oldest to newest:",
        i,
        l
          ? `
Current unsent draft in the input box; treat only as optional operator intent, not as sent history:
${l}`
          : "",
      ].filter(Boolean).join(`
`),
      S = V(`${i}
${u ? JSON.stringify(u) : ""}
${g ? JSON.stringify(g) : ""}`),
      h = await chrome.storage.local.get([
        "orangeSupabaseUrl",
        "orangeSupabasePublishableKey",
        "orangeSupabaseAccessToken",
      ]);
    if (
      h.orangeSupabaseUrl &&
      h.orangeSupabasePublishableKey &&
      h.orangeSupabaseAccessToken
    ) {
      const c = async (K, T = 2200, d = 0.7) => {
          let R = null;
          for (let _ = 0; _ < 2; _ += 1) {
            const L = new AbortController(),
              te = setTimeout(() => L.abort(), 48e3);
            try {
              return await fetch(
                `${h.orangeSupabaseUrl}/functions/v1/ai-gateway`,
                {
                  method: "POST",
                  signal: L.signal,
                  headers: {
                    "Content-Type": "application/json",
                    apikey: h.orangeSupabasePublishableKey,
                    Authorization: `Bearer ${h.orangeSupabaseAccessToken}`,
                  },
                  body: JSON.stringify({
                    action: "generate",
                    messages: K,
                    maxTokens: T,
                    temperature: d,
                  }),
                },
              );
            } catch (q) {
              if (((R = q), q?.name === "AbortError"))
                throw new Error(
                  "AI\u5DF2\u5C1D\u8BD5\u591A\u4E2AKey\u548C\u6A21\u578B\u4F46\u4ECD\u8D85\u8FC748\u79D2\uFF0C\u8BF7\u91CD\u65B0\u751F\u6210",
                );
              if (_ === 0) {
                await new Promise((ne) => setTimeout(ne, 700));
                continue;
              }
            } finally {
              clearTimeout(te);
            }
          }
          throw new Error(
            `\u65E0\u6CD5\u8FDE\u63A5AI\u7F51\u5173\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u6216\u91CD\u65B0\u767B\u5F55${R?.message ? ` \xB7 ${R.message}` : ""}`,
          );
        },
        N = await c([
          {
            role: "system",
            content: `${String(globalThis.ORANGE_AI_SYSTEM_PROMPT || "")}

Relevant U.S. culture reference (optional cues only):
${JSON.stringify(S)}
Return only valid JSON matching the requested structure.`,
          },
          { role: "user", content: A },
        ]),
        f = await N.json().catch(() => null);
      if (!N.ok || !f?.ok)
        throw new Error(
          f?.message ||
            `\u591A\u6A21\u578BAI\u7F51\u5173\u8BF7\u6C42\u5931\u8D25\uFF1AHTTP ${N.status}`,
        );
      const U = x(String(f.content || ""));
      let b = m(U);
      try {
        if (!b) throw new Error("AI\u8FD4\u56DE\u4E0D\u662F\u6709\u6548JSON");
        return {
          advice: O(b),
          model: `${f.provider || "AI"} \xB7 ${f.model || "\u81EA\u52A8\u6A21\u578B"}`,
        };
      } catch {
        const T = await c(
            [
              {
                role: "system",
                content: `Repair the supplied model output into valid JSON matching this schema. Preserve meaning, supply exactly three complete bilingual replies, and output JSON only. Schema: ${JSON.stringify(C)}`,
              },
              { role: "user", content: U.slice(0, 18e3) },
            ],
            1800,
            0.15,
          ),
          d = await T.json().catch(() => null);
        if (!T.ok || !d?.ok)
          throw new Error(
            d?.message ||
              "AI\u8FD4\u56DE\u683C\u5F0F\u81EA\u52A8\u4FEE\u590D\u5931\u8D25",
          );
        if (((b = m(String(d.content || ""))), !b))
          throw new Error(
            "AI\u8FD4\u56DE\u683C\u5F0F\u5F02\u5E38\uFF0C\u81EA\u52A8\u4FEE\u590D\u540E\u4ECD\u65E0\u6CD5\u8BC6\u522B",
          );
        return {
          advice: O(b),
          model: `${d.provider || f.provider || "AI"} \xB7 ${d.model || f.model || "\u81EA\u52A8\u6A21\u578B"}`,
        };
      }
    }
    if (!n)
      throw new Error(
        "\u6CA1\u6709\u53EF\u7528\u7684Groq Key\uFF1B\u5982\u9700\u4F7F\u7528Gemini\u5907\u7528\uFF0C\u8BF7\u5148\u5728\u63D2\u4EF6\u8BBE\u7F6E\u4FDD\u5B58Google AI Studio API Key",
      );
    const Z = `${B}/${encodeURIComponent(o)}:generateContent`,
      j = new AbortController(),
      ee = setTimeout(() => j.abort(), 5e4);
    let v;
    try {
      v = await fetch(Z, {
        method: "POST",
        signal: j.signal,
        headers: { "Content-Type": "application/json", "x-goog-api-key": n },
        body: JSON.stringify({
          systemInstruction: {
            parts: [
              { text: String(globalThis.ORANGE_AI_SYSTEM_PROMPT || "") },
              {
                text: `
# Relevant U.S. Culture / Interest Reference
Use only as optional rapport cues, never as stereotypes:
${JSON.stringify(S)}`,
              },
            ],
          },
          contents: [{ role: "user", parts: [{ text: A }] }],
          generationConfig: {
            maxOutputTokens: 1900,
            responseMimeType: "application/json",
            responseJsonSchema: C,
            thinkingConfig: W(o),
          },
        }),
      });
    } catch (c) {
      throw c?.name === "AbortError"
        ? new Error(
            "Gemini \u751F\u6210\u8D85\u8FC7 50 \u79D2\uFF0C\u5DF2\u81EA\u52A8\u505C\u6B62\u3002\u5EFA\u8BAE\u5207\u6362 Gemini 3.5 Flash-Lite \u540E\u91CD\u8BD5",
          )
        : c;
    } finally {
      clearTimeout(ee);
    }
    const P = await v.text();
    let w = null;
    try {
      w = P ? JSON.parse(P) : null;
    } catch {}
    if (!v.ok) {
      const c = w?.error?.message || P || `HTTP ${v.status}`;
      throw new Error(`Google Gemini \u8BF7\u6C42\u5931\u8D25\uFF1A${c}`);
    }
    const I = x(H(w));
    if (!I) {
      const c =
        w?.promptFeedback?.blockReason || w?.candidates?.[0]?.finishReason;
      throw new Error(
        c
          ? `Gemini \u6CA1\u6709\u8FD4\u56DE\u53EF\u7528\u5185\u5BB9\uFF1A${c}`
          : "Gemini \u6CA1\u6709\u8FD4\u56DE\u53EF\u7528\u5185\u5BB9\uFF0C\u8BF7\u518D\u8BD5\u4E00\u6B21",
      );
    }
    const D = m(I);
    if (!D) {
      const c = a(w?.candidates?.[0]?.finishReason, 80);
      throw (
        console.error("[Orange AI Copilot] JSON parse failed", {
          finishReason: c,
          modelText: I,
        }),
        c === "MAX_TOKENS"
          ? new Error(
              "Gemini \u8F93\u51FA\u88AB\u622A\u65AD\uFF0C\u8BF7\u518D\u8BD5\u4E00\u6B21",
            )
          : new Error(
              "Gemini \u8FD4\u56DE\u683C\u5F0F\u5F02\u5E38\uFF0C\u5DF2\u542F\u7528\u5BB9\u9519\u89E3\u6790\u4F46\u4ECD\u65E0\u6CD5\u8BC6\u522B",
            )
      );
    }
    return { advice: O(D), model: o };
  }
  chrome.runtime.onMessage.addListener((e, n, o) =>
    e?.type === "ORANGE_AI_GET_SETTINGS"
      ? (J()
          .then((i) =>
            o({
              ok: !0,
              configured: !!i.apiKey,
              model: i.model,
              provider: "google-ai-studio",
            }),
          )
          .catch((i) =>
            o({
              ok: !1,
              error:
                i?.message || "\u8BFB\u53D6 Gemini \u8BBE\u7F6E\u5931\u8D25",
            }),
          ),
        !0)
      : e?.type !== "ORANGE_AI_GENERATE_ADVICE"
        ? !1
        : (X(e)
            .then((i) => o({ ok: !0, ...i }))
            .catch((i) => {
              (console.error("[Orange AI Copilot] Gemini request failed", i),
                o({
                  ok: !1,
                  error:
                    i?.message ||
                    "Gemini \u667A\u80FD\u63D0\u9192\u751F\u6210\u5931\u8D25",
                }));
            }),
          !0),
  );
})();
