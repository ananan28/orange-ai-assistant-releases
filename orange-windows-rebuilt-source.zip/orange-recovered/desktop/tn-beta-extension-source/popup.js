(() => {
  "use strict";
  const p = Object.freeze({
      schemaVersion: 6,
      enabled: !0,
      imageDataUrl: "",
      imageOpacity: 1,
      panelOpacity: 0.22,
      groupPanelOpacity: 0.9,
      blur: 0,
      brightness: 100,
      glassBlur: 4,
    }),
    _ = "orangeGeminiApiKey",
    v = "orangeGeminiModel",
    k = "gemini-3.5-flash-lite",
    a = (t) => document.querySelector(t),
    N = (t) => Array.from(document.querySelectorAll(t));
  let B = null,
    g = "",
    A = !1,
    r = { ...p },
    O = null;
  const G = a("#site-name"),
    h = a("#site-status"),
    D = a("#save-state"),
    P = a("#background-panel"),
    T = a("#background-preview"),
    R = a("#preview-badge");
  function u(t, e, n, c) {
    const o = Number(t);
    return Number.isFinite(o) ? Math.min(n, Math.max(e, o)) : c;
  }
  function C(t) {
    const e = String(t || "").trim();
    return /^#[0-9a-f]{6}$/i.test(e) ? e.toLowerCase() : "";
  }
  function i(t) {
    return `${t}:${g}`;
  }
  function s(t, e = "") {
    ((D.textContent = t), (D.className = e));
  }
  async function d(t, e = {}) {
    if (!B?.id) return !1;
    try {
      return (await chrome.tabs.sendMessage(B.id, { type: t, ...e }), !0);
    } catch {
      return !1;
    }
  }
  function L() {
    return i("aiBtCustomBackground");
  }
  function U(t) {
    const e = t && typeof t == "object" ? t : {};
    return {
      schemaVersion: 6,
      enabled: typeof e.enabled == "boolean" ? e.enabled : !0,
      imageDataUrl: typeof e.imageDataUrl == "string" ? e.imageDataUrl : "",
      imageOpacity: u(e.imageOpacity, 0.15, 1, p.imageOpacity),
      panelOpacity: u(e.panelOpacity, 0.06, 0.72, p.panelOpacity),
      groupPanelOpacity: u(
        e.groupPanelOpacity,
        0.35,
        0.98,
        p.groupPanelOpacity,
      ),
      blur: u(e.blur, 0, 12, p.blur),
      brightness: u(e.brightness, 55, 145, p.brightness),
      glassBlur: u(e.glassBlur, 0, 10, p.glassBlur),
    };
  }
  async function E({ immediate: t = !1 } = {}) {
    if (!g) return;
    const e = async () => {
      O = null;
      try {
        (s("\u6B63\u5728\u540C\u6B65\u2026", "busy"),
          (r.schemaVersion = 6),
          await chrome.storage.local.set({ [L()]: r }),
          await d("AI_BT_BACKGROUND_CHANGED"),
          s("\u8BBE\u7F6E\u5DF2\u540C\u6B65", "ok"));
      } catch (n) {
        (console.error("[Orange Popup] background save failed", n),
          s("\u4FDD\u5B58\u5931\u8D25", "error"));
      }
    };
    (O && clearTimeout(O), t ? await e() : (O = setTimeout(e, 90)));
  }
  function b(t, e, n) {
    const c = a(`#${t}`),
      o = a(`#${t}-output`);
    !c || !o || ((c.value = String(e)), (o.textContent = `${e}${n}`));
  }
  function y() {
    ((a("#background-enabled").checked = !!r.enabled),
      b("brightness", Math.round(r.brightness), "%"),
      b("blur", Math.round(r.blur), "px"),
      b("glass-blur", Math.round(r.glassBlur), "px"),
      b("panel-opacity", Math.round(r.panelOpacity * 100), "%"),
      b("group-panel-opacity", Math.round(r.groupPanelOpacity * 100), "%"),
      b("image-opacity", Math.round(r.imageOpacity * 100), "%"));
    const t =
      r.imageDataUrl || chrome.runtime.getURL("assets/panel-background.png");
    ((T.style.backgroundImage = `url(${JSON.stringify(t)})`),
      (T.style.filter = `brightness(${r.brightness}%)`),
      (T.style.opacity = String(Math.max(0.35, r.imageOpacity))),
      (R.textContent = r.imageDataUrl
        ? "\u81EA\u5B9A\u4E49\u80CC\u666F"
        : "\u9ED8\u8BA4\u80CC\u666F"));
    const e = !!g;
    (P.classList.toggle("disabled", !e),
      (a("#background-enabled").disabled = !e),
      (a("#background-note").textContent = e
        ? "\u80CC\u666F\u5B9E\u65F6\u5E94\u7528\u5230\u5F53\u524D\u5E73\u53F0\uFF1A\u4E3B\u804A\u5929\u533A\u89C6\u89C9\u7A7F\u900F\uFF0C\u8054\u7CFB\u4EBA\u5217\u8868\u4E0E\u4FA7\u680F\u4F7F\u7528\u5206\u5C42\u6BDB\u73BB\u7483\uFF1B\u4EC5\u672C\u673A\u53EF\u89C1\u3002"
        : "\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u7F51\u7AD9\u6807\u7B7E\u9875\u3002"));
  }
  function I(t) {
    N("[data-mode]").forEach((e) => {
      e.classList.toggle("active", e.dataset.mode === t);
    });
  }
  async function $() {
    B = (await chrome.tabs.query({ active: !0, currentWindow: !0 }))[0] || null;
    let e = null;
    try {
      e = B?.url ? new URL(B.url) : null;
    } catch {}
    ((g = e?.hostname || ""),
      (A = /(^|\.)opensms\.xin$/i.test(g)),
      (G.textContent = g || "Chrome \u5185\u90E8\u9875\u9762"),
      (h.textContent = A
        ? "OpenSMS \u5DF2\u8BC6\u522B"
        : g
          ? "\u7FFB\u8BD1\u53EF\u7528"
          : "\u53D7\u9650\u9875\u9762"),
      (h.className = `status-pill ${A ? "ok" : "warn"}`));
  }
  async function H() {
    if (!g) {
      (I("pause"), y());
      return;
    }
    const t = [
        i("aiBtMode"),
        i("aiBtPhoneMask"),
        i("aiBtInputTranslator"),
        i("aiBtTranslationColor"),
        i("aiBtBubbleLightColor"),
        L(),
      ],
      e = await chrome.storage.local.get(t),
      n = A ? "chat" : "pause",
      c = ["chat", "page", "pause"].includes(e[i("aiBtMode")])
        ? e[i("aiBtMode")]
        : n;
    (I(c),
      (a("#phone-mask").checked = !!e[i("aiBtPhoneMask")]),
      (a("#input-translator").checked = !!e[i("aiBtInputTranslator")]));
    const o = C(e[i("aiBtTranslationColor")]);
    a("#translation-color").value = o || "#ffd166";
    const l = C(e[i("aiBtBubbleLightColor")]);
    ((a("#bubble-light-color").value = l || "#a97bff"),
      (r = U(e[L()])),
      !e[L()] && g && (r.enabled = !0),
      y());
  }
  async function M() {
    const t = await chrome.storage.local.get([_, v]),
      e = String(t?.[_] || "").trim(),
      n = String(t?.[v] || k).trim() || k,
      c = a("#ai-api-key"),
      o = a("#ai-model"),
      l = a("#ai-config-status");
    (c &&
      ((c.value = ""),
      (c.placeholder = e
        ? "\u5DF2\u4FDD\u5B58 \xB7 \u8F93\u5165\u65B0 Key \u53EF\u66FF\u6362"
        : "\u7C98\u8D34 Gemini API Key")),
      o && (o.value = n),
      l &&
        ((l.textContent = e ? "\u5DF2\u914D\u7F6E" : "\u672A\u914D\u7F6E"),
        (l.className = `status-pill ${e ? "ok" : "warn"}`)));
  }
  async function K() {
    const t = a("#ai-api-key"),
      e = a("#ai-model"),
      n = String(t?.value || "").trim(),
      c = String(e?.value || k).trim() || k,
      o = { [v]: c };
    (n && (o[_] = n),
      await chrome.storage.local.set(o),
      t && (t.value = ""),
      await M(),
      s("Google AI \u8BBE\u7F6E\u5DF2\u4FDD\u5B58", "ok"));
  }
  async function V() {
    (await chrome.storage.local.remove(_),
      await M(),
      s("Gemini Key \u5DF2\u6E05\u9664", "ok"));
  }
  async function F(t) {
    if (!(t instanceof File) || !t.type.startsWith("image/"))
      throw new Error("\u8BF7\u9009\u62E9\u56FE\u7247\u6587\u4EF6");
    const e = await new Promise((w, x) => {
        const m = new FileReader();
        ((m.onload = () => w(String(m.result || ""))),
          (m.onerror = () =>
            x(new Error("\u65E0\u6CD5\u8BFB\u53D6\u56FE\u7247"))),
          m.readAsDataURL(t));
      }),
      n = await new Promise((w, x) => {
        const m = new Image();
        ((m.onload = () => w(m)),
          (m.onerror = () =>
            x(new Error("\u65E0\u6CD5\u89E3\u6790\u56FE\u7247"))),
          (m.src = e));
      }),
      o = Math.min(
        1,
        2560 / Math.max(n.naturalWidth || 1, n.naturalHeight || 1),
      ),
      l = document.createElement("canvas");
    ((l.width = Math.max(1, Math.round((n.naturalWidth || 1) * o))),
      (l.height = Math.max(1, Math.round((n.naturalHeight || 1) * o))));
    const S = l.getContext("2d", { alpha: !1 });
    if (!S) return e;
    S.drawImage(n, 0, 0, l.width, l.height);
    try {
      const w = l.toDataURL("image/webp", 0.9);
      if (w.startsWith("data:image/webp")) return w;
    } catch {}
    return l.toDataURL("image/jpeg", 0.9);
  }
  function f(t, e, n = Number) {
    const c = a(`#${t}`),
      o = a(`#${t}-output`);
    (c.addEventListener("input", () => {
      const l = Number(c.value);
      r[e] = n(l);
      const S = t.includes("opacity") || t === "brightness" ? "%" : "px";
      ((o.textContent = `${l}${S}`), y(), E());
    }),
      c.addEventListener("change", () => E({ immediate: !0 })));
  }
  function W() {
    (N("[data-mode]").forEach((t) => {
      t.addEventListener("click", async () => {
        if (!g) return;
        const e = t.dataset.mode;
        (I(e),
          await chrome.storage.local.set({ [i("aiBtMode")]: e }),
          await d("AI_BT_MODE_CHANGED", { mode: e }),
          s("\u7FFB\u8BD1\u6A21\u5F0F\u5DF2\u66F4\u65B0", "ok"));
      });
    }),
      a("#input-translator").addEventListener("change", async (t) => {
        const e = t.target.checked;
        (await chrome.storage.local.set({ [i("aiBtInputTranslator")]: e }),
          await d("AI_BT_INPUT_TRANSLATOR_CHANGED", { enabled: e }),
          s("\u8F93\u5165\u7FFB\u8BD1\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#phone-mask").addEventListener("change", async (t) => {
        const e = t.target.checked;
        (await chrome.storage.local.set({ [i("aiBtPhoneMask")]: e }),
          await d("AI_BT_PHONE_MASK_CHANGED", { enabled: e }),
          s("\u9690\u79C1\u906E\u6321\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#translation-color").addEventListener("input", async (t) => {
        const e = C(t.target.value);
        (await chrome.storage.local.set({ [i("aiBtTranslationColor")]: e }),
          await d("AI_BT_TRANSLATION_COLOR_CHANGED", { color: e }),
          s("\u8BD1\u6587\u989C\u8272\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#color-reset").addEventListener("click", async () => {
        ((a("#translation-color").value = "#ffd166"),
          await chrome.storage.local.set({ [i("aiBtTranslationColor")]: "" }),
          await d("AI_BT_TRANSLATION_COLOR_CHANGED", { color: "" }),
          s("\u5DF2\u6062\u590D\u9ED8\u8BA4\u989C\u8272", "ok"));
      }),
      a("#bubble-light-color").addEventListener("input", async (t) => {
        const e = C(t.target.value) || "#a97bff";
        (await chrome.storage.local.set({ [i("aiBtBubbleLightColor")]: e }),
          await d("AI_BT_BUBBLE_LIGHT_COLOR_CHANGED", { color: e }),
          s("\u6C14\u6CE1\u6D41\u5149\u989C\u8272\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#bubble-light-reset").addEventListener("click", async () => {
        const t = "#a97bff";
        ((a("#bubble-light-color").value = t),
          await chrome.storage.local.set({ [i("aiBtBubbleLightColor")]: t }),
          await d("AI_BT_BUBBLE_LIGHT_COLOR_CHANGED", { color: t }),
          s("\u5DF2\u6062\u590D\u9ED8\u8BA4\u6D41\u5149", "ok"));
      }),
      a("#ai-save")?.addEventListener("click", async () => {
        try {
          (s("\u6B63\u5728\u4FDD\u5B58 Google AI \u8BBE\u7F6E\u2026", "busy"),
            await K());
        } catch (t) {
          (console.error("[Orange Popup] AI settings save failed", t),
            s("Google AI \u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25", "error"));
        }
      }),
      a("#ai-clear")?.addEventListener("click", async () => {
        try {
          await V();
        } catch (t) {
          (console.error("[Orange Popup] AI key clear failed", t),
            s("\u6E05\u9664 Gemini Key \u5931\u8D25", "error"));
        }
      }),
      a("#ai-model")?.addEventListener("change", async (t) => {
        (await chrome.storage.local.set({ [v]: String(t.target.value || k) }),
          s("AI \u6A21\u578B\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#background-enabled").addEventListener("change", async (t) => {
        ((r.enabled = t.target.checked), await E({ immediate: !0 }), y());
      }),
      a("#upload-background").addEventListener("click", () =>
        a("#background-file").click(),
      ),
      a("#background-file").addEventListener("change", async (t) => {
        const e = t.target.files?.[0];
        if (!e) return;
        const n = a("#upload-background"),
          c = n.textContent;
        ((n.disabled = !0),
          (n.textContent = "\u6B63\u5728\u5904\u7406\u56FE\u7247\u2026"));
        try {
          ((r.imageDataUrl = await F(e)),
            (r.enabled = !0),
            y(),
            await E({ immediate: !0 }),
            (n.textContent = "\u56FE\u7247\u5DF2\u5E94\u7528"));
        } catch (o) {
          (console.error("[Orange Popup] image error", o),
            (n.textContent = "\u56FE\u7247\u5904\u7406\u5931\u8D25"),
            s(o.message || "\u56FE\u7247\u5904\u7406\u5931\u8D25", "error"));
        } finally {
          (setTimeout(() => {
            ((n.disabled = !1), (n.textContent = c));
          }, 900),
            (t.target.value = ""));
        }
      }),
      a("#reset-background").addEventListener("click", async () => {
        ((r = { ...p, enabled: A }),
          y(),
          await E({ immediate: !0 }),
          s("\u5DF2\u6062\u590D\u9ED8\u8BA4\u80CC\u666F", "ok"));
      }),
      f("brightness", "brightness", (t) => u(t, 55, 145, 100)),
      f("blur", "blur", (t) => u(t, 0, 12, 0)),
      f("glass-blur", "glassBlur", (t) => u(t, 0, 10, 4)),
      f("panel-opacity", "panelOpacity", (t) => u(t / 100, 0.06, 0.72, 0.22)),
      f("group-panel-opacity", "groupPanelOpacity", (t) =>
        u(t / 100, 0.35, 0.98, 0.9),
      ),
      f("image-opacity", "imageOpacity", (t) => u(t / 100, 0.15, 1, 1)));
  }
  async function z() {
    W();
    try {
      (await $(), await H(), await M());
      const t = await d("AI_BT_GET_PAGE_STATE");
      g &&
        !t &&
        ((h.textContent = "\u5237\u65B0\u9875\u9762\u540E\u751F\u6548"),
        (h.className = "status-pill warn"));
    } catch (t) {
      (console.error("[Orange Popup] init failed", t),
        (G.textContent =
          "\u65E0\u6CD5\u8BFB\u53D6\u5F53\u524D\u6807\u7B7E\u9875"),
        (h.textContent = "\u9700\u8981\u5237\u65B0"),
        (h.className = "status-pill warn"),
        s("\u521D\u59CB\u5316\u5931\u8D25", "error"));
    }
  }
  z();
})();
