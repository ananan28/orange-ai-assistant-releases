(() => {
  "use strict";
  const v = "orange-ai-reply-root",
    I = "ai-bt-root",
    ee = `#${I} .ai-bt-actions`,
    N = "data-orange-ai-reply",
    $ = "data-orange-ai-reflow",
    U = "orange-ai-reply-toast",
    k = "orange-ai-copilot-panel",
    R = { test: () => !0 },
    te = "orangeAiContactMemory:v1:";
  let P = !1,
    T = null,
    w = 0,
    L = {};
  function p(e) {
    return String(e || "")
      .replace(/\s+/g, " ")
      .trim();
  }
  function h(e) {
    if (!(e instanceof Element)) return !1;
    const n = getComputedStyle(e);
    if (
      n.display === "none" ||
      n.visibility === "hidden" ||
      Number(n.opacity) === 0
    )
      return !1;
    const t = e.getBoundingClientRect();
    return (
      t.width >= 20 && t.height >= 14 && t.bottom >= 0 && t.top <= innerHeight
    );
  }
  function ne(e) {
    if (!(e instanceof Element) || !h(e) || e.closest(`#${I}, #${v}`))
      return !1;
    if (e instanceof HTMLTextAreaElement) return !e.disabled && !e.readOnly;
    if (e instanceof HTMLInputElement) {
      const n = String(e.type || "text").toLowerCase();
      return (
        ["text", "search", "email", "url", "tel"].includes(n) &&
        !e.disabled &&
        !e.readOnly
      );
    }
    return !!e.isContentEditable;
  }
  function Y(e) {
    return e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement
      ? String(e.value || "")
      : String(e?.innerText || e?.textContent || "");
  }
  function ae(e) {
    return String(e || "")
      .replace(
        /\r\n?/g,
        `
`,
      )
      .replace(/[\u200B\uFEFF]/g, "")
      .replace(/\u00A0/g, " ")
      .replace(
        /[ \t]+\n/g,
        `
`,
      )
      .replace(
        /\n[ \t]+/g,
        `
`,
      )
      .replace(
        /\n{2,}/g,
        `
`,
      )
      .trim();
  }
  function D(e) {
    if (e?.isConnected) {
      if (
        (e.focus({ preventScroll: !0 }),
        e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement)
      ) {
        const n = String(e.value || "").length;
        try {
          e.setSelectionRange(n, n);
        } catch {}
        return;
      }
      if (e.isContentEditable) {
        const n = window.getSelection(),
          t = document.createRange();
        (t.selectNodeContents(e),
          t.collapse(!1),
          n?.removeAllRanges(),
          n?.addRange(t));
      }
    }
  }
  function oe(e, n) {
    const t = ae(n);
    if (e instanceof HTMLInputElement) {
      const a = Object.getOwnPropertyDescriptor(
        HTMLInputElement.prototype,
        "value",
      )?.set;
      a ? a.call(e, t) : (e.value = t);
    } else if (e instanceof HTMLTextAreaElement) {
      const a = Object.getOwnPropertyDescriptor(
        HTMLTextAreaElement.prototype,
        "value",
      )?.set;
      a ? a.call(e, t) : (e.value = t);
    } else if (e?.isContentEditable) e.textContent = t;
    else return !1;
    try {
      e.dispatchEvent(
        new InputEvent("input", {
          bubbles: !0,
          composed: !0,
          inputType: "insertText",
          data: t,
        }),
      );
    } catch {
      e.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
    }
    return (
      D(e),
      requestAnimationFrame(() => D(e)),
      setTimeout(() => D(e), 0),
      !0
    );
  }
  function O() {
    return (
      document.querySelector("#v-im-app .main-content .right") ||
      document.querySelector("#v-im-app .main.content .right") ||
      document.querySelector("#im-app .main-content .right") ||
      document.querySelector("#im-app .main_content .right") ||
      document.querySelector("div.main-content div.right") ||
      document.querySelector("#v-im-app .right, #im-app .right") ||
      null
    );
  }
  function y(e) {
    if (!ne(e)) return !1;
    if (!/(^|\.)opensms\.xin$/i.test(location.hostname)) return !0;
    const n = O();
    return !n || n.contains(e);
  }
  function B() {
    const e = document.activeElement;
    if (y(e)) return e;
    if (y(T) && T.isConnected) return T;
    const n =
      typeof H < "u" ? H.find((r) => r.host.test(location.hostname)) : null;
    if (n?.editors?.length)
      for (const r of n.editors) {
        const o = Array.from(document.querySelectorAll(r)).filter(
          (i) => y(i) && h(i),
        );
        if (o.length) return o[o.length - 1];
      }
    const t =
        (/(^|\.)opensms\.xin$/i.test(location.hostname) && O()) || document,
      a = [
        "textarea",
        "[contenteditable='true']",
        "input[type='text']",
        "input:not([type])",
      ],
      s = [];
    for (const r of a)
      t.querySelectorAll(r).forEach((o) => {
        y(o) && s.push(o);
      });
    return s.length
      ? (s.sort((r, o) => {
          const i = r.getBoundingClientRect(),
            c = o.getBoundingClientRect(),
            l = i.bottom + Math.min(i.width, 900) * 0.1;
          return c.bottom + Math.min(c.width, 900) * 0.1 - l;
        }),
        s[0] || null)
      : null;
  }
  function se(e, n, t) {
    const a = `${e?.className || ""} ${n?.className || ""}`.toLowerCase();
    if (/im-chat-other|incoming|receive|received|opponent|customer/.test(a))
      return "Them";
    if (
      /im-chat-user|im-chat-self|im-chat-mine|outgoing|sent|mine|self/.test(a)
    )
      return "You";
    if (t && n instanceof Element) {
      const s = t.getBoundingClientRect(),
        r = n.getBoundingClientRect();
      return r.left + r.width / 2 >= s.left + s.width / 2 ? "You" : "Them";
    }
    return "Chat";
  }
  function q(e) {
    if (!(e instanceof Element)) return "";
    const n = e.cloneNode(!0);
    n.querySelectorAll(
      ".ai-bt-chat-translation, .ai-bt-page-translation, .ai-bt-generated, .ai-bt-phone-mask-layer, .oz-bubble-character, .oz-time-character, .oz-time-character-img, button, svg, img",
    ).forEach((a) => a.remove());
    let t = p(n.textContent || "");
    return (
      (t = t
        .replace(
          /\b20\d{2}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?\b/g,
          " ",
        )
        .replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g, " ")
        .replace(
          /(?:已发送|已送达|发送中|送达|发送失败|delivered|sent)\b/gi,
          " ",
        )
        .replace(/\s+/g, " ")
        .trim()),
      t
    );
  }
  function re() {
    const e = O();
    if (!e) return "";
    const n = [
      ".im-chat-other .im-chat-text",
      ".im-chat-user .im-chat-text",
      ".im-chat-self .im-chat-text",
      ".im-chat-mine .im-chat-text",
    ];
    let t = Array.from(e.querySelectorAll(n.join(", ")));
    t.length ||
      (t = Array.from(
        e.querySelectorAll(
          ".im-chat-text, .message-content, [class*='message-content'], [class*='message-text']",
        ),
      ));
    const a = [],
      s = new Set();
    for (const r of t) {
      if (!(r instanceof Element) || s.has(r)) continue;
      s.add(r);
      const o = q(r);
      if (!o) continue;
      const i = r.closest(
          ".im-chat-other, .im-chat-user, .im-chat-self, .im-chat-mine, .chat-message, .chat_message, .message-item, .message_item, [class*='chat-message'], [class*='message-item']",
        ),
        c = se(i, r, e);
      a.push(`${c}: ${o}`);
    }
    return a.join(`
`);
  }
  const H = [
      {
        host: /(^|\.)textnow\.com$/i,
        containers: ["#messageView", "#messageView ul"],
        messages: [
          "li.chat-item.incoming",
          "li.chat-item.outgoing",
          "li.chat-item",
        ],
        editors: [
          "textarea#text-input",
          "textarea[placeholder*='Type a message' i]",
        ],
        platform: "textnow",
      },
      {
        host: /(^|\.)xinghansms\.net$/i,
        containers: [
          ".chat_right_body .chat_message .el-scrollbar__view",
          ".chat_right_body .chat_message",
          ".chat_right .chat_message .el-scrollbar__view",
          ".chat_right .chat_message",
        ],
        messages: [
          ":scope > *",
          "[class*='message-item']",
          "[class*='message-row']",
          "[class*='message-content']",
          "[class*='message-text']",
        ],
        editors: [
          ".chat_right_body .chat_message_operates textarea",
          ".chat_right_body .chat_message_operates input[type='text']",
          ".chat_right_body .chat_message_operates [contenteditable='true']",
          ".chat_message_operates textarea",
          ".chat_message_operates input[type='text']",
          ".chat_message_operates [contenteditable='true']",
        ],
        platform: "xinghan",
      },
      {
        host: /(^|\.)client\.xhsim\.ai$/i,
        containers: ["#messageParent"],
        messages: [":scope > [id^='chatMessage_']", "[id^='chatMessage_']"],
        editors: [
          "#kt_chat_messenger_footer textarea",
          "#kt_chat_messenger_footer [contenteditable='true']",
          "#kt_chat_messenger_footer input[type='text']",
          "textarea[placeholder*='Type a message' i]",
        ],
        platform: "xhsim",
      },
      {
        host: /(^|\.)c2csms\.com$/i,
        containers: [
          ".chat-panel .chat-content .messages-area .messages-list",
          ".chat-content .messages-area .messages-list",
          ".messages-area .messages-list",
          ".messages-list",
        ],
        messages: [
          ":scope > *",
          "[class*='message-item']",
          "[class*='message-row']",
          "[class*='message-content']",
          "[class*='message-text']",
          "[class*='bubble']",
        ],
        editors: [
          ".chat-panel .input-area textarea",
          ".chat-panel .input-area input[type='text']",
          ".chat-panel .input-area [contenteditable='true']",
          ".input-area textarea",
          ".input-area input[type='text']",
          ".input-area [contenteditable='true']",
        ],
        platform: "c2c",
      },
      {
        host: /(^|\.)skt1\.net$/i,
        containers: [
          ".chat_right_body .chat_message .el-scrollbar__view",
          ".chat_right_body .chat_message",
          ".chat_right .chat_message .el-scrollbar__view",
          ".chat_right .chat_message",
        ],
        messages: [
          ":scope > div",
          "[class*='message-item']",
          "[class*='message-row']",
          "[class*='message-content']",
          "[class*='message-text']",
        ],
        editors: [
          ".chat_right_body .chat_message_operates .inputchat_message_operate_text",
          ".chat_message_operates .inputchat_message_operate_text",
          ".chat_right_body .chat_message_operates input[type='text']",
        ],
        platform: "skt1",
      },
    ],
    ie = {
      host: /.*/,
      containers: [
        ".chat_message",
        ".messages-list",
        ".messages-area",
        ".chat-content",
        ".conversation-content",
        ".chat-panel",
        "[class*='chat-message']",
        "[class*='messages-list']",
        "[class*='conversation-content']",
      ],
      messages: [
        ":scope > *",
        "[class*='message-item']",
        "[class*='message-row']",
        "[class*='message-content']",
        "[class*='message-text']",
        "[class*='bubble']",
        ".im-chat-text",
      ],
      editors: [
        "textarea",
        "[contenteditable='true']",
        ".input-area input[type='text']",
        ".chat-input input[type='text']",
        "[class*='input-area'] input[type='text']",
        "[class*='chat-input'] input[type='text']",
      ],
      platform: "generic",
    };
  function ce() {
    const e = H.find((a) => a.host.test(location.hostname)) || ie,
      n = B(),
      t = [];
    for (const a of e.containers)
      document.querySelectorAll(a).forEach((s) => {
        if (!(s instanceof Element) || t.includes(s)) return;
        let r = 0;
        (n && s.contains(n) && (r += 1e5),
          h(s) && (r += 1e4),
          (r += Math.min(
            s.querySelectorAll("[class*='message'], p").length,
            1e3,
          )),
          t.push(s),
          (s.__orangeAiScopeScore = r));
      });
    return (
      t.sort(
        (a, s) => (s.__orangeAiScopeScore || 0) - (a.__orangeAiScopeScore || 0),
      ),
      t[0] ? { scope: t[0], config: e } : null
    );
  }
  function le(e, n) {
    if (!(e instanceof Element)) return e?.getBoundingClientRect?.() || null;
    const t = n?.getBoundingClientRect?.(),
      a = [e, ...e.querySelectorAll("p, span, div")];
    let s = null,
      r = 1 / 0;
    for (const o of a) {
      if (!(o instanceof Element) || !h(o)) continue;
      const i = q(o);
      if (!i || i.length > 1800) continue;
      const c = o.getBoundingClientRect();
      if (
        c.width < 8 ||
        c.height < 8 ||
        (t &&
          (c.width > t.width * 0.94 ||
            c.height > Math.max(220, t.height * 0.55)))
      )
        continue;
      const l = Array.from(o.children).filter((b) => {
          if (!(b instanceof Element)) return !1;
          const d = q(b);
          return d && d.length >= Math.max(4, i.length * 0.55);
        }).length,
        u = c.width * c.height + l * 1e5;
      u < r && ((s = c), (r = u));
    }
    return s || e.getBoundingClientRect();
  }
  function ue(e, n, t) {
    const a = String(e?.className || "").toLowerCase();
    if (/incoming|receive|received|other|customer|left/.test(a)) return "Them";
    if (/outgoing|sent|mine|self|right/.test(a)) return "You";
    if (t?.platform === "xhsim" && e instanceof HTMLElement) {
      const o = String(e.getAttribute("style") || "").toLowerCase(),
        i = parseFloat(e.style.marginRight || "0") || 0,
        c = parseFloat(e.style.marginLeft || "0") || 0;
      if (
        (/margin-right/.test(o) && i > 0 && c <= 0) ||
        /text-align\s*:\s*right/.test(o)
      )
        return "You";
      if (
        (/margin-left/.test(o) && c > 0 && i <= 0) ||
        /text-align\s*:\s*left/.test(o)
      )
        return "Them";
    }
    const s = n?.getBoundingClientRect?.(),
      r = le(e, n);
    if (s && r) {
      const o = s.left + s.width / 2;
      return r.left + r.width / 2 >= o ? "You" : "Them";
    }
    return "Chat";
  }
  function me() {
    const e = ce();
    if (!e) return "";
    const { scope: n, config: t } = e;
    let a = [];
    for (const o of t.messages) {
      const i = Array.from(n.querySelectorAll(o));
      if (i.length) {
        a = i;
        break;
      }
    }
    if (!a.length) return "";
    const s = [],
      r = new Set();
    for (const o of a) {
      if (!(o instanceof Element) || r.has(o)) continue;
      r.add(o);
      const i = q(o);
      if (!i) continue;
      const c = o.closest(
          ".chat-message, .chat_message, .message-item, .message_item, [class*='chat-message'], [class*='message-item'], [class*='message-row'], [id^='chatMessage_']",
        ),
        u = ue(c && c !== n ? c : o, n, t);
      s.push(`${u}: ${i}`);
    }
    return s.join(`
`);
  }
  function j() {
    return /(^|\.)opensms\.xin$/i.test(location.hostname) ? re() : me();
  }
  function de() {
    return (
      document.querySelector("#v-im-app .main-content .left") ||
      document.querySelector("#v-im-app .main.content .left") ||
      document.querySelector("#im-app .main-content .left") ||
      document.querySelector("#im-app .main_content .left") ||
      document.querySelector("div.main-content div.left") ||
      null
    );
  }
  function ge(e) {
    const n = String(e || "");
    let t = 2166136261;
    for (let a = 0; a < n.length; a += 1)
      ((t ^= n.charCodeAt(a)), (t = Math.imul(t, 16777619)));
    return (t >>> 0).toString(36);
  }
  function x(e) {
    return p(e)
      .replace(/未读|回复|发送|发信人|收信人/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 180);
  }
  function g(e) {
    try {
      return globalThis.ORANGE_NANP_LOOKUP?.normalizeNanpPhone?.(e) || "";
    } catch {
      return "";
    }
  }
  function pe(e) {
    try {
      return globalThis.ORANGE_NANP_LOOKUP?.lookup?.(e) || null;
    } catch {
      return null;
    }
  }
  function he() {
    const e = document.querySelector("#v-im-app, #im-app") || document.body;
    if (!(e instanceof Element)) return null;
    function n(o) {
      const i = p(o),
        c = i.search(/对方号码\s*[:：]?/i);
      if (c < 0) return "";
      let l = i.slice(c).replace(/^.*?对方号码\s*[:：]?\s*/i, "");
      return (
        (l = l.split(/我方号码|搜索收信人号码|发信人|收信人/i)[0] || l),
        g(l)
      );
    }
    const t = document.createTreeWalker(e, NodeFilter.SHOW_TEXT);
    let a;
    for (; (a = t.nextNode()); ) {
      const o = String(a.nodeValue || "");
      if (!/对方号码/i.test(o)) continue;
      let i = a.parentElement;
      for (
        let c = 0;
        i && c < 5 && !i.closest?.(`#${v}, #${I}, #${k}`);
        c += 1, i = i.parentElement
      ) {
        const l = p(i.innerText || i.textContent || "");
        if (!l || l.length > 500) continue;
        const u = n(l);
        if (u) return { phone: u, source: "opponent-number-field", label: l };
      }
    }
    const s = p(e.innerText || e.textContent || ""),
      r = n(s);
    return r
      ? {
          phone: r,
          source: "opponent-number-label",
          label: `\u5BF9\u65B9\u53F7\u7801 ${r}`,
        }
      : null;
  }
  function fe() {
    if (!/(^|\.)skt1\.net$/i.test(location.hostname)) return null;
    const e = Array.from(
      document.querySelectorAll(
        ".chat_right_container .header, .chat_right .header, .chat_right_body .header",
      ),
    );
    for (const a of e) {
      if (!(a instanceof Element) || !h(a)) continue;
      const s = p(a.innerText || a.textContent || "");
      if (!s || !s.includes(">")) continue;
      const r = s.split(">").pop() || "",
        o = g(r);
      if (o) return { phone: o, source: "skt1-chat-header", label: s };
    }
    const n = document.querySelector(
      ".chat_right_body, .chat_right, [class*='chat_right']",
    );
    if (n instanceof Element)
      for (const a of n.querySelectorAll("div,span,p")) {
        if (!h(a)) continue;
        const s = p(a.innerText || a.textContent || "");
        if (!s || s.length > 100 || !/(?:>|→|->)/.test(s)) continue;
        const r = s.split(/(?:>|→|->)/).pop() || "",
          o = g(r);
        if (o)
          return {
            phone: o,
            source: "skt1-current-chat-generic-header",
            label: s,
          };
      }
    const t = document.querySelector(
      ".chat_left, .chat-left, [class*='chat_left']",
    );
    if (t) {
      const a = Array.from(
        t.querySelectorAll(
          ".is-active, .active, .selected, [aria-selected='true'], [aria-current='true'], [data-selected='true']",
        ),
      );
      for (const s of a) {
        if (!(s instanceof Element) || !h(s)) continue;
        const r = p(s.innerText || s.textContent || ""),
          o = g(r);
        if (o) return { phone: o, source: "skt1-selected-contact", label: r };
      }
    }
    return null;
  }
  function be() {
    if (!/(^|\.)xinghansms\.net$/i.test(location.hostname)) return null;
    const e = [
      ".chat_right .chat_right_header",
      ".chat_right_header",
      ".chat_right_body .chat_right_container .header",
      ".chat_right_container .header",
      ".chat_right_body .header",
    ];
    for (const t of e)
      for (const a of document.querySelectorAll(t)) {
        if (!(a instanceof Element) || !h(a)) continue;
        const s = p(a.innerText || a.textContent || "");
        if (!s || !/(?:->|→|>)/.test(s)) continue;
        const r = s.split(/(?:->|→|>)/).pop() || "",
          o = g(r);
        if (o) return { phone: o, source: "xinghan-chat-header", label: s };
      }
    const n = document.querySelector(".chat_right, [class*='chat_right']");
    if (n instanceof Element) {
      const t = Array.from(n.querySelectorAll("div, span, p"));
      for (const a of t) {
        if (!h(a)) continue;
        const s = p(a.innerText || a.textContent || "");
        if (!s || s.length > 120 || !/(?:->|→|>)/.test(s)) continue;
        const r = s.split(/(?:->|→|>)/).pop() || "",
          o = g(r);
        if (o)
          return {
            phone: o,
            source: "xinghan-current-chat-fallback",
            label: s,
          };
      }
    }
    return null;
  }
  function ye() {
    if (!/(^|\.)c2csms\.com$/i.test(location.hostname)) return null;
    const e = Array.from(
      document.querySelectorAll(
        ".chat-panel .chat-content .chat-header, .chat-content .chat-header, .chat-panel .chat-header, .chat-header",
      ),
    );
    for (const t of e) {
      if (!(t instanceof Element) || !h(t)) continue;
      const a = p(t.innerText || t.textContent || "");
      if (!a || a.length > 350) continue;
      const s = g(a);
      if (s) return { phone: s, source: "c2c-chat-header", label: a };
    }
    const n = Array.from(
      document.querySelectorAll(
        ".conversation-panel, [class*='conversation-panel'], [class*='conversation-list']",
      ),
    );
    for (const t of n) {
      const a = t.querySelector(
        ".active, .is-active, .selected, [aria-selected='true'], [aria-current='true'], [data-selected='true']",
      );
      if (!(a instanceof Element) || !h(a)) continue;
      const s = p(a.innerText || a.textContent || ""),
        r = s.match(
          /收信人\s*[:：]?\s*(?:\+?1[\s().-]*)?(?:\(?\d{3}\)?[\s.-]*)\d{3}[\s.-]*\d{4}/i,
        ),
        o = g(r?.[0] || "");
      if (o) return { phone: o, source: "c2c-selected-recipient", label: s };
    }
    return null;
  }
  function xe() {
    if (!/(^|\.)client\.xhsim\.ai$/i.test(location.hostname)) return null;
    const e = document.querySelector("#messageParent"),
      n = [];
    let t = e?.parentElement;
    for (let a = 0; t && a < 6; a += 1, t = t.parentElement) n.push(t);
    for (const a of n) {
      const s = Array.from(a.querySelectorAll("input,button,span,div,p"));
      for (const r of s) {
        if (!(r instanceof Element) || !h(r) || e?.contains(r)) continue;
        const o = x(r.value || r.innerText || r.textContent || "");
        if (!o || o.length > 80 || /[*]{2,}/.test(o)) continue;
        const i = g(o);
        if (i)
          return { phone: i, source: "xhsim-current-chat-header", label: o };
      }
    }
    return null;
  }
  function z(e) {
    let n = "",
      t = "\u5F53\u524D\u8054\u7CFB\u4EBA",
      a = "";
    if (/(^|\.)textnow\.com$/i.test(location.hostname)) {
      const o = document.querySelector(
          ".conversation-title__name[data-number], .conversation-title_name[data-number]",
        ),
        i = o?.getAttribute("data-number") || "",
        c = x(o?.textContent || ""),
        l = g(i) || g(c);
      l && ((n = l), (t = c || l), (a = "textnow-conversation-title"));
    }
    if (/(^|\.)client\.xhsim\.ai$/i.test(location.hostname)) {
      const o = xe();
      o?.phone && ((n = o.phone), (t = o.label || o.phone), (a = o.source));
    }
    if (/(^|\.)xinghansms\.net$/i.test(location.hostname)) {
      const o = be();
      o?.phone && ((n = o.phone), (t = o.label || o.phone), (a = o.source));
    }
    if (!n && /(^|\.)c2csms\.com$/i.test(location.hostname)) {
      const o = ye();
      o?.phone && ((n = o.phone), (t = o.label || o.phone), (a = o.source));
    }
    if (!n && /(^|\.)skt1\.net$/i.test(location.hostname)) {
      const o = fe();
      o?.phone && ((n = o.phone), (t = o.label || o.phone), (a = o.source));
    }
    if (!n && R.test(location.hostname)) {
      const o = he();
      o?.phone && ((n = o.phone), (t = o.label || o.phone), (a = o.source));
    }
    if (!n && /(^|\.)opensms\.xin$/i.test(location.hostname)) {
      const o = de(),
        i =
          o?.querySelector(".oz-contact-card.oz-selected") ||
          o?.querySelector(
            "[aria-selected='true'], [aria-current='true'], [data-selected='true']",
          ) ||
          o?.querySelector(
            ".oz-contact-card.is-active, .oz-contact-card.active, .oz-contact-card.selected",
          );
      if (i) {
        const c = x(i.innerText || i.textContent || ""),
          l = g(c);
        ((n = l || c),
          (t = c || l || t),
          l && (a = "selected-contact-fallback"));
      }
      if (!n) {
        const l = O()?.querySelector(
            ".chat-header, .conversation-header, [class*='chat-header'], [class*='conversation-header'], [class*='user-info'], [class*='contact-info']",
          ),
          u = x(l?.innerText || l?.textContent || ""),
          b = g(u);
        ((n = b || u),
          (t = u || b || t),
          b && (a = "conversation-header-fallback"));
      }
    }
    if (!n) {
      const o = document.querySelector(
          ".active[aria-selected], .selected[aria-selected], [aria-selected='true'], [aria-current='true'], [data-selected='true']",
        ),
        i = document.querySelector(
          ".chat-header, .conversation-header, [class*='chat-header'], [class*='conversation-header'], [class*='recipient-info'], [class*='contact-info']",
        );
      for (const c of [i, o]) {
        if (!(c instanceof Element) || !h(c)) continue;
        const l = x(c.innerText || c.textContent || ""),
          u = g(l);
        if (u) {
          ((n = u), (t = l || u), (a = "generic-current-conversation"));
          break;
        }
      }
    }
    if (!n) {
      const o = `${location.hostname}|${location.pathname}|${location.hash}`,
        i =
          String(e || "")
            .split(
              `
`,
            )
            .find((c) => /^Them:\s*/.test(c)) || "";
      ((n = `${o}|${i.slice(0, 160)}`),
        (t = x(i.replace(/^Them:\s*/, "")) || t));
    }
    const s = g(n) || g(t),
      r = s ? pe(s) : null;
    return (
      r && s && ((r.scannedPhone = s), (r.phoneSource = a || "fallback")),
      {
        key: `${te}${location.hostname}:${ge(s || n)}`,
        label: t.slice(0, 120),
        rawHint: n.slice(0, 160),
        phoneDigits: s,
        phoneSource: a,
        areaLookup: r,
      }
    );
  }
  globalThis.ORANGE_GET_CURRENT_IDENTITY = () => z(j());
  function V(e, n = 20) {
    const t = [],
      a = new Set();
    for (const s of Array.isArray(e) ? e : []) {
      const r = p(s);
      if (!r) continue;
      const o = r.toLowerCase();
      if (!a.has(o) && (a.add(o), t.push(r), t.length >= n)) break;
    }
    return t;
  }
  function M(e, n) {
    const t = `${n}: `,
      a = String(e || "")
        .split(
          `
`,
        )
        .map((s) => s.trim())
        .filter(Boolean);
    for (let s = a.length - 1; s >= 0; s -= 1)
      if (a[s].startsWith(t)) return a[s].slice(t.length).trim();
    return "";
  }
  function W(e) {
    const n = String(e || "")
        .split(
          `
`,
        )
        .map((a) => a.trim())
        .filter(Boolean),
      t = n[n.length - 1] || "";
    return t.startsWith("Them: ")
      ? "Them"
      : t.startsWith("You: ")
        ? "You"
        : "Chat";
  }
  function _e(e) {
    return /\b(stop (?:texting|messaging|contacting)|do not contact|don['’]?t contact|don['’]?t text|leave me alone|not interested in (?:talking|chatting)|remove my number|unsubscribe)\b/i.test(
      String(e || ""),
    );
  }
  function F(e, n) {
    const t = e?.activity && typeof e.activity == "object" ? e.activity : {},
      a = new Date().toISOString(),
      s = M(n, "Them"),
      r = M(n, "You"),
      o = { ...t };
    return (
      !o.lastCustomerMessage && s
        ? ((o.lastCustomerMessage = s),
          (o.lastCustomerReplyAt = o.lastCustomerReplyAt || ""))
        : s &&
          s !== o.lastCustomerMessage &&
          ((o.lastCustomerMessage = s), (o.lastCustomerReplyAt = a)),
      !o.lastOutgoingMessage && r
        ? ((o.lastOutgoingMessage = r),
          (o.lastOutgoingAt = o.lastOutgoingAt || ""))
        : r &&
          r !== o.lastOutgoingMessage &&
          ((o.lastOutgoingMessage = r), (o.lastOutgoingAt = a)),
      (o.lastSpeaker = W(n)),
      (o.lastObservedAt = a),
      (o.explicitStop = _e(s) || e?.continuationSignal === "explicit_stop"),
      o
    );
  }
  function Se(e) {
    const n = e?.lastCustomerReplyAt || e?.lastOutgoingAt || "";
    if (!n)
      return {
        label: "\u65F6\u957F\u672A\u77E5",
        hours: null,
        bucket: "unknown",
      };
    const t = Date.now() - Date.parse(n);
    if (!Number.isFinite(t) || t < 0)
      return {
        label: "\u65F6\u957F\u672A\u77E5",
        hours: null,
        bucket: "unknown",
      };
    const a = t / 36e5;
    if (a < 24)
      return {
        label: `${Math.max(1, Math.round(a))} \u5C0F\u65F6\u5185`,
        hours: a,
        bucket: "under_1d",
      };
    const s = Math.floor(a / 24);
    return s <= 3
      ? { label: `${s} \u5929`, hours: a, bucket: "1_3d" }
      : s <= 14
        ? { label: `${s} \u5929`, hours: a, bucket: "4_14d" }
        : s <= 45
          ? { label: `${s} \u5929`, hours: a, bucket: "15_45d" }
          : { label: `${s} \u5929\u4EE5\u4E0A`, hours: a, bucket: "over_45d" };
  }
  function ve(e, n) {
    const t = e?.activity || F(e, n),
      a = Se(t);
    return {
      latestSpeaker: W(n),
      silenceLabel: a.label,
      silenceBucket: a.bucket,
      lastCustomerMessage: t?.lastCustomerMessage || M(n, "Them"),
      lastOutgoingMessage: t?.lastOutgoingMessage || M(n, "You"),
      explicitStop: !!(
        t?.explicitStop || e?.continuationSignal === "explicit_stop"
      ),
    };
  }
  async function $e(e) {
    try {
      const t = (await chrome.storage.local.get(e.key))?.[e.key];
      return t && typeof t == "object" ? t : null;
    } catch (n) {
      return (
        console.debug("[Orange AI Copilot] contact memory read failed", n),
        null
      );
    }
  }
  function Ae(e = {}, n = {}) {
    const t = (r) => n?.[r] || e?.[r] || null,
      a = [
        "interests",
        "food",
        "sports",
        "travel",
        "lifestyle",
        "importantStories",
      ],
      s = {
        name: t("name"),
        location: t("location"),
        occupation: t("occupation"),
        age: t("age"),
      };
    for (const r of a)
      s[r] = V(
        [...(e?.[r] || []), ...(n?.[r] || [])],
        r === "importantStories" ? 12 : 10,
      );
    return s;
  }
  async function Ee(e, n, t, a) {
    if (!e?.key || !n) return null;
    const s = {
      version: 1,
      identityLabel: e.label,
      knownProfile: Ae(t?.knownProfile, n.knownProfile),
      kellyDisclosed: V(
        [...(t?.kellyDisclosed || []), ...(n.kellyDisclosed || [])],
        24,
      ),
      relationshipStage: n.relationshipStage || t?.relationshipStage || "",
      lastTopic: n.topic || t?.lastTopic || "",
      heat: n.heat || t?.heat || null,
      continuationSignal:
        n?.continuation?.signal || t?.continuationSignal || "open",
      areaCodeHint: e?.areaLookup || t?.areaCodeHint || null,
      activity: F(t, a || ""),
      updatedAt: new Date().toISOString(),
    };
    try {
      return (await chrome.storage.local.set({ [e.key]: s }), s);
    } catch (r) {
      return (
        console.debug("[Orange AI Copilot] contact memory save failed", r),
        s
      );
    }
  }
  function f(e, n = "info") {
    let t = document.getElementById(U);
    (t ||
      ((t = document.createElement("div")),
      (t.id = U),
      t.setAttribute("role", "status"),
      document.documentElement.appendChild(t)),
      (t.className = `orange-ai-reply-toast ${n}`),
      (t.textContent = String(e || "")),
      t.classList.add("show"),
      clearTimeout(f._timer),
      (f._timer = setTimeout(
        () => t?.classList.remove("show"),
        n === "error" ? 4600 : 2400,
      )));
  }
  function m(e) {
    return String(e ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
  function Ce(e) {
    return [
      "\u8C28\u614E",
      "\u613F\u610F\u804A",
      "\u6709\u5171\u540C\u70B9",
      "\u660E\u663E\u719F\u6089",
      "\u670B\u53CB\u611F",
    ][Math.max(1, Math.min(5, Number(e) || 1)) - 1];
  }
  function ke(e) {
    return e === "high"
      ? "\u4F18\u5148"
      : e === "low"
        ? "\u5907\u7528"
        : "\u53EF\u9009";
  }
  function Te(e) {
    const n = [];
    (e?.name && n.push(["\u540D\u5B57", e.name]),
      e?.location && n.push(["\u5730\u533A", e.location]),
      e?.occupation && n.push(["\u5DE5\u4F5C", e.occupation]),
      e?.age && n.push(["\u5E74\u9F84", e.age]));
    const t = [
      ["\u5174\u8DA3", e?.interests],
      ["\u7F8E\u98DF", e?.food],
      ["\u8FD0\u52A8", e?.sports],
      ["\u65C5\u884C", e?.travel],
      ["\u751F\u6D3B", e?.lifestyle],
    ];
    for (const [a, s] of t)
      Array.isArray(s) && s.length && n.push([a, s.slice(0, 5).join(" \xB7 ")]);
    return (
      Array.isArray(e?.importantStories) &&
        e.importantStories.length &&
        n.push(["\u8BB0\u5FC6", e.importantStories.slice(-3).join(" \xB7 ")]),
      n
    );
  }
  let _ = null,
    A = null,
    we = null;
  function G() {
    document.getElementById(k)?.remove();
  }
  function Le(e, n) {
    G();
    const t = document.createElement("aside");
    ((t.id = k),
      t.setAttribute("role", "dialog"),
      t.setAttribute("aria-label", "AI\u667A\u80FD\u5171\u9E23\u63D0\u9192"));
    const a = Number(e?.heat?.level) || 1,
      s = Te(e?.knownProfile),
      r = Array.isArray(e?.replies) ? e.replies : [],
      o = Array.isArray(e?.directions) ? e.directions : [],
      i = Array.isArray(e?.kellyDisclosed) ? e.kellyDisclosed : [],
      c = e?.continuation || {},
      l = e?._mode === "reengage",
      u = e?.areaLookup || null,
      b = e?.reengagementMeta || null;
    ((t.innerHTML = `
      <div class="orange-ai-copilot-head">
        <div>
          <span class="orange-ai-kicker">AI SOCIAL COPILOT</span>
          <h3>${l ? "\u5BA2\u6237\u56DE\u6D41\u5EFA\u8BAE" : "\u667A\u80FD\u5171\u9E23\u63D0\u9192"}</h3>
        </div>
        <button type="button" class="orange-ai-close" aria-label="\u5173\u95ED">\xD7</button>
      </div>

      <div class="orange-ai-meta-row">
        <span class="orange-ai-heat heat-${Math.max(1, Math.min(5, a))}">\u70ED\u5EA6 ${a}/5 \xB7 ${m(e?.heat?.label || Ce(a))}</span>
        ${e?.topic ? `<span class="orange-ai-topic">${m(e.topic)}</span>` : ""}
      </div>

      ${
        u
          ? `
        <section class="orange-ai-card orange-ai-area-hint">
          <div class="orange-ai-card-title">\u{1F4CD} \u533A\u53F7\u5730\u70B9\u7EBF\u7D22</div>
          ${u.scannedPhone ? `<div class="orange-ai-resonance"><b>\u8BC6\u522B\u53F7\u7801</b><span>${m(`+1 ${u.scannedPhone.slice(0, 3)} ${u.scannedPhone.slice(3, 6)} ${u.scannedPhone.slice(6)}`)}</span></div>` : ""}
          <div class="orange-ai-resonance primary"><b>${m(u.areaCode || "")}</b><span>${m(u.labelZh || u.regionZh || "")}<br>${m(u.label || u.region || "")}</span></div>
          ${u.citiesEn?.length || u.nearbyCitiesEn?.length ? `<div class="orange-ai-resonance"><b>\u57CE\u5E02 / Cities</b><span>${m((u.citiesZh || []).join("\u3001"))}<br>${m((u.citiesEn || []).join(", "))}</span></div><div class="orange-ai-resonance"><b>\u5468\u8FB9 / Nearby</b><span>${m((u.nearbyCitiesZh || []).join("\u3001"))}<br>${m((u.nearbyCitiesEn || []).join(", "))}</span></div>` : ""}
          <small class="orange-ai-note">\u4F18\u5148\u8BFB\u53D6\u5F53\u524D\u4F1A\u8BDD\u9876\u90E8\u201C\u5BF9\u65B9\u53F7\u7801\u201D\u5B57\u6BB5\u3002\u533A\u53F7\u4EC5\u4EE3\u8868\u53F7\u7801\u53EF\u80FD\u5F52\u5C5E\u5730\u533A\uFF0C\u4E0D\u7B49\u4E8E\u5BA2\u6237\u5F53\u524D\u4F4F\u5740\uFF1B\u643A\u53F7\u8F6C\u7F51\u540E\u53EF\u80FD\u4E0D\u540C\u3002</small>
        </section>`
          : ""
      }

      ${
        l && b
          ? `
        <section class="orange-ai-card orange-ai-reflow-card">
          <div class="orange-ai-card-title">\u267B\uFE0F \u56DE\u6D41\u72B6\u6001</div>
          <div class="orange-ai-resonance primary"><b>\u672A\u56DE\u590D</b><span>${m(b.silenceLabel || "\u65F6\u957F\u672A\u77E5")}</span></div>
          <small class="orange-ai-note">\u56DE\u6D41\u4F18\u5148\u7528\u65E7\u8BDD\u9898\u3001\u5174\u8DA3\u3001\u5730\u533A\u751F\u6D3B\u6216 Kelly \u7684\u8F7B\u91CF\u751F\u6D3B\u5206\u4EAB\u91CD\u65B0\u6253\u5F00\u8BDD\u9898\uFF0C\u4E0D\u50AC\u3001\u4E0D\u8D23\u5907\u3001\u4E0D\u5236\u9020\u7D27\u8FEB\u611F\u3002</small>
        </section>`
          : ""
      }

      ${
        e?.relationshipStage || c?.signal !== "open"
          ? `
        <section class="orange-ai-card">
          <div class="orange-ai-card-title">\u{1F9ED} \u5BF9\u8BDD\u72B6\u6001</div>
          ${e?.relationshipStage ? `<div class="orange-ai-resonance"><b>\u9636\u6BB5</b><span>${m(e.relationshipStage)}</span></div>` : ""}
          ${c?.signal && c.signal !== "open" ? `<div class="orange-ai-resonance primary"><b>\u4FE1\u53F7</b><span>${m(c.signal === "polite_close" ? "\u793C\u8C8C\u6536\u5C3E\u4FE1\u53F7 \xB7 \u63A5\u4F4F\u540E\u7559\u94A9\u5B50" : c.signal === "temporary_busy" ? "\u6682\u65F6\u5FD9\u788C \xB7 \u4E0D\u50AC\u56DE\u590D\uFF0C\u8F7B\u91CF\u7559\u94A9\u5B50" : "\u660E\u786E\u505C\u6B62 \xB7 \u5C0A\u91CD\u8FB9\u754C")}</span></div>` : ""}
          ${c?.strategy ? `<small class="orange-ai-note">${m(c.strategy)}</small>` : ""}
        </section>`
          : ""
      }

      ${
        e?.reminder
          ? `
        <section class="orange-ai-card orange-ai-reminder">
          <div class="orange-ai-card-title">\u{1F4A1} \u73B0\u5728\u6700\u9002\u5408</div>
          <p>${m(e.reminder)}</p>
        </section>`
          : ""
      }

      <section class="orange-ai-card">
        <div class="orange-ai-card-title">\u{1F525} \u5171\u9E23\u70B9</div>
        ${e?.resonance?.primary ? `<div class="orange-ai-resonance primary"><b>\u4F18\u5148</b><span>${m(e.resonance.primary)}</span></div>` : ""}
        ${e?.resonance?.secondary ? `<div class="orange-ai-resonance"><b>\u5907\u7528</b><span>${m(e.resonance.secondary)}</span></div>` : ""}
        ${e?.resonance?.reason ? `<small class="orange-ai-note">${m(e.resonance.reason)}</small>` : ""}
      </section>

      ${
        s.length
          ? `
        <section class="orange-ai-card">
          <div class="orange-ai-card-title">\u{1F9E9} \u5BA2\u6237\u957F\u671F\u8BB0\u5FC6</div>
          <div class="orange-ai-profile-grid">
            ${s.map(([d, S]) => `<span><b>${m(d)}</b>${m(S)}</span>`).join("")}
          </div>
        </section>`
          : ""
      }

      ${
        i.length || e?.reciprocalDisclosure
          ? `
        <section class="orange-ai-card">
          <div class="orange-ai-card-title">\u{1F4AC} Kelly \u4FE1\u606F\u91CA\u653E</div>
          ${i.length ? `<p class="orange-ai-note">\u5DF2\u91CA\u653E\uFF1A${m(i.join(" \xB7 "))}</p>` : ""}
          ${e?.reciprocalDisclosure ? `<div class="orange-ai-resonance primary"><b>\u672C\u8F6E</b><span>${m(e.reciprocalDisclosure)}</span></div>` : ""}
        </section>`
          : ""
      }

      <section class="orange-ai-card orange-ai-replies-card">
        <div class="orange-ai-card-title">${l ? "\u267B\uFE0F \u56DE\u6D41\u65B9\u6848" : "\u270D\uFE0F \u56DE\u590D\u65B9\u6848"} <small>\u6B63\u6587\u4E0D\u5E26\u95EE\u53E5 \xB7 \u70B9\u51FB\u540E\u586B\u5165\u8F93\u5165\u6846</small></div>
        <div class="orange-ai-replies">
          ${r
            .map(
              (d, S) => `
            <button type="button" class="orange-ai-reply-option" data-orange-ai-option="${S}">
              <span class="orange-ai-option-label">${m(d.label || `\u65B9\u6848 ${S + 1}`)}</span>
              <span class="orange-ai-option-zh">${m(d.zh || "\u4E2D\u6587\u7FFB\u8BD1\u751F\u6210\u4E2D")}</span>
              <span class="orange-ai-option-text">${m(d.text || "")}</span>
            </button>`,
            )
            .join("")}
        </div>
      </section>

      <section class="orange-ai-card">
        <div class="orange-ai-card-title">\u{1F9ED} \u4E0B\u4E00\u6B65\u65B9\u5411 <small>\u7531\u4F60\u4EBA\u5DE5\u51B3\u5B9A\u662F\u5426\u63A8\u8FDB</small></div>
        <div class="orange-ai-directions">
          ${
            o.length
              ? o
                  .map(
                    (d) => `
            <div class="orange-ai-direction priority-${m(d.priority || "medium")}">
              <div><span>${m(ke(d.priority))}</span><b>${m(d.label)}</b></div>
              <p>${m(d.reason || "")}</p>
            </div>`,
                  )
                  .join("")
              : '<p class="orange-ai-empty">\u8FD9\u4E00\u8F6E\u5148\u4FDD\u6301\u5171\u9E23\uFF0C\u4E0D\u6025\u7740\u63A8\u8FDB\u8D44\u6599\u3002</p>'
          }
        </div>
      </section>

      ${
        e?.avoid
          ? `
        <section class="orange-ai-avoid">
          <b>\u8FD9\u4E00\u8F6E\u907F\u514D\uFF1A</b> ${m(e.avoid)}
        </section>`
          : ""
      }

      <div class="orange-ai-copilot-foot">
        <span>${m(n || "Gemini")}</span>
        <button type="button" class="orange-ai-regenerate">\u21BB \u91CD\u65B0\u5206\u6790</button>
      </div>
    `),
      t.querySelector(".orange-ai-close")?.addEventListener("click", G),
      t.querySelectorAll("[data-orange-ai-option]").forEach((d) => {
        d.addEventListener("click", () => {
          const S = Number(d.getAttribute("data-orange-ai-option")),
            Q = String(r[S]?.text || "").trim(),
            Z = _?.isConnected && y(_) ? _ : B();
          if (!Z) {
            f(
              "\u6CA1\u6709\u627E\u5230\u804A\u5929\u8F93\u5165\u6846\uFF0C\u8BF7\u5148\u70B9\u4E00\u4E0B\u8F93\u5165\u6846",
              "error",
            );
            return;
          }
          if (!Q || !oe(Z, Q)) {
            f(
              "\u56DE\u590D\u586B\u5165\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u70B9\u51FB\u8F93\u5165\u6846",
              "error",
            );
            return;
          }
          ((_ = Z),
            t
              .querySelectorAll(".orange-ai-reply-option")
              .forEach((Pe) => Pe.classList.remove("selected")),
            d.classList.add("selected"),
            f(
              "\u5DF2\u586B\u5165\u56DE\u590D\u8349\u7A3F\uFF0C\u4F60\u53EF\u4EE5\u7EE7\u7EED\u4EBA\u5DE5\u6DFB\u52A0\u4E0B\u4E00\u6B65\u65B9\u5411",
              "success",
            ));
        });
      }),
      t
        .querySelector(".orange-ai-regenerate")
        ?.addEventListener("click", () => {
          E(A, { forceEditor: _, mode: e?._mode || "reply" });
        }),
      document.documentElement.appendChild(t));
  }
  function K(e, n) {
    if (!(e instanceof HTMLButtonElement)) return;
    const t = e.hasAttribute($);
    ((e.disabled = !!n), e.classList.toggle("orange-ai-is-busy", !!n));
    const a = e.querySelector("strong"),
      s = e.querySelector("small");
    (a &&
      (a.textContent = n
        ? t
          ? "\u56DE\u6D41\u5206\u6790\u4E2D\u2026"
          : "AI\u5206\u6790\u4E2D\u2026"
        : t
          ? "\u5BA2\u6237\u56DE\u6D41"
          : "AI\u667A\u80FD\u63D0\u9192"),
      s &&
        (s.textContent = n
          ? t
            ? "\u6B63\u5728\u5BFB\u627E\u81EA\u7136\u91CD\u65B0\u5F00\u573A\u70B9"
            : "\u6B63\u5728\u5BFB\u627E\u6700\u4F73\u5171\u9E23\u70B9"
          : t
            ? "\u6C89\u9ED8\u56DE\u6D41 \xB7 \u65E7\u8BDD\u9898\u56DE\u94A9 \xB7 3\u79CD\u65B9\u6848"
            : "\u5171\u9E23\u5206\u6790 \xB7 3\u79CD\u56DE\u590D \xB7 \u4E0B\u4E00\u6B65\u65B9\u5411"));
  }
  async function E(e, n = {}) {
    if (P) return;
    const t = n.mode === "reengage" ? "reengage" : "reply",
      a = n.forceEditor?.isConnected && y(n.forceEditor) ? n.forceEditor : B();
    if (!a) {
      f(
        "\u6CA1\u6709\u627E\u5230\u804A\u5929\u8F93\u5165\u6846\uFF0C\u8BF7\u5148\u70B9\u4E00\u4E0B\u8F93\u5165\u6846",
        "error",
      );
      return;
    }
    const s = j();
    if (!s) {
      f(
        "\u6CA1\u6709\u8BFB\u53D6\u5230\u5F53\u524D\u4F1A\u8BDD\u5185\u5BB9",
        "error",
      );
      return;
    }
    const r = z(s);
    let o = await $e(r);
    const i = F(o, s);
    o = {
      ...(o || {}),
      activity: i,
      areaCodeHint: r.areaLookup || o?.areaCodeHint || null,
    };
    const c = ve(o, s);
    if (t === "reengage") {
      if (c.explicitStop) {
        f(
          "\u5BA2\u6237\u5DF2\u660E\u786E\u8868\u793A\u505C\u6B62\u8054\u7CFB\uFF0C\u56DE\u6D41\u529F\u80FD\u5DF2\u7981\u7528",
          "error",
        );
        return;
      }
      if (c.latestSpeaker === "Them") {
        f(
          "\u5F53\u524D\u6700\u540E\u4E00\u6761\u662F\u5BA2\u6237\u56DE\u590D\uFF0C\u76F4\u63A5\u4F7F\u7528 AI\u667A\u80FD\u63D0\u9192 \u66F4\u5408\u9002",
          "info",
        );
        return;
      }
    }
    ((_ = a),
      (A = e instanceof HTMLButtonElement ? e : A),
      (we = { context: s, draft: Y(a), identity: r }),
      (P = !0),
      K(A, !0),
      f(
        t === "reengage"
          ? "\u6B63\u5728\u751F\u6210\u81EA\u7136\u56DE\u6D41\u65B9\u5F0F\u2026"
          : "\u6B63\u5728\u5206\u6790\u5BF9\u8BDD\u70ED\u5EA6\u548C\u5171\u9E23\u70B9\u2026",
        "info",
      ));
    try {
      const l = await chrome.runtime.sendMessage({
        type: "ORANGE_AI_GENERATE_ADVICE",
        context: s,
        draft: Y(a),
        pageTitle: document.title,
        pageHost: location.hostname,
        localDate: new Date().toString(),
        contactMemory: o,
        mode: t,
        phoneRegionHint: r.areaLookup || o?.areaCodeHint || null,
        reengagementMeta: c,
      });
      if (!l?.ok || !l?.advice)
        throw new Error(
          l?.error || "AI \u667A\u80FD\u63D0\u9192\u751F\u6210\u5931\u8D25",
        );
      const u = await Ee(r, l.advice, o, s);
      (u?.knownProfile && (l.advice.knownProfile = u.knownProfile),
        u?.kellyDisclosed && (l.advice.kellyDisclosed = u.kellyDisclosed),
        (l.advice.areaLookup = r.areaLookup || u?.areaCodeHint || null),
        (l.advice.reengagementMeta = c),
        (l.advice._mode = t),
        Le(l.advice, l.model),
        f(
          t === "reengage"
            ? "\u56DE\u6D41\u65B9\u6848\u5DF2\u751F\u6210 \xB7 \u5BA2\u6237\u8BB0\u5FC6\u5DF2\u7ED3\u5408"
            : "\u667A\u80FD\u5171\u9E23\u63D0\u9192\u5DF2\u751F\u6210 \xB7 \u5BA2\u6237\u4FE1\u606F\u5DF2\u8BB0\u5F55",
          "success",
        ));
    } catch (l) {
      (console.error("[Orange AI Copilot] generation failed", l),
        f(
          l?.message || "AI \u667A\u80FD\u63D0\u9192\u751F\u6210\u5931\u8D25",
          "error",
        ));
    } finally {
      ((P = !1), K(A, !1));
    }
  }
  function Oe() {
    const e = document.createElement("button");
    return (
      (e.type = "button"),
      e.setAttribute(N, "true"),
      (e.innerHTML = `
      <span class="ai-bt-action-icon">\u2728</span>
      <span>
        <strong>AI\u667A\u80FD\u63D0\u9192</strong>
        <small>\u5171\u9E23\u5206\u6790 \xB7 3\u79CD\u56DE\u590D \xB7 \u4E0B\u4E00\u6B65\u65B9\u5411</small>
      </span>
    `),
      e.addEventListener("click", (n) => {
        (n.preventDefault(), n.stopPropagation(), E(e));
      }),
      e
    );
  }
  function qe() {
    const e = document.createElement("button");
    return (
      (e.type = "button"),
      e.setAttribute($, "true"),
      (e.innerHTML = `
      <span class="ai-bt-action-icon">\u267B\uFE0F</span>
      <span>
        <strong>\u5BA2\u6237\u56DE\u6D41</strong>
        <small>\u6C89\u9ED8\u56DE\u6D41 \xB7 \u65E7\u8BDD\u9898\u56DE\u94A9 \xB7 3\u79CD\u65B9\u6848</small>
      </span>
    `),
      e.addEventListener("click", (n) => {
        (n.preventDefault(), n.stopPropagation(), E(e, { mode: "reengage" }));
      }),
      e
    );
  }
  const X = {
    California: "\u52A0\u5229\u798F\u5C3C\u4E9A\u5DDE",
    Texas: "\u5FB7\u514B\u8428\u65AF\u5DDE",
    Florida: "\u4F5B\u7F57\u91CC\u8FBE\u5DDE",
    Washington: "\u534E\u76DB\u987F\u5DDE",
    Arizona: "\u4E9A\u5229\u6851\u90A3\u5DDE",
    Nevada: "\u5185\u534E\u8FBE\u5DDE",
    Oregon: "\u4FC4\u52D2\u5188\u5DDE",
    "New York": "\u7EBD\u7EA6\u5DDE",
    "New Jersey": "\u65B0\u6CFD\u897F\u5DDE",
    Pennsylvania: "\u5BBE\u5915\u6CD5\u5C3C\u4E9A\u5DDE",
    Illinois: "\u4F0A\u5229\u8BFA\u4F0A\u5DDE",
    Georgia: "\u4E54\u6CBB\u4E9A\u5DDE",
    Massachusetts: "\u9A6C\u8428\u8BF8\u585E\u5DDE",
    Virginia: "\u5F17\u5409\u5C3C\u4E9A\u5DDE",
    Maryland: "\u9A6C\u91CC\u5170\u5DDE",
    Ohio: "\u4FC4\u4EA5\u4FC4\u5DDE",
    Michigan: "\u5BC6\u6B47\u6839\u5DDE",
    Colorado: "\u79D1\u7F57\u62C9\u591A\u5DDE",
    Hawaii: "\u590F\u5A01\u5937\u5DDE",
    Alaska: "\u963F\u62C9\u65AF\u52A0\u5DDE",
    Ontario: "\u5B89\u5927\u7565\u7701",
    "British Columbia": "\u4E0D\u5217\u98A0\u54E5\u4F26\u6BD4\u4E9A\u7701",
    Quebec: "\u9B41\u5317\u514B\u7701",
    Alberta: "\u963F\u5C14\u4F2F\u5854\u7701",
  };
  function Me() {
    const e = document.createElement("button");
    return (
      (e.type = "button"),
      (e.dataset.orangeAreaStatus = "true"),
      (e.innerHTML =
        '<span class="ai-bt-action-icon">\u{1F4CD}</span><span><strong>\u81EA\u52A8\u533A\u53F7\u67E5\u8BE2</strong><small>\u70B9\u51FB\u6216\u5207\u6362\u5BA2\u6237\u540E\u81EA\u52A8\u8BC6\u522B / Auto lookup</small></span>'),
      e.addEventListener("click", () => {
        const n = J(e);
        Ie(n);
      }),
      e
    );
  }
  function J(e = document.querySelector("[data-orange-area-status]")) {
    if (!e) return null;
    const n = z(j()),
      t = n.areaLookup,
      a = e.querySelector("small");
    if (!a) return n;
    if (!t)
      return (
        (a.textContent = n.phoneDigits
          ? `${n.phoneDigits} \xB7 \u6682\u65E0\u7F8E\u56FD\u533A\u53F7\u8D44\u6599 / No US area match`
          : "\u672A\u8BC6\u522B\u5230\u5BA2\u6237\u53F7\u7801 / No customer number found"),
        n
      );
    const s = t.regionZh || X[t.region] || t.region;
    return (
      (a.textContent = `${t.areaCode} \xB7 ${t.labelZh || s} / ${t.label || `${t.region}, USA`}`),
      n
    );
  }
  function Ie(e) {
    document.getElementById("orange-ai-area-lookup-panel")?.remove();
    const n = e?.areaLookup || null,
      t = n ? n.regionZh || X[n.region] || n.region : "\u672A\u8BC6\u522B",
      a = e?.phoneDigits
        ? `+1 ${e.phoneDigits.slice(0, 3)} ${e.phoneDigits.slice(3, 6)} ${e.phoneDigits.slice(6)}`
        : "\u672A\u8BC6\u522B / Not detected",
      s = document.createElement("section");
    s.id = "orange-ai-area-lookup-panel";
    const r = n
      ? [
          [
            "\u56FD\u5BB6 / Country",
            `${n.countryZh || "\u7F8E\u56FD"} / ${n.countryEn || "United States"}`,
          ],
          ["\u5DDE / State", `${t} / ${n.region}`],
          [
            "\u4E3B\u8981\u57CE\u5E02 / Main cities",
            `${(n.citiesZh || []).join("\u3001") || t} / ${(n.citiesEn || []).join(", ") || n.metroHint || n.region}`,
          ],
          [
            "\u5468\u8FB9\u57CE\u5E02 / Nearby cities",
            `${(n.nearbyCitiesZh || []).join("\u3001") || "\u6682\u65E0\u8BE6\u7EC6\u8D44\u6599"} / ${(n.nearbyCitiesEn || []).join(", ") || "No detailed nearby-city data"}`,
          ],
          [
            "\u65F6\u533A / Time zone",
            `${n.timezoneZh || "\u7F8E\u56FD\u5F53\u5730\u65F6\u533A"} / ${n.timezoneEn || "United States local time"}`,
          ],
        ]
      : [];
    ((s.innerHTML = `<header><div><strong>\u{1F4CD} \u81EA\u52A8\u533A\u53F7\u67E5\u8BE2</strong><small>Area Code Lookup</small></div><button type="button" aria-label="\u5173\u95ED">\xD7</button></header><div class="orange-area-phone"><span>\u8BC6\u522B\u53F7\u7801 / Phone</span><b>${m(a)}</b></div>${n ? `<div class="orange-area-code"><span>${m(n.areaCode)}</span><div><b>${m(n.labelZh || t)}</b><small>${m(n.label || `${n.region}, USA`)}</small></div></div><div class="orange-area-details">${r.map(([o, i]) => `<div><b>${m(o)}</b><span>${m(i)}</span></div>`).join("")}</div>` : '<div class="orange-area-empty">\u6CA1\u6709\u627E\u5230\u5F53\u524D\u5BA2\u6237\u7684\u7F8E\u56FD\u7535\u8BDD\u53F7\u7801<br><small>No U.S. customer number was found.</small></div>'}<p>\u533A\u53F7\u4EC5\u8868\u793A\u53F7\u7801\u53EF\u80FD\u7684\u539F\u59CB\u5F52\u5C5E\u5730\u533A\uFF0C\u4E0D\u4EE3\u8868\u5BA2\u6237\u5F53\u524D\u4F4F\u5740\u3002<br><small>Area code is only an approximate numbering-origin hint, not the customer's verified current location.</small></p>`),
      s
        .querySelector("header button")
        .addEventListener("click", () => s.remove()),
      document.documentElement.appendChild(s));
  }
  function Ne() {
    if (!R.test(location.hostname)) return !0;
    const e = document.querySelector(ee);
    if (!e) return !1;
    document.getElementById(v)?.remove();
    let n = e.querySelector(`[${N}]`);
    if (!n) {
      n = Oe();
      const t = e.querySelector("[data-ai-bt-input-translator-toggle]");
      t?.nextSibling ? e.insertBefore(n, t.nextSibling) : e.appendChild(n);
    }
    if (!e.querySelector(`[${$}]`)) {
      const t = qe();
      n?.nextSibling ? e.insertBefore(t, n.nextSibling) : e.appendChild(t);
    }
    return (
      e.querySelector("[data-orange-area-status]") || e.insertBefore(Me(), n),
      J(),
      e
        .querySelectorAll(`[${N}]`)
        .forEach((t) => (t.style.display = L.ai_reply === !1 ? "none" : "")),
      e
        .querySelectorAll(`[${$}]`)
        .forEach((t) => (t.style.display = L.reengage === !1 ? "none" : "")),
      e
        .querySelectorAll("[data-orange-area-status]")
        .forEach((t) => (t.style.display = L.area_lookup === !1 ? "none" : "")),
      !0
    );
  }
  function Re() {
    if (!R.test(location.hostname) || document.getElementById(v)) return;
    const e = document.createElement("div");
    e.id = v;
    const n = document.createElement("button");
    ((n.type = "button"),
      (n.className = "orange-ai-reply-fallback"),
      (n.textContent = "\u2728 AI\u63D0\u9192"),
      (n.title =
        "\u5206\u6790\u5F53\u524D\u5B8C\u6574\u4F1A\u8BDD\uFF0C\u7ED9\u51FA\u5171\u9E23\u63D0\u9192\u3001\u4E09\u79CD\u56DE\u590D\u65B9\u6848\u548C\u4E0B\u4E00\u6B65\u65B9\u5411"),
      n.addEventListener("click", (a) => {
        (a.preventDefault(), a.stopPropagation(), E(n));
      }));
    const t = document.createElement("button");
    ((t.type = "button"),
      (t.className = "orange-ai-reply-fallback orange-ai-reflow-fallback"),
      t.setAttribute($, "true"),
      (t.textContent = "\u267B\uFE0F \u56DE\u6D41"),
      (t.title =
        "\u5BA2\u6237\u957F\u65F6\u95F4\u672A\u56DE\u590D\u65F6\uFF0C\u7ED3\u5408\u5BA2\u6237\u8BB0\u5FC6\u3001\u533A\u53F7\u5730\u533A\u548C\u65E7\u8BDD\u9898\u751F\u6210\u81EA\u7136\u56DE\u6D41\u65B9\u6848"),
      t.addEventListener("click", (a) => {
        (a.preventDefault(), a.stopPropagation(), E(t, { mode: "reengage" }));
      }),
      e.append(n, t),
      document.documentElement.appendChild(e));
  }
  function C() {
    Array.from(document.querySelectorAll('input[type="password"]')).some(
      (e) => e.offsetParent !== null,
    ) ||
      (w && clearTimeout(w),
      (w = setTimeout(() => {
        ((w = 0), Ne() || Re());
      }, 80)));
  }
  (document.addEventListener(
    "focusin",
    (e) => {
      y(e.target) && (T = e.target);
    },
    !0,
  ),
    document.addEventListener(
      "keydown",
      (e) => {
        e.key === "Escape" && document.getElementById(k) && G();
      },
      !0,
    ),
    new MutationObserver(() => C()).observe(document.documentElement, {
      childList: !0,
      subtree: !0,
    }),
    C(),
    chrome.storage.local.get("orangePermissions").then((e) => {
      ((L = e.orangePermissions || {}), C());
    }),
    setTimeout(C, 800),
    setTimeout(C, 2200));
})();
