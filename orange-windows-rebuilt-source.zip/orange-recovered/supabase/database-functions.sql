CREATE OR REPLACE FUNCTION public.allocate_tn_proxy(p_user_id uuid, p_account_local_id uuid, p_account_label text DEFAULT ''::text)
 RETURNS TABLE(proxy_id uuid, group_id uuid, group_name text, tn_capacity integer, used_accounts bigint)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare chosen record;
begin
  if p_user_id is null or p_account_local_id is null then raise exception 'missing TN allocation identity'; end if;
  perform pg_advisory_xact_lock(hashtext('orange-tn-proxy-allocation'));
  return query
    select b.proxy_id,b.group_id,g.group_name,p.tn_capacity,
      (select count(*) from public.tn_account_proxy_bindings x where x.proxy_id=b.proxy_id)
    from public.tn_account_proxy_bindings b
    left join public.tn_proxy_groups g on g.id=b.group_id
    join public.translation_proxy_pool p on p.id=b.proxy_id
    where b.owner_user_id=p_user_id and b.account_local_id=p_account_local_id;
  if found then return; end if;

  select g.id as group_id,g.group_name,g.proxy_id,p.tn_capacity into chosen
  from public.tn_proxy_groups g
  join public.translation_proxy_pool p on p.id=g.proxy_id
  where g.owner_user_id=p_user_id and p.enabled=true and p.pool_kind in ('tn','shared')
    and (p.tn_capacity is null or (select count(*) from public.tn_account_proxy_bindings x where x.proxy_id=p.id) < p.tn_capacity)
    and (g.max_accounts is null or (select count(*) from public.tn_account_proxy_bindings x where x.group_id=g.id) < g.max_accounts)
  order by (select count(*) from public.tn_account_proxy_bindings x where x.proxy_id=p.id) desc, g.created_at
  limit 1;
  if chosen.proxy_id is null then raise exception 'TN IP池容量不足或没有为该员工开放IP'; end if;
  insert into public.tn_account_proxy_bindings(owner_user_id,account_local_id,account_label,proxy_id,group_id)
  values(p_user_id,p_account_local_id,left(coalesce(p_account_label,''),120),chosen.proxy_id,chosen.group_id);
  return query select chosen.proxy_id,chosen.group_id,chosen.group_name,chosen.tn_capacity,
    (select count(*) from public.tn_account_proxy_bindings x where x.proxy_id=chosen.proxy_id);
end $function$


CREATE OR REPLACE FUNCTION public.can_receive_internal_message(candidate_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (
    select 1
    from public.profiles p
    where p.id = candidate_id
      and coalesce(p.account_status, 'active') = 'active'
  );
$function$


CREATE OR REPLACE FUNCTION public.can_use_app(target_user uuid DEFAULT auth.uid())
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  p public.profiles%rowtype;
  local_time time;
begin
  if target_user is distinct from auth.uid() and not public.is_admin() then
    return false;
  end if;

  select * into p from public.profiles where id = target_user;
  if not found then return false; end if;
  if p.account_status <> 'active' then return false; end if;
  if p.valid_from > now() then return false; end if;
  if p.valid_until is not null and p.valid_until <= now() then return false; end if;

  if p.daily_start is not null then
    local_time := (now() at time zone p.access_timezone)::time;
    if p.daily_start < p.daily_end then
      if not (local_time >= p.daily_start and local_time < p.daily_end) then
        return false;
      end if;
    elsif p.daily_start > p.daily_end then
      if not (local_time >= p.daily_start or local_time < p.daily_end) then
        return false;
      end if;
    end if;
  end if;

  return true;
exception
  when invalid_parameter_value then
    return false;
end;
$function$


CREATE OR REPLACE FUNCTION public.clear_all_internal_messages()
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare changed integer;
begin
  update public.internal_messages
  set sender_hidden_at = case when sender_id = auth.uid() then now() else sender_hidden_at end,
      recipient_hidden_at = case when recipient_id = auth.uid() then now() else recipient_hidden_at end
  where sender_id = auth.uid() or recipient_id = auth.uid();
  get diagnostics changed = row_count;
  return changed;
end;
$function$


CREATE OR REPLACE FUNCTION public.clear_internal_conversation(peer_id uuid)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare changed integer;
begin
  update public.internal_messages
  set sender_hidden_at = case when sender_id = auth.uid() then now() else sender_hidden_at end,
      recipient_hidden_at = case when recipient_id = auth.uid() then now() else recipient_hidden_at end
  where (sender_id = auth.uid() and recipient_id = peer_id)
     or (sender_id = peer_id and recipient_id = auth.uid());
  get diagnostics changed = row_count;
  return changed;
end;
$function$


CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  generated_username text;
begin
  generated_username := lower(coalesce(
    nullif(new.raw_user_meta_data ->> 'username', ''),
    split_part(coalesce(new.email, ''), '@', 1)
  ));

  if generated_username = '' then
    raise exception 'A username is required';
  end if;

  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    generated_username,
    nullif(new.raw_user_meta_data ->> 'display_name', '')
  );

  return new;
end;
$function$


CREATE OR REPLACE FUNCTION public.has_feature(requested_feature text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
  select public.can_use_app(auth.uid()) and coalesce(
    (
      select o.enabled
      from public.user_permission_overrides o
      where o.user_id = auth.uid()
        and o.feature_code = requested_feature
    ),
    (
      select pp.enabled
      from public.profiles p
      join public.plan_permissions pp on pp.plan = p.plan
      where p.id = auth.uid()
        and pp.feature_code = requested_feature
    ),
    false
  );
$function$


CREATE OR REPLACE FUNCTION public.is_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
  select exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
      and p.account_status = 'active'
      and p.valid_from <= now()
      and (p.valid_until is null or p.valid_until > now())
  );
$function$


CREATE OR REPLACE FUNCTION public.list_internal_contacts()
 RETURNS TABLE(id uuid, username text, display_name text, role text)
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select p.id, p.username, p.display_name, p.role
  from public.profiles p
  where p.id <> auth.uid()
    and coalesce(p.account_status, 'active') = 'active'
  order by coalesce(nullif(p.display_name, ''), p.username), p.username;
$function$


CREATE OR REPLACE FUNCTION public.list_tn_account_counts()
 RETURNS TABLE(user_id uuid, account_count integer, updated_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin') then
    raise exception '仅管理员可查看TN账号数量';
  end if;
  return query
    select c.user_id, c.account_count, c.updated_at
    from public.employee_tn_account_counts c
    order by c.updated_at desc;
end;
$function$


CREATE OR REPLACE FUNCTION public.mark_internal_conversation_read(peer_id uuid)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare changed integer;
begin
  update public.internal_messages
  set read_at = coalesce(read_at, now())
  where sender_id = peer_id and recipient_id = auth.uid() and read_at is null;
  get diagnostics changed = row_count;
  return changed;
end;
$function$


CREATE OR REPLACE FUNCTION public.release_tn_proxy(p_user_id uuid, p_account_local_id uuid)
 RETURNS integer
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  with removed as (delete from public.tn_account_proxy_bindings where owner_user_id=p_user_id and account_local_id=p_account_local_id returning 1)
  select count(*)::integer from removed;
$function$


CREATE OR REPLACE FUNCTION public.rls_auto_enable()
 RETURNS event_trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$function$


CREATE OR REPLACE FUNCTION public.set_my_tn_account_count(new_count integer)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if auth.uid() is null then raise exception '请先登录'; end if;
  if new_count < 0 or new_count > 1000 then raise exception 'TN账号数量超出范围'; end if;
  insert into public.employee_tn_account_counts(user_id, account_count, updated_at)
  values (auth.uid(), new_count, now())
  on conflict (user_id) do update
    set account_count = excluded.account_count, updated_at = excluded.updated_at;
end;
$function$


CREATE OR REPLACE FUNCTION public.set_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
begin
  new.updated_at = now();
  return new;
end;
$function$
