// Deploy as Edge Function: proxy-health
// Configure Verify JWT = OFF and set PROXY_HEALTH_CRON_SECRET. Supabase Cron
// calls this function with header x-cron-secret every configured interval.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { withSupabase } from "jsr:@supabase/server@^1";

function json(body: Record<string, unknown>, status = 200) {
  return Response.json(body, { status });
}

function base64ToBytes(value: string) {
  const binary = atob(value);
  return Uint8Array.from(binary, char => char.charCodeAt(0));
}

async function encryptionKey() {
  const secret = Deno.env.get("PROXY_POOL_ENCRYPTION_SECRET") || "";
  if (secret.length < 32) throw new Error("PROXY_POOL_ENCRYPTION_SECRET至少需要32个字符");
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return crypto.subtle.importKey("raw", digest, { name:"AES-GCM" }, false, ["decrypt"]);
}

async function decrypt(value: string, iv: string) {
  if (!value) return "";
  const plain = await crypto.subtle.decrypt(
    { name:"AES-GCM", iv:base64ToBytes(iv) },
    await encryptionKey(),
    base64ToBytes(value),
  );
  return new TextDecoder().decode(plain);
}

async function testProxy(row: any) {
  const username = await decrypt(row.encrypted_username, row.username_iv);
  const password = await decrypt(row.encrypted_password, row.password_iv);
  const proxyUrl = `${row.protocol || "http"}://${row.host}:${row.port}`;
  const client = Deno.createHttpClient({
    proxy: {
      url: proxyUrl,
      ...(username ? { basicAuth:{ username, password } } : {}),
    },
  });
  const startedAt = Date.now();
  const targets = [
    { url:"https://api.ipify.org?format=json", json:true },
    { url:"https://api64.ipify.org?format=json", json:true },
    { url:"https://icanhazip.com/", json:false },
  ];
  const errors:string[] = [];
  try {
    for (const target of targets) {
      try {
        const response = await fetch(target.url, {
          signal:AbortSignal.timeout(6000),
          headers:{ "Accept":target.json ? "application/json" : "text/plain", "User-Agent":"Orange-AI-Proxy-Health/0.5.7" },
          client,
        } as RequestInit & { client:Deno.HttpClient });
        const text = (await response.text()).trim();
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const exitIp = target.json ? String(JSON.parse(text)?.ip || "") : text.split(/\s+/)[0];
        if (!exitIp) throw new Error("没有返回出口IP");
        return { healthy:true, latencyMs:Date.now() - startedAt, exitIp, error:"", target:new URL(target.url).hostname };
      } catch (error) {
        errors.push(`${new URL(target.url).hostname}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    return { healthy:false, latencyMs:Date.now() - startedAt, exitIp:"", error:`三个检测点均失败 · ${errors.join("；")}`.slice(0, 500) };
  } finally {
    client.close();
  }
}

export default {
  fetch: withSupabase({
    auth:"none",
    env: {
      url:Deno.env.get("SUPABASE_URL")!,
      publishableKeys:{ default:Deno.env.get("SUPABASE_ANON_KEY")! },
      secretKeys:{ default:Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")! },
    },
  }, async (req, ctx) => {
    try {
      const expected = Deno.env.get("PROXY_HEALTH_CRON_SECRET") || "";
      const supplied = req.headers.get("x-cron-secret") || "";
      if (expected.length < 16 || supplied !== expected) return json({ ok:false, message:"无权运行IP池检测" }, 401);
      const admin = ctx.supabaseAdmin;
      const { data:poolSettings, error:poolSettingsError } = await admin.from("translation_proxy_settings").select("enabled,health_check_interval_minutes,failure_threshold").eq("singleton", true).maybeSingle();
      if (poolSettingsError) throw poolSettingsError;
      if (poolSettings?.enabled === false) return json({ ok:true, disabled:true, checked:0, message:"翻译IP池已关闭，本轮未检测" });
      const intervalMinutes = Math.max(1, Math.min(60, Number(poolSettings?.health_check_interval_minutes || 10)));
      const failureThreshold = Math.max(1, Math.min(10, Number(poolSettings?.failure_threshold || 2)));
      const { data:lastScan } = await admin.from("proxy_activity_logs").select("created_at").eq("source", "scheduled-health").eq("event_type", "pool_scan_completed").order("created_at", { ascending:false }).limit(1).maybeSingle();
      if (lastScan?.created_at && Date.now() - new Date(lastScan.created_at).getTime() < intervalMinutes * 60000) {
        return json({ ok:true, skipped:true, checked:0, message:`尚未到后台设置的 ${intervalMinutes} 分钟检测间隔` });
      }
      const { data: rows, error } = await admin.from("translation_proxy_pool")
        .select("id,label,protocol,host,port,encrypted_username,username_iv,encrypted_password,password_iv,enabled,health_status,failure_count")
        .eq("enabled", true)
        .order("created_at", { ascending:true });
      if (error) throw error;

      const proxies = rows || [];
      const results:any[] = [];
      let cursor = 0;
      const workers = Array.from({ length:Math.min(5, proxies.length) }, async () => {
        while (cursor < proxies.length) {
          const row = proxies[cursor++];
          const result = await testProxy(row);
          const nextFailures = result.healthy ? 0 : Number(row.failure_count || 0) + 1;
          const nextStatus = result.healthy
            ? "healthy"
            : nextFailures >= failureThreshold
              ? "failing"
              : (row.health_status === "healthy" ? "healthy" : "unknown");
          const changed = row.health_status !== nextStatus;
          const message = result.healthy
            ? `出口IP ${result.exitIp} · ${result.latencyMs}ms`
            : (result.error || "代理测试失败").slice(0, 500);
          const { error:updateError } = await admin.from("translation_proxy_pool").update({
            health_status:nextStatus,
            failure_count:nextFailures,
            last_checked_at:new Date().toISOString(),
            last_error:message,
            updated_at:new Date().toISOString(),
          }).eq("id", row.id);
          if (updateError) throw updateError;
          if (changed) await admin.from("proxy_activity_logs").insert({
            proxy_id:row.id,
            source:"scheduled-health",
            event_type:result.healthy ? "proxy_recovered" : "proxy_failed",
            target:result.healthy ? (result.target || "multi-endpoint") : "multi-endpoint",
            message,
          });
          results.push({ id:row.id, probeHealthy:result.healthy, status:nextStatus, latencyMs:result.latencyMs });
        }
      });
      await Promise.all(workers);

      const { data:available } = await admin.from("translation_proxy_pool")
        .select("id,last_used_at").eq("enabled", true).in("health_status", ["healthy", "unknown"]);
      const availableIds = new Set((available || []).map((item:any) => item.id));
      const { data:assignments } = await admin.from("translation_proxy_assignments")
        .select("user_id,proxy_id,assignment_mode,allowed_by_admin");
      const counts = new Map<string,number>();
      for (const item of assignments || []) if (item.proxy_id && availableIds.has(item.proxy_id)) counts.set(item.proxy_id, (counts.get(item.proxy_id) || 0) + 1);
      let repaired = 0;
      for (const item of assignments || []) {
        if (item.assignment_mode !== "automatic" || item.allowed_by_admin === false || (item.proxy_id && availableIds.has(item.proxy_id))) continue;
        const selected = [...(available || [])].sort((a:any, b:any) =>
          ((counts.get(a.id) || 0) - (counts.get(b.id) || 0)) ||
          ((a.last_used_at ? new Date(a.last_used_at).getTime() : 0) - (b.last_used_at ? new Date(b.last_used_at).getTime() : 0))
        )[0] || null;
        await admin.from("translation_proxy_assignments").update({
          proxy_id:selected?.id || null,
          assigned_at:new Date().toISOString(),
          last_error:selected ? null : "暂时没有可用IP",
          updated_at:new Date().toISOString(),
        }).eq("user_id", item.user_id);
        if (selected) counts.set(selected.id, (counts.get(selected.id) || 0) + 1);
        repaired += 1;
      }

      await admin.from("proxy_activity_logs").insert({
        source:"scheduled-health",
        event_type:"pool_scan_completed",
        target:`${proxies.length} proxies`,
        message:`正常 ${results.filter(item => item.status === "healthy").length} · 待复检 ${results.filter(item => item.status === "unknown").length} · 失效 ${results.filter(item => item.status === "failing").length} · 修复分配 ${repaired}`,
      });
      await admin.from("proxy_activity_logs").delete().lt("created_at", new Date(Date.now() - 30 * 86400000).toISOString());
      return json({ ok:true, checked:results.length, healthy:results.filter(item => item.status === "healthy").length, unknown:results.filter(item => item.status === "unknown").length, failing:results.filter(item => item.status === "failing").length, repaired });
    } catch (error) {
      console.error("proxy-health error", error);
      return json({ ok:false, message:error instanceof Error ? error.message : String(error) }, 500);
    }
  }),
};

