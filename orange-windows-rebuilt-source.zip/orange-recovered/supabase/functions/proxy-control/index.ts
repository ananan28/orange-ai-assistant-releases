// Supabase Edge Function: proxy-control
// Gives a signed-in employee only the translation proxy assigned to that account.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { withSupabase } from "jsr:@supabase/server@^1";

type Action = "assignment" | "report_failure" | "report_success" | "site_fixed" | "site_pool" | "tn_groups" | "tn_fixed";
type ProxyProtocol = "http" | "https" | "socks5";

interface Payload {
  action: Action;
  proxyId?: string;
  reason?: string;
  forceSwitch?: boolean;
  excludedProxyIds?: string[];
  siteKey?: string;
  groupId?: string;
}

interface ProxyRow {
  id: string;
  label: string;
  protocol: ProxyProtocol;
  host: string;
  port: number;
  encrypted_username: string;
  username_iv: string;
  encrypted_password: string;
  password_iv: string;
  enabled: boolean;
  health_status: "unknown" | "healthy" | "failing" | "disabled";
  failure_count: number;
  last_used_at: string | null;
}

function json(body: Record<string, unknown>, status = 200) {
  return Response.json(body, { status });
}

function fail(message: string, status = 400) {
  return json({ ok: false, message }, status);
}

function isTargetScopedRejection(reason: string) {
  // A 403/429 only proves that one target rejected or rate-limited this exit
  // IP.  The tunnel can still be healthy for websites and other services, so
  // never poison the shared pool's global health state for these responses.
  return /\bHTTP\s+(403|429)\b/i.test(reason);
}

function base64ToBytes(value: string) {
  const binary = atob(value);
  return Uint8Array.from(binary, char => char.charCodeAt(0));
}

async function encryptionKey() {
  const secret = Deno.env.get("PROXY_POOL_ENCRYPTION_SECRET") || "";
  if (secret.length < 32) throw new Error("PROXY_POOL_ENCRYPTION_SECRET至少需要32个字符");
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return crypto.subtle.importKey("raw", digest, { name: "AES-GCM" }, false, ["decrypt"]);
}

async function decrypt(value: string, iv: string) {
  if (!value) return "";
  const plain = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: base64ToBytes(iv) },
    await encryptionKey(),
    base64ToBytes(value),
  );
  return new TextDecoder().decode(plain);
}

async function publicProxy(row: ProxyRow | null) {
  if (!row) return null;
  return {
    id: row.id,
    label: row.label,
    protocol: row.protocol,
    host: row.host,
    port: row.port,
    username: await decrypt(row.encrypted_username, row.username_iv),
    password: await decrypt(row.encrypted_password, row.password_iv),
  };
}

async function chooseProxy(admin: any, rows: ProxyRow[], excludedIds = new Set<string>()) {
  const enabledRows = rows.filter(row => row.enabled && row.health_status !== "disabled" && !excludedIds.has(row.id));
  // Prefer known-good/unknown lines. If every line was previously marked
  // failing, retry the oldest ones instead of returning an empty pool forever;
  // the authenticated desktop probe will restore a recovered line.
  let candidates = enabledRows.filter(row => row.health_status !== "failing");
  if (!candidates.length) candidates = enabledRows.sort((a, b) => {
    const aChecked = a.last_used_at ? new Date(a.last_used_at).getTime() : 0;
    const bChecked = b.last_used_at ? new Date(b.last_used_at).getTime() : 0;
    return aChecked - bChecked;
  });
  if (!candidates.length) return null;

  const { data: assignments, error } = await admin
    .from("translation_proxy_assignments")
    .select("proxy_id");
  if (error) throw error;
  const counts = new Map<string, number>();
  for (const item of assignments || []) {
    if (item.proxy_id) counts.set(item.proxy_id, (counts.get(item.proxy_id) || 0) + 1);
  }
  candidates.sort((a, b) => {
    const countDifference = (counts.get(a.id) || 0) - (counts.get(b.id) || 0);
    if (countDifference) return countDifference;
    const aUsed = a.last_used_at ? new Date(a.last_used_at).getTime() : 0;
    const bUsed = b.last_used_at ? new Date(b.last_used_at).getTime() : 0;
    return aUsed - bUsed;
  });
  return candidates[0];
}

async function logEvent(admin:any, values:Record<string,unknown>) {
  try { await admin.from("proxy_activity_logs").insert(values); } catch {}
}

async function membershipGraceDays(admin:any) {
  const { data, error } = await admin.from("membership_settings").select("basic_grace_days").eq("singleton", true).maybeSingle();
  if (error && String(error.code || "") !== "42P01") throw error;
  return Math.max(1, Math.min(365, Number(data?.basic_grace_days || 30)));
}

async function hasTnAccountAccess(admin:any, profile:any, userId:string) {
  const flagResult = await admin.from("app_feature_flags")
    .select("feature_key,enabled")
    .in("feature_key", ["module_tn", "tn_accounts"]);
  if (flagResult.error) return false;
  const flags = new Map((flagResult.data || []).map((row:any) => [String(row.feature_key), row.enabled === true]));
  if (flags.get("module_tn") !== true || flags.get("tn_accounts") !== true) return false;
  if (profile.role === "admin") return true;

  const [planResult, overrideResult] = await Promise.all([
    admin.from("plan_permissions")
      .select("feature_code,enabled")
      .eq("plan", profile.plan)
      .in("feature_code", ["tn_accounts"]),
    admin.from("user_permission_overrides")
      .select("feature_code,enabled")
      .eq("user_id", userId)
      .in("feature_code", ["tn_accounts"]),
  ]);
  if (planResult.error || overrideResult.error) return false;

  const permissions:Record<string,boolean> = { tn_accounts:false };
  for (const row of planResult.data || []) permissions[String(row.feature_code)] = row.enabled === true;
  for (const row of overrideResult.data || []) permissions[String(row.feature_code)] = row.enabled === true;
  // TN account/proxy access is separate from the TN assistant. Basic members are
  // allowed to open assigned TN accounts through their fixed IP while the
  // extension receives tn_assistant=false and therefore disables all helpers.
  return permissions.tn_accounts === true;
}

export default {
  fetch: withSupabase({
    auth: "user",
    env: {
      url: Deno.env.get("SUPABASE_URL")!,
      publishableKeys: { default: Deno.env.get("SUPABASE_ANON_KEY")! },
      secretKeys: { default: Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")! },
    },
  }, async (req, ctx) => {
    try {
      const userId = String(ctx.jwtClaims?.sub ?? ctx.userClaims?.id ?? "");
      if (!userId) return fail("登录状态无效", 401);
      const admin = ctx.supabaseAdmin;
      const { data: profile, error: profileError } = await admin
        .from("profiles")
        .select("role,plan,account_status,valid_from,valid_until")
        .eq("id", userId)
        .single();
      if (profileError || !profile || profile.account_status !== "active") return fail("账号不可用", 403);
      const nowMs = Date.now();
      if (profile.valid_from && new Date(profile.valid_from).getTime() > nowMs) return fail("账号尚未生效", 403);
      if (profile.valid_until && new Date(profile.valid_until).getTime() <= nowMs) {
        if (profile.role !== "admin" && profile.plan === "advanced") {
          const graceDays = await membershipGraceDays(admin);
          const basicUntil = new Date(nowMs + graceDays * 86400000).toISOString();
          const { error:downgradeError } = await admin.from("profiles")
            .update({ plan:"basic", valid_until:basicUntil, account_status:"active", updated_at:new Date(nowMs).toISOString() })
            .eq("id", userId).eq("plan", "advanced");
          if (downgradeError) throw downgradeError;
          profile.plan = "basic";
          profile.valid_until = basicUntil;
        } else if (profile.role !== "admin" && profile.plan === "basic") {
          await admin.from("profiles").update({ account_status:"paused", updated_at:new Date(nowMs).toISOString() }).eq("id", userId);
          return fail("普通会员体验期已结束，请联系管理员续费", 403);
        } else {
          return fail("账号已到期", 403);
        }
      }

      const body = await req.json() as Payload;
      if (!["assignment", "report_failure", "report_success", "site_fixed", "site_pool", "tn_groups", "tn_fixed"].includes(body.action)) return fail("不支持的操作");

      if (["tn_groups", "tn_fixed"].includes(body.action)) {
        const allowed = await hasTnAccountAccess(admin, profile, userId);
        if (!allowed) return fail("TN功能未授权、已关闭或权限数据不可用", 403);
      }

      if (body.action === "tn_groups") {
        const { data:groups, error:groupsError } = await admin.from("tn_proxy_groups")
          .select("id,group_name,proxy_id,max_accounts,created_at")
          .eq("owner_user_id",userId).order("created_at",{ascending:true});
        if (groupsError) throw groupsError;
        const proxyIds = [...new Set((groups || []).map((row:any) => row.proxy_id).filter(Boolean))];
        const { data:proxies, error:proxyError } = proxyIds.length
          ? await admin.from("translation_proxy_pool").select("id,label,host,port,enabled,health_status").in("id",proxyIds)
          : { data:[], error:null };
        if (proxyError) throw proxyError;
        const proxyMap = new Map((proxies || []).map((row:any) => [row.id,row]));
        return json({ok:true,groups:(groups || []).map((row:any) => {
          const proxy:any = proxyMap.get(row.proxy_id) || null;
          return { id:row.id, groupName:row.group_name, proxyId:row.proxy_id, maxAccounts:row.max_accounts,
            proxyLabel:proxy?.label || "固定IP不可用", proxyEndpoint:proxy ? `${proxy.host}:${proxy.port}` : "",
            proxyEnabled:proxy?.enabled === true, healthStatus:proxy?.health_status || "disabled" };
        })});
      }

      if (body.action === "tn_fixed") {
        const groupId = String(body.groupId || "");
        if (!groupId) return fail("请选择TN固定IP分组");
        const { data:group, error:groupError } = await admin.from("tn_proxy_groups")
          .select("id,group_name,proxy_id,max_accounts").eq("id",groupId).eq("owner_user_id",userId).maybeSingle();
        if (groupError || !group) return fail("TN固定IP分组不存在或不属于当前账号",404);
        const { data:fixedProxy, error:fixedError } = await admin.from("translation_proxy_pool")
          .select("id,label,protocol,host,port,encrypted_username,username_iv,encrypted_password,password_iv,enabled,health_status,failure_count,last_used_at")
          .eq("id",group.proxy_id).eq("enabled",true).maybeSingle();
        if (fixedError || !fixedProxy) return json({ok:true,proxy:null,mode:"tn_fixed",switched:false,group,message:"固定IP已停用或删除；禁止本机直连"});
        await logEvent(admin,{user_id:userId,proxy_id:fixedProxy.id,source:"desktop",event_type:"tn_fixed_open",target:group.group_name,message:"TN分组使用固定IP；禁止自动轮换和本机直连"});
        return json({ok:true,proxy:await publicProxy(fixedProxy as ProxyRow),mode:"tn_fixed",switched:false,group});
      }

      if (body.action === "site_fixed") {
        const siteKey = String(body.siteKey || "").trim().toLowerCase();
        const { data:site, error:siteError } = await admin.from("work_sites")
          .select("site_key,enabled,minimum_plan,proxy_mode,fixed_proxy_id")
          .eq("site_key",siteKey).maybeSingle();
        if (siteError || !site?.enabled) return fail("网站不存在或已下架",404);
        if (site.minimum_plan === "advanced" && profile.role !== "admin" && profile.plan !== "advanced") return fail("当前账号无权使用此网站",403);
        if (site.proxy_mode !== "fixed" || !site.fixed_proxy_id) return fail("此网站没有设置固定IP");
        const { data:fixedProxy, error:fixedError } = await admin.from("translation_proxy_pool")
          .select("id,label,protocol,host,port,encrypted_username,username_iv,encrypted_password,password_iv,enabled,health_status,failure_count,last_used_at")
          .eq("id",site.fixed_proxy_id).eq("enabled",true).maybeSingle();
        if (fixedError || !fixedProxy) return json({ok:true,proxy:null,mode:"fixed_site",message:"固定IP已停用或删除"});
        await logEvent(admin,{user_id:userId,proxy_id:fixedProxy.id,source:"desktop",event_type:"fixed_site_open",target:siteKey,message:"使用网站固定IP；禁止自动轮换"});
        return json({ok:true,proxy:await publicProxy(fixedProxy as ProxyRow),mode:"fixed_site",switched:false});
      }

      if (body.action === "site_pool") {
        const siteKey = String(body.siteKey || "").trim().toLowerCase();
        const poolKind = body.poolKind === "tn" ? "tn" : "translation";
        const { data:site, error:siteError } = await admin.from("work_sites").select("site_key,enabled,minimum_plan,proxy_mode").eq("site_key",siteKey).maybeSingle();
        if (siteError || !site?.enabled) return fail("网站不存在或已下架",404);
        if (site.minimum_plan === "advanced" && profile.role !== "admin" && profile.plan !== "advanced") return fail("当前账号无权使用此网站",403);
        if ((poolKind === "tn" && site.proxy_mode !== "tn_pool") || (poolKind === "translation" && site.proxy_mode !== "automatic")) return fail("网站IP池类型不匹配");
        const allowedKinds = poolKind === "tn" ? ["tn"] : ["translation","shared"];
        const { data:rows, error:poolError } = await admin.from("translation_proxy_pool")
          .select("id,label,protocol,host,port,encrypted_username,username_iv,encrypted_password,password_iv,enabled,health_status,failure_count,last_used_at")
          .eq("enabled",true).in("pool_kind",allowedKinds).order("failure_count",{ascending:true}).order("last_used_at",{ascending:true,nullsFirst:true}).limit(20);
        if (poolError) throw poolError;
        const chosen = (rows || []).find((row:any) => row.health_status !== "disabled" && row.health_status !== "failing") || (rows || [])[0];
        if (!chosen) return json({ok:true,proxy:null,mode:`${poolKind}_site_pool`,message:`${poolKind === "tn" ? "TN" : "翻译/网站"}IP池暂无可用线路`});
        await admin.from("translation_proxy_pool").update({last_used_at:new Date().toISOString()}).eq("id",chosen.id);
        await logEvent(admin,{user_id:userId,proxy_id:chosen.id,source:"desktop",event_type:"site_pool_open",target:siteKey,message:`网站仅从${poolKind === "tn" ? "TN" : "翻译/网站"}池选线`});
        return json({ok:true,proxy:await publicProxy(chosen as ProxyRow),mode:`${poolKind}_site_pool`,switched:true});
      }

      const { data: settings, error: settingsError } = await admin
        .from("translation_proxy_settings")
        .select("enabled,failure_threshold")
        .eq("singleton", true)
        .single();
      if (settingsError) throw settingsError;
      if (!settings.enabled) return json({ ok: true, proxy: null, mode: "disabled" });

      const { data: poolData, error: poolError } = await admin
        .from("translation_proxy_pool")
        .select("id,label,protocol,host,port,encrypted_username,username_iv,encrypted_password,password_iv,enabled,health_status,failure_count,last_used_at")
        .eq("enabled", true)
        .in("pool_kind", ["translation", "shared"]);
      if (poolError) throw poolError;
      const pool = (poolData || []) as ProxyRow[];
      const requestedExclusions = new Set((Array.isArray(body.excludedProxyIds) ? body.excludedProxyIds : []).map(value => String(value)).slice(0, 500));

      const { data: assignment, error: assignmentError } = await admin
        .from("translation_proxy_assignments")
        .select("user_id,proxy_id,assignment_mode,allowed_by_admin")
        .eq("user_id", userId)
        .maybeSingle();
      if (assignmentError) throw assignmentError;
      if (assignment?.allowed_by_admin === false) {
        return json({ ok: true, proxy: null, mode: "denied", message: "管理员未开放此账号使用翻译IP" });
      }

      if (body.action === "report_success") {
        if (assignment?.proxy_id && (!body.proxyId || body.proxyId === assignment.proxy_id)) {
          const previous = pool.find(row => row.id === assignment.proxy_id) || null;
          await admin.from("translation_proxy_pool").update({
            health_status: "healthy",
            failure_count: 0,
            last_error: null,
            last_checked_at: new Date().toISOString(),
            last_used_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }).eq("id", assignment.proxy_id);
          if (previous?.health_status !== "healthy") await logEvent(admin, {
            user_id:userId, proxy_id:assignment.proxy_id, source:"desktop",
            event_type:"proxy_recovered", target:"translation-or-site", message:"当前绑定IP检测恢复正常",
          });
        }
        return json({ ok: true });
      }

      if (body.action === "report_failure") {
        if (!assignment?.proxy_id || (body.proxyId && body.proxyId !== assignment.proxy_id)) {
          return json({ ok: true, proxy: null, mode: assignment?.assignment_mode || "automatic" });
        }
        const current = pool.find(row => row.id === assignment.proxy_id) || null;
        const threshold = Number(settings.failure_threshold || 2);
        const reason = String(body.reason || "翻译代理连接失败").slice(0, 500);
        const targetScoped = isTargetScopedRejection(reason);
        const failures = targetScoped ? threshold : (body.forceSwitch === true ? threshold : Number(current?.failure_count || 0) + 1);
        if (!targetScoped) {
          await admin.from("translation_proxy_pool").update({
            failure_count: failures,
            health_status: failures >= threshold ? "failing" : "unknown",
            last_error: reason,
            last_checked_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }).eq("id", assignment.proxy_id);
        }
        await admin.from("translation_proxy_assignments").update({
          last_failure_at: new Date().toISOString(),
          last_error: reason,
          updated_at: new Date().toISOString(),
        }).eq("user_id", userId);
        await logEvent(admin, {
          user_id:userId, proxy_id:assignment.proxy_id, source:"desktop",
          event_type:targetScoped ? "target_rejected" : "proxy_failure",
          target:targetScoped ? "translation-or-site-specific" : "translation-or-site", message:reason,
        });

        // A desktop full-pool scan sends the current line in excludedProxyIds.
        // Keep the configured failure counter, but do not hand the same line
        // straight back to that scan or it would stop after only one attempt.
        const scanningNextLine = requestedExclusions.has(assignment.proxy_id);
        if (assignment.assignment_mode === "fixed" || (failures < threshold && !scanningNextLine)) {
          return json({
            ok: true,
            proxy: await publicProxy(current),
            mode: assignment.assignment_mode,
            switched: false,
          });
        }
        requestedExclusions.add(assignment.proxy_id);
        const replacement = await chooseProxy(admin, pool, requestedExclusions);
        const effectiveProxy = replacement || (targetScoped ? current : null);
        await admin.from("translation_proxy_assignments").update({
          proxy_id: effectiveProxy?.id || null,
          assigned_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }).eq("user_id", userId);
        await logEvent(admin, {
          user_id:userId, proxy_id:replacement?.id || null, source:"desktop",
          event_type:replacement ? "proxy_switched" : (targetScoped ? "target_cooldown" : "proxy_unavailable"), target:"translation-or-site",
          message:replacement ? `${targetScoped ? "目标服务拒绝当前IP" : "原IP失效"}，已自动更换到 ${replacement.label || replacement.host}` : (targetScoped ? "目标服务暂时拒绝；保留全局健康线路供其他网站使用" : "原IP失效，池内暂时没有可用线路"),
        });
        return json({
          ok: true,
          proxy: await publicProxy(effectiveProxy),
          mode: "automatic",
          switched: Boolean(replacement),
          targetScoped,
        });
      }

      let selected = assignment?.proxy_id ? pool.find(row => row.id === assignment.proxy_id) || null : null;
      if (selected && assignment?.assignment_mode !== "fixed" && selected.health_status === "failing") selected = null;
      if (!selected && assignment?.assignment_mode === "fixed") {
        return json({ ok: true, proxy: null, mode: "fixed", message: "指定代理已停用或删除" });
      }
      if (!selected || requestedExclusions.has(selected.id)) selected = await chooseProxy(admin, pool, requestedExclusions);
      const mode = assignment?.assignment_mode || "automatic";
      await admin.from("translation_proxy_assignments").upsert({
        user_id: userId,
        proxy_id: selected?.id || null,
        assignment_mode: mode,
        allowed_by_admin: assignment?.allowed_by_admin !== false,
        assigned_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }, { onConflict: "user_id" });
      if (selected) {
        await admin.from("translation_proxy_pool").update({ last_used_at: new Date().toISOString() }).eq("id", selected.id);
        if (selected.id !== assignment?.proxy_id) await logEvent(admin, {
          user_id:userId, proxy_id:selected.id, source:"desktop", event_type:"proxy_assigned",
          target:"translation-or-site", message:`自动分配 ${selected.label || selected.host}`,
        });
      }
      return json({ ok: true, proxy: await publicProxy(selected), mode, switched: false });
    } catch (error) {
      console.error("proxy-control error", error);
      return fail(error instanceof Error ? error.message : String(error), 500);
    }
  }),
};

