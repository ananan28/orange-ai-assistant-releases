# Orange AI Windows 恢复工程

桌面版本 1.0.40；来源为正常运行安装包中的 app.asar、resources.zip 和 Supabase 当前部署。

## Windows 使用

安装 Node.js 24 后，在 desktop 目录执行：

```powershell
npm ci
npm run verify
npm start
```

开发版使用独立目录 orange-ai-internal-dev，不读取正式软件的登录缓存。需要重新登录同一 Supabase 后端。

生成 Windows x64 安装包：

```powershell
npm run build:win
```

输出位于 desktop/dist；打包命令明确禁止自动发布。正式安装版可能与现有软件共用数据目录，测试前请备份当前软件数据。

## 恢复内容

桌面主程序、预加载脚本、界面代码已格式化，附带普通和 TN 两套完整外置扩展。package-lock.json 固定依赖；Electron 44.5.1 是本次选定版本，原安装包运行时版本未确认，兼容性仍需 Windows 实测。Supabase SDK 固定为安装包实际包含的 2.112.3，更新模块固定为 6.8.9。应用 ID 为重建值，原应用 ID 未找到。

Supabase 下包含 5 个后端 TypeScript 函数以及数据库结构快照。当前桌面工程连接已有正常工作的项目，不需重建线上数据库。数据库 JSON 快照不能当作完整迁移执行；没有导出服务端密钥或业务记录。

## 验证与限制

30 个 JS 文件通过语法检查；主程序必要文件及扩展 manifest 引用已检查。Windows 打包结果见 BUILD-STATUS.txt。登录、AI、代理、内部消息、TN、自动更新仍需要 Windows 上实际验证。未修改线上 Supabase、未提交仓库。

这是可维护的恢复工程，不是原始未压缩源码的逐字恢复。原注释、原始变量名、Git 历史未恢复。macOS M4 适配尚未开始。
