'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const candidate=path.resolve(__dirname,'..'),baseline=path.resolve(process.argv[2]);
const source=(root,file)=>fs.readFileSync(path.join(root,file),'utf8');
function aiScanCount(root){
 const text=source(root,'extension-source/ai_reply.js');let scans=0,next=0;const timers=new Map();
 const ctx={O:0,Array,document:{hidden:false,querySelectorAll(){scans++;return []}},setTimeout(fn){timers.set(++next,fn);return next},clearTimeout(id){timers.delete(id)},et:()=>true,tt(){}};
 vm.createContext(ctx);const a=text.indexOf('  function v() {');vm.runInContext(text.slice(a,text.indexOf('  let ae = 0;',a)),ctx);
 for(let i=0;i<1000;i++)ctx.v();for(const fn of [...timers.values()])fn();return scans;
}
async function credentialScanCount(root){
 const text=source(root,'site-preload.js');let observer,scans=0;const timers=[];
 const ctx={installDetachedWindowControls(){},isOpenAiLoginHost:false,isTextNowHost:false,installCredentialPanel:async()=>{scans++;return false},MutationObserver:class{constructor(fn){observer=fn}observe(){}disconnect(){}},document:{documentElement:{}},setTimeout(fn,ms){if(ms<1000)timers.push(fn);return 1},clearTimeout(){},addEventListener(){},console};
 vm.createContext(ctx);const a=text.indexOf('async function startCredentialUi()');vm.runInContext(text.slice(a,text.indexOf('\nconst pageTranslation',a)),ctx);await ctx.startCredentialUi();
 for(let i=0;i<1000;i++)observer();for(const fn of timers)await fn();return scans;
}
function workspaceWrites(root){
 const text=source(root,'main.js');let state={users:{}},writes=0;
 const ctx={currentWorkspaceUserKey:()=>"u",readWorkspaceStore:()=>JSON.parse(JSON.stringify(state)),sanitizeWorkspaceState:n=>n,writeWorkspaceStore:n=>{state=n;writes++}};
 vm.createContext(ctx);const a=text.indexOf('function saveCurrentWorkspaceState(');vm.runInContext(text.slice(a,text.indexOf('function savedWindowState',a)),ctx);
 for(let i=0;i<100;i++)ctx.saveCurrentWorkspaceState({tabs:[],activeIndex:0});return writes;
}
async function hiddenWindowPeak(root){
 const text=source(root,'main.js');let active=0,peak=0;
 const ctx={authGeneration:0,currentSession:{access_token:'fixture'},currentProfile:{role:'employee'},config:{},effectiveExtensionPermissions:()=>({}),currentFeatureFlags:{},allowedSites:new Map(),siteAdapters:{},tnSharedAppearanceStorageValues:()=>({}),URL,BrowserWindow:class{constructor(){active++;peak=Math.max(peak,active);this.webContents={executeJavaScript:async()=>{}}}async loadURL(){await Promise.resolve()}isDestroyed(){return false}destroy(){active--}}};
 vm.createContext(ctx);let a=text.indexOf('const extensionAuthSnapshots');if(a<0)a=text.indexOf('async function syncExtensionAuth(');vm.runInContext(text.slice(a,text.indexOf('function effectiveExtensionPermissions',a)),ctx);
 await Promise.all(Array.from({length:20},()=>ctx.syncExtensionAuth({},{id:'fixture'})));assert.equal(active,0);return peak;
}
(async()=>{
 const results=[];for(const [label,root] of [['baseline-1.0.43',baseline],['unreleased-diagnostic-draft',candidate]])results.push({label,passwordQueriesFor1000AiUiTriggers:aiScanCount(root),credentialScansFor1000Mutations:await credentialScanCount(root),writesFor100UnchangedWorkspaceSaves:workspaceWrites(root),peakCredentialWindowsFor20ConcurrentSyncs:await hiddenWindowPeak(root)});
 console.log(JSON.stringify({method:'Actual source functions executed in controlled VM fixtures. Operation counts, not real browser CPU or memory measurements.',results},null,2));
 const draft=results[1];assert.equal(draft.passwordQueriesFor1000AiUiTriggers,1);assert.equal(draft.credentialScansFor1000Mutations,2);assert.equal(draft.writesFor100UnchangedWorkspaceSaves,1);assert.equal(draft.peakCredentialWindowsFor20ConcurrentSyncs,1);
})().catch(error=>{console.error(error);process.exitCode=1});
