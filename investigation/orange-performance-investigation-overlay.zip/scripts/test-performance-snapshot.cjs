'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const text=fs.readFileSync(path.join(__dirname,'../main.js'),'utf8');
const a=text.indexOf('function performanceSnapshot()'),b=text.indexOf('async function capturePerformanceReport()',a);
function contents(id,pid,url,type='window'){return {id,isDestroyed:()=>false,getOSProcessId:()=>pid,getURL:()=>url,getType:()=>type}}
const home=contents(1,10,'file:///private/user/app/index.html'),site=contents(2,11,'https://mail.google.com/mail/u/user@example.test/#inbox/secret'),extension=contents(3,12,'chrome-extension://secret-extension/popup.html');
const ctx={URL,Map,Date,mainWindow:{webContents:home},workbenchWindow:null,webContents:{getAllWebContents:()=>[home,site,extension,{isDestroyed:()=>true}]},app:{getAppMetrics:()=>[10,11,12,13].map(pid=>({pid,type:pid===13?'GPU':'Tab',cpu:{percentCPUUsage:2},memory:{workingSetSize:100,privateBytes:50},secret:'do not serialize'}))}};
vm.createContext(ctx);vm.runInContext(text.slice(a,b),ctx);const snapshot=ctx.performanceSnapshot();
assert.equal(snapshot.processes.length,4);assert.equal(snapshot.processes[0].pages[0].role,'main-page');assert.equal(snapshot.processes[1].pages[0].role,'website:mail.google.com');assert.equal(snapshot.processes[2].pages[0].role,'extension');assert.equal(snapshot.processes[3].pages.length,0);
const report=JSON.stringify(snapshot);for(const sensitive of ['user@example.test','#inbox','/private/user','secret-extension','do not serialize'])assert.ok(!report.includes(sensitive));
console.log('PASS: PID mapping, distinct process accounting, and diagnostics exclude URL paths, account names, extension IDs and arbitrary fields.');
