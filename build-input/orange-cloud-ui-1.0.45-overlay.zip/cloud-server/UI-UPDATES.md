# Signed cloud UI updates

Shell 1.0.45 adds signed UI release loading. It does not implement account-data synchronization or third-party cookie migration.

Supported update files: src/app.js, src/index.html, src/styles.css, src/fixes-1.0.40.css, src/workbench.js, src/workbench.html, src/workbench.css. Backend Edge Functions can already be deployed centrally. Main-process code, preload bridges, extensions, Electron, native dependencies and packaging still require a shell update. Do not promise all application code is hot-swappable.

Flow: an authenticated client subscribes to the minimal cloud_ui_channels realtime catalog, with five-minute REST fallback. A changed sequence causes one authenticated Edge Function request. The server signs the approved release with Ed25519; only the server role can read its signing-key table or release bodies. The embedded client public key validates the manifest, hashes, file allowlist, channel and minimum shell version. The private signing key is not in this repository or client binaries.

Downloads are staged locally. Switching waits until no workbench/detached window is open, no dialog is open, no input has focus, and no visible form is marked as an unsaved user edit. Pending changes are retried locally every five seconds without network traffic, or applied on next startup. The main page reloads while main-process login and third-party browser sessions remain in memory. A 30-second readiness timeout or interrupted unconfirmed activation rolls back to the last confirmed release or packaged UI. Bad sequences are blocked. Previous release assets are retained; obsolete cache directories are pruned after successful confirmation.

Preparation: node scripts/make-ui-release.cjs <ui-version> <minimum-shell-version> <output.json>. This only prepares a payload. Approval and publication are separate management operations. Publish transactionally: retire the channel's current published release, insert the reviewed payload as published with a new sequence, then update cloud_ui_channels to that sequence. A rollback is a new approved sequence containing a previously good payload; never reset a client's sequence counter. Keep the stable channel empty until the user approves rollout.

The test channel currently has a CSS-only fixture of existing styles. The stable channel was not published. A live response was verified using the embedded client public key. Existing account/device/member authorization functions were not replaced.

Automated checks cover signature tampering, unsafe filenames, shell incompatibility, interrupted activation, corrupted cache, replay suppression and server/client signing interoperability. Native Windows/macOS tests exercise real renderer reload, intentional broken HTML rollback, and session-cookie retention using synthetic local fixtures. They do not establish real Gmail/TN login portability, long-running logout stability, full account-data sync, or reduced twenty-page memory use.

Operational prerequisites: protect project-admin access and backups of the signing-key table, retain old keys for any key rotation, and keep the same embedded public key unless a new trusted shell supplies a key rotation. Do not log or export the private key into release artifacts.
