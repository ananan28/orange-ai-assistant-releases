begin;
create table if not exists public.cloud_ui_signing_keys (
 id integer primary key check (id=1),
 public_key_pem text not null,
 private_key_pem text not null,
 created_at timestamptz not null default now()
);
alter table public.cloud_ui_signing_keys enable row level security;
revoke all on public.cloud_ui_signing_keys from public, anon, authenticated;
grant select on public.cloud_ui_signing_keys to service_role;
create table if not exists public.cloud_ui_releases (
 sequence bigint generated always as identity primary key,
 channel text not null check (channel in ('stable','test')),
 version text not null check (version ~ '^[0-9]+[.][0-9]+[.][0-9]+$'),
 min_shell_version text not null,
 payload jsonb not null check (jsonb_typeof(payload)='object' and octet_length(payload::text)<=2097152),
 state text not null default 'draft' check (state in ('draft','published','retired')),
 created_at timestamptz not null default now(),
 published_at timestamptz,
 unique(channel,version)
);
create unique index if not exists cloud_ui_single_published_channel on public.cloud_ui_releases(channel) where state='published';
alter table public.cloud_ui_releases enable row level security;
revoke all on public.cloud_ui_releases from public, anon, authenticated;
grant select on public.cloud_ui_releases to service_role;
commit;

-- Minimal realtime catalog; release bodies and signing keys remain service-only.
begin;
create table if not exists public.cloud_ui_channels (
 channel text primary key check(channel in ('stable','test')),
 sequence bigint references public.cloud_ui_releases(sequence),
 updated_at timestamptz not null default now()
);
alter table public.cloud_ui_channels enable row level security;
revoke all on public.cloud_ui_channels from public,anon,authenticated;
grant select on public.cloud_ui_channels to authenticated;
grant all on public.cloud_ui_channels to service_role;
do $$ begin
 if not exists(select 1 from pg_policies where schemaname='public' and tablename='cloud_ui_channels' and policyname='cloud_ui_channel_read') then
  create policy cloud_ui_channel_read on public.cloud_ui_channels for select to authenticated using (true);
 end if;
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='cloud_ui_channels') then
  alter publication supabase_realtime add table public.cloud_ui_channels;
 end if;
end $$;
insert into public.cloud_ui_channels(channel) values('stable'),('test') on conflict do nothing;
commit;
