import {createClient} from 'npm:@supabase/supabase-js@2.112.3';
import {createReleaseHandler} from './handler.mjs';
const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
Deno.serve(createReleaseHandler({
 async readRelease(channel){
  const {data,error}=await admin.from('cloud_ui_releases').select('sequence,channel,version,min_shell_version,payload,published_at').eq('channel',channel).eq('state','published').maybeSingle();
  if(error)throw Error('release unavailable');
  return data;
 },
 async readSigningKey(){
  const {data,error}=await admin.from('cloud_ui_signing_keys').select('private_key_pem').eq('id',1).single();
  if(error)throw Error('signer unavailable');
  return data.private_key_pem;
 }
}));
