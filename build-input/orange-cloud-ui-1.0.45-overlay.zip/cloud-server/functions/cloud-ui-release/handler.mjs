export function canonical(value){
 if(value===null||typeof value!=='object')return JSON.stringify(value);
 if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';
 return '{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonical(value[key])).join(',')+'}';
}
const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','X-Content-Type-Options':'nosniff'};
export function createReleaseHandler({readRelease,readSigningKey}){
 const reply=(body,status=200)=>new Response(JSON.stringify(body),{status,headers});
 return async req=>{
  if(req.method!=='GET')return reply({ok:false,code:'METHOD_NOT_ALLOWED'},405);
  const channel=new URL(req.url).searchParams.get('channel')||'stable';
  if(!['stable','test'].includes(channel))return reply({ok:false,code:'INVALID_CHANNEL'},400);
  try{
   const release=await readRelease(channel);
   if(!release)return reply({ok:true,release:null});
   const manifest={schema:1,sequence:release.sequence,channel:release.channel,version:release.version,minShellVersion:release.min_shell_version,publishedAt:release.published_at,payload:release.payload};
   const pem=await readSigningKey();
   const bytes=Uint8Array.from(atob(pem.replace(/-----[^-]+-----|\s/g,'')),c=>c.charCodeAt(0));
   const key=await crypto.subtle.importKey('pkcs8',bytes,'Ed25519',false,['sign']);
   const signature=new Uint8Array(await crypto.subtle.sign('Ed25519',key,new TextEncoder().encode(canonical(manifest))));
   return reply({ok:true,release:{manifest,signature:btoa(String.fromCharCode(...signature))}});
  }catch{return reply({ok:false,code:'UPDATE_SERVICE_UNAVAILABLE'},503)}
 };
}
