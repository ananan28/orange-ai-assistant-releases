'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {ALLOWED,compareVersion}=require('../ui-release-manager');
const [version,minShellVersion,output]=process.argv.slice(2);
if(!version||!minShellVersion||!output)throw Error('Usage: node scripts/make-ui-release.cjs <ui-version> <minimum-shell-version> <output.json>');
compareVersion(version,version);compareVersion(minShellVersion,minShellVersion);
const files={};for(const name of ALLOWED){const bytes=fs.readFileSync(path.join(__dirname,'../src',name));files[name]={content:bytes.toString('base64'),sha256:crypto.createHash('sha256').update(bytes).digest('hex')}}
const payload={shellApi:1,files};const body={version,minShellVersion,payload};
if(Buffer.byteLength(JSON.stringify(payload))>1800000)throw Error('Release exceeds size budget');
fs.writeFileSync(output,JSON.stringify(body),{mode:0o600});
console.log('Prepared '+version+' UI bundle. This command does not publish or alter employee clients.');
