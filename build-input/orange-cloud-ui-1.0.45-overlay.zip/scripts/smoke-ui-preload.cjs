const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('uiProbe',{ready:value=>ipcRenderer.send('ui-probe:ready',value)});
