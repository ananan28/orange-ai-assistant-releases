'use strict';
const {app,BrowserWindow,ipcMain,session}=require('electron');
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {UiReleaseManager,canonical}=require('../ui-release-manager');
const keys=crypto.generateKeyPairSync('ed25519');
let win,temp;
function signed(sequence,html){const files={'index.html':{content:Buffer.from(html).toString('base64'),sha256:crypto.createHash('sha256').update(html).digest('hex')}};const manifest={schema:1,sequence,channel:'test',version:`1.0.${45+sequence}`,minShellVersion:'1.0.45',publishedAt:new Date().toISOString(),payload:{shellApi:1,files}};return {manifest,signature:crypto.sign(null,Buffer.from(canonical(manifest)),keys.privateKey).toString('base64')}}
function ready(expected,timeout=5000){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{ipcMain.removeListener('ui-probe:ready',receive);reject(Error('UI ready timeout'))},timeout);function receive(event,value){if(event.sender===win.webContents&&value===expected){clearTimeout(timer);ipcMain.removeListener('ui-probe:ready',receive);resolve()}}ipcMain.on('ui-probe:ready',receive)})}
app.whenReady().then(async()=>{
 temp=await fs.mkdtemp(path.join(os.tmpdir(),'orange-ui-native-'));
 const base=path.join(temp,'base');await fs.mkdir(path.join(base,'src'),{recursive:true});await fs.mkdir(path.join(base,'extension-source/assets'),{recursive:true});
 for(const name of ['app.js','styles.css','fixes-1.0.40.css','workbench.js','workbench.html','workbench.css'])await fs.writeFile(path.join(base,'src',name),'');
 await fs.writeFile(path.join(base,'src/index.html'),'<script>window.uiProbe.ready("baseline")</script>');
 const manager=await new UiReleaseManager({base,root:path.join(temp,'updates'),channel:'test',shellVersion:'1.0.45',publicKey:keys.publicKey.export({type:'spki',format:'pem'})}).initialize();
 const profile=session.fromPartition('ui-native-'+crypto.randomUUID());
 await profile.cookies.set({url:'https://fixture.invalid',name:'retained',value:'session-fixture',httpOnly:true});
 win=new BrowserWindow({show:false,webPreferences:{session:profile,preload:path.join(__dirname,'smoke-ui-preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
 let wait=ready('baseline');await win.loadFile(manager.resolve('index.html'));await wait;
 await manager.stage(signed(1,'<script>window.uiProbe.ready("updated")</script>'));await manager.activate();
 wait=ready('updated');await win.loadFile(manager.resolve('index.html'));await wait;await manager.confirm();
 assert.equal((await profile.cookies.get({url:'https://fixture.invalid'}))[0].value,'session-fixture');
 await manager.stage(signed(2,'<script>throw Error("Intentional broken UI fixture")</script>'));await manager.activate();
 wait=ready('broken',1000).then(()=>false,()=>true);await win.loadFile(manager.resolve('index.html'));assert.equal(await wait,true);
 await manager.rollback();wait=ready('updated');await win.loadFile(manager.resolve('index.html'));await wait;
 assert.equal((await profile.cookies.get({url:'https://fixture.invalid'}))[0].value,'session-fixture');
 assert.ok(manager.state.blocked.includes(2));
 console.log('PASS: native '+process.platform+' signed UI switch and broken-update rollback retain the same browser session cookie; no real third-party credentials used.');
 win.destroy();await fs.rm(temp,{recursive:true,force:true});app.exit(0);
}).catch(error=>{console.error(error);win?.destroy();app.exit(1)});
