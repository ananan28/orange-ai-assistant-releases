'use strict';
const {spawnSync}=require('node:child_process');
const env={...process.env};delete env.ELECTRON_RUN_AS_NODE;
const result=spawnSync(require('electron'),['scripts/smoke-ui-updates.cjs'],{env,stdio:'inherit',timeout:60000});
if(result.error)throw result.error;
if(result.status!==0)throw Error('Native UI test failed: '+result.status+' '+result.signal);
