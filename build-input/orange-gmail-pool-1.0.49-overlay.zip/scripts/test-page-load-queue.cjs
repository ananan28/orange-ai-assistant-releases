'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('src/workbench.js','utf8');
let now=0,serial=0;const timers=new Map();
const context={setTimeout(fn,ms){timers.set(++serial,{fn,at:now+ms});return serial},clearTimeout(id){timers.delete(id)}};
vm.createContext(context);
vm.runInContext(source.slice(source.indexOf('class PageLoadQueue'),source.indexOf('const pageLoadQueue'))+';globalThis.Queue=PageLoadQueue;',context);
function tick(ms){const end=now+ms;while(true){const task=[...timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!task)break;now=task[1].at;timers.delete(task[0]);task[1].fn()}now=end}
const queue=new context.Queue({limit:2,timeout:1000,delay:10}),started=[];
for(let i=0;i<150;i++)queue.add(i,()=>started.push(i));
queue.prioritize(149);tick(10);assert.deepEqual(started,[149,0]);assert.equal(queue.running.size,2);
queue.prioritize(148);tick(10);assert.deepEqual(started,[149,0,148]);assert.equal(queue.running.size,3);
queue.prioritize(147);tick(10);assert.equal(started.length,3,'interactive reserve is bounded');
queue.cancel(147);queue.done(0);tick(10);assert.equal(started.length,3,'normal jobs wait for normal capacity');
queue.done(149);tick(10);assert.equal(started.at(-1),1);assert.ok(!started.includes(147));
tick(1100);assert.ok(started.length>4,'stalled jobs eventually release queue capacity');
console.log('PASS: 150 queued pages, two normal starts, bounded interactive reserve, selected-page priority, cancellation and stalled-page recovery.');
