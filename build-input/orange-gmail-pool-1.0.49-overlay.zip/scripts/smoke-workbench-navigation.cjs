'use strict';
const {app,BrowserWindow}=require('electron');
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
let win,server;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function until(fn,label){const end=Date.now()+12000;while(Date.now()<end){try{if(await fn())return}catch{}await wait(100)}throw Error('Timeout: '+label)}
app.whenReady().then(async()=>{
 const source=fs.readFileSync(path.join(__dirname,'../main.js'),'utf8');
 const helper=source.slice(source.indexOf('function installAccountPopupNavigation('),source.indexOf('async function configureSiteAccountSession('));
 const install=new Function('path','__dirname','shell','installReloadShortcuts',helper+';return installAccountPopupNavigation')(path,path.resolve(__dirname,'..'),{openExternal:()=>{throw Error('Unexpected external browser')}},()=>{});
 server=http.createServer((req,res)=>{if(req.url==='/redirect'){res.writeHead(302,{Location:'/login'});res.end();return}
 res.setHeader('Content-Type','text/html');res.end('<html><body style="margin:0;background:rgb(10,90,170);color:white"><h1>'+req.url+'</h1><script>window.fixtureMarker="preserved"</script></body></html>')});
 await new Promise(r=>server.listen(0,'0.0.0.0',r));const port=server.address().port,url=`http://127.0.0.1:${port}`;
 win=new BrowserWindow({width:1100,height:760,show:true,webPreferences:{preload:path.join(__dirname,'smoke-workbench-preload.cjs'),webviewTag:true,contextIsolation:true,nodeIntegration:false,sandbox:true}});
 const guests=[];win.webContents.on('did-attach-webview',(_,guest)=>{guests.push(guest);install(guest)});
 await win.loadFile(path.join(__dirname,'../src/workbench.html'));
 const run=script=>win.webContents.executeJavaScript(script);
 await until(()=>run('restoring === false'),'workbench ready');
 await run(`setTabCenterOpen(false);openTab({siteId:'fixture',url:${JSON.stringify(url+'/first')},partition:'persist:orange-native-fixture-a'});openTab({siteId:'fixture',url:${JSON.stringify(url+'/second')},partition:'persist:orange-native-fixture-b'})`);
 await until(()=>guests.length===2&&guests.every(g=>g.getURL().startsWith(url)),'two guests attached');await wait(500);
 assert.equal(await run('getComputedStyle(empty).display'),'none','Empty welcome panel leaked over guest');
 const first=guests.find(g=>g.getURL().endsWith('/first')),second=guests.find(g=>g.getURL().endsWith('/second')),ids=guests.map(g=>g.id);let navigations=0;guests.forEach(g=>g.on('did-start-navigation',()=>navigations++));
 await first.session.cookies.set({url,name:'retained',value:'fixture',httpOnly:true});
 await run('reorderTab("tab-1","tab-2");reorderTab("tab-2","tab-1");activate("tab-1")');await wait(500);
 assert.deepEqual(guests.map(g=>g.id),ids);assert.equal(navigations,0,'Reordering remounted/navigated a guest');
 assert.equal(await first.executeJavaScript('window.fixtureMarker'),'preserved');
 await first.loadURL(url+'/redirect');assert.ok(first.getURL().endsWith('/login'));
 let popup;first.once('did-create-window',w=>{popup=w});
 await first.executeJavaScript(`window.open('http://localhost:${port}/external-login','_blank');void 0`,true);
 await until(()=>popup&&popup.webContents.getURL().includes('/external-login'),'cross-origin login popup');
 assert.equal(popup.webContents.session,first.session);assert.equal((await popup.webContents.session.cookies.get({url}))[0].value,'fixture');popup.destroy();
 for(let i=0;i<4;i++){win.setPosition(100+i*12,100+i*10);win.setSize(1000+i*20,700+i*10);await wait(150)}
 win.maximize();await wait(250);win.unmaximize();await wait(250);
 assert.equal(await first.executeJavaScript('window.fixtureMarker'),'preserved');
 const image=await first.capturePage();const pixels=image.toBitmap();let colored=0;for(let i=0;i<pixels.length;i+=4){if(pixels[i]>130&&pixels[i+1]>50&&pixels[i+1]<130&&pixels[i+2]<50)colored++}assert.ok(colored>10000,'Guest did not paint after move/resize');
 await run(`showTabLoadError(tabs.get('tab-1'),{validatedURL:${JSON.stringify(url+'/recovered')},errorDescription:'ERR_SOCKET_NOT_CONNECTED'});`);
 assert.ok(await run('!tabs.get("tab-1").view.getURL().startsWith("data:")'));
 await run('document.querySelector(".work-error button").click()');await until(()=>first.getURL().endsWith('/recovered'),'retry navigates original URL');
 assert.equal((await first.session.cookies.get({url}))[0].value,'fixture');
 console.log('PASS: actual workbench hides welcome, reorders without guest reload, permits redirect and cross-origin same-session popup, paints after move/resize, retries failed URL with cookies retained on '+process.platform);
 win.destroy();await new Promise(r=>server.close(r));app.exit(0);
}).catch(error=>{console.error(error);win?.destroy();server?.close();app.exit(1)});
