'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const main=fs.readFileSync('main.js','utf8'),work=fs.readFileSync('src/workbench.js','utf8');
const code=main.slice(main.indexOf('const siteTransportState ='),main.indexOf('function installAccountPopupNavigation('));
const c={};vm.createContext(c);vm.runInContext(code,c);
(async()=>{
 let sets=0,closes=0;const s={setProxy:async()=>{sets++},closeAllConnections:async()=>{closes++}};
 await Promise.all(Array.from({length:20},()=>c.configureSiteTransport(s,null)));
 assert.equal(sets,1);assert.equal(closes,0);
 await c.configureSiteTransport(s,{host:'fixture.invalid',port:8000});assert.equal(sets,2);assert.equal(closes,1);
 await c.configureSiteTransport(s,{host:'fixture.invalid',port:8000});assert.equal(closes,1);
 await c.configureSiteTransport(s,null);assert.equal(closes,2);
 const r={URL};vm.createContext(r);vm.runInContext(work.slice(work.indexOf('function isWebUrl('),work.indexOf('function showTabLoadError(')),r);
 let opened='',removed=0;const tab={nativeKind:'',url:'https://example.test/login',failedUrl:'https://example.test/auth',errorNode:{remove:()=>removed++},view:{getURL:()=> 'chrome-error://chromewebdata/',loadURL:async url=>{opened=url}}};r.retryWorkTab(tab);assert.equal(opened,'https://example.test/auth');assert.equal(removed,1);assert.equal(tab.failedUrl,'');
 const reorder=work.slice(work.indexOf('function reorderTab('),work.indexOf('async function choosePlatform('));assert.ok(!reorder.includes('appendChild(c.view)'));
 console.log('PASS: 20 concurrent same-route preparations cause one proxy setup and no socket teardown; real route changes reconnect; failed-page retry retains original URL and tab reorder does not move guests.');
})().catch(e=>{console.error(e);process.exitCode=1});
