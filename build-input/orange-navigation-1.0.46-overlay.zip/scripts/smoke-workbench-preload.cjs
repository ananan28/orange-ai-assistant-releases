const {contextBridge}=require('electron');
const noop=()=>{};
contextBridge.exposeInMainWorld('orangeApp',{
 onOpenWorkTab:noop,onSwitchWorkTab:noop,onActivateAccount:noop,onTnAccessRevoked:noop,
 getWorkspaceState:async()=>({tabs:[]}),saveWorkspaceState:async()=>({ok:true}),saveWorkspaceStateSync:noop,
 getSiteWallpaper:async()=>({ok:true}),setTnTabVisibility:noop,listPlatforms:async()=>({sites:[]}),
});
