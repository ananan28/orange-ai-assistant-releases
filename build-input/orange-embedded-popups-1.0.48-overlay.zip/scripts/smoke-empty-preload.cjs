// Intentionally empty isolated preload: no real credentials or third-party calls.
