const {contextBridge,ipcRenderer}=require('electron');
const noop=()=>{};
contextBridge.exposeInMainWorld('orangeApp',{
 setPopupLayout:value=>ipcRenderer.send('workbench:popup-layout',value),
 popupCommand:value=>ipcRenderer.send('workbench:popup-command',value),
 onPopupState:fn=>{ipcRenderer.on('workbench:popup-state',(_e,value)=>fn(value));},
 onPopupLayoutNeeded:fn=>{ipcRenderer.on('workbench:popup-layout-needed',()=>fn());},
 onOpenWorkTab:noop,onSwitchWorkTab:noop,onActivateAccount:noop,onTnAccessRevoked:noop,
 getWorkspaceState:async()=>({tabs:[]}),saveWorkspaceState:async()=>({ok:true}),saveWorkspaceStateSync:noop,
 getSiteWallpaper:async()=>({ok:true}),setTnTabVisibility:noop,listPlatforms:async()=>({sites:[]}),
});
