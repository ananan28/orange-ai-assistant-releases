'use strict';
const {WebContentsView} = require('electron');

// Keep the real Chromium popup (opener, POST body and session included), but
// present it in its account's existing workbench area instead of an OS window.
class EmbeddedPopupManager {
  constructor({ipcMain, preload, openExternal}) {
    this.hosts = new Map();
    this.preload = preload;
    this.openExternal = openExternal;
    ipcMain.on('workbench:popup-layout', (event, value) => {
      const state = this.hosts.get(event.sender.id);
      if (!state || !value || typeof value !== 'object') return;
      const previousRoot=state.activeRoot;
      const rootId = Number(value.rootId);
      state.activeRoot = state.roots.has(rootId) ? rootId : 0;
      state.obscured = value.obscured === true;
      state.bounds = this.clampBounds(state.host, value.bounds);
      this.layout(state);
      if (previousRoot!==state.activeRoot && !state.obscured) {
        const target=this.top(state,state.activeRoot)?.contents||state.roots.get(state.activeRoot);
        if (target && !target.isDestroyed()) target.focus();
      }
    });
    ipcMain.on('workbench:popup-command', (event, value) => {
      const state = this.hosts.get(event.sender.id);
      if (!state || state.obscured || !value || typeof value !== 'object') return;
      const record = this.top(state, state.activeRoot);
      if (!record || record.contents.isDestroyed()) return;
      const wc = record.contents;
      switch (value.action) {
        case 'close': wc.close({waitForBeforeUnload:true}); break;
        case 'reload': value.ignoreCache ? wc.reloadIgnoringCache() : wc.reload(); break;
        case 'back':
          if (wc.navigationHistory.canGoBack()) wc.navigationHistory.goBack();
          else wc.close({waitForBeforeUnload:true});
          break;
        case 'forward': if (wc.navigationHistory.canGoForward()) wc.navigationHistory.goForward(); break;
        case 'zoom': {
          const factor = Number(value.factor);
          if (Number.isFinite(factor)) wc.setZoomFactor(Math.min(2,Math.max(0.5,factor)));
          break;
        }
      }
    });
  }
  clampBounds(host, bounds = {}) {
    const [width,height] = host.getContentSize();
    const number = (v, fallback) => Number.isFinite(Number(v)) ? Math.round(Number(v)) : fallback;
    const x = Math.min(width,Math.max(0,number(bounds?.x,0)));
    const y = Math.min(height,Math.max(0,number(bounds?.y,48)));
    return {x,y,width:Math.max(0,Math.min(width-x,number(bounds?.width,width-x))),
      height:Math.max(0,Math.min(height-y,number(bounds?.height,height-y)))};
  }
  top(state, rootId) {
    return [...state.records.values()].filter(r => r.rootId===rootId && !r.contents.isDestroyed()).at(-1);
  }
  register(host) {
    const hostId=host.webContents.id;
    let state = this.hosts.get(hostId);
    if (state) return state;
    state = {host,roots:new Map(),records:new Map(),activeRoot:0,obscured:false,bounds:null,lastState:''};
    this.hosts.set(host.webContents.id,state);
    host.on('resize', () => {
      // Hide until the renderer reports the new content rectangle; never paint
      // over the toolbar or sidebar using stale bounds during a live resize.
      for (const r of state.records.values()) r.view.setVisible(false);
      if (!host.webContents.isDestroyed()) host.webContents.send('workbench:popup-layout-needed');
    });
    host.once('closed', () => {
      this.hosts.delete(hostId);
      for (const r of state.records.values()) if (!r.contents.isDestroyed()) r.contents.close();
      state.records.clear();
    });
    host.webContents.on('did-start-navigation', (_event,_url,_inPlace,isMainFrame) => {
      if (isMainFrame) {state.activeRoot=0;state.obscured=true;this.layout(state);}
    });
    return state;
  }
  install(contents, host, rootId = contents.id) {
    const state = this.register(host);
    if (rootId === contents.id) {
      state.roots.set(rootId,contents);
      contents.once('destroyed', () => {
        state.roots.delete(rootId);
        for (const r of [...state.records.values()]) if (r.rootId===rootId && !r.contents.isDestroyed()) r.contents.close();
        this.layout(state);
      });
    }
    contents.setWindowOpenHandler(({url}) => {
      let protocol;
      try {protocol=new URL(url).protocol;} catch {return {action:'deny'};}
      if (!['http:','https:'].includes(protocol) && url!=='about:blank') {
        if (['mailto:','tel:'].includes(protocol)) Promise.resolve(this.openExternal(url)).catch(()=>{});
        return {action:'deny'};
      }
      return {action:'allow',createWindow: options => {
        const view = new WebContentsView({webPreferences:{...options.webPreferences,
          session:contents.session,preload:this.preload,nodeIntegration:false,contextIsolation:true,sandbox:true}});
        const child = view.webContents;
        const record = {view,contents:child,rootId,parentId:contents.id};
        state.records.set(child.id,record);
        host.contentView.addChildView(view);
        child.setZoomFactor(contents.getZoomFactor());
        this.install(child,host,rootId);
        const closeChild = () => {if (!child.isDestroyed()) child.close();};
        contents.once('destroyed',closeChild);
        child.once('destroyed', () => {
          contents.removeListener('destroyed',closeChild);
          state.records.delete(child.id);
          if (!host.isDestroyed()) host.contentView.removeChildView(view);
          this.layout(state);
          if (state.activeRoot===rootId && !state.obscured) {
            const target=this.top(state,rootId)?.contents||state.roots.get(rootId);
            if (target && !target.isDestroyed()) target.focus();
          }
        });
        for (const event of ['did-navigate','did-navigate-in-page','page-title-updated','did-stop-loading']) {
          child.on(event,()=>this.publish(state));
        }
        child.on('before-input-event', (event,input) => {
          if (input.type!=='keyDown') return;
          const key=String(input.key||'').toLowerCase(), modifier=input.control||input.meta;
          if (modifier && key==='tab') {event.preventDefault();host.webContents.send('workbench:switch-tab',input.shift?-1:1);}
          else if (key==='f5'||(modifier&&key==='r')) {event.preventDefault();modifier&&input.shift?child.reloadIgnoringCache():child.reload();}
          else if (modifier&&['+','=','-','0'].includes(key)) {
            event.preventDefault();child.setZoomFactor(key==='0'?1:Math.max(0.5,Math.min(2,child.getZoomFactor()+(key==='-'?-0.1:0.1))));this.publish(state);
          }
        });
        this.layout(state);
        if (state.activeRoot===rootId && !state.obscured) child.focus();
        // Electron owns initial navigation, including form POST and about:blank.
        return child;
      }};
    });
  }
  layout(state) {
    if (state.host.isDestroyed()) return;
    const top = this.top(state,state.activeRoot);
    const bounds = this.clampBounds(state.host,state.bounds||{});
    for (const r of state.records.values()) {
      const visible = r===top && !state.obscured && bounds.width>0 && bounds.height>0;
      r.view.setBounds(bounds);
      r.view.setVisible(visible);
    }
    this.publish(state);
  }
  publish(state) {
    if (state.host.isDestroyed() || state.host.webContents.isDestroyed()) return;
    const record = this.top(state,state.activeRoot);
    const value = {rootId:state.activeRoot,popupId:record?.contents.id||0,
      depth:[...state.records.values()].filter(r=>r.rootId===state.activeRoot).length,
      url:record?.contents.getURL()||'',zoom:record?.contents.getZoomFactor()||1};
    const key=JSON.stringify(value);
    if (key!==state.lastState) {state.lastState=key;state.host.webContents.send('workbench:popup-state',value);}
  }
}
module.exports={EmbeddedPopupManager};
