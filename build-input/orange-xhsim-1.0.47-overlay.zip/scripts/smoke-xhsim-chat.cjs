'use strict';
const {app,BrowserWindow}=require('electron');
const fs=require('node:fs'),http=require('node:http'),assert=require('node:assert/strict');
app.commandLine.appendSwitch('host-resolver-rules','MAP client.xhsim.ai 127.0.0.1');
let win,server;
const content=fs.readFileSync('extension-source/content.js','utf8');
const reply=fs.readFileSync('extension-source/ai_reply.js','utf8');
function declaration(source,name){
 const start=source.search(new RegExp('^  (?:async )?function '+name+'\\(', 'm'));
 assert.ok(start>=0,name);
 const rest=source.slice(start+1), next=rest.search(/\n  (?:async )?function /);
 assert.ok(next>=0,name+' next');
 return source.slice(start,start+1+next);
}
app.whenReady().then(async()=>{
 server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end(`<!doctype html><html><body>
 <form onsubmit="event.preventDefault()"><div id="kt_chat_messenger_body"><div id="messageParent">
 <div id="inMessage"><div id="msg" data-kt-element="message-text" class="text-start">Do you go to church?</div></div>
 <div id="outMessage"><div id="msg" data-kt-element="message-text" class="text-end">When are you free</div></div>
 </div></div><textarea id="sendMessageText" data-kt-element="input">hello\n\nthere</textarea>
 <button type="button" id="send">发送文字</button><button type="button" id="image">发送图片</button></form>
 <script>window.sent=[];send.addEventListener('click',()=>{window.sent.push(sendMessageText.value);sendMessageText.value=''});sendMessageText.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send.click()}});</script></body></html>`)});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 win=new BrowserWindow({show:true,width:900,height:700,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
 await win.loadURL(`http://client.xhsim.ai:${server.address().port}/fixture`);
 const run=s=>win.webContents.executeJavaScript(s,true);
 // Real Chromium layout, repeated IDs, enclosing form, real translation renderer.
 const functions=['E','Ke','At','X','ot','re','st','rn','ge','yo'].map(n=>declaration(content,n)).join('\n');
 await run(`window.testChat=(()=>{const nt='ai-bt-generated',at='ai-bt-chat-translation',z='ai-bt-root',ut='ai-bt-custom-bg',te='ai-bt-custom-bg-layer',C='chat';let w=C,J=1;const Nt=new WeakMap(),ee=new WeakMap();const mt=()=>true,dt=()=>true,Yn=()=>false,Ht=()=>({}),sn=()=>document,le=()=>{},ia=()=>{};let fail=false,calls=0;const zt=async(s,e,n,a,o)=>{calls++;if(fail){o.onError('fixture network unavailable');return ''}return '译文：'+s};${functions};return {rn,yo,fail:v=>fail=v,calls:()=>calls}})();void 0;`);
 assert.equal(await run('testChat.rn().length'),2,'form/repeated IDs omitted messages');
 await run('Promise.all(testChat.rn().map(n=>testChat.yo(n,1)))');
 assert.equal(await run('document.querySelectorAll(".ai-bt-chat-translation-text").length'),2);
 await run(`messageParent.insertAdjacentHTML('beforeend','<div id="inMessage"><div id="msg" data-kt-element="message-text">New incoming message</div></div>');testChat.fail(true);testChat.yo(testChat.rn()[2],1)`);
 assert.ok((await run('testChat.rn()[2].querySelector(".ai-bt-retranslate-status").textContent')).includes('fixture network unavailable'));
 await run('testChat.fail(false);document.querySelector(".ai-bt-retranslate-status button").click()');
 await new Promise(r=>setTimeout(r,100));
 assert.equal(await run('document.querySelectorAll(".ai-bt-chat-translation-text").length'),3);
 // Exercise actual formatter on pointerdown and Enter, then Chromium's own click.
 const format=['V','X','ce'].map(n=>declaration(reply,n)).join('\n');
 await run(`(()=>{const Ae='fixture-enabled',w=()=>document.querySelector('#sendMessageText'),K=e=>e.value,se=s=>s.replace(/\\s+/g,' ').trim();${format};document.addEventListener('pointerdown',e=>{if(e.target.id==='send')V()},true);document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.id==='sendMessageText')V()},true)})();sendMessageText.focus();`);
 const rect=await run('(()=>{const r=send.getBoundingClientRect();return {x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)}})()');
 win.webContents.sendInputEvent({type:'mouseMove',...rect});win.webContents.sendInputEvent({type:'mouseDown',button:'left',clickCount:1,...rect});
 await new Promise(r=>setTimeout(r,100)); // flush rAF between pointerdown and click
 win.webContents.sendInputEvent({type:'mouseUp',button:'left',clickCount:1,...rect});
 await new Promise(r=>setTimeout(r,150));
 assert.deepEqual(await run('window.sent'),['hello there'],'formatter interfered with native click');
 await run('sendMessageText.value="next\\n\\nmessage";sendMessageText.focus()');
 win.webContents.sendInputEvent({type:'keyDown',keyCode:'Return'});win.webContents.sendInputEvent({type:'keyUp',keyCode:'Return'});
 await new Promise(r=>setTimeout(r,150));
 assert.deepEqual(await run('window.sent'),['hello there','next message'],'formatter interfered with Enter or sent duplicate');
 console.log('PASS: Chromium Xhsim fixture translates repeated-ID bubbles inside form; new message error visible and manual retry recovers; real mouse click and Enter send once with normalized text on '+process.platform);
 win.destroy();await new Promise(r=>server.close(r));app.exit(0);
}).catch(e=>{console.error(e);win?.destroy();server?.close();app.exit(1)});
