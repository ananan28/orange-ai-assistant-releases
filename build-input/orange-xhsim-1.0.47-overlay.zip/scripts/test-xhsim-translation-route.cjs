'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const src=fs.readFileSync('extension-source/content.js','utf8');
const start=src.indexOf('  async function zt('),end=src.indexOf('  async function ',start+5);
const fn=src.slice(start,end);
(async()=>{
 let desktop=0,extension=0,failure='';
 const c={location:{hostname:'client.xhsim.ai'},E:s=>s.trim(),mt:()=>true,dt:()=>true,Y:new Map(),za:async()=>'',Zn:async()=>{},Jn:()=>true,Gn:async()=>{desktop++;return {ok:true,translated:'你好'}},chrome:{runtime:{sendMessage:async()=>{extension++;throw Error('extension unavailable')}}},console};
 vm.createContext(c);vm.runInContext(fn,c);
 assert.equal(await c.zt('Hello'),'你好');assert.equal(desktop,1);assert.equal(extension,0);
 c.Y.clear();c.Gn=async()=>({ok:false,message:'desktop offline'});c.chrome.runtime.sendMessage=async()=>{extension++;return {ok:false,error:'translation route offline'}};
 assert.equal(await c.zt('New text','en','zh-CN','chat_translate',{onError:s=>failure=s}),'');assert.equal(failure,'translation route offline');assert.equal(extension,1);
 console.log('PASS: Xhsim uses desktop translation bridge before extension; dual-route failure reports an actionable reason.');
})().catch(e=>{console.error(e);process.exitCode=1});
