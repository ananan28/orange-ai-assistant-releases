-- Orange AI Assistant 0.8.4: private chat images/files.
-- Run once in the existing formal Supabase project's SQL Editor.

alter table public.internal_messages
  add column if not exists message_type text not null default 'text',
  add column if not exists attachment_path text null,
  add column if not exists attachment_name text null,
  add column if not exists attachment_mime text null,
  add column if not exists attachment_size bigint null;

do $$
declare item record;
begin
  for item in
    select conname from pg_constraint
    where conrelid = 'public.internal_messages'::regclass
      and contype = 'c' and pg_get_constraintdef(oid) ilike '%char_length(body)%'
  loop
    execute format('alter table public.internal_messages drop constraint %I', item.conname);
  end loop;
end $$;

alter table public.internal_messages alter column body set default '';
alter table public.internal_messages drop constraint if exists internal_messages_type_check;
alter table public.internal_messages add constraint internal_messages_type_check
  check (message_type in ('text', 'image', 'file'));
alter table public.internal_messages drop constraint if exists internal_messages_payload_check;
alter table public.internal_messages add constraint internal_messages_payload_check check (
  (message_type = 'text' and char_length(body) between 1 and 4000 and attachment_path is null)
  or
  (message_type in ('image', 'file') and char_length(body) between 0 and 4000
    and attachment_path is not null and attachment_name is not null
    and attachment_size between 1 and 20971520)
);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('internal-message-attachments','internal-message-attachments',false,20971520,array[
  'image/png','image/jpeg','image/webp','image/gif','application/pdf','text/plain','text/csv',
  'application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/zip','application/x-zip-compressed','application/x-7z-compressed','application/vnd.rar','application/x-rar-compressed','application/octet-stream'
]::text[])
on conflict (id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists internal_attachment_participant_read on storage.objects;
create policy internal_attachment_participant_read on storage.objects for select to authenticated
using (bucket_id='internal-message-attachments' and ((storage.foldername(name))[1]=auth.uid()::text or (storage.foldername(name))[2]=auth.uid()::text));

drop policy if exists internal_attachment_sender_insert on storage.objects;
create policy internal_attachment_sender_insert on storage.objects for insert to authenticated
with check (bucket_id='internal-message-attachments' and (storage.foldername(name))[1]=auth.uid()::text and exists (
  select 1 from public.profiles p where p.id::text=(storage.foldername(name))[2] and p.id<>auth.uid() and coalesce(p.account_status,'active')='active'
));

drop policy if exists internal_attachment_sender_delete on storage.objects;
create policy internal_attachment_sender_delete on storage.objects for delete to authenticated
using (bucket_id='internal-message-attachments' and (storage.foldername(name))[1]=auth.uid()::text);
