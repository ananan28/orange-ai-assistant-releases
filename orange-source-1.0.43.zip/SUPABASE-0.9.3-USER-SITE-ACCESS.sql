-- Orange AI Assistant 0.9.3
-- Per-user website visibility. Safe to run more than once.

create table if not exists public.user_site_access (
  user_id uuid not null references auth.users(id) on delete cascade,
  site_id uuid not null references public.work_sites(id) on delete cascade,
  allowed boolean not null default true,
  updated_at timestamptz not null default now(),
  updated_by uuid null references auth.users(id) on delete set null,
  primary key (user_id, site_id)
);

create index if not exists user_site_access_site_idx
  on public.user_site_access (site_id, user_id);

alter table public.user_site_access enable row level security;

revoke all on table public.user_site_access from anon;
revoke all on table public.user_site_access from authenticated;
grant select on table public.user_site_access to authenticated;
grant all on table public.user_site_access to service_role;

drop policy if exists "user_site_access_select_own" on public.user_site_access;
create policy "user_site_access_select_own"
  on public.user_site_access
  for select
  to authenticated
  using ((select auth.uid()) = user_id);

comment on table public.user_site_access is
  'Explicit website visibility per employee. No rows means legacy membership defaults; once rows exist, missing or false sites are hidden.';
