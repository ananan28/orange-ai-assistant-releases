"use strict";
const TN_DOM_SELECTORS = Object.freeze({
  newTextButton: "button#newText",
  newConversationForm: "#newConversationForm",
  recipientInput: "input#newConversationTextField",
  recipientBadge: "#recipientsView li.tn-badge",
  recipientNumber: "#recipientsView li.tn-badge span.text-body-sm",
  recipientRemove: "#recipientsView li.tn-badge span.remove",
  messageInput: "textarea#text-input",
  sendButton: "#send_button",
  messageView: "#messageView",
  outgoingMessage: "#messageView li.chat-item.outgoing .tn-chat-bubble-text",
});
function normalizeTnPhone(t) {
  const e = String(t || "").replace(/\D/g, "");
  return e.length === 11 && e.startsWith("1") ? e.slice(1) : e;
}
function inspectTnDocument(t) {
  const e = {};
  for (const [i, s] of Object.entries(TN_DOM_SELECTORS)) e[i] = !!t.querySelector(s);
  const o = t.querySelector(TN_DOM_SELECTORS.recipientNumber)?.textContent || "",
    n = t.querySelector(TN_DOM_SELECTORS.sendButton);
  return {
    ok: ["newTextButton", "messageInput", "sendButton", "messageView"].every((i) => e[i]),
    found: e,
    selectedRecipient: normalizeTnPhone(o),
    sendButtonVisible: !!(n && getComputedStyle(n).display !== "none" && n.getClientRects().length),
    pageVersion: t.querySelector('meta[name="TN-WEB-VERSION"]')?.content || "",
  };
}
module.exports = { TN_DOM_SELECTORS, normalizeTnPhone, inspectTnDocument };
