-- 1.0.2 网站可选择独立TN IP池。
-- work_sites.proxy_mode为text字段；清理可能由旧版本添加的限制，并建立新限制。
alter table public.work_sites drop constraint if exists work_sites_proxy_mode_check;
alter table public.work_sites add constraint work_sites_proxy_mode_check
  check (proxy_mode in ('direct','automatic','tn_pool','fixed'));

comment on column public.work_sites.proxy_mode is
  'direct=本机；automatic=翻译/网站池；tn_pool=仅TN池；fixed=固定单IP';

alter table public.work_sites
  add column if not exists chat_container_selector text,
  add column if not exists message_selector text,
  add column if not exists input_selector text,
  add column if not exists phone_selector text;

comment on column public.work_sites.chat_container_selector is '特殊网站的对话区域CSS选择器';
comment on column public.work_sites.message_selector is '特殊网站的消息气泡CSS选择器';
comment on column public.work_sites.input_selector is '特殊网站的聊天输入框CSS选择器';
comment on column public.work_sites.phone_selector is '特殊网站的客户号码CSS选择器';
