-- Orange AI Assistant 0.8.2 non-destructive work_sites upgrade.
-- Run once in the existing Supabase project's SQL Editor.
-- This does not delete or replace existing websites, users, permissions or proxies.

alter table public.work_sites
  add column if not exists proxy_mode text not null default 'direct';

alter table public.work_sites
  add column if not exists fixed_proxy_id uuid null
  references public.translation_proxy_pool(id)
  on delete set null;

update public.work_sites
set proxy_mode = case
  when coalesce(proxy_required, false) then 'automatic'
  else 'direct'
end
where proxy_mode is null or proxy_mode = '';

notify pgrst, 'reload schema';
