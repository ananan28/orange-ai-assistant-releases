# 橘子AI助手 1.0.3

- 新增独立的 TN IP 池管理页，TN 默认使用 SOCKS5，并与翻译/网站池隔离。
- 网站可选择本机直连、翻译/网站池轮换、仅 TN 池轮换或固定 IP。
- 新网站先使用通用规则自动识别；特殊结构可由管理员一次配置对话区、消息、输入框和号码选择器，全员同步。
- 扩展 OpenAI、Groq、Gemini、DeepSeek、xAI、Mistral、OpenRouter、Together、Azure OpenAI 等服务商和模型预设。
- 保留 Anthropic 接入位；当前 Claude 可通过 OpenRouter 使用。
- 修复 AI 重新翻译无反馈，失败时在消息旁显示明确原因。
- 延续每条双方消息的复制/重新翻译、五天翻译缓存、异常换行清理、登录账号选择和平台文字标签等修复。

Supabase 已更新 `work_sites` 适配字段和 `tn_pool` 模式；`admin-users` 与 `proxy-control` 函数已同步发布。
