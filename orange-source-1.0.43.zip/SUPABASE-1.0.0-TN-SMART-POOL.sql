-- Orange AI Assistant 1.0.0: TN account-level fixed proxy allocation.
-- Safe to run repeatedly.

alter table public.translation_proxy_pool
  add column if not exists pool_kind text not null default 'translation',
  add column if not exists tn_capacity integer;

alter table public.translation_proxy_pool drop constraint if exists translation_proxy_pool_pool_kind_check;
alter table public.translation_proxy_pool add constraint translation_proxy_pool_pool_kind_check
  check (pool_kind in ('translation','tn','shared'));
alter table public.translation_proxy_pool drop constraint if exists translation_proxy_pool_tn_capacity_check;
alter table public.translation_proxy_pool add constraint translation_proxy_pool_tn_capacity_check
  check (tn_capacity is null or tn_capacity >= 1);

update public.translation_proxy_pool p set pool_kind='shared', tn_capacity=coalesce(p.tn_capacity,30)
where exists (select 1 from public.tn_proxy_groups g where g.proxy_id=p.id);

create table if not exists public.tn_account_proxy_bindings (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  account_local_id uuid not null,
  account_label text not null default '',
  proxy_id uuid not null references public.translation_proxy_pool(id) on delete restrict,
  group_id uuid references public.tn_proxy_groups(id) on delete set null,
  locked boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(owner_user_id,account_local_id)
);
create index if not exists tn_account_proxy_bindings_proxy_idx on public.tn_account_proxy_bindings(proxy_id);
alter table public.tn_account_proxy_bindings enable row level security;
revoke all on public.tn_account_proxy_bindings from anon, authenticated;

create or replace function public.allocate_tn_proxy(
  p_user_id uuid,
  p_account_local_id uuid,
  p_account_label text default ''
) returns table(proxy_id uuid, group_id uuid, group_name text, tn_capacity integer, used_accounts bigint)
language plpgsql security definer
set search_path = public, pg_temp
as $$
declare chosen record;
begin
  if p_user_id is null or p_account_local_id is null then raise exception 'missing TN allocation identity'; end if;
  perform pg_advisory_xact_lock(hashtext('orange-tn-proxy-allocation'));
  return query
    select b.proxy_id,b.group_id,g.group_name,p.tn_capacity,
      (select count(*) from public.tn_account_proxy_bindings x where x.proxy_id=b.proxy_id)
    from public.tn_account_proxy_bindings b
    left join public.tn_proxy_groups g on g.id=b.group_id
    join public.translation_proxy_pool p on p.id=b.proxy_id
    where b.owner_user_id=p_user_id and b.account_local_id=p_account_local_id;
  if found then return; end if;

  select g.id as group_id,g.group_name,g.proxy_id,p.tn_capacity into chosen
  from public.tn_proxy_groups g
  join public.translation_proxy_pool p on p.id=g.proxy_id
  where g.owner_user_id=p_user_id and p.enabled=true and p.pool_kind in ('tn','shared')
    and (p.tn_capacity is null or (select count(*) from public.tn_account_proxy_bindings x where x.proxy_id=p.id) < p.tn_capacity)
    and (g.max_accounts is null or (select count(*) from public.tn_account_proxy_bindings x where x.group_id=g.id) < g.max_accounts)
  order by (select count(*) from public.tn_account_proxy_bindings x where x.proxy_id=p.id) desc, g.created_at
  limit 1;
  if chosen.proxy_id is null then raise exception 'TN IP池容量不足或没有为该员工开放IP'; end if;
  insert into public.tn_account_proxy_bindings(owner_user_id,account_local_id,account_label,proxy_id,group_id)
  values(p_user_id,p_account_local_id,left(coalesce(p_account_label,''),120),chosen.proxy_id,chosen.group_id);
  return query select chosen.proxy_id,chosen.group_id,chosen.group_name,chosen.tn_capacity,
    (select count(*) from public.tn_account_proxy_bindings x where x.proxy_id=chosen.proxy_id);
end $$;

revoke all on function public.allocate_tn_proxy(uuid,uuid,text) from public, anon, authenticated;
grant execute on function public.allocate_tn_proxy(uuid,uuid,text) to service_role;

create or replace function public.release_tn_proxy(p_user_id uuid,p_account_local_id uuid)
returns integer language sql security definer set search_path=public,pg_temp as $$
  with removed as (delete from public.tn_account_proxy_bindings where owner_user_id=p_user_id and account_local_id=p_account_local_id returning 1)
  select count(*)::integer from removed;
$$;
revoke all on function public.release_tn_proxy(uuid,uuid) from public, anon, authenticated;
grant execute on function public.release_tn_proxy(uuid,uuid) to service_role;
