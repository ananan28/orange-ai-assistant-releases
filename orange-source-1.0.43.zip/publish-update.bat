@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo   Orange AI Assistant - Publish Update
echo ========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js is not installed.
  pause
  exit /b 1
)

where gh >nul 2>nul
if errorlevel 1 (
  echo [ERROR] GitHub CLI is not installed.
  echo Install it once from: https://cli.github.com/
  echo Then run: gh auth login
  pause
  exit /b 1
)

for /f "delims=" %%v in ('node -p "require('./package.json').version"') do set "APP_VERSION=%%v"
set "RELEASE_TAG=v%APP_VERSION%"
set "SETUP_FILE=dist\Orange-AI-Assistant-Setup-%APP_VERSION%.exe"
set "BLOCKMAP_FILE=%SETUP_FILE%.blockmap"
set "LATEST_FILE=dist\latest.yml"
set "RELEASE_REPO=ananan28/orange-ai-assistant-releases"

set "ELECTRON_BUILDER_CACHE=%~dp0offline-cache\electron-builder"

echo [1/5] Installing dependencies...
call npm ci
if errorlevel 1 goto :failed

echo [2/5] Checking source code...
call npm run check
if errorlevel 1 goto :failed

echo [3/5] Building protected installer...
call npm run dist:win
if errorlevel 1 (
  echo [WARN] Official download source failed. Retrying with the fallback mirror...
  set "ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/"
  set "ELECTRON_BUILDER_BINARIES_MIRROR=https://npmmirror.com/mirrors/electron-builder-binaries/"
  call npm run dist:win
)
if errorlevel 1 goto :build_network_failed

echo Generating update metadata from package version and final installer...
call node scripts\generate-update-files.js
if errorlevel 1 goto :failed

if not exist "%SETUP_FILE%" goto :missing
if not exist "%BLOCKMAP_FILE%" goto :missing
if not exist "%LATEST_FILE%" goto :missing

echo [4/5] Publishing %RELEASE_TAG%...
gh release view "%RELEASE_TAG%" --repo "%RELEASE_REPO%" >nul 2>nul
if errorlevel 1 (
  gh release create "%RELEASE_TAG%" "%SETUP_FILE%" "%BLOCKMAP_FILE%" "%LATEST_FILE%" --repo "%RELEASE_REPO%" --title "Orange AI Assistant %APP_VERSION%" --notes "正式版自动更新 %APP_VERSION%"
) else (
  gh release upload "%RELEASE_TAG%" "%SETUP_FILE%" "%BLOCKMAP_FILE%" "%LATEST_FILE%" --repo "%RELEASE_REPO%" --clobber
)
if errorlevel 1 goto :failed

echo [5/5] Verifying automatic-update files...
set "ASSET_LIST=%TEMP%\orange-ai-release-assets-%APP_VERSION%.txt"
set "REMOTE_LATEST=%TEMP%\orange-ai-latest-%APP_VERSION%.yml"
if exist "%REMOTE_LATEST%" del /q "%REMOTE_LATEST%"
gh release view "%RELEASE_TAG%" --repo "%RELEASE_REPO%" --json assets --jq ".assets[].name" > "%ASSET_LIST%"
if errorlevel 1 goto :failed
findstr /x /c:"Orange-AI-Assistant-Setup-%APP_VERSION%.exe" "%ASSET_LIST%" >nul || goto :publish_missing
findstr /x /c:"Orange-AI-Assistant-Setup-%APP_VERSION%.exe.blockmap" "%ASSET_LIST%" >nul || goto :publish_missing
findstr /x /c:"latest.yml" "%ASSET_LIST%" >nul || goto :publish_missing
gh release download "%RELEASE_TAG%" --repo "%RELEASE_REPO%" --pattern "latest.yml" --output "%REMOTE_LATEST%" --clobber
if errorlevel 1 goto :publish_missing
findstr /x /c:"version: %APP_VERSION%" "%REMOTE_LATEST%" >nul || goto :publish_invalid
findstr /c:"url: Orange-AI-Assistant-Setup-%APP_VERSION%.exe" "%REMOTE_LATEST%" >nul || goto :publish_invalid

echo.
echo [SUCCESS] Update %APP_VERSION% is published.
echo Employees will receive it automatically.
pause
exit /b 0

:missing
echo [ERROR] Update files are missing from dist.
pause
exit /b 1

:publish_missing
echo [ERROR] GitHub release is missing EXE, blockmap, or latest.yml.
echo Employees will not be able to update until all three files are uploaded.
pause
exit /b 1

:publish_invalid
echo [ERROR] GitHub latest.yml does not match version %APP_VERSION% or its installer.
echo Automatic update would fail, so this release was not reported as successful.
pause
exit /b 1

:build_network_failed
echo [ERROR] Both official and fallback download sources failed.
echo This is a network download failure, not a source-code check failure.
echo Keep any completed files in dist and retry this script after the network recovers.
echo Manual release page: https://github.com/ananan28/orange-ai-assistant-releases/releases/new?tag=%RELEASE_TAG%
pause
exit /b 1

:failed
echo [FAILED] Publish did not finish. Keep this window open and send a screenshot.
echo Manual release page: https://github.com/ananan28/orange-ai-assistant-releases/releases/new?tag=%RELEASE_TAG%
pause
exit /b 1
