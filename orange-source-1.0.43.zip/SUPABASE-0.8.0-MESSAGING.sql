-- Orange AI Assistant 0.8.0: announcements, private messaging and TN count-only reporting.
-- Run once in the existing formal Supabase project's SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.app_announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  body text not null check (char_length(body) between 1 and 5000),
  target_user_id uuid null references public.profiles(id) on delete cascade,
  pinned boolean not null default false,
  published_at timestamptz not null default now(),
  expires_at timestamptz null,
  created_by uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.app_announcement_reads (
  announcement_id uuid not null references public.app_announcements(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key (announcement_id, user_id)
);

create table if not exists public.internal_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now(),
  read_at timestamptz null,
  sender_hidden_at timestamptz null,
  recipient_hidden_at timestamptz null,
  check (sender_id <> recipient_id)
);

-- Privacy boundary: the server stores only a number. TN names, cookies,
-- partitions, IP credentials and login state never enter this table.
create table if not exists public.employee_tn_account_counts (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  account_count integer not null default 0 check (account_count between 0 and 1000),
  updated_at timestamptz not null default now()
);

create index if not exists internal_messages_sender_created_idx on public.internal_messages(sender_id, created_at desc);
create index if not exists internal_messages_recipient_created_idx on public.internal_messages(recipient_id, created_at desc);
create index if not exists announcements_published_idx on public.app_announcements(pinned desc, published_at desc);

alter table public.app_announcements enable row level security;
alter table public.app_announcement_reads enable row level security;
alter table public.internal_messages enable row level security;
alter table public.employee_tn_account_counts enable row level security;

drop policy if exists announcement_read_visible on public.app_announcements;
create policy announcement_read_visible on public.app_announcements for select to authenticated
using (
  (
    target_user_id is null
    or target_user_id = auth.uid()
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  )
  and (expires_at is null or expires_at > now())
);

drop policy if exists announcement_admin_insert on public.app_announcements;
create policy announcement_admin_insert on public.app_announcements for insert to authenticated
with check (
  created_by = auth.uid()
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);

drop policy if exists announcement_admin_update on public.app_announcements;
create policy announcement_admin_update on public.app_announcements for update to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

drop policy if exists announcement_admin_delete on public.app_announcements;
create policy announcement_admin_delete on public.app_announcements for delete to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

drop policy if exists announcement_reads_own_select on public.app_announcement_reads;
create policy announcement_reads_own_select on public.app_announcement_reads for select to authenticated
using (
  user_id = auth.uid()
  or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);

drop policy if exists announcement_reads_own_insert on public.app_announcement_reads;
create policy announcement_reads_own_insert on public.app_announcement_reads for insert to authenticated
with check (
  user_id = auth.uid()
  and exists (
    select 1 from public.app_announcements a
    where a.id = announcement_id
      and (a.target_user_id is null or a.target_user_id = auth.uid())
      and (a.expires_at is null or a.expires_at > now())
  )
);

drop policy if exists internal_messages_participant_select on public.internal_messages;
create policy internal_messages_participant_select on public.internal_messages for select to authenticated
using (
  (sender_id = auth.uid() and sender_hidden_at is null)
  or (recipient_id = auth.uid() and recipient_hidden_at is null)
);

drop policy if exists internal_messages_sender_insert on public.internal_messages;
create policy internal_messages_sender_insert on public.internal_messages for insert to authenticated
with check (
  sender_id = auth.uid()
  and recipient_id <> auth.uid()
  and exists (
    select 1 from public.profiles p
    where p.id = recipient_id and coalesce(p.account_status, 'active') = 'active'
  )
);

revoke all on public.app_announcements, public.app_announcement_reads, public.internal_messages from anon;
revoke all on public.employee_tn_account_counts from anon, authenticated;
grant select, insert, update, delete on public.app_announcements to authenticated;
grant select, insert on public.app_announcement_reads to authenticated;
grant select, insert on public.internal_messages to authenticated;

create or replace function public.set_my_tn_account_count(new_count integer)
returns void language plpgsql security definer set search_path = public
as $$
begin
  if auth.uid() is null then raise exception '请先登录'; end if;
  if new_count < 0 or new_count > 1000 then raise exception 'TN账号数量超出范围'; end if;
  insert into public.employee_tn_account_counts(user_id, account_count, updated_at)
  values (auth.uid(), new_count, now())
  on conflict (user_id) do update
    set account_count = excluded.account_count, updated_at = excluded.updated_at;
end;
$$;

create or replace function public.list_tn_account_counts()
returns table(user_id uuid, account_count integer, updated_at timestamptz)
language plpgsql security definer set search_path = public
as $$
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin') then
    raise exception '仅管理员可查看TN账号数量';
  end if;
  return query
    select c.user_id, c.account_count, c.updated_at
    from public.employee_tn_account_counts c
    order by c.updated_at desc;
end;
$$;

create or replace function public.list_internal_contacts()
returns table(id uuid, username text, display_name text, role text)
language sql security definer set search_path = public
as $$
  select p.id, p.username, p.display_name, p.role
  from public.profiles p
  where p.id <> auth.uid()
    and coalesce(p.account_status, 'active') = 'active'
  order by coalesce(nullif(p.display_name, ''), p.username), p.username;
$$;

create or replace function public.mark_internal_conversation_read(peer_id uuid)
returns integer language plpgsql security definer set search_path = public
as $$
declare changed integer;
begin
  update public.internal_messages
  set read_at = coalesce(read_at, now())
  where sender_id = peer_id and recipient_id = auth.uid() and read_at is null;
  get diagnostics changed = row_count;
  return changed;
end;
$$;

create or replace function public.clear_internal_conversation(peer_id uuid)
returns integer language plpgsql security definer set search_path = public
as $$
declare changed integer;
begin
  update public.internal_messages
  set sender_hidden_at = case when sender_id = auth.uid() then now() else sender_hidden_at end,
      recipient_hidden_at = case when recipient_id = auth.uid() then now() else recipient_hidden_at end
  where (sender_id = auth.uid() and recipient_id = peer_id)
     or (sender_id = peer_id and recipient_id = auth.uid());
  get diagnostics changed = row_count;
  return changed;
end;
$$;

create or replace function public.clear_all_internal_messages()
returns integer language plpgsql security definer set search_path = public
as $$
declare changed integer;
begin
  update public.internal_messages
  set sender_hidden_at = case when sender_id = auth.uid() then now() else sender_hidden_at end,
      recipient_hidden_at = case when recipient_id = auth.uid() then now() else recipient_hidden_at end
  where sender_id = auth.uid() or recipient_id = auth.uid();
  get diagnostics changed = row_count;
  return changed;
end;
$$;

grant execute on function public.list_internal_contacts() to authenticated;
grant execute on function public.mark_internal_conversation_read(uuid) to authenticated;
grant execute on function public.clear_internal_conversation(uuid) to authenticated;
grant execute on function public.clear_all_internal_messages() to authenticated;
revoke execute on function public.set_my_tn_account_count(integer) from public, anon;
revoke execute on function public.list_tn_account_counts() from public, anon;
grant execute on function public.set_my_tn_account_count(integer) to authenticated;
grant execute on function public.list_tn_account_counts() to authenticated;

do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'internal_messages') then
    alter publication supabase_realtime add table public.internal_messages;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'app_announcements') then
    alter publication supabase_realtime add table public.app_announcements;
  end if;
end $$;
