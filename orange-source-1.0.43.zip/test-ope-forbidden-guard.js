"use strict";

require("./extension-source/ope_forbidden_guard.js");
const guard = globalThis.ORANGE_OPE_FORBIDDEN_GUARD;

if (!guard) throw new Error("OPE guard API was not initialized");

const requiredTerms = [
  "HI", "Hi", "hi", "hi！", "hi,", "hi.", "hello", "Hello", "HELL0", "hello!", "hello,", "hello.",
  "hey", "Hey", "How about you？", "how are you", "Oh", "How old are you？", "foot", "Contacts",
  "Are you okay", "management", "How about", "How are", "Long time no see", "Long time", "work",
  "WORK", "W0RK", "working", "job", "JOB", "jobs", "J0B", "Email", "office", "coffee", "usa",
  "USA", "America", "United States", "company", "country", "phone", "NUMBER", "remember", "Howdy",
  "What's your name", "Do you remember it now？", "Whatsapp", "號碼", "電話", "号码", "通讯录"
];

let failures = 0;
for (const text of requiredTerms) {
  const issues = guard.detect(text);
  if (!issues.length) {
    failures += 1;
    console.error(`NOT DETECTED: ${text}`);
  }
}

const specialCases = [
  ["Visit https://example.com", "url"],
  ["你好，很高兴认识你", "chinese"],
  ["x".repeat(301), "length"],
  ["I traveled from Canada to France.", "country"],
  ["I can show you an extra income opportunity in cryptocurrency.", "phrase"]
];
for (const [text, expectedCode] of specialCases) {
  const issues = guard.detect(text);
  if (!issues.some(issue => issue.code === expectedCode)) {
    failures += 1;
    console.error(`MISSING ${expectedCode}: ${text}`);
  }
}

const allowed = [
  "It was nice seeing you at the gallery yesterday.",
  "The dinner was wonderful, and I enjoyed our conversation."
];
for (const text of allowed) {
  const issues = guard.detect(text);
  if (issues.length) {
    failures += 1;
    console.error(`FALSE POSITIVE: ${text}`, issues);
  }
}

if (guard.detect("hello work", { includeForbiddenWords:false }).length) {
  failures += 1;
  console.error("Forbidden-word switch off still reported a word");
}
if (!guard.detect("x".repeat(301), { includeForbiddenWords:false }).some(issue => issue.code === "length")) {
  failures += 1;
  console.error("300-character limit was incorrectly disabled with the forbidden-word switch");
}
if (guard.detect("x".repeat(300)).some(issue => issue.code === "length")) {
  failures += 1;
  console.error("Exactly 300 characters should be allowed");
}

if (failures) process.exit(1);
console.log(`OPE forbidden-word guard passed ${requiredTerms.length + specialCases.length + allowed.length} cases.`);
