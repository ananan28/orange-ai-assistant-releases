// Supabase Edge Function: admin-users
// Only signed-in users whose public.profiles.role is "admin" may use it.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { withSupabase } from "jsr:@supabase/server@^1";

type Plan = "basic" | "advanced";
type AccountRole = "user" | "admin";
type AccountStatus = "active" | "paused" | "disabled" | "expired";
type ProxyProtocol = "http" | "https" | "socks5";

interface RequestPayload {
  action:
    | "list_users"
    | "create_user"
    | "update_user"
    | "delete_user"
    | "renew_user"
    | "reset_password"
    | "list_devices"
    | "revoke_device"
    | "force_logout"
    | "restore_access"
    | "block_client_ip"
    | "unblock_client_ip"
    | "list_sites"
    | "save_site"
    | "delete_site"
    | "list_user_site_access"
    | "save_user_site_access"
    | "list_permissions"
    | "save_permission"
    | "list_feature_flags"
    | "save_feature_flag"
    | "list_proxy_pool"
    | "list_proxy_logs"
    | "import_proxies"
    | "toggle_proxy"
    | "delete_proxy"
    | "delete_failed_proxies"
    | "get_proxy_secret"
    | "set_proxy_health"
    | "save_proxy_assignment"
    | "repair_proxy_assignments"
    | "delete_proxy_assignment"
    | "save_proxy_settings"
    | "list_tn_groups"
    | "save_tn_group"
    | "delete_tn_group"
    | "get_membership_settings"
    | "save_membership_settings";
  userId?: string;
  deviceId?: string;
  username?: string;
  password?: string;
  displayName?: string;
  role?: AccountRole;
  plan?: Plan;
  accountStatus?: AccountStatus;
  validUntil?: string | null;
  validDays?: number;
  dailyStart?: string | null;
  dailyEnd?: string | null;
  accessTimezone?: string;
  deviceLimit?: number;
  siteId?: string;
  siteKey?: string;
  siteName?: string;
  siteUrl?: string;
  siteIconUrl?: string;
  siteProxyRequired?: boolean;
  siteProxyMode?: "direct" | "automatic" | "tn_pool" | "fixed";
  siteFixedProxyId?: string | null;
  siteEnabled?: boolean;
  sortOrder?: number;
  minimumPlan?: Plan;
  siteAccess?: Array<{ siteId?: string; allowed?: boolean }>;
  featureCode?: string;
  featureKey?: string;
  enabled?: boolean;
  proxyId?: string;
  forceUnbind?: boolean;
  proxyProtocol?: ProxyProtocol;
  proxyPoolKind?: "translation" | "tn" | "shared";
  tnCapacity?: number | null;
  proxyLabel?: string;
  importText?: string;
  assignmentMode?: "automatic" | "fixed";
  allowedByAdmin?: boolean;
  healthy?: boolean;
  latencyMs?: number;
  exitIp?: string;
  errorMessage?: string;
  failureThreshold?: number;
  healthCheckIntervalMinutes?: number;
  groupId?: string;
  groupUserId?: string;
  groupName?: string;
  groupProxyId?: string;
  maxAccounts?: number | null;
  clientIp?: string;
  reason?: string;
  basicGraceDays?: number;
}

const INTERNAL_EMAIL_DOMAIN = "orange.internal";
const USERNAME_PATTERN = /^[\p{L}\p{N}][\p{L}\p{N}_.-]{1,31}$/u;
const TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/;

function fail(message: string, status = 400) {
  return Response.json({ ok: false, message }, { status });
}

async function membershipGraceDays(admin:any) {
  const { data, error } = await admin.from("membership_settings").select("basic_grace_days").eq("singleton", true).maybeSingle();
  if (error && String(error.code || "") !== "42P01") throw error;
  return Math.max(1, Math.min(365, Number(data?.basic_grace_days || 30)));
}

function readableServerError(value: unknown) {
  if (value instanceof Error && value.message) return value.message;
  if (typeof value === "string" && value.trim()) return value.trim();
  if (value && typeof value === "object") {
    const row = value as Record<string, unknown>;
    const code = typeof row.code === "string" ? row.code : "";
    if (code === "23505") return "同一账号已存在同名固定IP分组；请直接更新原分组或更换名称";
    if (code === "23503") return "数据库关联约束阻止了本次操作；请刷新后确认关联数据。若正在删除员工，请确认0.9.2数据库升级已执行后再重试";
    if (code === "42P01") return "正式数据库尚未建立TN固定IP分组表，请先运行0.7.0正式升级SQL";
    if (code === "42703") return "TN固定IP分组表版本不匹配，请运行0.7.0正式升级SQL";
    const parts = [row.message, row.details, row.hint, row.error, code]
      .filter(item => typeof item === "string" && item.trim()) as string[];
    if (parts.length) return [...new Set(parts)].join("；");
    try { return JSON.stringify(value); } catch { /* ignore */ }
  }
  return "未知服务器错误";
}

function normalizeUsername(value: unknown) {
  const username = String(value ?? "").trim().normalize("NFKC").toLowerCase();
  if (!USERNAME_PATTERN.test(username)) {
    throw new Error("账号需为2-32位中文、字母或数字，可包含点、横线或下划线");
  }
  return username;
}

function validatePassword(value: unknown) {
  const password = String(value ?? "");
  if (password.length < 6) throw new Error("密码至少需要6位，可使用纯数字");
  return password;
}

async function internalEmailForUsername(username: string) {
  if (/^[a-z0-9][a-z0-9_.-]{2,31}$/.test(username)) return `${username}@${INTERNAL_EMAIL_DOMAIN}`;
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(username));
  // Keep the email prefix within the existing profiles.username 32-char limit.
  const hex = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("").slice(0, 30);
  return `u_${hex}@${INTERNAL_EMAIL_DOMAIN}`;
}

function validatePlan(value: unknown): Plan {
  if (value !== "basic" && value !== "advanced") {
    throw new Error("版本必须是 basic 或 advanced");
  }
  return value;
}

function validateRole(value: unknown): AccountRole {
  if (value !== "user" && value !== "admin") {
    throw new Error("身份必须是 user 或 admin");
  }
  return value;
}

function validateStatus(value: unknown): AccountStatus {
  if (!["active", "paused", "disabled", "expired"].includes(String(value))) {
    throw new Error("账号状态不正确");
  }
  return value as AccountStatus;
}

function validateDeviceLimit(value: unknown) {
  const limit = Number(value);
  if (!Number.isInteger(limit) || limit < 1 || limit > 50) {
    throw new Error("设备数量必须是1到50之间的整数");
  }
  return limit;
}

function validateDate(value: unknown) {
  if (value === null || value === undefined || value === "") return null;
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) throw new Error("到期时间格式不正确");
  return date.toISOString();
}
function validateTime(value: unknown) {
  if (value === null || value === undefined || value === "") return null;
  const time = String(value);
  if (!TIME_PATTERN.test(time)) throw new Error("每日时间格式应为 HH:MM");
  return time;
}
function validateClientIp(value: unknown) {
  const ip = String(value ?? "").trim().toLowerCase();
  if (ip.length < 3 || ip.length > 45 || !/^[0-9a-f:.]+$/.test(ip) || (!ip.includes(".") && !ip.includes(":"))) {
    throw new Error("请输入正确的公网IPv4或IPv6地址");
  }
  return ip;
}

async function listStorageFiles(admin: any, bucket: string, prefix: string): Promise<string[]> {
  const output: string[] = [];
  for (let offset = 0; ; offset += 100) {
    const { data, error } = await admin.storage.from(bucket).list(prefix, { limit:100, offset, sortBy:{ column:"name", order:"asc" } });
    if (error) throw error;
    const items = data || [];
    for (const item of items) {
      const itemPath = prefix ? `${prefix}/${item.name}` : item.name;
      if (item.id) output.push(itemPath);
      else output.push(...await listStorageFiles(admin, bucket, itemPath));
    }
    if (items.length < 100) break;
  }
  return output;
}

async function deleteUserMessageAttachments(admin: any, userId: string) {
  const bucket = "internal-message-attachments";
  const paths = new Set<string>();
  try {
    for (const item of await listStorageFiles(admin, bucket, userId)) paths.add(item);
    const { data: roots, error } = await admin.storage.from(bucket).list("", { limit:1000, offset:0 });
    if (error) throw error;
    for (const root of roots || []) {
      if (root.name === userId) continue;
      for (const item of await listStorageFiles(admin, bucket, `${root.name}/${userId}`)) paths.add(item);
    }
    const all = [...paths];
    for (let index = 0; index < all.length; index += 100) {
      const { error: removeError } = await admin.storage.from(bucket).remove(all.slice(index, index + 100));
      if (removeError) throw removeError;
    }
  } catch (error) {
    if (!/bucket.*not found|not found/i.test(String((error as any)?.message || error))) throw error;
  }
}

function bytesToBase64(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function base64ToBytes(value: string) {
  const binary = atob(value);
  return Uint8Array.from(binary, char => char.charCodeAt(0));
}

async function proxyEncryptionKey() {
  const secret = Deno.env.get("PROXY_POOL_ENCRYPTION_SECRET") || "";
  if (secret.length < 32) throw new Error("PROXY_POOL_ENCRYPTION_SECRET至少需要32个字符");
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return crypto.subtle.importKey("raw", digest, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

async function encryptProxyValue(value: string) {
  if (!value) return { encrypted: "", iv: "" };
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    await proxyEncryptionKey(),
    new TextEncoder().encode(value),
  );
  return { encrypted: bytesToBase64(new Uint8Array(encrypted)), iv: bytesToBase64(iv) };
}

async function decryptProxyValue(value: string, iv: string) {
  if (!value) return "";
  const plain = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: base64ToBytes(iv) },
    await proxyEncryptionKey(),
    base64ToBytes(value),
  );
  return new TextDecoder().decode(plain);
}

async function proxyFingerprint(protocol: string, host: string, port: number, username: string) {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`${protocol}|${host.toLowerCase()}|${port}|${username}`),
  );
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}

function validateProxyProtocol(value: unknown): ProxyProtocol {
  const protocol = String(value || "http").toLowerCase();
  if (!["http", "https", "socks5"].includes(protocol)) throw new Error("代理协议只能是http、https或socks5");
  return protocol as ProxyProtocol;
}

function parseProxyLine(value: string, defaultProtocol: ProxyProtocol) {
  const line = value.trim();
  if (!line || line.startsWith("#")) return null;
  let protocol = defaultProtocol;
  let host = "";
  let port = 0;
  let username = "";
  let password = "";
  if (/^(https?|socks5):\/\//i.test(line)) {
    const parsed = new URL(line);
    protocol = validateProxyProtocol(parsed.protocol.replace(":", ""));
    host = parsed.hostname;
    port = Number(parsed.port);
    username = decodeURIComponent(parsed.username || "");
    password = decodeURIComponent(parsed.password || "");
  } else {
    const parts = line.split(":");
    if (parts.length < 2) throw new Error(`代理格式不正确：${line}`);
    host = parts.shift() || "";
    port = Number(parts.shift());
    username = parts.shift() || "";
    password = parts.join(":");
  }
  host = host.trim().toLowerCase();
  if (!/^[a-z0-9.-]{1,253}$/.test(host) || host.startsWith(".") || host.endsWith(".")) {
    throw new Error(`代理主机不正确：${host}`);
  }
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error(`代理端口不正确：${port}`);
  return { protocol, host, port, username, password };
}

export default {
  fetch: withSupabase({
    auth: "user",
    env: {
      url: Deno.env.get("SUPABASE_URL")!,
      publishableKeys: { default: Deno.env.get("SUPABASE_ANON_KEY")! },
      secretKeys: { default: Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")! },
    },
  }, async (req, ctx) => {
    try {
      const callerId = String(ctx.jwtClaims?.sub ?? ctx.userClaims?.id ?? "");
      if (!callerId) return fail("登录状态无效", 401);
      const admin = ctx.supabaseAdmin;

      // This query uses the caller-scoped client and therefore respects RLS.
      const { data: caller, error: callerError } = await admin
        .from("profiles")
        .select("role,account_status,valid_from,valid_until")
        .eq("id", callerId)
        .single();

      if (callerError || !caller) return fail("无法验证管理员身份", 403);
      if (caller.role !== "admin") return fail("仅管理员可以执行此操作", 403);
      if (caller.account_status !== "active") return fail("管理员账号已停用", 403);

      const now = Date.now();
      if (new Date(caller.valid_from).getTime() > now) {
        return fail("管理员账号尚未生效", 403);
      }
      if (caller.valid_until && new Date(caller.valid_until).getTime() <= now) {
        return fail("管理员账号已到期", 403);
      }

      let body: RequestPayload;
      try {
        body = await req.json();
      } catch {
        return fail("请求内容不是有效JSON");
      }

      switch (body.action) {
        case "list_tn_groups": {
          const [groupResult, profileResult, proxyResult] = await Promise.all([
            admin.from("tn_proxy_groups").select("id,owner_user_id,group_name,proxy_id,max_accounts,created_at,updated_at").order("created_at",{ascending:true}),
            admin.from("profiles").select("id,username,display_name"),
            admin.from("translation_proxy_pool").select("id,label,host,port,enabled,health_status,pool_kind,tn_capacity").in("pool_kind",["tn","shared"]),
          ]);
          if (groupResult.error) throw groupResult.error;
          if (profileResult.error) throw profileResult.error;
          if (proxyResult.error) throw proxyResult.error;
          const users = new Map((profileResult.data || []).map((row:any) => [row.id,row]));
          const proxies = new Map((proxyResult.data || []).map((row:any) => [row.id,row]));
          return Response.json({ok:true,groups:(groupResult.data || []).map((row:any) => {
            const user:any = users.get(row.owner_user_id) || null;
            const proxy:any = proxies.get(row.proxy_id) || null;
            return {...row,username:user?.username || "",display_name:user?.display_name || "",proxy_label:proxy?.label || "",proxy_endpoint:proxy ? `${proxy.host}:${proxy.port}` : "",proxy_enabled:proxy?.enabled === true,health_status:proxy?.health_status || "disabled"};
          })});
        }

        case "save_tn_group": {
          const ownerUserId = String(body.groupUserId || "");
          const groupName = String(body.groupName || "").trim().slice(0,60);
          const proxyId = String(body.groupProxyId || "");
          if (!ownerUserId || !groupName || !proxyId) return fail("请选择账号、填写分组名并选择固定IP");
          const maxAccounts = body.maxAccounts === null || Number(body.maxAccounts) === 0 ? null : Number(body.maxAccounts ?? 30);
          if (maxAccounts !== null && (!Number.isInteger(maxAccounts) || maxAccounts < 1 || maxAccounts > 10000)) return fail("分组容量应为1到10000；0表示无限制");
          const [{data:target,error:targetError},{data:proxy,error:proxyError}] = await Promise.all([
            admin.from("profiles").select("id").eq("id",ownerUserId).maybeSingle(),
            admin.from("translation_proxy_pool").select("id,enabled").eq("id",proxyId).maybeSingle(),
          ]);
          if (targetError || !target) return fail("账号不存在",404);
          if (proxyError || !proxy?.enabled) return fail("固定IP不存在或已停用");
          const values = {owner_user_id:ownerUserId,group_name:groupName,proxy_id:proxyId,max_accounts:maxAccounts,updated_at:new Date().toISOString()};
          // Reusing the default group name should update that employee's group
          // instead of surfacing PostgreSQL's duplicate-key object.
          const query = body.groupId
            ? admin.from("tn_proxy_groups").update(values).eq("id",body.groupId)
            : admin.from("tn_proxy_groups").upsert(values,{onConflict:"owner_user_id,group_name"});
          const {data,error} = await query.select("id,owner_user_id,group_name,proxy_id,max_accounts").single();
          if (error) throw error;
          return Response.json({ok:true,group:data});
        }

        case "delete_tn_group": {
          if (!body.groupId) return fail("缺少groupId");
          const {error} = await admin.from("tn_proxy_groups").delete().eq("id",body.groupId);
          if (error) throw error;
          return Response.json({ok:true});
        }

        case "list_proxy_logs": {
          const [logResult, proxyResult] = await Promise.all([
            admin.from("proxy_activity_logs")
              .select("id,user_id,proxy_id,source,event_type,target,status_code,message,created_at")
              .order("created_at", { ascending:false }).limit(100),
            admin.from("translation_proxy_pool").select("id,label,host,port"),
          ]);
          if (logResult.error) throw logResult.error;
          if (proxyResult.error) throw proxyResult.error;
          const proxyMap = new Map((proxyResult.data || []).map((proxy:any) => [proxy.id, proxy]));
          const logs = (logResult.data || []).map((row:any) => {
            const proxy:any = row.proxy_id ? proxyMap.get(row.proxy_id) : null;
            return { ...row, proxy_label:proxy?.label || "", proxy_endpoint:proxy ? `${proxy.host}:${proxy.port}` : "" };
          });
          return Response.json({ ok:true, logs });
        }

        case "list_proxy_pool": {
          const [proxyResult, assignmentResult, profileResult, settingsResult, tnGroupResult] = await Promise.all([
            admin.from("translation_proxy_pool")
              .select("id,label,protocol,host,port,enabled,health_status,failure_count,last_checked_at,last_used_at,last_error,created_at,pool_kind,tn_capacity")
              .order("created_at", { ascending: true }),
            admin.from("translation_proxy_assignments")
              .select("user_id,proxy_id,assignment_mode,allowed_by_admin,assigned_at,last_failure_at,last_error"),
            admin.from("profiles").select("id,username,display_name,role,account_status").order("username"),
            admin.from("translation_proxy_settings").select("enabled,failure_threshold,health_check_interval_minutes").eq("singleton", true).single(),
            admin.from("tn_proxy_groups").select("id,proxy_id,owner_user_id,group_name"),
          ]);
          if (proxyResult.error) throw proxyResult.error;
          if (assignmentResult.error) throw assignmentResult.error;
          if (profileResult.error) throw profileResult.error;
          if (settingsResult.error) throw settingsResult.error;
          if (tnGroupResult.error) throw tnGroupResult.error;
          const profiles = profileResult.data || [];
          const profileMap = new Map(profiles.map((profile: any) => [profile.id, profile]));
          const assignments = (assignmentResult.data || []).map((assignment: any) => ({
            ...assignment,
            username: profileMap.get(assignment.user_id)?.username || "已删除账号",
            display_name: profileMap.get(assignment.user_id)?.display_name || "",
          }));
          const assignmentCount = new Map<string, number>();
          for (const assignment of assignments) {
            if (assignment.proxy_id) assignmentCount.set(assignment.proxy_id, (assignmentCount.get(assignment.proxy_id) || 0) + 1);
          }
          const tnGroupCount = new Map<string, number>();
          for (const group of tnGroupResult.data || []) {
            if (group.proxy_id) tnGroupCount.set(group.proxy_id, (tnGroupCount.get(group.proxy_id) || 0) + 1);
          }
          const proxies = (proxyResult.data || []).map((proxy: any) => ({
            ...proxy,
            assignment_count: assignmentCount.get(proxy.id) || 0,
            tn_group_count: tnGroupCount.get(proxy.id) || 0,
            total_binding_count: (assignmentCount.get(proxy.id) || 0) + (tnGroupCount.get(proxy.id) || 0),
          }));
          return Response.json({
            ok: true,
            proxies,
            assignments,
            users: profiles.filter((profile: any) => profile.role !== "admin" && profile.account_status === "active"),
            settings: settingsResult.data,
          });
        }

        case "import_proxies": {
          const poolKind = ["translation","tn","shared"].includes(String(body.proxyPoolKind)) ? String(body.proxyPoolKind) : "translation";
          const protocol = validateProxyProtocol(body.proxyProtocol || (poolKind === "tn" ? "socks5" : "http"));
          const tnCapacity = poolKind === "translation" ? null : Math.max(1,Math.min(10000,Number(body.tnCapacity || 30)));
          const lines = String(body.importText || "").split(/\r?\n/).map(line => line.trim()).filter(Boolean);
          if (!lines.length) return fail("请粘贴至少一条代理");
          if (lines.length > 500) return fail("每次最多导入500条代理");
          const rows = [];
          for (let index = 0; index < lines.length; index += 1) {
            const parsed = parseProxyLine(lines[index], protocol);
            if (!parsed) continue;
            const username = await encryptProxyValue(parsed.username);
            const password = await encryptProxyValue(parsed.password);
            rows.push({
              endpoint_fingerprint: await proxyFingerprint(parsed.protocol, parsed.host, parsed.port, parsed.username),
              label: String(body.proxyLabel || "").trim().slice(0, 60) || `代理 ${index + 1}`,
              protocol: parsed.protocol,
              pool_kind: poolKind,
              tn_capacity: tnCapacity,
              host: parsed.host,
              port: parsed.port,
              encrypted_username: username.encrypted,
              username_iv: username.iv,
              encrypted_password: password.encrypted,
              password_iv: password.iv,
              enabled: true,
              health_status: "unknown",
              failure_count: 0,
              last_error: null,
              created_by: callerId,
              updated_at: new Date().toISOString(),
            });
          }
          const { data, error } = await admin.from("translation_proxy_pool")
            .upsert(rows, { onConflict: "endpoint_fingerprint" })
            .select("id");
          if (error) throw error;
          return Response.json({ ok: true, imported: data?.length || rows.length });
        }

        case "toggle_proxy": {
          if (!body.proxyId) return fail("缺少proxyId");
          const enabled = Boolean(body.enabled);
          const { error } = await admin.from("translation_proxy_pool").update({
            enabled,
            health_status: enabled ? "unknown" : "disabled",
            failure_count: enabled ? 0 : undefined,
            last_error: enabled ? null : "管理员已暂停",
            updated_at: new Date().toISOString(),
          }).eq("id", body.proxyId);
          if (error) throw error;
          return Response.json({ ok: true });
        }

        case "delete_proxy": {
          if (!body.proxyId) return fail("缺少proxyId");
          const [{ count: employeeBindings, error: assignmentCountError }, { count: tnBindings, error: tnCountError }] = await Promise.all([
            admin.from("translation_proxy_assignments").select("user_id", { count:"exact", head:true }).eq("proxy_id", body.proxyId),
            admin.from("tn_proxy_groups").select("id", { count:"exact", head:true }).eq("proxy_id", body.proxyId),
          ]);
          if (assignmentCountError) throw assignmentCountError;
          if (tnCountError) throw tnCountError;
          const bindingCount = Number(employeeBindings || 0) + Number(tnBindings || 0);
          if (bindingCount && body.forceUnbind !== true) {
            return fail(`此代理仍绑定 ${Number(employeeBindings || 0)} 个员工分配和 ${Number(tnBindings || 0)} 个TN分组，请确认解除绑定后再删除`, 409);
          }
          if (body.forceUnbind === true) {
            const [assignmentResult, groupResult, siteResult] = await Promise.all([
              admin.from("translation_proxy_assignments").update({proxy_id:null,assignment_mode:"automatic",updated_at:new Date().toISOString()}).eq("proxy_id",body.proxyId),
              admin.from("tn_proxy_groups").delete().eq("proxy_id",body.proxyId),
              admin.from("work_sites").update({fixed_proxy_id:null,proxy_mode:"direct",updated_at:new Date().toISOString()}).eq("fixed_proxy_id",body.proxyId),
            ]);
            if (assignmentResult.error) throw assignmentResult.error;
            if (groupResult.error) throw groupResult.error;
            if (siteResult.error) throw siteResult.error;
          }
          const { data:deleted, error } = await admin.from("translation_proxy_pool").delete().eq("id", body.proxyId).select("id").maybeSingle();
          if (error) throw error;
          if (!deleted) return fail("代理未删除：记录不存在或数据库权限不足", 409);
          return Response.json({ ok: true, deleted:1, unbound:bindingCount });
        }

        case "delete_failed_proxies": {
          const { data, error } = await admin.from("translation_proxy_pool")
            .delete()
            .eq("health_status", "failing")
            .select("id");
          if (error) throw error;
          return Response.json({ ok: true, deleted: data?.length || 0 });
        }

        case "get_proxy_secret": {
          if (!body.proxyId) return fail("缺少proxyId");
          const { data, error } = await admin.from("translation_proxy_pool")
            .select("id,label,protocol,host,port,encrypted_username,username_iv,encrypted_password,password_iv")
            .eq("id", body.proxyId)
            .single();
          if (error || !data) return fail("代理不存在", 404);
          return Response.json({ ok: true, proxy: {
            id: data.id,
            label: data.label,
            protocol: data.protocol,
            host: data.host,
            port: data.port,
            username: await decryptProxyValue(data.encrypted_username, data.username_iv),
            password: await decryptProxyValue(data.encrypted_password, data.password_iv),
          } });
        }

        case "set_proxy_health": {
          if (!body.proxyId) return fail("缺少proxyId");
          const healthy = Boolean(body.healthy);
          const errorMessage = String(body.errorMessage || "").slice(0, 500);
          const { data:settings } = await admin.from("translation_proxy_settings")
            .select("failure_threshold").eq("singleton", true).maybeSingle();
          const { data:current } = await admin.from("translation_proxy_pool")
            .select("health_status,failure_count").eq("id", body.proxyId).single();
          const threshold = Math.max(1, Math.min(10, Number(settings?.failure_threshold || 2)));
          const nextFailures = healthy ? 0 : Number(current?.failure_count || 0) + 1;
          const nextStatus = healthy
            ? "healthy"
            : nextFailures >= threshold
              ? "failing"
              : (current?.health_status === "healthy" ? "healthy" : "unknown");
          const { error } = await admin.from("translation_proxy_pool").update({
            health_status: nextStatus,
            failure_count: nextFailures,
            last_checked_at: new Date().toISOString(),
            last_error: healthy
              ? `出口IP ${String(body.exitIp || "未知")} · ${Math.max(0, Number(body.latencyMs || 0))}ms`
              : (errorMessage || "代理测试失败"),
            updated_at: new Date().toISOString(),
          }).eq("id", body.proxyId);
          if (error) throw error;
          return Response.json({ ok: true });
        }

        case "save_proxy_assignment": {
          if (!body.userId) return fail("缺少userId");
          const mode = body.assignmentMode === "fixed" ? "fixed" : "automatic";
          if (mode === "fixed" && !body.proxyId) return fail("指定分配必须选择一条代理");
          const { data: target, error: targetError } = await admin.from("profiles")
            .select("id,role,account_status").eq("id", body.userId).single();
          if (targetError || !target) return fail("员工账号不存在", 404);
          if (target.role === "admin") return fail("管理员账号不需要员工代理分配");
          let selectedProxyId = body.proxyId || null;
          if (selectedProxyId) {
            const { data: proxy, error: proxyError } = await admin.from("translation_proxy_pool")
              .select("id,enabled").eq("id", selectedProxyId).single();
            if (proxyError || !proxy || !proxy.enabled) return fail("所选代理不存在或已暂停");
          }
          if (mode === "automatic") {
            const [poolResult, assignmentResult] = await Promise.all([
              admin.from("translation_proxy_pool")
                .select("id,health_status,last_used_at,enabled")
                .eq("enabled", true)
                .in("health_status", ["healthy", "unknown"]),
              admin.from("translation_proxy_assignments").select("user_id,proxy_id"),
            ]);
            if (poolResult.error) throw poolResult.error;
            if (assignmentResult.error) throw assignmentResult.error;
            const counts = new Map<string, number>();
            for (const assignment of assignmentResult.data || []) {
              if (assignment.user_id === body.userId || !assignment.proxy_id) continue;
              counts.set(assignment.proxy_id, (counts.get(assignment.proxy_id) || 0) + 1);
            }
            const candidates = [...(poolResult.data || [])].sort((a: any, b: any) => {
              const countDifference = (counts.get(a.id) || 0) - (counts.get(b.id) || 0);
              if (countDifference) return countDifference;
              const healthDifference = (a.health_status === "healthy" ? 0 : 1) - (b.health_status === "healthy" ? 0 : 1);
              if (healthDifference) return healthDifference;
              return (a.last_used_at ? new Date(a.last_used_at).getTime() : 0) - (b.last_used_at ? new Date(b.last_used_at).getTime() : 0);
            });
            selectedProxyId = candidates[0]?.id || null;
          }
          const { error } = await admin.from("translation_proxy_assignments").upsert({
            user_id: body.userId,
            proxy_id: selectedProxyId,
            assignment_mode: mode,
            allowed_by_admin: body.allowedByAdmin !== false,
            assigned_at: new Date().toISOString(),
            last_error: null,
            updated_at: new Date().toISOString(),
          }, { onConflict: "user_id" });
          if (error) throw error;
          return Response.json({ ok: true, proxyId: selectedProxyId, assigned: Boolean(selectedProxyId) });
        }

        case "delete_proxy_assignment": {
          if (!body.userId) return fail("缺少userId");
          const { error } = await admin.from("translation_proxy_assignments").delete().eq("user_id", body.userId);
          if (error) throw error;
          return Response.json({ ok: true });
        }

        case "repair_proxy_assignments": {
          const [poolResult, assignmentResult] = await Promise.all([
            admin.from("translation_proxy_pool")
              .select("id,health_status,last_used_at,enabled")
              .eq("enabled", true)
              .in("health_status", ["healthy", "unknown"]),
            admin.from("translation_proxy_assignments")
              .select("user_id,proxy_id,assignment_mode,allowed_by_admin"),
          ]);
          if (poolResult.error) throw poolResult.error;
          if (assignmentResult.error) throw assignmentResult.error;
          const pool = poolResult.data || [];
          const availableIds = new Set(pool.map((proxy: any) => proxy.id));
          const assignments = assignmentResult.data || [];
          const counts = new Map<string, number>();
          for (const assignment of assignments) {
            if (assignment.proxy_id && availableIds.has(assignment.proxy_id)) {
              counts.set(assignment.proxy_id, (counts.get(assignment.proxy_id) || 0) + 1);
            }
          }
          let repaired = 0;
          for (const assignment of assignments) {
            if (assignment.assignment_mode !== "automatic" || assignment.allowed_by_admin === false) continue;
            if (assignment.proxy_id && availableIds.has(assignment.proxy_id)) continue;
            const selected = [...pool].sort((a: any, b: any) => {
              const countDifference = (counts.get(a.id) || 0) - (counts.get(b.id) || 0);
              if (countDifference) return countDifference;
              const healthDifference = (a.health_status === "healthy" ? 0 : 1) - (b.health_status === "healthy" ? 0 : 1);
              if (healthDifference) return healthDifference;
              return (a.last_used_at ? new Date(a.last_used_at).getTime() : 0) - (b.last_used_at ? new Date(b.last_used_at).getTime() : 0);
            })[0] || null;
            const { error } = await admin.from("translation_proxy_assignments").update({
              proxy_id:selected?.id || null,
              assigned_at:new Date().toISOString(),
              last_error:selected ? null : "暂时没有可用IP",
              updated_at:new Date().toISOString(),
            }).eq("user_id", assignment.user_id);
            if (error) throw error;
            if (selected) counts.set(selected.id, (counts.get(selected.id) || 0) + 1);
            repaired += 1;
          }
          return Response.json({ ok:true, repaired });
        }

        case "save_proxy_settings": {
          const threshold = Number(body.failureThreshold ?? 2);
          if (!Number.isInteger(threshold) || threshold < 1 || threshold > 10) return fail("失败切换次数必须是1到10");
          const interval = Number(body.healthCheckIntervalMinutes ?? 10);
          if (!Number.isInteger(interval) || interval < 1 || interval > 60) return fail("自动检测间隔必须是1到60分钟");
          const { error } = await admin.from("translation_proxy_settings").upsert({
            singleton: true,
            enabled: body.enabled !== false,
            failure_threshold: threshold,
            health_check_interval_minutes: interval,
            updated_at: new Date().toISOString(),
          }, { onConflict: "singleton" });
          if (error) throw error;
          return Response.json({ ok: true });
        }

        case "get_membership_settings": {
          const days = await membershipGraceDays(admin);
          return Response.json({ ok:true, settings:{ basicGraceDays:days } });
        }
        case "save_membership_settings": {
          const days = Math.max(1, Math.min(365, Math.round(Number(body.basicGraceDays || 30))));
          const { error } = await admin.from("membership_settings").upsert({ singleton:true, basic_grace_days:days, updated_at:new Date().toISOString(), updated_by:callerId }, { onConflict:"singleton" });
          if (error) throw error;
          return Response.json({ ok:true, settings:{ basicGraceDays:days } });
        }

        case "list_permissions": {
          const { data, error } = await admin.from("plan_permissions").select("plan,feature_code,enabled");
          if (error) throw error;
          const permissions: Record<string, Record<string, boolean>> = { basic: {}, advanced: {} };
          for (const row of data || []) permissions[row.plan][row.feature_code] = Boolean(row.enabled);
          return Response.json({ ok: true, permissions });
        }

        case "save_permission": {
          const plan = validatePlan(body.plan);
          const featureCode = String(body.featureCode || "").trim();
          if (!/^[a-z][a-z0-9_]{1,49}$/.test(featureCode)) return fail("功能代码格式不正确");
          const expected = Boolean(body.enabled);
          const { data:saved, error } = await admin.from("plan_permissions")
            .upsert({ plan, feature_code:featureCode, enabled:expected }, { onConflict:"plan,feature_code" })
            .select("plan,feature_code,enabled").single();
          if (error) throw error;
          if (!saved || saved.enabled !== expected) return fail("权限保存后回读不一致，请检查plan_permissions表约束", 500);
          return Response.json({ ok:true, saved });
        }
        case "list_feature_flags": {
          const { data, error } = await admin.from("app_feature_flags")
            .select("feature_key,parent_key,label,enabled,fail_closed,sort_order,reason,updated_at")
            .order("sort_order", { ascending:true });
          if (error) throw error;
          return Response.json({ ok:true, flags:data || [] });
        }
        case "save_feature_flag": {
          const featureKey = String(body.featureKey || "").trim();
          const reason = String(body.reason || "").trim().slice(0, 300);
          if (!/^[a-z][a-z0-9_]{1,49}$/.test(featureKey)) return fail("功能代码格式不正确");
          if (!reason) return fail("请填写停用或启用原因");
          const { data:existing, error:readError } = await admin.from("app_feature_flags")
            .select("enabled,reason,updated_by,updated_at").eq("feature_key", featureKey).single();
          if (readError || !existing) return fail("功能开关不存在");
          const nextEnabled = Boolean(body.enabled);
          const changedAt = new Date().toISOString();
          const { data:updated, error:updateError } = await admin.from("app_feature_flags").update({
            enabled:nextEnabled, reason, updated_by:callerId, updated_at:changedAt
          }).eq("feature_key", featureKey).select("feature_key,enabled").single();
          if (updateError) throw updateError;
          if (!updated || updated.enabled !== nextEnabled) return fail("功能开关保存后回读不一致", 500);
          const { error:auditError } = await admin.from("app_feature_flag_audit").insert({
            feature_key:featureKey, old_enabled:Boolean(existing.enabled), new_enabled:nextEnabled,
            reason, changed_by:callerId
          });
          if (auditError) {
            const { error:rollbackError } = await admin.from("app_feature_flags").update({
              enabled:Boolean(existing.enabled),
              reason:String(existing.reason || ""),
              updated_by:existing.updated_by || null,
              updated_at:existing.updated_at || new Date().toISOString(),
            }).eq("feature_key", featureKey);
            if (rollbackError) throw new Error(`审计写入失败且自动回滚失败：${readableServerError(auditError)}；${readableServerError(rollbackError)}`);
            return fail(`审计写入失败，功能开关已自动回滚：${readableServerError(auditError)}`, 500);
          }
          return Response.json({ ok:true, saved:updated });
        }
        case "list_sites": {
          const { data, error } = await admin.from("work_sites")
            .select("id,site_key,display_name,url,icon_url,host_label,enabled,sort_order,minimum_plan,proxy_required,proxy_mode,fixed_proxy_id,chat_container_selector,message_selector,input_selector,phone_selector")
            .order("sort_order", { ascending: true });
          if (error) throw error;
          return Response.json({ ok: true, sites: data });
        }

        case "save_site": {
          const siteKey = String(body.siteKey || "").trim().toLowerCase();
          const displayName = String(body.siteName || "").trim().slice(0, 60);
          const url = String(body.siteUrl || "").trim();
          const iconUrl = String(body.siteIconUrl || "").trim();
          if (!/^[a-z0-9][a-z0-9_-]{1,31}$/.test(siteKey)) return fail("网站标识格式不正确");
          if (!displayName) return fail("网站名称不能为空");
          let parsed: URL;
          try { parsed = new URL(url); } catch { return fail("网站地址格式不正确"); }
          if (parsed.protocol !== "https:") return fail("网站地址必须使用HTTPS");
          if (iconUrl) {
            let parsedIcon: URL;
            try { parsedIcon = new URL(iconUrl); } catch { return fail("平台图标地址格式不正确"); }
            if (parsedIcon.protocol !== "https:") return fail("平台图标地址必须使用HTTPS");
          }
          const proxyMode = String(body.siteProxyMode || (body.siteProxyRequired ? "automatic" : "direct"));
          if (!["direct","automatic","tn_pool","fixed"].includes(proxyMode)) return fail("网站IP模式不正确");
          const fixedProxyId = proxyMode === "fixed" ? String(body.siteFixedProxyId || "") : "";
          if (proxyMode === "fixed") {
            if (!fixedProxyId) return fail("请选择固定IP");
            const { data:fixedProxy, error:fixedProxyError } = await admin.from("translation_proxy_pool").select("id,enabled").eq("id", fixedProxyId).maybeSingle();
            if (fixedProxyError || !fixedProxy?.enabled) return fail("选择的固定IP不存在或已停用");
          }
          const row = {
            site_key: siteKey,
            display_name: displayName,
            url: parsed.toString(),
            host_label: parsed.hostname,
            icon_url: iconUrl || null,
            proxy_required: proxyMode !== "direct",
            proxy_mode: proxyMode,
            fixed_proxy_id: fixedProxyId || null,
            chat_container_selector: String(body.chatContainerSelector || "").trim().slice(0, 500) || null,
            message_selector: String(body.messageSelector || "").trim().slice(0, 500) || null,
            input_selector: String(body.inputSelector || "").trim().slice(0, 500) || null,
            phone_selector: String(body.phoneSelector || "").trim().slice(0, 500) || null,
            enabled: body.siteEnabled !== false,
            sort_order: Number.isInteger(Number(body.sortOrder)) ? Number(body.sortOrder) : 100,
            updated_at: new Date().toISOString(),
            minimum_plan: validatePlan(body.minimumPlan || "basic"),
          };
          const query = body.siteId
            ? admin.from("work_sites").update(row).eq("id", body.siteId)
            : admin.from("work_sites").insert(row);
          const { data, error } = await query.select("id,site_key,display_name,url,icon_url,host_label,enabled,sort_order,minimum_plan,proxy_required,proxy_mode,fixed_proxy_id,chat_container_selector,message_selector,input_selector,phone_selector").single();
          if (error) throw error;
          return Response.json({ ok: true, site: data });
        }

        case "delete_site": {
          if (!body.siteId) return fail("缺少siteId");
          const { error } = await admin.from("work_sites").delete().eq("id", body.siteId);
          if (error) throw error;
          return Response.json({ ok: true });
        }

        case "list_user_site_access": {
          const userId = String(body.userId || "");
          if (!userId) return fail("缺少用户ID");
          const [{ data:target, error:targetError }, { data:siteRows, error:siteError }, { data:accessRows, error:accessError }] = await Promise.all([
            admin.from("profiles").select("id,role,plan").eq("id", userId).maybeSingle(),
            admin.from("work_sites").select("id,site_key,display_name,icon_url,minimum_plan,enabled,sort_order").order("sort_order", { ascending:true }),
            admin.from("user_site_access").select("site_id,allowed").eq("user_id", userId),
          ]);
          if (targetError || !target) return fail("账号不存在或已删除", 404);
          if (siteError) throw siteError;
          if (accessError) throw accessError;
          const explicit = new Map((accessRows || []).map((row:any) => [String(row.site_id), row.allowed === true]));
          const hasExplicitRules = explicit.size > 0;
          const sites = (siteRows || []).map((site:any) => ({
            ...site,
            allowed: target.role === "admin" ? true : (hasExplicitRules
              ? explicit.get(String(site.id)) === true
              : (site.minimum_plan !== "advanced" || target.plan === "advanced")),
          }));
          return Response.json({ ok:true, sites, hasExplicitRules, adminLocked:target.role === "admin" });
        }

        case "save_user_site_access": {
          const userId = String(body.userId || "");
          if (!userId) return fail("缺少用户ID");
          const { data:target, error:targetError } = await admin.from("profiles").select("id,role").eq("id", userId).maybeSingle();
          if (targetError || !target) return fail("账号不存在或已删除", 404);
          if (target.role === "admin") return fail("管理员固定拥有全部网站权限");
          const requested = Array.isArray(body.siteAccess) ? body.siteAccess : [];
          const { data:sites, error:sitesError } = await admin.from("work_sites").select("id");
          if (sitesError) throw sitesError;
          const validIds = new Set((sites || []).map((row:any) => String(row.id)));
          const selected = new Map<string, boolean>();
          for (const row of requested) {
            const siteId = String(row?.siteId || "");
            if (validIds.has(siteId)) selected.set(siteId, row?.allowed === true);
          }
          const rows = [...validIds].map(siteId => ({
            user_id:userId, site_id:siteId, allowed:selected.get(siteId) === true,
            updated_at:new Date().toISOString(), updated_by:callerId,
          }));
          if (rows.length) {
            const { error:insertError } = await admin.from("user_site_access").upsert(rows, { onConflict:"user_id,site_id" });
            if (insertError) throw insertError;
          } else {
            const { error:deleteError } = await admin.from("user_site_access").delete().eq("user_id", userId);
            if (deleteError) throw deleteError;
          }
          const { data:verified, error:verifyError } = await admin.from("user_site_access").select("site_id,allowed").eq("user_id", userId);
          if (verifyError) throw verifyError;
          if ((verified || []).length !== rows.length) return fail("网站权限保存后回读不一致", 500);
          return Response.json({ ok:true, saved:verified || [] });
        }

        case "list_users": {
          // Keep the admin list truthful even if an expired Advanced user has
          // not logged in yet. The downgrade is idempotent and preserves paused
          // or disabled accounts.
          const graceDays = await membershipGraceDays(admin);
          const nowIso = new Date().toISOString();
          const { data:expiredAdvanced, error:expiredAdvancedError } = await admin.from("profiles")
            .select("id").eq("role","user").eq("plan","advanced").eq("account_status","active").lte("valid_until", nowIso);
          if (expiredAdvancedError) throw expiredAdvancedError;
          for (const row of expiredAdvanced || []) {
            const basicUntil = new Date(Date.now() + graceDays * 86400000).toISOString();
            const { error:downgradeError } = await admin.from("profiles").update({ plan:"basic", valid_until:basicUntil, updated_at:nowIso }).eq("id", row.id).eq("plan","advanced");
            if (downgradeError) throw downgradeError;
          }
          const { error:pauseExpiredBasicError } = await admin.from("profiles")
            .update({ account_status:"paused", updated_at:nowIso })
            .eq("role","user").eq("plan","basic").eq("account_status","active").lte("valid_until", nowIso);
          if (pauseExpiredBasicError) throw pauseExpiredBasicError;
          const { data, error } = await admin
            .from("profiles")
            .select(
              "id,username,display_name,role,plan,account_status,valid_from,valid_until,daily_start,daily_end,access_timezone,device_limit,force_logout_after,last_login_at,created_at",
            )
            .order("created_at", { ascending: false });
          if (error) throw error;
          const { data: devices, error: devicesError } = await admin
            .from("devices")
            .select("user_id,device_name,platform,last_seen_at,revoked_at,last_ip")
            .order("last_seen_at", { ascending: false });
          if (devicesError) throw devicesError;
          const { data: blockedIps, error: blockedError } = await admin.from("blocked_client_ips")
            .select("id,ip_address,reason,created_at,blocked_by")
            .order("created_at", { ascending:false });
          if (blockedError) throw blockedError;
          const blockedSet = new Set((blockedIps || []).map((row:any) => String(row.ip_address || "")));

          const onlineCutoff = Date.now() - 150 * 1000;
          const devicesByUser = new Map<string, Array<Record<string, unknown>>>();
          for (const device of devices ?? []) {
            const userId = String(device.user_id || "");
            if (!devicesByUser.has(userId)) devicesByUser.set(userId, []);
            devicesByUser.get(userId)!.push(device);
          }
          const users = (data ?? []).map((user) => {
            const userDevices = devicesByUser.get(user.id) ?? [];
            const activeDevices = userDevices.filter((device) =>
              !device.revoked_at &&
              Boolean(device.last_seen_at) &&
              new Date(String(device.last_seen_at)).getTime() >= onlineCutoff
            );
            const latestDevice = userDevices[0] ?? null;
            return {
              ...user,
              online: activeDevices.length > 0,
              active_device_count: activeDevices.length,
              last_seen_at: latestDevice?.last_seen_at ?? user.last_login_at ?? null,
              device_name: activeDevices[0]?.device_name ?? latestDevice?.device_name ?? "",
              device_platform: activeDevices[0]?.platform ?? latestDevice?.platform ?? "",
              last_ip: activeDevices[0]?.last_ip ?? latestDevice?.last_ip ?? "",
              ip_blocked: blockedSet.has(String(activeDevices[0]?.last_ip ?? latestDevice?.last_ip ?? "")),
            };
          });
          return Response.json({ ok: true, users, blockedIps:blockedIps || [], onlineThresholdSeconds: 150 });
        }

        case "create_user": {
          const username = normalizeUsername(body.username);
          const password = validatePassword(body.password);
          const role = validateRole(body.role ?? "user");
          const plan = role === "admin" ? "advanced" : validatePlan(body.plan ?? "basic");
          const deviceLimit = validateDeviceLimit(body.deviceLimit ?? 50);
          const validDays = Number(body.validDays ?? 0);
          if (!Number.isInteger(validDays) || validDays < 0 || validDays > 3650) return fail("有效天数必须是0到3650之间的整数");
          const validUntil = role === "admin" || validDays === 0 ? null : new Date(Date.now() + validDays * 86400000).toISOString();
          const displayName = String(body.displayName ?? username).trim().slice(0, 80);
          const email = await internalEmailForUsername(username);

          const { data: created, error: createError } = await admin.auth.admin.createUser({
            email,
            password,
            email_confirm: true,
            user_metadata: { username, display_name: displayName, role },
          });
          if (createError || !created.user) {
            if (createError?.message?.toLowerCase().includes("already")) {
              return fail("用户名已经存在", 409);
            }
            throw createError ?? new Error("创建账号失败");
          }

          const { data: profile, error: profileError } = await admin
            .from("profiles")
            .update({
              display_name: displayName,
              role,
              plan,
              account_status: "active",
              valid_from: new Date().toISOString(),
              valid_until: validUntil,
              daily_start: validateTime(body.dailyStart),
              daily_end: validateTime(body.dailyEnd),
              access_timezone: String(body.accessTimezone || "Asia/Bangkok"),
              device_limit: deviceLimit,
            })
            .eq("id", created.user.id)
            .select("id,username,display_name,role,plan,account_status,valid_until,device_limit")
            .single();

          if (profileError) {
            // Roll back the Auth user if its profile could not be configured.
            await admin.auth.admin.deleteUser(created.user.id);
            throw profileError;
          }

          return Response.json({ ok: true, user: profile }, { status: 201 });
        }

        case "renew_user": {
          if (!body.userId) return fail("缺少userId");
          const days = Number(body.validDays);
          if (!Number.isInteger(days) || days < 0 || days > 3650) return fail("续期天数必须是0到3650之间的整数");
          const { data: target, error: targetError } = await admin.from("profiles").select("role,valid_until").eq("id", body.userId).single();
          if (targetError || !target) return fail("账号不存在", 404);
          if (target.role === "admin") return fail("管理员账号不使用会员续期");
          const base = target.valid_until && new Date(target.valid_until).getTime() > Date.now() ? new Date(target.valid_until).getTime() : Date.now();
          const validUntil = days === 0 ? null : new Date(base + days * 86400000).toISOString();
          const { error } = await admin.from("profiles").update({ valid_until: validUntil, account_status: "active", force_logout_after: null }).eq("id", body.userId);
          if (error) throw error;
          const { error: deviceError } = await admin.from("devices").delete().eq("user_id", body.userId).not("revoked_at", "is", null);
          if (deviceError) throw deviceError;
          return Response.json({ ok: true, validUntil });
        }

        case "delete_user": {
          if (!body.userId) return fail("缺少userId");
          if (body.userId === callerId) return fail("不能删除当前登录的管理员账号");
          const { data: target, error: targetError } = await admin.from("profiles").select("role,username").eq("id", body.userId).single();
          if (targetError || !target) return fail("账号不存在", 404);
          if (target.role === "admin") {
            const { count, error: countError } = await admin.from("profiles")
              .select("id", { count: "exact", head: true })
              .eq("role", "admin");
            if (countError) throw countError;
            if ((count ?? 0) <= 1) return fail("不能删除系统中最后一个管理员账号");
          }
          // Preserve historical announcements while removing the employee.
          // Older messaging schemas used ON DELETE RESTRICT for created_by,
          // which otherwise prevents the Auth user from being deleted.
          const { error: announcementError } = await admin.from("app_announcements")
            .update({ created_by: callerId })
            .eq("created_by", body.userId);
          if (announcementError && String(announcementError.code || "") !== "42P01") throw announcementError;
          await deleteUserMessageAttachments(admin, body.userId);
          const cleanup = async (table:string, column:string) => {
            const { error:cleanupError } = await admin.from(table).delete().eq(column, body.userId!);
            if (cleanupError && String(cleanupError.code || "") !== "42P01") throw cleanupError;
          };
          await cleanup("user_permission_overrides", "user_id");
          await cleanup("devices", "user_id");
          await cleanup("translation_proxy_assignments", "user_id");
          await cleanup("employee_tn_account_counts", "user_id");
          await cleanup("tn_proxy_groups", "owner_user_id");
          const { error:authDeleteError } = await admin.auth.admin.deleteUser(body.userId);
          if (authDeleteError) throw authDeleteError;
          const { error:profileDeleteError } = await admin.from("profiles").delete().eq("id", body.userId);
          if (profileDeleteError) throw profileDeleteError;
          const [authVerification, profileVerification] = await Promise.all([
            admin.auth.admin.getUserById(body.userId),
            admin.from("profiles").select("id").eq("id", body.userId).maybeSingle(),
          ]);
          if (authVerification.data?.user) throw new Error("Auth账号仍然存在，服务器没有完成永久删除");
          if (profileVerification.error) throw profileVerification.error;
          if (profileVerification.data) throw new Error("员工资料仍然存在，服务器没有完成永久删除");
          return Response.json({ ok:true, deleted:true, permanentlyDeleted:true, userId:body.userId, username:target.username });
        }

        case "update_user": {
          if (!body.userId) return fail("缺少userId");
          const patch: Record<string, unknown> = {};

          if (body.displayName !== undefined) {
            patch.display_name = String(body.displayName).trim().slice(0, 80);
          }
          if (body.plan !== undefined) patch.plan = validatePlan(body.plan);
          if (body.accountStatus !== undefined) {
            const status = validateStatus(body.accountStatus);
            if (body.userId === callerId && status !== "active") {
              return fail("不能停用当前正在使用的管理员账号");
            }
            patch.account_status = status;
            if (status === "active") patch.force_logout_after = null;
          }
          if (body.validUntil !== undefined) patch.valid_until = validateDate(body.validUntil);
          if (body.dailyStart !== undefined) patch.daily_start = validateTime(body.dailyStart);
          if (body.dailyEnd !== undefined) patch.daily_end = validateTime(body.dailyEnd);
          if (body.accessTimezone !== undefined) {
            patch.access_timezone = String(body.accessTimezone || "Asia/Bangkok");
          }
          if (body.deviceLimit !== undefined) {
            patch.device_limit = validateDeviceLimit(body.deviceLimit);
          }
          if (Object.keys(patch).length === 0) return fail("没有需要更新的内容");

          const { data, error } = await admin
            .from("profiles")
            .update(patch)
            .eq("id", body.userId)
            .select("id,username,display_name,role,plan,account_status,valid_until,device_limit")
            .single();
          if (error) throw error;
          if (body.accountStatus === "active") {
            const { error: deviceError } = await admin.from("devices").delete().eq("user_id", body.userId).not("revoked_at", "is", null);
            if (deviceError) throw deviceError;
          }
          return Response.json({ ok: true, user: data });
        }

        case "reset_password": {
          if (!body.userId) return fail("缺少userId");
          const password = validatePassword(body.password);
          const { error } = await admin.auth.admin.updateUserById(body.userId, { password });
          if (error) throw error;
          await admin.from("profiles").update({ force_logout_after: new Date().toISOString() })
            .eq("id", body.userId);
          return Response.json({ ok: true });
        }

        case "list_devices": {
          if (!body.userId) return fail("缺少userId");
          const { data, error } = await admin
            .from("devices")
            .select("id,device_name,platform,first_seen_at,last_seen_at,revoked_at")
            .eq("user_id", body.userId)
            .order("last_seen_at", { ascending: false });
          if (error) throw error;
          return Response.json({ ok: true, devices: data });
        }

        case "revoke_device": {
          if (!body.deviceId) return fail("缺少deviceId");
          const { data, error } = await admin
            .from("devices")
            .update({ revoked_at: new Date().toISOString() })
            .eq("id", body.deviceId)
            .select("id")
            .single();
          if (error) throw error;
          return Response.json({ ok: true, device: data });
        }

        case "force_logout": {
          if (!body.userId) return fail("缺少userId");
          if (body.userId === callerId) return fail("不能强制下线当前管理员账号");
          const timestamp = new Date().toISOString();
          const { error: profileError } = await admin
            .from("profiles")
            .update({ force_logout_after: timestamp })
            .eq("id", body.userId);
          if (profileError) throw profileError;
          const { error: deviceError } = await admin
            .from("devices")
            .update({ revoked_at: timestamp })
            .eq("user_id", body.userId)
            .is("revoked_at", null);
          if (deviceError) throw deviceError;
          return Response.json({ ok: true });
        }

        case "restore_access": {
          if (!body.userId) return fail("缺少userId");
          if (body.userId === callerId) return fail("当前管理员账号不需要重新授权");
          const { data: target, error: targetError } = await admin.from("profiles").select("id,role").eq("id", body.userId).single();
          if (targetError || !target) return fail("账号不存在", 404);
          const { error: profileError } = await admin.from("profiles")
            .update({ account_status:"active", force_logout_after:null })
            .eq("id", body.userId);
          if (profileError) throw profileError;
          const { error: deviceError } = await admin.from("devices").delete().eq("user_id", body.userId).not("revoked_at", "is", null);
          if (deviceError) throw deviceError;
          return Response.json({ ok:true, message:"账号与设备登录权限已恢复；员工可在原电脑重新登录" });
        }

        case "block_client_ip": {
          const clientIp = validateClientIp(body.clientIp);
          const reason = String(body.reason || "管理员封禁").trim().slice(0,200) || "管理员封禁";
          const { data, error } = await admin.from("blocked_client_ips")
            .upsert({ ip_address:clientIp, reason, blocked_by:callerId, created_at:new Date().toISOString() }, { onConflict:"ip_address" })
            .select("id,ip_address,reason,created_at")
            .single();
          if (error) throw error;
          return Response.json({ ok:true, blockedIp:data });
        }

        case "unblock_client_ip": {
          const clientIp = validateClientIp(body.clientIp);
          const { error } = await admin.from("blocked_client_ips").delete().eq("ip_address", clientIp);
          if (error) throw error;
          return Response.json({ ok:true, clientIp });
        }

        default:
          return fail("不支持的操作");
      }
    } catch (error) {
      console.error("admin-users error", error);
      const message = readableServerError(error);
      return fail(`服务器处理失败：${message}`, 500);
    }
  }),
};

