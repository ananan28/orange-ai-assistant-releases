"use strict";
const DEFAULT_HOST = "www.textnow.com",
  DEFAULT_DOMAIN = ".textnow.com",
  WRAPPER_KEYS = ["cookies", "cookie", "cookieData", "data", "items", "entries"];
function cleanCookieText(e) {
  let t = String(e || "").trim();
  const o = t.match(/(?:^|\s)(?:-b|--cookie)\s+(["'])([\s\S]*?)\1/i),
    r = t.match(/(?:^|\s)(?:-H|--header)\s+(["'])Cookie:\s*([\s\S]*?)\1/i),
    n = t.match(/^Cookie\s*:\s*(.+)$/im);
  o ? (t = o[2]) : r ? (t = r[2]) : n && (t = n[1]);
  const i = t.match(/document\.cookie\s*=\s*(["'])([\s\S]*?)\1/i);
  return (i && (t = i[2]), (t = t.replace(/^\s*Cookie\s*:\s*/i, "")), t.trim());
}
function isTextNowHost(e) {
  const t = String(e || "")
    .replace(/^\./, "")
    .toLowerCase();
  return t === "textnow.com" || t.endsWith(".textnow.com");
}
function normalizedHost(e) {
  let t = String(e || DEFAULT_DOMAIN)
    .trim()
    .toLowerCase();
  try {
    /^https?:\/\//i.test(t) && (t = new URL(t).hostname);
  } catch {}
  return ((t = t.replace(/^\./, "").split(/[/:]/)[0]), isTextNowHost(t) ? t : "");
}
function sameSiteValue(e) {
  const t = String(e || "")
    .toLowerCase()
    .replace(/[-_ ]/g, "");
  return t === "strict"
    ? "strict"
    : t === "lax"
      ? "lax"
      : t === "none" || t === "norestriction"
        ? "no_restriction"
        : "unspecified";
}
function expirationSeconds(e) {
  if (e == null || e === "" || e === 0 || e === "0") return null;
  let t = Number(e);
  return (
    Number.isFinite(t) || (t = Date.parse(String(e)) / 1e3),
    Number.isFinite(t) ? (t > 1e12 ? t / 1e3 : t) : null
  );
}
function cookieLike(e) {
  return !!(
    e &&
    typeof e == "object" &&
    !Array.isArray(e) &&
    typeof (e.name ?? e.Name) == "string" &&
    (Object.prototype.hasOwnProperty.call(e, "value") ||
      Object.prototype.hasOwnProperty.call(e, "Value"))
  );
}
function rowsFromJson(e, t = {}) {
  if (typeof e == "string")
    try {
      return rowsFromJson(JSON.parse(e), t);
    } catch {
      return rowsFromHeader(e);
    }
  if (Array.isArray(e)) return e.flatMap((r) => rowsFromJson(r, t));
  if (!e || typeof e != "object") return [];
  if (cookieLike(e)) return [{ ...t, ...e, name: e.name ?? e.Name, value: e.value ?? e.Value }];
  if (Array.isArray(e?.log?.entries))
    return e.log.entries.flatMap((r) => [
      ...rowsFromJson(r?.request?.cookies || [], t),
      ...rowsFromJson(r?.response?.cookies || [], t),
    ]);
  for (const r of WRAPPER_KEYS) {
    if (!Object.prototype.hasOwnProperty.call(e, r)) continue;
    const o = e[r];
    if (typeof o == "string")
      try {
        return rowsFromJson(JSON.parse(o), { ...t, ...e });
      } catch {
        return rowsFromHeader(o);
      }
    return rowsFromJson(o, { ...t, ...e });
  }
  const n = Object.entries(e),
    i = n.filter(([r, o]) => isTextNowHost(r) && o && typeof o == "object");
  return i.length
    ? i.flatMap(([r, o]) => rowsFromJson(o, { ...t, domain: r }))
    : n.length && n.every(([, r]) => ["string", "number", "boolean"].includes(typeof r))
      ? n.map(([r, o]) => ({ ...t, name: r, value: String(o) }))
      : n.flatMap(([r, o]) => {
          if (!o || typeof o != "object") return [];
          const a = isTextNowHost(r) ? { ...t, domain: r } : t;
          return rowsFromJson(o, a);
        });
}
function rowsFromSetCookie(e) {
  return String(e || "")
    .split(/\r?\n/)
    .map((o) => o.trim())
    .filter((o) => /^Set-Cookie\s*:/i.test(o))
    .map((o) => {
      const r = o.replace(/^Set-Cookie\s*:\s*/i, "").split(/;\s*/),
        n = r.shift() || "",
        i = n.indexOf("=");
      if (i < 1) return null;
      const c = {
        name: n.slice(0, i).trim(),
        value: n.slice(i + 1),
        domain: DEFAULT_HOST,
        hostOnly: !0,
        path: "/",
      };
      for (const f of r) {
        const l = f.indexOf("="),
          p = (l < 0 ? f : f.slice(0, l)).trim().toLowerCase(),
          u = l < 0 ? "" : f.slice(l + 1).trim();
        p === "domain"
          ? ((c.domain = u), (c.hostOnly = !1))
          : p === "path"
            ? (c.path = u)
            : p === "expires"
              ? (c.expires = u)
              : p === "max-age" && Number.isFinite(Number(u))
                ? (c.expirationDate = Math.floor(Date.now() / 1e3) + Number(u))
                : p === "samesite"
                  ? (c.sameSite = u)
                  : p === "secure"
                    ? (c.secure = !0)
                    : p === "httponly" && (c.httpOnly = !0);
      }
      return c;
    })
    .filter(Boolean);
}
function rowsFromHeader(e) {
  let t = cleanCookieText(e);
  return (
    (t = t
      .split(/\r?\n/)
      .map((n) => n.trim())
      .filter(Boolean)
      .reduce((n, i) => (n ? `${n}${/;\s*$/.test(n) ? " " : ""}${i}` : i), "")
      .trim()),
    t
      .split(/;\s*/)
      .map((n) => {
        const i = n.indexOf("=");
        if (i < 1) return null;
        const r = n.slice(0, i).trim();
        return !r || /^(?:path|domain|expires|max-age|samesite|secure|httponly)$/i.test(r)
          ? null
          : {
              name: r,
              value: n.slice(i + 1).trim(),
              domain: DEFAULT_DOMAIN,
              hostOnly: !1,
              path: "/",
              secure: !0,
              sourceFormat: "header",
            };
      })
      .filter(Boolean)
  );
}
function rowsFromLooseText(e) {
  const t = [],
    n = String(e || "")
      .split(/\r?\n/)
      .map((i) => i.trim())
      .filter(Boolean);
  for (const i of n) {
    const r = i.split("	"),
      o = r.length > 1 ? r : [i];
    for (const a of o) {
      const u = cleanCookieText(a).replace(/^\s*(?:cookies?|ck)\s*[=:]\s*/i, ""),
        l = rowsFromHeader(u);
      if (l.length) {
        t.push(...l);
        break;
      }
    }
  }
  return t;
}
function rowsFromNetscape(e) {
  const t = [];
  for (const o of String(e || "").split(/\r?\n/)) {
    const r = o.trim();
    if (!r || (r.startsWith("#") && !r.startsWith("#HttpOnly_"))) continue;
    const n = r.replace(/^#HttpOnly_/, "").split("	");
    n.length < 7 ||
      t.push({
        domain: n[0],
        hostOnly: String(n[1]).toUpperCase() !== "TRUE",
        path: n[2] || "/",
        secure: String(n[3]).toUpperCase() === "TRUE",
        expirationDate: n[4],
        name: n[5],
        value: n.slice(6).join("	"),
        httpOnly: r.startsWith("#HttpOnly_"),
      });
  }
  return t;
}
function splitDelimitedLine(e, t) {
  if (t === "	") return e.split("	");
  const o = [];
  let r = "",
    n = !1;
  for (let i = 0; i < e.length; i += 1) {
    const c = e[i];
    c === '"'
      ? n && e[i + 1] === '"'
        ? ((r += '"'), (i += 1))
        : (n = !n)
      : c === t && !n
        ? (o.push(r), (r = ""))
        : (r += c);
  }
  return (o.push(r), o);
}
function rowsFromDevtools(e) {
  const t = String(e || "")
      .split(/\r?\n/)
      .filter((r) => r.trim()),
    n = t[0]?.includes("	") ? "	" : t[0]?.includes(",") ? "," : "";
  if (t.length < 2 || !/\bname\b/i.test(t[0]) || !/\bvalue\b/i.test(t[0]) || !n) return [];
  const i = splitDelimitedLine(t[0], n).map((r) => r.trim().toLowerCase().replace(/\s+/g, ""));
  return t
    .slice(1)
    .map((r) => {
      const o = splitDelimitedLine(r, n),
        a = {};
      return (
        i.forEach((u, l) => {
          a[u] = o[l] ?? "";
        }),
        {
          name: a.name,
          value: a.value,
          domain: a.domain,
          path: a.path || "/",
          expirationDate: a.expires || a.expirationdate,
          httpOnly: /^(true|✓|yes)$/i.test(a.httponly),
          secure: /^(true|✓|yes)$/i.test(a.secure),
          sameSite: a.samesite,
        }
      );
    })
    .filter((r) => r.name);
}
function normalizeCookieRow(e) {
  const t = String(e?.name ?? e?.Name ?? "").trim(),
    n = String(e?.value ?? e?.Value ?? "");
  if (!t || /[\x00-\x20();<>@,:\\"/\[\]?={}]/.test(t)) return null;
  const i = String(e?.url || e?.URL || "").trim();
  let r = "",
    o = "";
  try {
    const f = new URL(i);
    ((r = f.hostname), (o = f.pathname));
  } catch {}
  const a = normalizedHost(e?.domain || e?.host || r || DEFAULT_DOMAIN);
  if (!a) return null;
  const u = String(e?.path || o || "/"),
    l = u.startsWith("/") ? u : "/",
    p = e?.hostOnly === !0 || e?.host_only === !0 || t.startsWith("__Host-"),
    y = t.startsWith("__Secure-") || t.startsWith("__Host-") ? !0 : e?.secure !== !1,
    s = sameSiteValue(e?.sameSite ?? e?.same_site),
    c = expirationSeconds(e?.expirationDate ?? e?.expires ?? e?.expiry ?? e?.expiration);
  if (c !== null && c <= Date.now() / 1e3) return null;
  const m = {
    url: `${y ? "https" : "http"}://${a}${l}`,
    name: t,
    value: n,
    path: l,
    secure: y,
    httpOnly: e?.httpOnly === !0 || e?.http_only === !0,
    sameSite: s === "no_restriction" && !y ? "unspecified" : s,
  };
  return (p || (m.domain = `.${a.replace(/^\./, "")}`), c !== null && (m.expirationDate = c), m);
}
function parseTnCookiePayload(e) {
  const t = String(e || "").trim();
  if (!t) throw new Error("\u8BF7\u7C98\u8D34Cookie");
  let o = [];
  if (t.startsWith("[") || t.startsWith("{") || (t.startsWith('"') && t.endsWith('"')))
    try {
      const n = JSON.parse(t);
      o = rowsFromJson(n);
    } catch {
      throw new Error("Cookie JSON\u683C\u5F0F\u4E0D\u6B63\u786E");
    }
  else
    /^#\s*Netscape HTTP Cookie File/im.test(t) ||
    /^(?:#HttpOnly_)?[^\t]+\t(?:TRUE|FALSE)\t/im.test(t)
      ? (o = rowsFromNetscape(t))
      : /^Set-Cookie\s*:/im.test(t)
        ? (o = rowsFromSetCookie(t))
        : ((o = rowsFromDevtools(t)), o.length || (o = rowsFromHeader(t)));
  let r = o.map(normalizeCookieRow).filter(Boolean);
  if (
    (!r.length &&
      !(t.startsWith("[") || t.startsWith("{")) &&
      (r = rowsFromLooseText(t).map(normalizeCookieRow).filter(Boolean)),
    !r.length)
  )
    throw new Error(
      "\u6CA1\u6709\u627E\u5230\u6709\u6548\u7684TextNow Cookie\uFF1B\u683C\u5F0F\u4E0D\u652F\u6301\u3001\u57DF\u540D\u4E0D\u6B63\u786E\u6216Cookie\u5DF2\u8FC7\u671F",
    );
  return r.slice(0, 500);
}
function splitTnCookiePayloads(e) {
  const t = String(e || "").trim();
  if (!t) return [""];
  const n = (s) => JSON.stringify(s?.cookies ?? s?.cookie ?? s?.cookieData ?? s),
    i = (s) =>
      s &&
      typeof s == "object" &&
      !Array.isArray(s) &&
      WRAPPER_KEYS.some((c) => Array.isArray(s[c]) || (s[c] && typeof s[c] == "object")),
    r = (s) =>
      Array.isArray(s?.accounts)
        ? s.accounts.map(n)
        : Array.isArray(s?.profiles)
          ? s.profiles.map(n)
          : Array.isArray(s) && s.length && s.every(Array.isArray)
            ? s.map(JSON.stringify)
            : Array.isArray(s) && s.length && s.every(i)
              ? s.map(n)
              : [JSON.stringify(s)];
  try {
    return r(JSON.parse(t));
  } catch {}
  const o = t
    .split(/\r?\n\s*-{3,}\s*\r?\n|\r?\n\s*={3,}\s*\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (o.length > 1) return o.flatMap((s) => splitTnCookiePayloads(s));
  const a = [];
  if (/^[\[{]/.test(t)) {
    let s = -1,
      c = 0,
      m = !1,
      f = !1;
    for (let g = 0; g < t.length; g += 1) {
      const h = t[g];
      if (m) {
        f ? (f = !1) : h === "\\" ? (f = !0) : h === '"' && (m = !1);
        continue;
      }
      if (h === '"') {
        m = !0;
        continue;
      }
      if (h === "[" || h === "{") (c === 0 && (s = g), (c += 1));
      else if ((h === "]" || h === "}") && c > 0 && ((c -= 1), c === 0 && s >= 0)) {
        try {
          a.push(...r(JSON.parse(t.slice(s, g + 1))));
        } catch {}
        s = -1;
      }
    }
  }
  if (a.length) return a;
  const u = (s) => {
      let c = String(s || "").trim();
      return (c.startsWith('"') && c.endsWith('"') && (c = c.slice(1, -1).replace(/""/g, '"')), c);
    },
    l = (s) => {
      const c = u(s),
        m = c.match(/(?:^|;\s*)[^\s=;\t]{1,80}=/g)?.length || 0,
        f =
          /(?:^|;\s*)(?:connect\.sid|ppid|_cfuvid|xsrf-token|_csrf|g_state|_px\w*|_ga\w*|pptz|pxcts)=/i.test(
            c,
          );
      return m + (f ? 5 : 0);
    },
    p = t
      .split(/\r?\n/)
      .map(
        (s) =>
          s
            .split("	")
            .map(u)
            .sort((c, m) => l(m) - l(c))[0] || "",
      )
      .filter((s) => l(s) >= 3);
  if (p.length >= 2) return p;
  const y = t
    .split(/\r?\n\s*\r?\n+/)
    .map((s) => s.trim())
    .filter(Boolean);
  return y.length > 1 ? y : [t];
}
function inspectTnCookiePayloads(e) {
  const t = splitTnCookiePayloads(e),
    n = [],
    i = [];
  return (
    t.forEach((r, o) => {
      try {
        n.push({ index: o + 1, batch: r, cookieCount: parseTnCookiePayload(r).length });
      } catch (a) {
        i.push({ index: o + 1, message: a?.message || "CK\u65E0\u6548" });
      }
    }),
    { detected: t.length, valid: n, invalid: i }
  );
}
module.exports = { parseTnCookiePayload, splitTnCookiePayloads, inspectTnCookiePayloads };
