-- Orange AI Assistant 0.9.1: permission hardening + TN compatibility migration.
-- This migration is additive and does not overwrite existing administrator choices.
-- Run after the older formal schema. It is also safe when 0.9.0 feature flags were not run yet.

create table if not exists public.plan_permissions (
  plan text not null,
  feature_code text not null,
  enabled boolean not null default false,
  primary key (plan, feature_code)
);

create table if not exists public.user_permission_overrides (
  user_id uuid not null references public.profiles(id) on delete cascade,
  feature_code text not null,
  enabled boolean not null default false,
  primary key (user_id, feature_code)
);

create table if not exists public.app_feature_flags (
  feature_key text primary key check (feature_key ~ '^[a-z][a-z0-9_]{1,49}$'),
  parent_key text references public.app_feature_flags(feature_key) on delete restrict,
  label text not null,
  enabled boolean not null default true,
  fail_closed boolean not null default false,
  sort_order integer not null default 100,
  reason text not null default '',
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null
);

create table if not exists public.app_feature_flag_audit (
  id bigint generated always as identity primary key,
  feature_key text not null,
  old_enabled boolean,
  new_enabled boolean not null,
  reason text not null,
  changed_by uuid references auth.users(id) on delete set null,
  changed_at timestamptz not null default now()
);

alter table public.app_feature_flags enable row level security;
alter table public.app_feature_flag_audit enable row level security;

drop policy if exists feature_flags_authenticated_read on public.app_feature_flags;
create policy feature_flags_authenticated_read on public.app_feature_flags
for select to authenticated using (true);

revoke all on public.app_feature_flags from anon;
revoke all on public.app_feature_flag_audit from anon, authenticated;
grant select on public.app_feature_flags to authenticated;

-- Keep existing enabled/disabled values. Only labels, parent relationships and safety metadata are refreshed.
insert into public.app_feature_flags(feature_key,parent_key,label,enabled,fail_closed,sort_order) values
('module_tn',null,'TN账号与发送台',true,true,100),
('tn_accounts','module_tn','TN账号管理与打开',true,true,110),
('tn_sender','module_tn','TN发送台',false,true,120),
('tn_dom_test','module_tn','TN定位测试',false,true,130),
('tn_live_test','module_tn','TN测试实发',false,true,140),
('module_messaging',null,'站内消息',true,false,200),
('messaging_text','module_messaging','站内文字私聊',true,false,210),
('messaging_attachments','module_messaging','站内图片与文件',true,false,220),
('messaging_announcements','module_messaging','公告',true,false,230),
('module_translation',null,'翻译功能',true,false,300),
('chat_translate','module_translation','聊天翻译',true,false,310),
('page_translate','module_translation','网页翻译',true,false,320),
('input_translate','module_translation','输入翻译',true,false,330),
('module_ai',null,'AI功能',true,false,400),
('ai_reply','module_ai','AI智能回复',true,false,410),
('reengage','module_ai','客户回流',true,false,420),
('personal_groq_key','module_ai','个人AI Key',true,false,430),
('public_groq_pool','module_ai','公共AI模型',true,false,440),
('module_privacy',null,'号码与隐私显示',true,false,500),
('phone_mask','module_privacy','号码遮挡',true,false,510),
('phone_mask_custom_text','module_privacy','遮挡文字自定义',true,false,520),
('phone_mask_custom_color','module_privacy','遮挡颜色自定义',true,false,530),
('module_visuals',null,'界面效果',true,false,600),
('custom_background','module_visuals','自定义背景',true,false,610),
('bubble_effect','module_visuals','气泡特效与跑马灯',true,false,620),
('module_proxy',null,'线路与查询',true,false,700),
('proxy_pool','module_proxy','翻译IP线路',true,false,710),
('area_lookup','module_proxy','自动区号查询',true,false,720)
on conflict(feature_key) do update set
  parent_key=excluded.parent_key,
  label=excluded.label,
  fail_closed=excluded.fail_closed,
  sort_order=excluded.sort_order;

-- Ensure permission definitions exist before plan_permissions rows are written.
-- Older production databases enforce plan_permissions.feature_code -> features.code,
-- so inserting plan rows first would abort the migration with FK 23503.
do $$
begin
  if to_regclass('public.features') is null then
    raise exception 'public.features does not exist; run the base permissions schema first';
  end if;

  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='features' and column_name='name_zh'
  ) and exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='features' and column_name='description_zh'
  ) then
    insert into public.features(code,name_zh,description_zh) values
      ('tn_assistant','TN助手','允许员工使用TN助手功能'),
      ('tn_accounts','TN账号管理','允许员工管理和打开分配给自己的TN账号'),
      ('tn_sender','TN发送台','允许员工使用TN发送台及发送功能'),
      ('tn_dom_test','TN DOM测试','允许员工使用TN页面DOM测试功能'),
      ('tn_live_test','TN真实发送测试','允许员工执行TN真实发送测试')
    on conflict(code) do update set
      name_zh=excluded.name_zh,
      description_zh=excluded.description_zh;
  else
    -- Minimal compatibility path for older schemas that only expose `code`.
    execute $sql$
      insert into public.features(code) values
        ('tn_assistant'),('tn_accounts'),('tn_sender'),('tn_dom_test'),('tn_live_test')
      on conflict(code) do nothing
    $sql$;
  end if;
end $$;

-- 0.9.1 adds an independent master permission for all Orange Assistant features inside TN.
-- Missing permission rows are denied by the client/Edge Function, so only insert defaults when absent.
insert into public.plan_permissions(plan,feature_code,enabled)
select v.plan,v.feature_code,v.enabled
from (values
  ('basic','tn_assistant',false),
  ('basic','tn_accounts',true),
  ('basic','tn_sender',false),
  ('basic','tn_dom_test',false),
  ('basic','tn_live_test',false),
  ('advanced','tn_assistant',true),
  ('advanced','tn_accounts',true),
  ('advanced','tn_sender',false),
  ('advanced','tn_dom_test',false),
  ('advanced','tn_live_test',false)
) as v(plan,feature_code,enabled)
where not exists (
  select 1 from public.plan_permissions p
  where p.plan=v.plan and p.feature_code=v.feature_code
);

-- 0.9.1 membership rule: Basic is a fixed fallback tier. It can enter the
-- platform and open assigned TN accounts through their IP, but every helper,
-- translation, AI, sender and test permission is disabled.
update public.plan_permissions
set enabled = case when feature_code = 'tn_accounts' then true else false end
where plan = 'basic';

-- SECURITY DEFINER RPC hardening. PostgreSQL grants EXECUTE on new functions to PUBLIC by
-- default; explicitly remove that broad grant and allow only signed-in users. The functions
-- themselves still bind all writes/reads to auth.uid() and the admin-only list RPC checks role.
do $$
begin
  if to_regprocedure('public.set_my_tn_account_count(integer)') is not null then
    revoke execute on function public.set_my_tn_account_count(integer) from public, anon;
    grant execute on function public.set_my_tn_account_count(integer) to authenticated;
  end if;
  if to_regprocedure('public.list_tn_account_counts()') is not null then
    revoke execute on function public.list_tn_account_counts() from public, anon;
    grant execute on function public.list_tn_account_counts() to authenticated;
  end if;
end $$;

-- Older schemas may keep announcement authors with ON DELETE RESTRICT. Make employee deletion safe
-- while preserving historical announcements. Skip cleanly if messaging has not been installed.
do $$
declare item record;
begin
  if to_regclass('public.app_announcements') is not null then
    alter table public.app_announcements alter column created_by drop not null;
    for item in
      select conname from pg_constraint
      where conrelid='public.app_announcements'::regclass
        and contype='f'
        and pg_get_constraintdef(oid) ilike '%created_by%profiles%'
    loop
      execute format('alter table public.app_announcements drop constraint %I', item.conname);
    end loop;
    alter table public.app_announcements
      add constraint app_announcements_created_by_fkey
      foreign key (created_by) references public.profiles(id) on delete set null;
  end if;
end $$;
