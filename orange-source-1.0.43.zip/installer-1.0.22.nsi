Unicode true
RequestExecutionLevel user
SetCompressor /SOLID lzma
!include "MUI2.nsh"
!define PRODUCT_NAME "橘子AI助手"
!define PRODUCT_VERSION "1.0.22"
!define PRODUCT_EXE "橘子AI助手.exe"
!define INSTALL_ROOT "$LOCALAPPDATA\Programs\orange-ai-internal"
Name "${PRODUCT_NAME} ${PRODUCT_VERSION}"
OutFile "dist\Orange-AI-Assistant-Setup-1.0.22.exe"
InstallDir "${INSTALL_ROOT}"
InstallDirRegKey HKCU "Software\OrangeAI\Assistant" "InstallDir"
BrandingText "${PRODUCT_NAME}"
Icon "build\icon.ico"
UninstallIcon "build\icon.ico"
VIProductVersion "1.0.22.1"
VIAddVersionKey /LANG=2052 "ProductName" "${PRODUCT_NAME}"
VIAddVersionKey /LANG=2052 "ProductVersion" "${PRODUCT_VERSION}"
VIAddVersionKey /LANG=2052 "CompanyName" "Orange AI"
VIAddVersionKey /LANG=2052 "FileDescription" "${PRODUCT_NAME} Windows 安装程序"
VIAddVersionKey /LANG=2052 "FileVersion" "1.0.22.1"
!define MUI_ABORTWARNING
!define MUI_ICON "build\icon.ico"
!define MUI_UNICON "build\icon.ico"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN "$INSTDIR\${PRODUCT_EXE}"
!define MUI_FINISHPAGE_RUN_TEXT "立即运行橘子AI助手"
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "SimpChinese"
Section "安装" SEC_MAIN
  SetShellVarContext current
  SetOutPath "$INSTDIR"
  File /r /x "Uninstall 橘子AI助手.exe" "dist\win-unpacked\*.*"
  WriteUninstaller "$INSTDIR\Uninstall 橘子AI助手.exe"
  CreateDirectory "$SMPROGRAMS\橘子AI助手"
  CreateShortcut "$DESKTOP\橘子AI助手.lnk" "$INSTDIR\${PRODUCT_EXE}"
  CreateShortcut "$SMPROGRAMS\橘子AI助手\橘子AI助手.lnk" "$INSTDIR\${PRODUCT_EXE}"
  CreateShortcut "$SMPROGRAMS\橘子AI助手\卸载橘子AI助手.lnk" "$INSTDIR\Uninstall 橘子AI助手.exe"
  WriteRegStr HKCU "Software\OrangeAI\Assistant" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OrangeAIAssistant" "DisplayName" "${PRODUCT_NAME}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OrangeAIAssistant" "DisplayVersion" "${PRODUCT_VERSION}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OrangeAIAssistant" "Publisher" "Orange AI"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OrangeAIAssistant" "DisplayIcon" "$INSTDIR\${PRODUCT_EXE}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OrangeAIAssistant" "UninstallString" '\"$INSTDIR\Uninstall 橘子AI助手.exe\"'
SectionEnd
Section "Uninstall"
  SetShellVarContext current
  Delete "$DESKTOP\橘子AI助手.lnk"
  Delete "$SMPROGRAMS\橘子AI助手\橘子AI助手.lnk"
  Delete "$SMPROGRAMS\橘子AI助手\卸载橘子AI助手.lnk"
  RMDir "$SMPROGRAMS\橘子AI助手"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OrangeAIAssistant"
  DeleteRegKey HKCU "Software\OrangeAI\Assistant"
  RMDir /r "$INSTDIR"
SectionEnd
