-- Orange AI Assistant 0.9.1
-- Membership fallback patch
-- Business rule:
--   1) Expired Advanced members automatically become Basic instead of losing login.
--   2) Basic is a fixed restricted tier: platform access + assigned TN account/IP login only.
--   3) Basic has no TN assistant, translation, AI, sender, DOM test, live test, or other helper permissions.
-- Safe to re-run.

begin;

-- Enforce the fixed Basic permission profile at database level.
update public.plan_permissions
set enabled = false
where plan = 'basic';

insert into public.plan_permissions(plan, feature_code, enabled)
values ('basic', 'tn_accounts', true)
on conflict (plan, feature_code)
do update set enabled = excluded.enabled;

-- Immediately convert already-expired active Advanced members.
-- Future expiries are handled by the updated session-control/admin-users Edge Functions.
update public.profiles
set plan = 'basic',
    valid_until = null,
    updated_at = now()
where role = 'user'
  and plan = 'advanced'
  and account_status = 'active'
  and valid_until is not null
  and valid_until <= now();

commit;

-- Verification: Basic should show tn_accounts=true and every other existing permission=false.
select plan, feature_code, enabled
from public.plan_permissions
where plan = 'basic'
order by feature_code;
