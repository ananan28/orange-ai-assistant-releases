# 橘子AI助手 1.0.0 交付说明

## 已完成

- Supabase 数据库迁移 `orange_1_0_0_tn_smart_pool` 已上线。
- `admin-users` Edge Function v43 已上线，JWT 验证开启。
- `proxy-control` Edge Function v16 已上线，JWT 验证开启。
- 代理删除会统计员工及TN分组绑定，支持确认解绑后删除，并显示真实错误。
- 新增 TN、翻译、共用三类IP池；TN导入默认 SOCKS5，支持设置单IP容量。
- 新增并发安全的TN账号级固定IP绑定与智能分配数据库函数。
- 同一员工批量导入TN账号时，会按剩余容量自动续接下一条IP分组。
- 发送前默认清理隐藏字符和异常隔行，并提供“保留原始段落”开关。
- 小橘子外观设置改为互斥抽屉并自动定位。
- 网站账号悬浮面板可直接删除账号，密码继续使用系统安全存储。
- 区号详情加入谷歌重新查询入口。
- 保留 OpenAI 官方、Groq、Gemini、OpenAI兼容API入口；Google翻译优先，AI备用。

## 验证结果

- TN核心：25项通过。
- UI回归：42项通过。
- TN DOM定位测试通过。
- TN Cookie多格式解析测试通过。
- 主进程、预加载脚本、工作台及扩展脚本语法检查通过。
- Windows x64 unpacked 程序完成 afterPack 校验。

## 构建

在Windows电脑解压源码，运行 `build-windows.bat`，即可生成 `dist/Orange-AI-Assistant-Setup-1.0.0.exe`。
