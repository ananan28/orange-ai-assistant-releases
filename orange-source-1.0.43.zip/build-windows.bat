@echo off
setlocal
cd /d "%~dp0"
call npm ci --no-audit --no-fund
if errorlevel 1 exit /b 1
call npm run check
if errorlevel 1 exit /b 1
call npm run dist:win
if errorlevel 1 exit /b 1
echo Installer is ready in dist. Nothing was published.
pause
