-- Orange AI Assistant 0.9.0: global emergency feature switches.
-- Run once in Supabase SQL Editor, then deploy SUPABASE-admin-users.ts.

create table if not exists public.app_feature_flags (
  feature_key text primary key check (feature_key ~ '^[a-z][a-z0-9_]{1,49}$'),
  parent_key text references public.app_feature_flags(feature_key) on delete restrict,
  label text not null,
  enabled boolean not null default true,
  fail_closed boolean not null default false,
  sort_order integer not null default 100,
  reason text not null default '',
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null
);

create table if not exists public.app_feature_flag_audit (
  id bigint generated always as identity primary key,
  feature_key text not null,
  old_enabled boolean,
  new_enabled boolean not null,
  reason text not null,
  changed_by uuid references auth.users(id) on delete set null,
  changed_at timestamptz not null default now()
);

alter table public.app_feature_flags enable row level security;
alter table public.app_feature_flag_audit enable row level security;

drop policy if exists feature_flags_authenticated_read on public.app_feature_flags;
create policy feature_flags_authenticated_read on public.app_feature_flags
for select to authenticated using (true);

insert into public.app_feature_flags(feature_key,parent_key,label,enabled,fail_closed,sort_order) values
('module_tn',null,'TN账号与发送台',true,true,100),
('tn_accounts','module_tn','TN账号管理与打开',true,true,110),
('tn_sender','module_tn','TN发送台',false,true,120),
('tn_dom_test','module_tn','TN定位测试',false,true,130),
('tn_live_test','module_tn','TN测试实发',false,true,140),
('module_messaging',null,'站内消息',true,false,200),
('messaging_text','module_messaging','站内文字私聊',true,false,210),
('messaging_attachments','module_messaging','站内图片与文件',true,false,220),
('messaging_announcements','module_messaging','公告',true,false,230),
('module_translation',null,'翻译功能',true,false,300),
('chat_translate','module_translation','聊天翻译',true,false,310),
('page_translate','module_translation','网页翻译',true,false,320),
('input_translate','module_translation','输入翻译',true,false,330),
('module_ai',null,'AI功能',true,false,400),
('ai_reply','module_ai','AI智能回复',true,false,410),
('reengage','module_ai','客户回流',true,false,420),
('personal_groq_key','module_ai','个人AI Key',true,false,430),
('public_groq_pool','module_ai','公共AI模型',true,false,440),
('module_privacy',null,'号码与隐私显示',true,false,500),
('phone_mask','module_privacy','号码遮挡',true,false,510),
('phone_mask_custom_text','module_privacy','遮挡文字自定义',true,false,520),
('phone_mask_custom_color','module_privacy','遮挡颜色自定义',true,false,530),
('module_visuals',null,'界面效果',true,false,600),
('custom_background','module_visuals','自定义背景',true,false,610),
('bubble_effect','module_visuals','气泡特效与跑马灯',true,false,620),
('module_proxy',null,'线路与查询',true,false,700),
('proxy_pool','module_proxy','翻译IP线路',true,false,710),
('area_lookup','module_proxy','自动区号查询',true,false,720)
on conflict(feature_key) do update set
  parent_key=excluded.parent_key,label=excluded.label,fail_closed=excluded.fail_closed,sort_order=excluded.sort_order;

revoke all on public.app_feature_flags from anon;
revoke all on public.app_feature_flag_audit from anon, authenticated;
grant select on public.app_feature_flags to authenticated;

-- TN还需要会员等级权限。只为缺失项补默认值，不覆盖管理员已经保存的设置。
insert into public.plan_permissions(plan,feature_code,enabled) values
('basic','tn_accounts',false),
('basic','tn_sender',false),
('basic','tn_dom_test',false),
('basic','tn_live_test',false),
('advanced','tn_accounts',true),
('advanced','tn_sender',false),
('advanced','tn_dom_test',false),
('advanced','tn_live_test',false)
on conflict(plan,feature_code) do nothing;
