-- Orange AI Assistant 1.0.20: bulk membership permissions for managed platforms.
-- Additive and idempotent. Existing permission choices are preserved.

do $$
begin
  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='features' and column_name='name_zh'
  ) and exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='features' and column_name='description_zh'
  ) then
    insert into public.features(code,name_zh,description_zh) values
      ('platform_whatsapp','WhatsApp 多账号','允许使用 WhatsApp 独立账号管理与打开'),
      ('platform_telegram','Telegram 多账号','允许使用 Telegram 独立账号管理与打开'),
      ('platform_gmail','Google 邮箱多账号','允许使用 Google 邮箱独立账号管理与打开')
    on conflict(code) do update set
      name_zh=excluded.name_zh,
      description_zh=excluded.description_zh;
  else
    insert into public.features(code) values
      ('platform_whatsapp'),('platform_telegram'),('platform_gmail')
    on conflict(code) do nothing;
  end if;
end $$;

insert into public.plan_permissions(plan,feature_code,enabled) values
  ('basic','platform_whatsapp',false),
  ('basic','platform_telegram',false),
  ('basic','platform_gmail',true),
  ('advanced','platform_whatsapp',false),
  ('advanced','platform_telegram',false),
  ('advanced','platform_gmail',true)
on conflict(plan,feature_code) do nothing;
