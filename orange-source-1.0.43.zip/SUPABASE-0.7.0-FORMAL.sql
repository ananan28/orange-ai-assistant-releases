-- 橘子AI助手 0.7.0 正式版非破坏性升级
-- 仅在现有正式 Supabase 项目执行一次；不会删除员工、权限、IP池或历史数据。

create table if not exists public.tn_proxy_groups (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  group_name text not null,
  proxy_id uuid not null references public.translation_proxy_pool(id) on delete restrict,
  max_accounts integer default 30 check (max_accounts is null or max_accounts >= 1),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (owner_user_id, group_name)
);

alter table public.tn_proxy_groups enable row level security;
revoke all on public.tn_proxy_groups from anon, authenticated;
grant all on public.tn_proxy_groups to service_role;

create index if not exists tn_proxy_groups_owner_idx on public.tn_proxy_groups(owner_user_id);
create index if not exists tn_proxy_groups_proxy_idx on public.tn_proxy_groups(proxy_id);

comment on table public.tn_proxy_groups is
  'TextNow account groups permanently pinned to one administrator-managed proxy.';

