-- Orange AI Assistant 0.8.5: allow user deletion without losing old announcements.
-- Run once after the 0.8.4 messaging attachment SQL.

alter table public.app_announcements alter column created_by drop not null;

do $$
declare item record;
begin
  for item in
    select conname from pg_constraint
    where conrelid = 'public.app_announcements'::regclass
      and contype = 'f'
      and pg_get_constraintdef(oid) ilike '%created_by%profiles%'
  loop
    execute format('alter table public.app_announcements drop constraint %I', item.conname);
  end loop;
end $$;

alter table public.app_announcements
  add constraint app_announcements_created_by_fkey
  foreign key (created_by) references public.profiles(id) on delete set null;

alter table public.devices add column if not exists last_ip inet null;

create table if not exists public.blocked_client_ips (
  id uuid primary key default gen_random_uuid(),
  ip_address inet not null unique,
  reason text not null default '管理员封禁',
  blocked_by uuid null references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists blocked_client_ips_address_idx on public.blocked_client_ips(ip_address);
alter table public.blocked_client_ips enable row level security;
revoke all on public.blocked_client_ips from anon, authenticated;
grant all on public.blocked_client_ips to service_role;
