"use strict";

const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const stable = fs.readFileSync(path.join(root, "tn-stable-core.js"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const preload = fs.readFileSync(path.join(root, "site-preload.js"), "utf8");
const appSource = fs.readFileSync(path.join(root, "src", "app.js"), "utf8");
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
const betaExtensionManifest = JSON.parse(fs.readFileSync(path.join(root, "tn-beta-extension-source", "manifest.json"), "utf8"));

const checks = [
  [pkg.version === "1.0.43", "candidate version is 1.0.43"],
  [/sourceVersion\s*:\s*"0\.7\.0-beta\.6"/.test(stable), "Beta.6 source contract"],
  [/partitionPrefix\s*:\s*"persist:orange-beta-tn-"/.test(stable), "Beta.6 partition identity"],
  [/backgroundThrottling\s*:\s*!1/.test(stable), "1.0.32 stable background execution contract"],
  [main.includes('require("./tn-stable-core")'), "formal runtime uses stable TN contract"],
  [main.includes("TN_STABLE_BASE.partitionPrefix"), "stable partition prefix is not redefined"],
  [main.includes("backgroundWebPreferences("), "stable browser preferences are used"],
  [main.includes("tnStablePermissionAllowed("), "stable permission policy is used"],
  [main.includes("TN_STABLE_BASE.messagingUrl"), "stable messaging entry is used"],
  [!main.includes('accountSession.setUserAgent'), "no TN user-agent spoofing"],
  [!main.includes('ipcMain.on("tn:verification-state"'), "no synthetic verification monitor"],
  [!preload.includes("verification-state"), "preload does not drive verification"],
  [preload.includes("isTextNowHost") && /isOpenAiLoginHost\s*\|\|\s*isTextNowHost/.test(preload), "formal credential DOM observer is excluded from TN"],
  [main.includes('ipcMain.handle("tn:import-cookies"') && !main.includes('clearStorageData({ storages: ["localstorage"]'), "non-destructive CK merge"],
  [!main.includes('webPreferences:{ partition, preload:path.join(__dirname, "site-preload.js"), contextIsolation:true, nodeIntegration:false, sandbox:true, backgroundThrottling:false }'), "TN browser preference is not redefined inline"],
  [main.includes('ipcMain.handle("tn:send-one"'), "formal TN sender feature retained"],
  [main.includes('ipcMain.handle("tn:add"'), "formal TN account management retained"],
  [main.includes('ipcMain.handle("auth:login"') && main.includes('ipcMain.handle("auth:logout"'), "formal login and logout retained"],
  [main.includes('supabase.auth.updateUser') && main.includes("currentPermissions"), "formal password and permission systems retained"],
  [appSource.includes("data-admin-nav") && appSource.includes("account_status"), "formal administrator and employee UI retained"],
  [/autoUpdater\.allowPrerelease\s*=\s*(?:false|!1)/.test(main), "employees receive formal fusion releases only"],
  [/return partitionFor\([^)]+\.id\)/.test(main) && !main.includes("migrateFormalTnPartitionsToStable"), "all TN accounts use the Beta.6 partition directly"],
  [appSource.includes("runNextTnSendAssignment") &&  /performTnSend\(\w+,\s*"tn_sender"\)/.test(main), "formal sender console is attached outside the stable TN core"]
  ,[main.includes("prepareBeta6FullProfileMigration(") && main.includes("beta6FullProfileImportedByUser") && main.includes("fs.cpSync("), "complete Beta.6 browser profile auto-migration"]
  ,[main.includes("ensureTnStableExtensionLoaded(") && betaExtensionManifest.version === "3.1.5", "TN uses the exact Beta.6 extension chain"]
];

const failed = checks.filter(([ok]) => !ok).map(([, label]) => label);
if (failed.length) {
  console.error(`[TN CORE ERROR] ${failed.join(", ")}`);
  process.exit(1);
}
console.log(`[TN CORE OK] ${checks.length} stable-core and formal-feature checks passed`);
