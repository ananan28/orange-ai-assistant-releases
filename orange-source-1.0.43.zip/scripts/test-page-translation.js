const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const preload = fs.readFileSync(path.join(root, "site-preload.js"), "utf8");
const workbench = fs.readFileSync(path.join(root, "src", "workbench.js"), "utf8");

const checks = [
  [main.includes('"\\u7FFB\\u8BD1\\u6210\\u4E2D\\u6587\\uFF08\\u7B80\\u4F53\\uFF09"'), "native page-translation menu"],
  [main.includes('send("page-translation:set"'), "menu starts page translation"],
  [main.includes('send("page-translation:restore"'), "menu restores original page"],
  [main.includes('featureAllowed("page_translate")'), "page translation permission gate"],
  [preload.includes('featureCode: "page_translate"'), "translation uses page permission"],
  [preload.includes('targetLanguage: "zh-CN"'), "Simplified Chinese target"],
  [preload.includes("new MutationObserver"), "dynamic content observer"],
  [preload.includes('"textarea"') && preload.includes('"[contenteditable=\'true\']"'), "editable fields excluded"],
  [/\.clear\(\)[\s\S]{0,120}page-translation:status/.test(preload), "restore cleanup"],
  [preload.includes('"#orange-page-translation-toast"'), "translation UI excluded from traversal"],
  [workbench.includes("function openTab("), "workbench tab implementation retained"],
  [main.includes("openWorkbenchTabLike113"), "1.0.13 web opening path retained"],
];

const failed = checks.filter(([ok]) => !ok).map(([, label]) => label);
if (failed.length) {
  console.error(`[PAGE TRANSLATION ERROR] Missing: ${failed.join(", ")}`);
  process.exit(1);
}
console.log(`[PAGE TRANSLATION OK] ${checks.length} checks passed`);
