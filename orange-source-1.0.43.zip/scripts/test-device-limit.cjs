const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict'),esbuild=require('esbuild');const root=path.resolve(__dirname,'..');
const source=fs.readFileSync(path.join(root,'SUPABASE-admin-users.ts'),'utf8');const part=source.slice(source.indexOf('function validateDeviceLimit'),source.indexOf('function validateDate'));const ctx={};vm.createContext(ctx);vm.runInContext(esbuild.transformSync(part,{loader:'ts'}).code,ctx);
for(const n of [1,10,50])assert.equal(ctx.validateDeviceLimit(n),n);
for(const n of [0,-1,51,1.5,NaN])assert.throws(()=>ctx.validateDeviceLimit(n));
assert.ok(source.includes('body.deviceLimit ?? 50'));assert.ok(source.includes('auth: "user"'));assert.ok(source.includes('caller.role !== "admin"'));
const html=fs.readFileSync(path.join(root,'src/index.html'),'utf8');for(const id of ['new-device-limit','edit-user-device-limit']){const tag=html.slice(html.indexOf('id="'+id+'"'),html.indexOf('>',html.indexOf('id="'+id+'"')));assert.ok(tag.includes('max="50"'));}console.log('PASS: device range 1–50, default 50, UI controls, user/admin authorization preserved.');
