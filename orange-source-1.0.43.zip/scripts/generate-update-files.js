"use strict";
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { buildBlockMap } = require("app-builder-lib/out/targets/blockmap/blockmap");

(async () => {
  const root = path.resolve(__dirname, "..");
  const packageJson = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
  const version = String(packageJson.version || "").trim();
  if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(version)) {
    throw new Error(`Invalid package version: ${version || "(empty)"}`);
  }
  const name = `Orange-AI-Assistant-Setup-${version}.exe`;
  const file = path.join(root, "dist", name);
  if (!fs.existsSync(file)) throw new Error(`Installer is missing: ${file}`);
  const blockmap = `${file}.blockmap`;
  const result = await buildBlockMap(file, "deflate", blockmap);
  const yml = [
    `version: ${version}`,
    "files:",
    `  - url: ${name}`,
    `    sha512: ${result.sha512}`,
    `    size: ${result.size}`,
    `path: ${name}`,
    `sha512: ${result.sha512}`,
    `releaseDate: '${new Date().toISOString()}'`,
    "",
  ].join("\n");
  fs.writeFileSync(path.join(root, "dist", "latest.yml"), yml);
  const sha256 = crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
  fs.writeFileSync(`${file}.sha256.txt`, `${sha256}  ${name}\n`);
  console.log(`[update OK] ${name}, ${result.size} bytes`);
})();
