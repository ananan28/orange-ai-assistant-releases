"use strict";

const assert = require("node:assert/strict");
const { parseTnCookiePayload, splitTnCookiePayloads, inspectTnCookiePayloads } = require("../tn-cookie-parser");

const future = Math.floor(Date.now() / 1000) + 86400;

const header = parseTnCookiePayload('Cookie: connect.sid=s%3Atest.signature; token=a=b=c; g_state={"i_l":0,"enabled":true}');
assert.equal(header.length, 3);
assert.equal(header.find(row => row.name === "token").value, "a=b=c");
assert.equal(header.find(row => row.name === "connect.sid").domain, ".textnow.com", "request-header cookies should use Beta.6-compatible TextNow domain scope");
assert.equal(Object.hasOwn(header[0], "expirationDate"), false, "header session cookies must stay session cookies");

const editor = parseTnCookiePayload(JSON.stringify([
  { name:"connect.sid", value:"signed", domain:"www.textnow.com", path:"/messaging", secure:true, httpOnly:true, sameSite:"Lax", expirationDate:future },
  { name:"__Host-test", value:"host-only", domain:"www.textnow.com", path:"/", secure:true, hostOnly:true }
]));
assert.equal(editor[0].domain, ".www.textnow.com");
assert.equal(editor[0].path, "/messaging");
assert.equal(editor[0].httpOnly, true);
assert.equal(editor[0].sameSite, "lax");
assert.equal(editor[0].expirationDate, future);
assert.equal(Object.hasOwn(editor[1], "domain"), false, "host-only cookie must not gain a Domain attribute");

const mapped = parseTnCookiePayload(JSON.stringify({ "connect.sid":"mapped", "XSRF-TOKEN":"csrf" }));
assert.equal(mapped.length, 2);

const netscape = parseTnCookiePayload(`# Netscape HTTP Cookie File\n.textnow.com\tTRUE\t/\tTRUE\t${future}\tconnect.sid\tnetscape`);
assert.equal(netscape.length, 1);
assert.equal(netscape[0].value, "netscape");

const devtools = parseTnCookiePayload(`Name\tValue\tDomain\tPath\tExpires\tHttpOnly\tSecure\tSameSite\nconnect.sid\tdevtools\t.textnow.com\t/\t${future}\ttrue\ttrue\tLax`);
assert.equal(devtools.length, 1);
assert.equal(devtools[0].httpOnly, true);

const csv = parseTnCookiePayload(`Name,Value,Domain,Path,Expires,HttpOnly,Secure,SameSite\nconnect.sid,"csv,value",.textnow.com,/,${future},true,true,Lax`);
assert.equal(csv[0].value, "csv,value");

const setCookie = parseTnCookiePayload(`Set-Cookie: connect.sid=set-cookie; Domain=.textnow.com; Path=/; HttpOnly; Secure; SameSite=Lax\nSet-Cookie: token=second; Domain=www.textnow.com; Path=/messaging; Secure`);
assert.equal(setCookie.length, 2);
assert.equal(setCookie[0].httpOnly, true);

const curl = parseTnCookiePayload(`curl 'https://www.textnow.com/messaging' -H 'Cookie: connect.sid=curl; token=test'`);
assert.equal(curl.length, 2);

const har = parseTnCookiePayload(JSON.stringify({log:{entries:[{request:{cookies:[{name:"connect.sid",value:"har",domain:"www.textnow.com",path:"/"}]}}]}}));
assert.equal(har.length, 1);

const encodedJson = parseTnCookiePayload(JSON.stringify(JSON.stringify([{name:"connect.sid",value:"encoded",domain:".textnow.com"}])));
assert.equal(encodedJson.length, 1);

const unknownWrapper = parseTnCookiePayload(JSON.stringify({vendorExport:{payload:{browserProfile:{records:[{Name:"connect.sid",Value:"wrapped=a=b",Domain:".textnow.com",Path:"/"}]}}}}));
assert.equal(unknownWrapper.length, 1, "unknown nested exporter wrappers must be traversed");
assert.equal(unknownWrapper[0].value, "wrapped=a=b");

const documentCookie = parseTnCookiePayload(`document.cookie = "alpha=value==; signed.token=s%3Aabc.def==; json={\\"nested\\":true}"`);
assert.equal(documentCookie.length, 3);
assert.equal(documentCookie.find(row => row.name === "signed.token").value, "s%3Aabc.def==");

assert.throws(() => parseTnCookiePayload(JSON.stringify([{ name:"expired", value:"x", domain:".textnow.com", expirationDate:1 }])), /已过期/);
assert.throws(() => parseTnCookiePayload(JSON.stringify([{ name:"foreign", value:"x", domain:"example.com" }])), /域名不正确/);

const batches = splitTnCookiePayloads(`${JSON.stringify([{name:"connect.sid",value:"one",domain:".textnow.com"}])}\n${JSON.stringify([{name:"connect.sid",value:"two",domain:".textnow.com"}])}`);
assert.equal(batches.length, 2);
const inspected = inspectTnCookiePayloads(batches.join("\n---\n"));
assert.equal(inspected.valid.length, 2);
assert.equal(inspected.invalid.length, 0);

const excelRows = Array.from({length:10}, (_,index) => `user${index + 1}\tpassword${index + 1}\tppid=TN-${index + 1}; _cfuvid=cf-${index + 1}; connect.sid=s%3A${index + 1}.signature; g_state={"i_l":0}`).join("\n");
const excelInspection = inspectTnCookiePayloads(excelRows);
assert.equal(excelInspection.detected, 10, "ten Excel rows must become ten CK accounts");
assert.equal(excelInspection.valid.length, 10);
assert.equal(excelInspection.invalid.length, 0);

const oneHeaderWithJsonValue = `ppid=TN-one; connect.sid=s%3Aone.signature; g_state={"i_l":0,"nested":{"enabled":true}}; _csrf=signed`;
const oneHeaderInspection = inspectTnCookiePayloads(oneHeaderWithJsonValue);
assert.equal(oneHeaderInspection.detected, 1, "JSON inside a Cookie value must not be counted as a separate CK");
assert.equal(oneHeaderInspection.valid.length, 1);

const hardWrappedHeader = `connect.sid=s%3Along-signature-part-one\npart-two==; _pxde=prefix:eyJ0aW1l\nc3RhbXAiOjE3fQ==; g_state={"i_l":\n0,"enabled":true}`;
const hardWrapped = parseTnCookiePayload(hardWrappedHeader);
assert.equal(hardWrapped.find(row => row.name === "connect.sid").value, "s%3Along-signature-part-onepart-two==");
assert.equal(hardWrapped.find(row => row.name === "_pxde").value, "prefix:eyJ0aW1lc3RhbXAiOjE3fQ==");
assert.equal(hardWrapped.find(row => row.name === "g_state").value, '{"i_l":0,"enabled":true}');

console.log("TN Cookie parser passed: Header/cURL, Set-Cookie, Cookie-Editor, object map, Netscape, DevTools TSV/CSV, Excel rows, hard-wrapped values, HAR, embedded/encoded JSON, expiry and batch formats.");
