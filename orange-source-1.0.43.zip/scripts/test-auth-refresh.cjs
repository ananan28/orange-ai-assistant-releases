const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('path').join(__dirname, '..', 'main.js'),'utf8');
const code=source.slice(source.indexOf('function classifyRefreshFailure'),source.indexOf('async function registerDevice'));
function setup(refresh, requests){let calls=0,refreshes=0;const original={access_token:'old'};const ctx={currentSession:original,authRefreshPromise:null,Error,Set,errorText:x=>x,supabase:{auth:{getSession:async()=>({data:{session:original}}),refreshSession:async()=>{refreshes++;return refresh()}},realtime:{setAuth(){}},functions:{invoke:async()=>requests[calls++]()}}};vm.createContext(ctx);vm.runInContext(code,ctx);return {ctx,calls:()=>calls,refreshes:()=>refreshes};}
const unauthorized=()=>({error:{context:{status:401}}});
(async()=>{
 for(const cause of [{message:'fetch failed'},{message:'timeout',status:0},{message:'server unavailable',status:503},{message:'rate limit',status:429}]){
  const s=setup(async()=>({error:cause}),[unauthorized]);
  await assert.rejects(s.ctx.invokeFunction('session-control',{}),e=>e.code==='AUTH_REFRESH_RETRYABLE'&&e.status!==401);
  assert.equal(s.ctx.currentSession.access_token,'old');assert.equal(s.calls(),1);
 }
 const thrown=setup(async()=>{throw new TypeError('fetch failed')},[unauthorized]);
 await assert.rejects(thrown.ctx.invokeFunction('session-control',{}),e=>e.code==='AUTH_REFRESH_RETRYABLE');
 for(const code of ['refresh_token_not_found','refresh_token_already_used','session_not_found']){
  const s=setup(async()=>({error:{code,message:'invalid session',status:400}}),[unauthorized]);
  await assert.rejects(s.ctx.invokeFunction('session-control',{}),e=>e.code==='INVALID_SESSION'&&e.status===401);
 }
 const good=setup(async()=>({data:{session:{access_token:'new'}}}),[unauthorized,()=>({data:{ok:true}})]);
 assert.equal((await good.ctx.invokeFunction('session-control',{})).ok,true);assert.equal(good.ctx.currentSession.access_token,'new');assert.equal(good.calls(),2);
 const forbidden=setup(async()=>{throw Error('must not refresh')},[()=>({error:{context:{status:403,clone:()=>({json:async()=>({code:'DEVICE_REVOKED',message:'device revoked'})})}}})]);
 await assert.rejects(forbidden.ctx.invokeFunction('session-control',{}),e=>e.code==='DEVICE_REVOKED'&&e.status===403);
 const concurrent=setup(async()=>({data:{session:{access_token:'new'}}}),[]);
 await Promise.all([concurrent.ctx.refreshCurrentAuthSession(),concurrent.ctx.refreshCurrentAuthSession()]);assert.equal(concurrent.refreshes(),1);
 console.log('PASS: 11 auth regression cases (network failures, invalid sessions, retry, revoked device, concurrent refresh)');
})().catch(e=>{console.error(e);process.exit(1)});
const heartbeatCode=source.slice(source.indexOf('function startHeartbeat()'),source.indexOf('\n}', source.indexOf('function startHeartbeat()'))+2);
async function checkHeartbeat(error,shouldLogout){
 let tick,signouts=0;const events=[];
 const ctx={Error,Set,Map,JSON,console:{warn(){},error(){}},heartbeatTimer:null,currentSession:{access_token:'old'},currentDeviceHash:'device',heartbeatFailureCount:0,currentProfile:{id:'user'},currentPermissions:{},managedTranslationProxy:null,mainWindow:{webContents:{send:(name,data)=>events.push(name)}},tnBackgroundWindows:new Map(),workPartition:'test',setInterval:fn=>{tick=fn;return 1},clearInterval(){},invokeFunction:async()=>{throw error},stopMessagingRealtime:async()=>{},destroyTnBackground(){},closeDetachedSiteWindows(){},applyTranslationProxy:async()=>{},supabase:{auth:{stopAutoRefresh(){},signOut:async()=>{signouts++}}},session:{fromPartition:()=>({})},ensureWorkExtensionLoaded:async()=>({}),syncExtensionAuth:async()=>{}};
 vm.createContext(ctx);vm.runInContext(heartbeatCode,ctx);ctx.startHeartbeat();await tick();
 assert.equal(signouts,shouldLogout?1:0);assert.equal(ctx.currentSession===null,shouldLogout);
 assert.ok(events.includes(shouldLogout?'auth:revoked':'auth:network-warning'));
}
(async()=>{
 for(const error of [Object.assign(new Error('fetch failed'),{code:'AUTH_REFRESH_RETRYABLE',status:0}),Object.assign(new Error('server unavailable'),{code:'AUTH_REFRESH_RETRYABLE',status:503}),new Error('fetch failed')])await checkHeartbeat(error,false);
 for(const error of [Object.assign(new Error('expired'),{code:'INVALID_SESSION',status:401}),Object.assign(new Error('device revoked'),{code:'DEVICE_REVOKED',status:403}),Object.assign(new Error('forced logout'),{code:'FORCE_LOGOUT',status:403})])await checkHeartbeat(error,true);
 const absent=setup(async()=>({error:{name:'AuthSessionMissingError',status:400,message:'session missing'}}),[unauthorized]);await assert.rejects(absent.ctx.invokeFunction('session-control',{}),e=>e.status===401);
 console.log('PASS: 7 additional heartbeat/session cases; transient failures retain login, explicit revocations log out.');
})().catch(e=>{console.error(e);process.exitCode=1});
