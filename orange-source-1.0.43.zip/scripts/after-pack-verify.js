"use strict";

const fs = require("node:fs");
const path = require("node:path");
const asar = require("@electron/asar");

module.exports = async function verifyPackagedApp(context) {
  const resources = path.join(context.appOutDir, "resources");
  const updateConfig = path.join(resources, "app-update.yml");
  fs.writeFileSync(updateConfig, [
    "provider: github",
    "owner: ananan28",
    "repo: orange-ai-assistant-releases",
    "updaterCacheDirName: orange-ai-internal-updater",
    ""
  ].join("\n"));
  const archive = path.join(resources, "app.asar");
  if (!fs.existsSync(archive)) throw new Error("Packaged app.asar is missing");

  // @electron/asar can return backslash-prefixed entries on Windows and
  // slash-prefixed entries on Linux. Normalize both before checking.
  const normalizeArchiveEntry = entry => String(entry).replaceAll("\\", "/").replace(/^\/+/, "");
  const entries = new Set(asar.listPackage(archive).map(normalizeArchiveEntry));
  const required = ["package.json", "main.js", "preload.js", "site-preload.js", "config.js", "tn-stable-core.js", "tn-dom-locator.js", "tn-cookie-parser.js", "src/app.js", "src/workbench.js", "src/index.html"];
  const missing = required.filter(file => !entries.has(file));
  if (missing.length) throw new Error(`Packaged app.asar is missing: ${missing.join(", ")}`);

  const packageJson = JSON.parse(asar.extractFile(archive, "package.json").toString("utf8"));
  if (packageJson.version !== context.packager.appInfo.version) throw new Error(`Packaged app version is stale: ${packageJson.version}`);
  if (packageJson.main !== "main.js") throw new Error(`Invalid packaged main entry: ${packageJson.main || "(missing)"}`);
  const packagedMain = asar.extractFile(archive, "main.js").toString("utf8");
  const packagedWorkbench = asar.extractFile(archive, "src/workbench.js").toString("utf8");
  const packagedSitePreload = asar.extractFile(archive, "site-preload.js").toString("utf8");
  const appMarkers = [
    [packagedMain, "forceAi===!0", "AI重新翻译主进程分支"],
    [packagedWorkbench, "PLATFORM_LABELS", "平台文字标签"],
    [packagedSitePreload, "orange-site-credential-panel", "登录账号下拉框"]
  ];
  for (const [source, marker, label] of appMarkers) if (!source.includes(marker)) throw new Error(`Packaged app is stale: missing ${label}`);

  const extensionRoot = path.join(resources, "extension-source");
  const manifestPath = path.join(extensionRoot, "manifest.json");
  if (!fs.existsSync(manifestPath)) throw new Error("Packaged extension manifest is missing");
  const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  const extensionRequired = new Set([manifest.background?.service_worker]);
  for (const item of manifest.content_scripts || []) {
    for (const file of item.js || []) extensionRequired.add(file);
    for (const file of item.css || []) extensionRequired.add(file);
  }
  const extensionMissing = [...extensionRequired].filter(Boolean).filter(file => !fs.existsSync(path.join(extensionRoot, file)));
  if (extensionMissing.length) throw new Error(`Packaged extension is missing: ${extensionMissing.join(", ")}`);
  const packagedContent = fs.readFileSync(path.join(extensionRoot, "content.js"), "utf8");
  const packagedBackground = fs.readFileSync(path.join(extensionRoot, "background.js"), "utf8");
  const packagedArea = fs.readFileSync(path.join(extensionRoot, "ai_reply.js"), "utf8");
  const extensionMarkers = [
    [packagedContent, "orangeTranslationCache:v1", "5天翻译缓存"],
    [packagedContent, "orangePreserveSendParagraphs", "发送前异常换行清理"],
    [packagedContent, "data-ai-bt-retranslate", "逐条AI重新翻译按钮"],
    [packagedBackground, "AI_AREA_CODE_REQUERY", "区号面板内重新查询"],
    [packagedArea, "AI_AREA_CODE_REQUERY", "区号重新查询界面"]
  ];
  for (const [source, marker, label] of extensionMarkers) if (!source.includes(marker)) throw new Error(`Packaged extension is stale: missing ${label}`);

  if (!fs.readFileSync(updateConfig, "utf8").includes("orange-ai-assistant-releases")) throw new Error("Packaged updater configuration is invalid");
  for (const requiredResource of ["tn-beta-extension-source/manifest.json"]) {
    if (!fs.existsSync(path.join(resources, requiredResource))) throw new Error(`Packaged resource is missing: ${requiredResource}`);
  }
  console.log(`[afterPack OK] ${packageJson.name} ${packageJson.version}: updater config, package.json -> main.js, and extension runtime complete`);
};
