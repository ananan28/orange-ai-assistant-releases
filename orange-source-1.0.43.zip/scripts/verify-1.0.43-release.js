"use strict";

const fs = require("node:fs");
const path = require("node:path");
const root = path.resolve(__dirname, "..");
const read = (...parts) => fs.readFileSync(path.join(root, ...parts), "utf8");
const main = read("main.js");
const app = read("src", "app.js");
const workbench = read("src", "workbench.js");
const preload = read("site-preload.js");
const desktopPreload = read("preload.js");
const indexHtml = read("src", "index.html");
const pkg = JSON.parse(read("package.json"));
const releasePreparer = read("scripts", "prepare-release-extension.js");
const updateGenerator = read("scripts", "generate-update-files.js");
const publishUpdate = read("publish-update.bat");
const extensionContent = read("extension-source", "content.js");
const extensionStyle = read("extension-source", "style.css");

const checks = [
  [pkg.version === "1.0.43", "版本号 1.0.43"],
  [!workbench.includes("#signal-wallpaper-context-tab") && !workbench.includes("setSignalLayout") && workbench.includes("#account-wallpaper-context-tab"), "Signal 删除后工作台无失效元素调用"],
  [!indexHtml.includes('data-messenger-launch="signal"') && !indexHtml.includes('data-admin-nav="signal"'), "Signal 界面已移除"],
  [!pkg.build.extraResources.some((item) => String(item.from || "").includes("signal")), "Signal 安装资源已移除"],
  [main.includes('ipcMain.handle("site:open-account"'), "网页平台独立账号入口"],
  [main.includes("web.whatsapp.com") && main.includes("web.telegram.org") && main.includes("mail.google.com"), "WhatsApp/Telegram/Gmail 官方入口"],
  [main.includes("Chrome/140.0.0.0") && main.includes("setUserAgent"), "WhatsApp 现代 Chromium 标识"],
  [main.includes("sitePartitionFor") && main.includes("persist:orange-site-"), "每账号独立持久会话"],
  [main.includes("siteAccountProxies") && main.includes('ipcMain.handle("site:set-account-proxy"'), "每账号固定 IP"],
  [workbench.includes("blockChinese") && preload.includes("isChineseGuardHost"), "中文发送拦截"],
  [preload.includes('addEventListener("submit", interceptChineseSend, !0)') && preload.includes("data-lexical-editor"), "中文发送拦截覆盖提交与新版编辑器"],
  [workbench.includes("chooseSiteWallpaper"), "账号壁纸"],
  [workbench.includes("rename-context-tab") || workbench.includes("renameContext"), "标签自定义名称"],
  [!indexHtml.includes("messenger-launchers"), "主页快捷启动大卡片已收起"],
  [main.includes('ipcMain.handle("site:list-managed-accounts"') && main.includes('ipcMain.handle("site:create-managed-account"') && main.includes('ipcMain.handle("site:update-managed-account"') && main.includes('ipcMain.handle("site:open-managed-account"'), "三个网页平台独立账号管理"],
  [indexHtml.includes('data-account-platform="whatsapp"') && indexHtml.includes('data-account-platform="telegram"') && indexHtml.includes('data-account-platform="gmail"'), "三个独立账号管理页"],
  [app.includes("platform_whatsapp") && app.includes("platform_telegram") && app.includes("platform_gmail"), "三个平台会员权限列表"],
  [main.includes("MANAGED_SITE_PERMISSION_CODES") && main.includes("managedSiteAllowedByPermission"), "三个平台入口运行时权限校验"],
  [main.includes("openWorkbenchTabLike113") && main.includes('webContents.send("workbench:open-tab"') && workbench.includes("pendingOpens.push"), "恢复 1.0.13 稳定网页打开链路"],
  [!main.includes("queueWorkbenchTabOpen") && !desktopPreload.includes("ackWorkTabOpen"), "已移除故障标签队列"],
  [read("extension-source", "content.js").includes('name: "whatsapp-web"'), "WhatsApp 聊天翻译适配器"],
  [extensionContent.includes('document.execCommand("insertText", !1, n)') && extensionContent.includes('"zh-CN", "en", "input_translate"'), "输入翻译快速写回受控编辑器"],
  [read("extension-source", "content.js").includes('inputType: "insertReplacementText"') && read("extension-source", "content.js").includes("data: null"), "输入翻译仅写回一次"],
  [main.includes("translateInputFast") && main.includes("Promise.any"), "长句并行翻译快速返回"],
  [/t\[\w+\]/.test(extensionContent) && extensionContent.includes("newValue"), "所有平台译文颜色实时刷新"],
  [(read("extension-source", "fixes-1.0.40.css").includes("--ai-bt-chat-translation-color") && read("extension-source", "manifest.json").includes("fixes-1.0.40.css")), "译文颜色覆盖内部文字节点"],
  [extensionContent.includes("#kt_chat_contacts_body") && extensionContent.includes("[data-kt-element='contacts']"), "星河联系人卡片检测与监听"],
  [releasePreparer.includes('new Set(["style.css"])') && !releasePreparer.includes('new Set(["content.js", "style.css"])'), "正式安装包使用当前翻译运行时"],
  [read("extension-source", "content.js").includes("#div-im-app .main-content .right") && read("extension-source", "content.js").includes("a.length ? { opensmsMessageRects: a } : {}"), "OPE 号码遮挡兼容"],
  [app.includes("xinghan") && (app.includes("星瀚") || app.includes("\\u661F\\u701A")), "星瀚标签"],
  [fs.existsSync(path.join(root, "extension-source", "ope_forbidden_guard.js")), "OPE 防禁用保护"],
  [fs.existsSync(path.join(root, "extension-source", "manifest.json")), "AI/翻译扩展"],
  [fs.existsSync(path.join(root, "tn-beta-extension-source", "manifest.json")), "TN 稳定扩展"],
  [!fs.existsSync(path.join(root, "signal-runtime")) && !fs.existsSync(path.join(root, "signal-window-host.ps1")), "Signal 源码资源已移除"],
  [fs.existsSync(path.join(root, "build-windows.bat")) && fs.existsSync(path.join(root, "publish-update.bat")), "构建与热更新 BAT"],
  [updateGenerator.includes("packageJson.version") && !updateGenerator.includes('const name = "Orange-AI-Assistant-Setup-1.0.26.exe"'), "更新文件跟随当前版本动态生成"],
  [publishUpdate.includes("gh release download") && publishUpdate.includes("version: %APP_VERSION%") && publishUpdate.includes("url: Orange-AI-Assistant-Setup-%APP_VERSION%.exe"), "发布后读取远端 latest.yml 并校验"],
];

const failed = checks.filter(([ok]) => !ok).map(([, label]) => label);
if (failed.length) {
  console.error(`[1.0.43 RELEASE ERROR] Missing: ${failed.join(", ")}`);
  process.exit(1);
}
console.log(`[1.0.43 RELEASE OK] ${checks.length} release checks passed`);
