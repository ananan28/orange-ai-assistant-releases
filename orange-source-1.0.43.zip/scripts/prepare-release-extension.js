"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const esbuild = require("esbuild");

const projectRoot = path.resolve(__dirname, "..");
const sourceRoot = path.join(projectRoot, "extension-source");
const stableChatRoot = path.join(projectRoot, "stable-extension-1.0.5");
// Keep the proven visual stylesheet, but always package the current content
// runtime. Pinning content.js to 1.0.5 silently discarded later platform,
// input-writeback, permission and live-setting fixes from formal releases.
const stableChatFiles = new Set(["style.css"]);
// Non-hidden staging directories are intentional. Hidden dot-directories were
// omitted by Windows packaging in older builds and produced an installer whose
// app.asar had no startup files.
const outputRoot = path.join(projectRoot, "release-extension");
const appOutputRoot = path.join(projectRoot, "release-app");
const tnStableRoot = path.join(projectRoot, "tn-beta-extension-source");
function listRuntimeFiles() {
  return fs.readdirSync(sourceRoot, { withFileTypes: true })
    .filter(entry => entry.isFile() && (
      entry.name === "manifest.json" ||
      entry.name.endsWith(".js") ||
      entry.name.endsWith(".css") ||
      entry.name.endsWith(".html")
    ))
    .map(entry => entry.name)
    .sort();
}

function sha256(filePath) {
  return crypto.createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
}

async function writeRuntimeFile(relativePath) {
  const useStableChatRuntime = stableChatFiles.has(relativePath);
  const source = path.join(useStableChatRuntime ? stableChatRoot : sourceRoot, relativePath);
  const target = path.join(outputRoot, relativePath);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  if (useStableChatRuntime) {
    fs.copyFileSync(source, target);
    return;
  }
  if (relativePath.endsWith(".js") || relativePath.endsWith(".css")) {
    const result = await esbuild.transform(fs.readFileSync(source, "utf8"), {
      loader: relativePath.endsWith(".js") ? "js" : "css",
      minify: true,
      sourcemap: false,
      legalComments: "none",
      target: "chrome120"
    });
    fs.writeFileSync(target, result.code);
    return;
  }
  fs.copyFileSync(source, target);
}

async function writeMinifiedAppFile(source, target) {
  fs.mkdirSync(path.dirname(target), { recursive: true });
  if (source.endsWith(".js") || source.endsWith(".css")) {
    const result = await esbuild.transform(fs.readFileSync(source, "utf8"), {
      loader: source.endsWith(".js") ? "js" : "css",
      minify: true,
      sourcemap: false,
      legalComments: "none",
      target: source.endsWith(".js") ? "node22" : "chrome120"
    });
    fs.writeFileSync(target, result.code);
    return;
  }
  fs.copyFileSync(source, target);
}

async function prepareDesktopRuntime() {
  fs.rmSync(appOutputRoot, { recursive: true, force: true });
  fs.mkdirSync(appOutputRoot, { recursive: true });
  for (const file of ["main.js", "preload.js", "site-preload.js", "config.js", "tn-stable-core.js", "tn-dom-locator.js", "tn-cookie-parser.js"]) {
    await writeMinifiedAppFile(path.join(projectRoot, file), path.join(appOutputRoot, file));
  }
  async function walk(sourceDirectory, targetDirectory) {
    for (const entry of fs.readdirSync(sourceDirectory, { withFileTypes: true })) {
      const source = path.join(sourceDirectory, entry.name);
      const target = path.join(targetDirectory, entry.name);
      if (entry.isDirectory()) await walk(source, target);
      else await writeMinifiedAppFile(source, target);
    }
  }
  await walk(path.join(projectRoot, "src"), path.join(appOutputRoot, "src"));
  for (const file of ["main.js", "preload.js", "site-preload.js", "config.js", "tn-stable-core.js", "tn-dom-locator.js", "tn-cookie-parser.js", "src/app.js", "src/workbench.js"]) {
    const staged = path.join(appOutputRoot, file);
    if (!fs.existsSync(staged)) throw new Error(`Desktop release is missing required file: ${file}`);
  }
}

module.exports = async function prepareReleaseExtension() {
  await prepareDesktopRuntime();
  fs.rmSync(outputRoot, { recursive: true, force: true });
  fs.mkdirSync(outputRoot, { recursive: true });
  const runtimeFiles = listRuntimeFiles();
  for (const relativePath of runtimeFiles) await writeRuntimeFile(relativePath);
  fs.cpSync(path.join(sourceRoot, "assets"), path.join(outputRoot, "assets"), { recursive: true });

  // Fail the build before packaging if the manifest or service worker refers
  // to a runtime file that was not staged. This prevents a partially loading
  // extension from disabling every managed website.
  const manifest = JSON.parse(fs.readFileSync(path.join(outputRoot, "manifest.json"), "utf8"));
  const requiredFiles = new Set();
  if (manifest.background?.service_worker) requiredFiles.add(manifest.background.service_worker);
  if (manifest.action?.default_popup) requiredFiles.add(manifest.action.default_popup);
  for (const script of manifest.content_scripts || []) {
    for (const file of script.js || []) requiredFiles.add(file);
    for (const file of script.css || []) requiredFiles.add(file);
  }
  for (const file of Object.values(manifest.icons || {})) requiredFiles.add(file);
  for (const resourceGroup of manifest.web_accessible_resources || []) {
    for (const file of resourceGroup.resources || []) requiredFiles.add(file);
  }
  for (const file of Object.values(manifest.action?.default_icon || {})) requiredFiles.add(file);

  const backgroundSource = fs.readFileSync(path.join(sourceRoot, manifest.background.service_worker), "utf8");
  for (const call of backgroundSource.matchAll(/importScripts\(([^)]+)\)/g)) {
    for (const quoted of call[1].matchAll(/["']([^"']+)["']/g)) requiredFiles.add(quoted[1]);
  }
  const missing = [...requiredFiles].filter(file => !fs.existsSync(path.join(outputRoot, file)));
  if (missing.length) throw new Error(`Release extension is missing required files: ${missing.join(", ")}`);

  const integrity = {};
  function collect(directory, prefix = "") {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const relative = path.join(prefix, entry.name).replaceAll(path.sep, "/");
      const absolute = path.join(directory, entry.name);
      if (entry.isDirectory()) collect(absolute, relative);
      else integrity[relative] = sha256(absolute);
    }
  }
  collect(outputRoot);
  fs.writeFileSync(path.join(outputRoot, "integrity.sha256.json"), JSON.stringify(integrity));

  // TN account sessions load this dedicated extension directory. Keep the
  // translator runtime identical so copy/retranslate and message detection
  // fixes cannot ship only to OPE/normal website tabs.
  for (const file of ["content.js", "background.js", "style.css"]) {
    fs.copyFileSync(path.join(outputRoot, file), path.join(tnStableRoot, file));
  }
  console.log(`[release] Prepared minified desktop and ${Object.keys(integrity).length} extension files; verified ${requiredFiles.size} manifest dependencies.`);
};

// 允许发布检查和开发者直接执行本脚本。旧版本使用 `node scripts/...`
// 时实际上什么也没生成，容易把上一次残留的 release-app/release-extension
// 打进安装包，造成“源码已修复、正式版仍是旧功能”。
if (require.main === module) {
  module.exports().catch(error => {
    console.error(`[release] ${error?.stack || error}`);
    process.exitCode = 1;
  });
}
