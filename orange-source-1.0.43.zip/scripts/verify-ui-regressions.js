"use strict";

const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const content = fs.readFileSync(path.join(root, "extension-source", "content.js"), "utf8");
const background = fs.readFileSync(path.join(root, "extension-source", "background.js"), "utf8");
const style = fs.readFileSync(path.join(root, "extension-source", "style.css"), "utf8");
const main = fs.readFileSync(path.join(root, "main.js"), "utf8");
const appSource = fs.readFileSync(path.join(root, "src", "app.js"), "utf8");
const workbenchSource = fs.readFileSync(path.join(root, "src", "workbench.js"), "utf8");
const workbenchHtml = fs.readFileSync(path.join(root, "src", "workbench.html"), "utf8");
const indexHtml = fs.readFileSync(path.join(root, "src", "index.html"), "utf8");
const preloadSource = fs.readFileSync(path.join(root, "preload.js"), "utf8");
const sitePreloadSource = fs.readFileSync(path.join(root, "site-preload.js"), "utf8");
const aiReplySource = fs.readFileSync(path.join(root, "extension-source", "ai_reply.js"), "utf8");
const aiReplyStyle = fs.readFileSync(path.join(root, "extension-source", "ai_reply.css"), "utf8");
const pageTranslationActions = fs.readFileSync(path.join(root, "extension-source", "page_translation_actions.js"), "utf8");
const featureSql = fs.readFileSync(path.join(root, "SUPABASE-0.9.0-FEATURE-FLAGS.sql"), "utf8");
const permissionFixSql = fs.readFileSync(path.join(root, "SUPABASE-0.9.1-PERMISSIONS-TN-FIX.sql"), "utf8");
const proxyControlSource = fs.readFileSync(path.join(root, "SUPABASE-proxy-control.ts"), "utf8");
const aiGatewaySource = fs.readFileSync(path.join(root, "SUPABASE-ai-gateway.ts"), "utf8");
const regressionGuard = fs.readFileSync(path.join(root, "REGRESSION_GUARD.md"), "utf8");
const sessionControlSource = fs.readFileSync(path.join(root, "SUPABASE-session-control.ts"), "utf8");
const releasePreparer = fs.readFileSync(path.join(root, "scripts", "prepare-release-extension.js"), "utf8");
const packVerifier = fs.readFileSync(path.join(root, "scripts", "after-pack-verify.js"), "utf8");
const tnCookieParserSource = fs.readFileSync(path.join(root, "tn-cookie-parser.js"), "utf8");
const requiredAsset = path.join(root, "extension-source", "assets", "orange-chibi-sticker.png");
const publishScript = fs.readFileSync(path.join(root, "publish-update.bat"), "utf8");
const windowsBuildScript = fs.readFileSync(path.join(root, "build-windows.bat"), "utf8");
const offlineNsisCache = path.join(root, "offline-cache", "electron-builder", "nsis-3.0.4.1", "nsis-3.0.4.1.7z");
const stableChatContent = path.join(root, "stable-extension-1.0.5", "content.js");
const stableChatStyle = path.join(root, "stable-extension-1.0.5", "style.css");

const checks = [
  [regressionGuard.includes("未被用户明确报告为故障") && regressionGuard.includes("不得标记为正式发布版"), "project-wide no-regression release guard"],
  [content.includes("confirmedDigits") && content.includes("allowedPhoneDigits"), "phone-mask all-occurrence pass"],
  [style.includes("classic full-platform marquee restoration"), "classic full-platform marquee"],
  [style.includes("--oz-crystal-angle: 360deg"), "moving rainbow angle animation"],
  [style.includes(".ai-bt-generic-message:has(.oz-crystal-bubble)::before"), "parent duplicate-ring suppression"],
  [style.includes(":is(.oz-crystal-bubble, .ai-bt-tn-light-bubble)\n  :is("), "nested duplicate-ring suppression"],
  [style.includes("Restore the original bubble-top character"), "bubble character restoration"],
  [fs.existsSync(requiredAsset), "bubble character asset"],
  [main.includes("tn:appearance-changed") && content.includes("tn:appearance-changed"), "TN appearance synchronization"],
  [content.includes("aiBtBubbleLightEnabled") && style.includes("html.ai-bt-bubble-light-off"), "bubble marquee on/off switch"],
  [main.includes('ipcMain.handle("tn:test-send"') && main.includes("recipient_mismatch") && main.includes("outgoing_confirmation_timeout"), "TN live-test fail-closed flow"],
  [appSource.includes("stagePrivateAttachment(namedImage)") && !appSource.includes("void sendPrivateAttachment(namedImage)"), "pasted image requires explicit send"],
  [content.includes('document.querySelector("#messageView")') && content.includes("layer?.remove()") && content.includes("document.hidden"), "reduced background and observer workload"],
  [!workbenchSource.includes("tab-detach") && !workbenchSource.includes("detachTab(") && !preloadSource.includes("detachWorkTab"), "detached tab entry removed"],
  [main.includes('ipcMain.handle("features:get"') && main.includes('performTnSend(payload, "tn_live_test")') && main.includes("syncFeatureFlagsToLoadedExtensions") && featureSql.includes("app_feature_flag_audit"), "remote feature kill switches"],
  [releasePreparer.includes('"tn-dom-locator.js"') && packVerifier.includes('"tn-dom-locator.js"'), "TN locator included in packaged app"],
  [appSource.includes("function esc(value)") && !appSource.includes("escapeHtml("), "renderer uses the defined HTML escape helper"],
  [appSource.includes("pendingFeatureFlagChanges") && appSource.includes('querySelector("#save-feature-flags")') && main.includes('case "save_feature_flag"') === false, "explicit global feature save workflow"],
  [appSource.includes("当前有未保存的开关修改") && appSource.includes("确定放弃所有未保存"), "feature refresh protects unsaved changes"],
  [appSource.includes("pendingPermissionChanges") && appSource.includes('querySelector("#save-permissions")') && appSource.includes("会员权限已全部保存"), "explicit membership permission save workflow"],
  [appSource.includes("管理员手动修改功能开关") && appSource.includes("故障时自动关闭"), "feature save reason fallback and clear fail-closed label"],
  [appSource.includes("数据库复核不一致") && main.includes('webContents.send("permissions:changed"') && preloadSource.includes("onPermissionsChanged"), "permission save readback and live refresh"],
  [appSource.includes("permanentlyDeleted") && appSource.includes("删除后复核失败") && appSource.includes("服务器没有确认账号已永久删除"), "permanent account deletion proof and list verification"],
  [appSource.includes('tn_assistant:"TN橘子助手总权限"') && main.includes("function tnFeatureAllowed(featureKey") && permissionFixSql.includes("('advanced','tn_assistant',true)"), "TN global and membership permission layers"],
  [appSource.includes("window.orangeApp.sendTnMessage") && appSource.includes("runNextTnSendAssignment") && main.includes('ipcMain.handle("tn:send-one"') && main.includes("duplicate_recipient"), "TN scheduled sender, interval and duplicate protection"],
  [appSource.includes("TN_SEND_STORAGE_PREFIX") && appSource.includes("tnSendOwnerId()") && main.includes("currentTnOwnerScope()"), "TN per-user local isolation"],
  [main.includes('permissions.tn_assistant = false') && main.includes('event.preventDefault()') && workbenchSource.includes("onTnAccessRevoked"), "TN revocation closes UI and blocks new webviews"],
  [main.includes("backgroundWebPreferences(partition") && !main.includes("heavyHiddenResource") && !main.includes("orangeTnWebContentsId"), "TN background lifecycle uses the Beta.6 stable contract"],
  [main.includes("Never erase TextNow's device") && !main.includes('ipcMain.on("tn:verification-state"') && !main.includes("accountSession.setUserAgent"), "Beta.6-compatible TN cookie merge and native verification lifecycle"],
  [proxyControlSource.includes("async function hasTnAccountAccess") && proxyControlSource.includes("TN功能未授权、已关闭或权限数据不可用") && proxyControlSource.includes('in("feature_code", ["tn_accounts"])'), "TN Edge Function revalidates global and TN-account membership access"],
  [sessionControlSource.includes('profile.plan==="advanced"') && sessionControlSource.includes('profile.plan="basic"') && sessionControlSource.includes('basicUntil') && sessionControlSource.includes('MEMBERSHIP_GRACE_EXPIRED'), "Expired Advanced falls back to timed Basic grace period"],
  [appSource.includes('id=\"user-filter\"') === false || appSource.includes('user-filter'), "Account admin quick filters"],
  [content.includes('AI_TRANSLATE_VARIANTS') && content.includes('showInputTranslationChoices') && content.includes('lastInputTranslationUndo'), "Input translation variants and undo"],
  [main.includes('if (key === "tn_accounts") return true') && proxyControlSource.includes('return permissions.tn_accounts === true') && !proxyControlSource.includes('return permissions.tn_assistant === true && permissions.tn_accounts === true'), "Basic TN account/IP access is independent from TN assistant"],
  [workbenchSource.includes('tab.addEventListener("contextmenu"') && workbenchHtml.includes("在独立窗口打开") && main.includes('ipcMain.handle("workbench:detach-tab"') && sitePreloadSource.includes("返回主工作台"), "full-tab context menu and independent window"],
  [aiReplySource.includes("hasActiveConversation(identity)") && aiReplySource.includes("areaWidgetVisible = false") && aiReplySource.includes('dragButton.addEventListener("pointerdown"') && aiReplySource.includes("openAreaDetails()") && aiReplyStyle.includes("orange-area-drag"), "area widget chat-only visibility, separate open, close and drag controls"],
  [main.includes("function siteCredentialRows") && main.includes("publicSiteCredentialRows") && indexHtml.includes('id="credential-profile"') && sitePreloadSource.includes("savedAccounts.forEach"), "multiple saved credentials per website"],
  [tnCookieParserSource.includes("rowsFromSetCookie") && tnCookieParserSource.includes("rowsFromNetscape") && tnCookieParserSource.includes("rowsFromDevtools") && main.includes("writeTextNowCookies"), "complete TN Cookie parsing and verified write flow"],
  [releasePreparer.includes('"tn-cookie-parser.js"') && packVerifier.includes('"tn-cookie-parser.js"'), "TN Cookie parser included in packaged app"],
  [aiReplySource.includes("clampAreaWidgetToViewport") && aiReplySource.includes('addEventListener("resize"') && aiReplySource.includes("widget.hidden || !areaWidgetVisible"), "area widget resize clamp without forced visibility"],
  [indexHtml.includes('id="tn-open-selected"') && indexHtml.includes('id="tn-select-all"') && appSource.includes("selectedTnAccountIds") && appSource.includes("正在打开 ${ids.length} 个TN账号"), "TN select-all and bulk open"],
  [appSource.includes("TN_LAST_MANAGED_GROUP_KEY") && appSource.includes("saveTnManagedGroup(selectedGroup)"), "TN managed proxy group selection persistence"],
  [indexHtml.includes('value="openai_official"') && indexHtml.includes("gpt-5.4-mini") && appSource.includes("https://api.openai.com/v1") && appSource.includes("openai-api-key-link") && main.includes("https://platform.openai.com/api-keys"), "official OpenAI API provider preset"],
  [content.includes("cleanDraftForSend") && content.includes("installSendCleanupEvents") && content.includes("orangePreserveSendParagraphs"), "send-time abnormal line-break cleanup"],
  [content.includes("orangeTranslationCache:v1") && content.includes("data-ai-bt-retranslate") && content.includes("data-ai-bt-copy-translation"), "five-day cache and per-message translation controls"],
  [sitePreloadSource.includes("orange-site-credential-panel") && sitePreloadSource.includes("＋ 使用新账号") && sitePreloadSource.includes("删除所选") && sitePreloadSource.includes("data-drag"), "inline saved-account chooser"],
  [workbenchSource.includes("PLATFORM_LABELS") && workbenchSource.includes('opensms:"OPE"') && workbenchSource.includes('xhsim:"星河"'), "plain platform tab labels"],
  [aiReplySource.includes("联网重新查询") && !aiReplySource.includes("google.com/search?q="), "area requery stays inside panel"],
  [style.includes(".ai-bt-input-translate-button") && style.includes("display:none !important"), "input translation badge hidden globally"],
  [appSource.includes("AI_MODEL_PRESETS") && appSource.includes("refreshAiModelSuggestions") && appSource.includes("OpenAI官方接口必须选择GPT模型"), "AI provider-model linkage and validation"],
  [content.includes("ai-bt-retranslate-status") && content.includes("AI重译失败：") && content.includes("failureReason"), "visible AI retranslation result and error details"],
  [content.includes('fallback.value = sourceText') && content.includes('title="复制英文原文"'), "copy action always copies original English"],
  [content.includes("element.querySelector(\"img,[class*='avatar']") && content.includes("prevents a second action group"), "avatar and outer-row duplicate action rejection"],
  [content.includes("setTimeout(() => hideBackTranslation(), 80)") && content.includes("await translateChatElement(messages[index], version)"), "send cleanup and stable sequential message translation"],
  [background.includes("setTimeout(() => controller.abort(), 8000)") && background.includes("for (const endpoint of endpoints)") && !background.includes("Promise.any(endpoints"), "exact 1.0.5 sequential translation endpoint strategy"],
  [content.includes("桌面端通信暂未响应，请刷新OPE后重试") && content.includes("result?.message) desktopProxyState"), "OPE proxy state timeout is reported without false unsupported status"],
  [content.includes('textNode.style.setProperty("-webkit-text-fill-color"') && style.includes(".ai-bt-chat-translation > .ai-bt-chat-translation-text"), "selected translation color overrides OPE inner text fill"],
  [content.includes("Native color pickers emit many input events") && !content.includes('translationColorInput?.addEventListener("input", event => {\n      translationTextColor = normalizeHexColor(event.target.value);\n      applyTranslationTextColor();'), "color picker preview avoids full-history redraw"],
  [publishScript.includes("ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/") && publishScript.includes(":build_network_failed") && publishScript.includes("releases/new?tag=%RELEASE_TAG%"), "Windows publisher retries download mirror and provides manual release fallback"],
  [windowsBuildScript.includes("ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/") && windowsBuildScript.includes(":network_failed") && windowsBuildScript.includes("Orange-AI-Assistant-Setup-%APP_VERSION%.exe.blockmap"), "standalone Windows builder retries mirror and verifies all update artifacts"],
  [fs.existsSync(offlineNsisCache) && windowsBuildScript.includes("ELECTRON_BUILDER_CACHE=%~dp0offline-cache\\electron-builder") && publishScript.includes("ELECTRON_BUILDER_CACHE=%~dp0offline-cache\\electron-builder"), "safe NSIS installer cache retained"],
  [!windowsBuildScript.includes("--prepackaged") && !publishScript.includes("--prepackaged") && !windowsBuildScript.includes("prepare:offline-win") && !publishScript.includes("prepare:offline-win") && packVerifier.includes("app-update.yml"), "Windows build always creates a fresh integrity-stamped application with updater configuration"],
  [fs.existsSync(stableChatContent) && fs.existsSync(stableChatStyle) && releasePreparer.includes('stableChatFiles = new Set(["content.js", "style.css"])'), "formal package restores exact 1.0.5 chat detection and rendering runtime"],
  [pageTranslationActions.includes("data-page-copy") && pageTranslationActions.includes("data-page-retranslate") && pageTranslationActions.includes("forceAi:true"), "web-page translations receive original-copy and AI-retranslate actions"],
  [releasePreparer.includes('const tnStableRoot') && releasePreparer.includes('["content.js", "background.js", "style.css"]'), "TN receives current copy and retranslation runtime"],
  [indexHtml.includes('data-admin-nav="tn-proxies"') && indexHtml.includes('id="tn-proxy-import-form"') && indexHtml.includes('value="tn_pool"'), "separate TN proxy pool and website TN routing"],
  [indexHtml.includes('id="site-message-selector"') && indexHtml.includes('id="site-input-selector"') && main.includes("orangeSiteAdapters") && content.includes("customSiteAdapter"), "admin-configured adapter for future websites"],
  [appSource.includes('deepseek:["deepseek-chat"') && appSource.includes('openrouter:[') && appSource.includes('"openai/gpt-5-mini"') && appSource.includes('"openai/gpt-oss-120b"') && appSource.includes('"qwen/qwen3-32b"') && indexHtml.includes('value="azure_openai"'), "expanded AI providers and model presets"],
  [proxyControlSource.includes('body.action === "site_pool"') && proxyControlSource.includes('poolKind === "tn"'), "TN-only website proxy selection"],
  [content.indexOf("let customSiteAdapter = null") < content.indexOf("let currentMode = defaultModeForHost()"), "custom site adapter initializes before translator startup"],
  [indexHtml.includes('id="groq-model" required') && indexHtml.includes('id="ai-custom-model"') && appSource.includes("selectedAiModel()"), "visible multi-model selector with custom model fallback"],
  [sitePreloadSource.includes("const rightSide = rect.right + 12") && sitePreloadSource.includes('password?.addEventListener("focus", expand)') && !sitePreloadSource.includes('else { collapse(); (loginFields()'), "credential panel stays beside login fields without blocking new account input"],
  [!aiGatewaySource.includes('response_format:{ type:"json_object" }') && aiGatewaySource.includes("result?.choices?.[0]?.message?.content"), "AI gateway accepts plain-text translation responses"],
  [main.includes("sitePartitionFor") && main.includes('ipcMain.handle("site:open-account"') && main.includes('ipcMain.handle("site:delete-account-data"'), "persistent isolated website account sessions"],
  [workbenchSource.includes("siteInstanceId") && workbenchSource.includes("修改本机显示名称") && workbenchHtml.includes("关闭当前标签（保留登录）"), "per-account tab rename and close-without-logout controls"],
  [workbenchSource.includes("deleteSiteAccountData") && workbenchSource.includes("其他账号不受影响") && workbenchHtml.includes("删除本机账号数据"), "employee-confirmed single-account local deletion"],
  [main.includes("singlePreciseTranslationSender") && main.includes("web\\.whatsapp") && main.includes("web\\.telegram"), "WhatsApp Telegram single precise input translation policy"],
  [aiGatewaySource.includes('type Provider = "deepl"') && aiGatewaySource.includes("DeepL-Auth-Key") && main.includes('preferredProvider:"deepl"'), "DeepL preferred translation route for WhatsApp"],
  [workbenchSource.includes("blockChinese") && sitePreloadSource.includes("orange:set-send-policy") && workbenchHtml.includes("禁止发送中文"), "per-account Chinese send guard for messaging platforms"],
  [workbenchSource.includes('xinghan:"星瀚"'), "Xinghan tab label spelling"],
];

const failed = checks.filter(([ok]) => !ok).map(([, name]) => name);
if (failed.length) {
  console.error(`[UI REGRESSION ERROR] Missing: ${failed.join(", ")}`);
  process.exit(1);
}
console.log(`[UI REGRESSION OK] ${checks.length} protected checks passed`);
