"use strict";

const assert = require("node:assert/strict");
const { TN_DOM_SELECTORS, normalizeTnPhone, inspectTnDocument } = require("../tn-dom-locator");

assert.equal(normalizeTnPhone("+1 (415) 555-0123"), "4155550123");
assert.equal(normalizeTnPhone("415-555-0123"), "4155550123");
assert.equal(new Set(Object.values(TN_DOM_SELECTORS)).size, Object.keys(TN_DOM_SELECTORS).length);

const nodes = new Map(Object.values(TN_DOM_SELECTORS).map(selector => [selector, {
  textContent:selector === TN_DOM_SELECTORS.recipientNumber ? "+1 415 555 0123" : "",
  getClientRects:() => [1]
}]));
const document = {
  querySelector(selector) {
    if (selector === 'meta[name="TN-WEB-VERSION"]') return { content:"26.34.1-1583" };
    return nodes.get(selector) || null;
  }
};
global.getComputedStyle = () => ({ display:"block" });
const result = inspectTnDocument(document);
assert.equal(result.ok, true);
assert.equal(result.selectedRecipient, "4155550123");
assert.equal(result.sendButtonVisible, true);

nodes.delete(TN_DOM_SELECTORS.sendButton);
assert.equal(inspectTnDocument(document).ok, false);

console.log("TN DOM locator passed: selectors, phone normalization and fail-closed behavior.");
