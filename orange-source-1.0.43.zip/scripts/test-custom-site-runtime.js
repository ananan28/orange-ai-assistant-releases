"use strict";

const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const content = fs.readFileSync(
  path.join(root, "extension-source", "content.js"),
  "utf8",
);
const style = fs.readFileSync(
  path.join(root, "extension-source", "style.css"),
  "utf8",
);

const checks = [
  [
    content.includes("...(t?.messageSelectors || []).filter(Boolean)"),
    "custom-site empty message selectors retain generic discovery",
  ],
  [
    content.includes("...(t?.containerSelectors || []).filter(Boolean)"),
    "custom-site empty container selectors retain generic discovery",
  ],
  [
    content.includes('"[data-message-id]"') &&
      content.includes('"[role=\'log\']"'),
    "generic message and conversation selectors are bundled",
  ],
  [
    !/for\s*\(const\s+\w+\s+of\s+an\(\)\)/.test(content),
    "chat discovery does not iterate the text-node predicate",
  ],
  [
    content.includes('classList.add("ai-bt-generic-message")'),
    "detected bubbles receive the shared effects class",
  ],
  [
    content.includes('className = "ai-bt-chat-translation-text"'),
    "chat translations use the colorable text node",
  ],
  [
    style.includes(".ai-bt-generic-message") &&
      style.includes("--ai-bt-bubble-light-color"),
    "bubble light styling remains connected",
  ],
];

const failed = checks.filter(([ok]) => !ok).map(([, label]) => label);
if (failed.length) {
  console.error(`[CUSTOM SITE RUNTIME ERROR] Missing: ${failed.join(", ")}`);
  process.exit(1);
}
console.log(`[CUSTOM SITE RUNTIME OK] ${checks.length} checks passed`);
