'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const main=fs.readFileSync(path.join(root,'main.js'),'utf8');
const start=main.indexOf('function configureGoogleMailBrowserSession(');
const end=main.indexOf('async function configureSiteAccountSession(',start);
const context={process:{versions:{chrome:'154.0.8042.123'}},app:{getVersion:()=> '1.0.43'}};
vm.createContext(context);vm.runInContext(main.slice(start,end),context);
let ua;
context.configureGoogleMailBrowserSession({setUserAgent:value=>{ua=value}});
assert.ok(ua.includes('Chrome/154.0.8042.123'));
assert.ok(ua.includes('OrangeAI/1.0.43'),'Application identity must remain explicit');
assert.ok(!ua.includes('Chrome/140.'),'Gmail must not reuse a stale hard-coded browser version');
const preload=fs.readFileSync(path.join(root,'site-preload.js'),'utf8');
let requireCalls=0;
vm.runInNewContext(preload,{location:{hostname:'accounts.google.com'},require(){requireCalls++;throw Error('Login page must not load application preload')}});
assert.equal(requireCalls,0,'Google authentication page must not run preload');
for(const directory of ['extension-source','tn-beta-extension-source']){
 const manifest=JSON.parse(fs.readFileSync(path.join(root,directory,'manifest.json'),'utf8'));
 for(const script of manifest.content_scripts||[]){
  if(script.matches.includes('<all_urls>'))assert.ok(script.exclude_matches.includes('https://accounts.google.com/*'));
 }
}
assert.ok(main.includes('(u.javascript = !0)'),'Guest JavaScript must be enabled');
assert.ok(main.includes('if (String(n || "").toLowerCase() === "gmail") configureGoogleMailBrowserSession(u);'));
console.log('PASS: Gmail Chromium version, application identity, clean Google authentication page, extension exclusion, JavaScript enabled.');
