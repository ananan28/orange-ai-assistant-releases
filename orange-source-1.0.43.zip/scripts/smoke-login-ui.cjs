'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),net=require('node:net'),assert=require('node:assert/strict'),{spawn}=require('node:child_process');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const exe=path.resolve(__dirname,'../dist/win-unpacked/橘子AI助手.exe');assert.ok(fs.existsSync(exe),'Packaged executable missing');
 const port=await new Promise(r=>{const s=net.createServer();s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>r(p));});});
 const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'orange-login-test-'));let logs='';
 const child=spawn(exe,[`--remote-debugging-port=${port}`],{env:{...process.env,APPDATA:temporary,LOCALAPPDATA:temporary},stdio:['ignore','pipe','pipe']});
 child.stdout.on('data',b=>{logs=(logs+b).slice(-8000)});child.stderr.on('data',b=>{logs=(logs+b).slice(-8000)});
 let socket;
 try{
  let target;const deadline=Date.now()+30000;
  while(Date.now()<deadline){
   if(child.exitCode!==null)throw Error('Packaged app exited before login UI loaded: '+child.exitCode+'\n'+logs);
   try{const targets=await(await fetch(`http://127.0.0.1:${port}/json/list`)).json();target=targets.find(t=>t.type==='page'&&t.url.includes('/src/index.html'));if(target)break;}catch{}
   await wait(500);
  }
  assert.ok(target,'Login window not exposed before timeout\n'+logs);
  socket=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{socket.addEventListener('open',r,{once:true});socket.addEventListener('error',j,{once:true});});
  const pending=new Map();let seq=0;socket.addEventListener('message',event=>{const m=JSON.parse(String(event.data));const p=pending.get(m.id);if(p){pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}});
  const request=(method,params)=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});socket.send(JSON.stringify({id,method,params}));});
  let result;
  while(Date.now()<deadline){
   const r=await request('Runtime.evaluate',{expression:'({ready: document.readyState, login: !!document.querySelector("#login-form"), visible: !!document.querySelector("#login-view") && getComputedStyle(document.querySelector("#login-view")).display !== "none", bridge: typeof window.orangeApp?.login, newMax: document.querySelector("#new-device-limit")?.max, editMax: document.querySelector("#edit-user-device-limit")?.max})',returnByValue:true});
   result=r.result.value;if(result?.ready==='complete'&&result.bridge==='function')break;await wait(500);
  }
  assert.ok(result?.login&&result.visible,'Login screen did not load: '+JSON.stringify(result));assert.equal(result.bridge,'function');assert.equal(result.newMax,'50');assert.equal(result.editMax,'50');
  const status=await request('Runtime.evaluate',{expression:'window.orangeApp.status()',awaitPromise:true,returnByValue:true});assert.equal(status.result.value.authenticated,false,'Fresh test process unexpectedly authenticated');
  console.log('PASS: packaged Windows login UI is visible, preload/IPC work, unauthenticated state works, device controls allow 50.');
 }finally{socket?.close();if(child.exitCode===null)child.kill();}
})().catch(e=>{console.error(e);process.exitCode=1});
