-- Orange AI Assistant 0.9.2 membership lifecycle + production fixes
begin;

create table if not exists public.membership_settings (
  singleton boolean primary key default true check (singleton),
  basic_grace_days integer not null default 30 check (basic_grace_days between 1 and 365),
  updated_at timestamptz not null default now(),
  updated_by uuid null references auth.users(id) on delete set null
);
insert into public.membership_settings(singleton,basic_grace_days) values(true,30) on conflict(singleton) do nothing;

-- Basic remains safe by default. Admins can change these later in Function Permissions.
update public.plan_permissions set enabled=false where plan='basic';
insert into public.plan_permissions(plan,feature_code,enabled) values('basic','tn_accounts',true)
on conflict(plan,feature_code) do update set enabled=excluded.enabled;

-- Fix the production delete-user conflict discovered during 0.9.1 validation:
-- ai_usage_daily.user_id is part of the PK, so SET NULL can never work.
do $$ begin
  if to_regclass('public.ai_usage_daily') is not null then
    alter table public.ai_usage_daily drop constraint if exists ai_usage_daily_user_id_fkey;
    alter table public.ai_usage_daily add constraint ai_usage_daily_user_id_fkey foreign key(user_id) references auth.users(id) on delete cascade;
  end if;
end $$;

commit;
