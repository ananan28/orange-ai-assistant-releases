# Orange AI Assistant 1.0.42 — test build

This engineering recovery uses the public 1.0.33 source backup as its build/test foundation and the user-provided 1.0.40 installer/resources as the authority for current desktop, UI and extension behavior.

263 of 324 top-level functions matched after esbuild normalization and were restored to the readable source bodies from the backup. Other changed functions retain the current runtime implementation; original variable names and comments may not be recoverable. This is a reconstructed maintainable project, not a byte-identical copy of the lost development workspace.

Changes: retryable refresh failures no longer cause forced logout; explicit invalid sessions and administrative revocations still log out. Session-missing errors are classified as definitive. Existing Supabase accounts now allow 50 devices; new accounts default to 50, with validated limits 1–50 in the database, API and UI.

Run `npm ci`, `npm run check`, then `npm run dist:win` on Windows. Dependency versions are pinned to the backup lockfile's actual resolved versions. `beforePack` regenerates desktop and extension staging; `afterPack` validates files, version and runtime markers. The GitHub test workflow builds with `--publish never` and uploads Actions artifacts only. No Release is authorized until the user tests the installer and explicitly confirms.

The current Supabase project is wqyzdzxixpvxeeiwuney. The admin-users backend snapshot includes its existing authentication/administrator checks and only the device-limit edits. App identity, profile name and TN/browser partition identities remain unchanged.
