let sites = [
  ["opensms", "OpenSMS", "opensms.xin"],
  ["skt1", "SKT1", "skt1.net"],
  ["xhsim", "\u661F\u6CB3", "client.xhsim.ai"],
  ["xinghan", "\u661F\u701A", "xinghansms.net"],
  ["c2c", "C2C", "c2csms.com"],
];
const BUILTIN_SITE_ICONS = Object.freeze({
  opensms: "./assets/site-icons/opensms.png",
  skt1: "./assets/site-icons/skt1.png",
  xhsim: "./assets/site-icons/xhsim.png",
  xinghan: "./assets/site-icons/xinghan.png",
  c2c: "./assets/site-icons/c2c.png",
  number_lookup: "./assets/site-icons/phone-lookup.png",
  gtp: "./assets/site-icons/gtp.png",
  gpt: "./assets/site-icons/gtp.png",
  phone_lookup: "./assets/site-icons/phone-lookup.png",
  truepeoplesearch: "./assets/site-icons/phone-lookup.png",
  ip_lookup: "./assets/site-icons/ip-lookup.png",
  ip138: "./assets/site-icons/ip-lookup.png",
});
function builtinSiteIcon(e, u) {
  const t = String(e || "").toLowerCase(),
    n = String(u || "").toLowerCase();
  return BUILTIN_SITE_ICONS[t]
    ? BUILTIN_SITE_ICONS[t]
    : n.includes("truepeoplesearch.com")
      ? BUILTIN_SITE_ICONS.truepeoplesearch
      : n.includes("ip138.com")
        ? BUILTIN_SITE_ICONS.ip138
        : "";
}
const loginView = document.querySelector("#login-view"),
  homeView = document.querySelector("#home-view"),
  form = document.querySelector("#login-form"),
  errorText = document.querySelector("#login-error"),
  loginButton = document.querySelector("#login-button");
let activeProfile = null,
  activePermissions = {},
  activeFeatureFlags = {},
  featureFlagRows = [];
const pendingFeatureFlagChanges = new Map();
let permissionSnapshot = { basic: {}, advanced: {} };
const pendingPermissionChanges = new Map();
let userSnapshot = [],
  blockedIpSnapshot = [],
  adminTnCountSnapshot = new Map(),
  proxyPoolSnapshot = { proxies: [], assignments: [], users: [], settings: {} },
  tnGroupSnapshot = [],
  adminTnGroupSnapshot = [],
  tnLocalProxySnapshot = [],
  messagingSnapshot = {
    currentUser: null,
    contacts: [],
    messages: [],
    announcements: [],
    reads: [],
  },
  activeMessagePeerId = "",
  messagingRefreshTimer = null,
  pendingPrivateAttachment = null,
  pendingPrivateAttachmentUrl = "";
const FEATURES = {
    platform_whatsapp: "WhatsApp \u591A\u8D26\u53F7",
    platform_telegram: "Telegram \u591A\u8D26\u53F7",
    platform_gmail: "Google \u90AE\u7BB1\u591A\u8D26\u53F7",
    tn_assistant: "TN\u6A58\u5B50\u52A9\u624B\u603B\u6743\u9650",
    tn_accounts: "TN\u8D26\u53F7\u7BA1\u7406\u4E0E\u6253\u5F00",
    tn_sender: "TN\u53D1\u9001\u53F0",
    tn_dom_test: "TN\u5B9A\u4F4D\u6D4B\u8BD5",
    tn_live_test: "TN\u6D4B\u8BD5\u5B9E\u53D1",
    chat_translate: "\u804A\u5929\u7FFB\u8BD1",
    page_translate: "\u7F51\u9875\u7FFB\u8BD1",
    input_translate: "\u8F93\u5165\u7FFB\u8BD1",
    ai_reply: "AI\u667A\u80FD\u56DE\u590D",
    reengage: "\u5BA2\u6237\u56DE\u6D41",
    area_lookup: "\u81EA\u52A8\u533A\u53F7\u67E5\u8BE2",
    phone_mask: "\u53F7\u7801\u906E\u6321",
    phone_mask_custom_text: "\u906E\u53F7\u6587\u5B57\u81EA\u5B9A\u4E49",
    phone_mask_custom_color: "\u906E\u53F7\u989C\u8272\u81EA\u5B9A\u4E49",
    bubble_effect: "\u6C14\u6CE1\u6846\u7279\u6548 / \u8DD1\u9A6C\u706F",
    custom_background: "\u81EA\u5B9A\u4E49\u80CC\u666F",
    personal_groq_key: "\u4E2A\u4EBAAI Key",
    public_groq_pool: "\u5458\u5DE5\u516C\u5171AI\u6A21\u578B",
  },
  RELEASE_NOTES = Object.freeze({
    "0.9.9": [
      "\u65B0\u589EOpenAI API\u5B98\u65B9\u670D\u52A1\u5546\u5165\u53E3\uFF0C\u9ED8\u8BA4\u6A21\u578B\u4E3AGPT-5.4 Mini",
      "\u652F\u6301OpenAI\u3001Groq\u3001Gemini\u548C\u5176\u4ED6OpenAI\u517C\u5BB9API\u6309\u4F18\u5148\u7EA7\u81EA\u52A8\u5207\u6362",
      "OpenAI API Key\u7EE7\u7EED\u901A\u8FC7\u73B0\u6709AI\u7F51\u5173\u52A0\u5BC6\u4FDD\u5B58\uFF0C\u4E0D\u5199\u5165\u5BA2\u6237\u7AEF\u6E90\u7801",
      "\u4FEE\u590DOpenAI API Key\u6309\u94AE\u88AB\u684C\u9762\u7AEF\u5916\u90E8\u94FE\u63A5\u767D\u540D\u5355\u62E6\u622A\u7684\u95EE\u9898",
      "\u4FDD\u7559TN\u7A33\u5B9A\u6838\u5FC3\u3001\u56FA\u5B9AIP\u5206\u7EC4\u3001\u7FFB\u8BD1\u3001\u533A\u53F7\u3001AI\u8F85\u52A9\u3001\u901A\u77E5\u548C\u5168\u90E8\u6743\u9650\u7CFB\u7EDF",
    ],
    "9.3.6": [
      "TN CK\u5347\u7EA7\u4E3A\u901A\u7528\u5BFC\u5165\u5668\uFF0C\u652F\u6301Header\u3001cURL\u3001Set-Cookie\u3001Cookie-Editor\u3001DevTools\u3001Netscape\u3001HAR\u548C\u591A\u5C42JSON",
      "\u878D\u5408Beta.6\u7A33\u5B9ATN\u6838\u5FC3\uFF1A\u666E\u901ACK\u6062\u590DTextNow\u5168\u7AD9\u57DF\uFF0C\u91CD\u65B0\u5BFC\u5165\u4E0D\u518D\u5220\u9664\u8BBE\u5907\u3001\u9A8C\u8BC1\u548C\u98CE\u63A7Cookie",
      "\u64A4\u9500\u6D4F\u89C8\u5668\u6807\u8BC6\u4F2A\u88C5\u3001\u9A8C\u8BC1\u7801\u76D1\u63A7\u548C\u81EA\u52A8\u5237\u65B0\uFF0C\u8BA9TextNow\u539F\u751F\u9875\u9762\u81EA\u884C\u5904\u7406\u767B\u5F55\u4E0E\u9A8C\u8BC1",
      "\u6240\u6709\u540E\u53F0\u5E38\u9A7BTN\u7EE7\u7EED\u5B9E\u65F6\u5728\u7EBF\uFF1B\u9690\u85CF\u9875\u9762\u5173\u95ED\u58F0\u97F3\u548C\u52A8\u753B\u5E76\u8DF3\u8FC7\u56FE\u7247\u3001\u89C6\u9891\u3001\u5B57\u4F53\uFF0C\u964D\u4F4E\u591A\u8D26\u53F7\u8D44\u6E90\u5360\u7528",
      "TN\u56FA\u5B9AIP\u5206\u7EC4\u6309\u5F53\u524D\u7528\u6237\u8BB0\u4F4F\u4E0A\u6B21\u9009\u62E9\uFF0C\u8FDE\u7EED\u6DFB\u52A0\u6216\u6279\u91CF\u5BFC\u5165\u65E0\u9700\u53CD\u590D\u9009\u62E9",
      "\u533A\u53F7\u60AC\u6D6E\u5361\u7247\u5728\u7A97\u53E3\u6700\u5927\u5316\u3001\u8FD8\u539F\u548C\u7F29\u653E\u540E\u81EA\u52A8\u6821\u6B63\u56DE\u53EF\u89C1\u533A\u57DF\uFF0C\u5173\u95ED\u72B6\u6001\u4E0D\u4F1A\u88AB\u5F3A\u5236\u6253\u5F00",
    ],
    "9.3.3": [
      "\u4FEE\u590D\u533A\u53F7\u6D6E\u7A97\u666E\u901A\u70B9\u51FB\u6CA1\u6709\u53CD\u5E94\u7684\u95EE\u9898",
      "\u70B9\u51FB\u533A\u53F7\u5185\u5BB9\u7A33\u5B9A\u6253\u5F00\u8BE6\u7EC6\u5730\u533A\u9762\u677F",
      "\u62D6\u52A8\u6539\u4E3A\u72EC\u7ACB\u628A\u624B\uFF0C\u4E0D\u518D\u4E0E\u6253\u5F00\u8BE6\u60C5\u7684\u70B9\u51FB\u4E8B\u4EF6\u51B2\u7A81",
      "\u4FDD\u7559\u4EC5\u5728\u771F\u5B9E\u5BF9\u8BDD\u663E\u793A\u3001\u624B\u52A8\u5173\u95ED\u548C\u91CD\u65B0\u6253\u5F00\u529F\u80FD",
    ],
    "9.3.2": [
      "\u4FEE\u590D\u8F93\u5165\u7FFB\u8BD1\u56DB\u4E2A\u5019\u9009\u6324\u5728\u540C\u4E00\u5C42\u3001\u6587\u5B57\u91CD\u53E0\u548C\u5185\u5BB9\u622A\u65AD",
      "\u77ED\u95EE\u5019\u7A33\u5B9A\u63D0\u4F9BHello\u3001Hi\u548CHey\u7B49\u7F8E\u5F0F\u5019\u9009\uFF0C\u4E0D\u518D\u53EA\u663E\u793A\u4E00\u6761",
      "\u7FFB\u8BD1\u5019\u9009\u6539\u4E3A\u56DB\u5F20\u7EB5\u5411\u5361\u7247\uFF0C\u70B9\u51FB\u4ECD\u53EA\u5199\u5165\u82F1\u6587",
      "\u53D6\u6D88\u7FFB\u8BD1\u5019\u9009\u6846\u53F3\u4FA7\u5C0F\xD7\uFF0C\u53D1\u9001\u3001\u5207\u6362\u5BF9\u8BDD\u6216\u7EE7\u7EED\u8F93\u5165\u540E\u81EA\u52A8\u6536\u8D77",
      "\u4FDD\u75599.3\u6309\u5458\u5DE5\u7F51\u7AD9\u6388\u6743\u3001\u6807\u7B7E\u62D6\u52A8\u3001\u4F1A\u5458\u5468\u671F\u548C\u7A33\u5B9AIP\u7FFB\u8BD1\u94FE\u8DEF",
    ],
    "0.9.3": [
      "\u6062\u590D0.9.0\u7A33\u5B9A\u7FFB\u8BD1IP\u4E3B\u94FE\u8DEF\uFF0C\u5019\u9009\u589E\u5F3A\u5931\u8D25\u4E5F\u4E0D\u5F71\u54CD\u57FA\u7840\u7FFB\u8BD1",
      "\u8F93\u5165\u7FFB\u8BD1\u5347\u7EA7\u4E3A\u82F1\u6587\u3001\u81EA\u7136\u8868\u8FBE\u3001\u5546\u52A1\u8868\u8FBE\u548C\u7F8E\u56FD\u804A\u5929\u8868\u8FBE\u56DB\u79CD\u5019\u9009",
      "\u5019\u9009\u663E\u793A\u4E2D\u6587\u542B\u4E49\uFF0C\u4F46\u70B9\u51FB\u540E\u53EA\u5199\u5165\u82F1\u6587\uFF0C\u4E0D\u4F1A\u628A\u4E2D\u6587\u5E26\u5165\u8F93\u5165\u6846",
      "\u5B8C\u5584\u7F8E\u5F0F\u6807\u70B9\u3001\u7A7A\u683C\u3001\u5F15\u53F7\u3001\u7F29\u5199\u3001\u65E5\u671F\u3001\u91D1\u989D\u3001Emoji\u4F4D\u7F6E\u548C\u804A\u5929\u8BED\u6C14",
      "\u7FFB\u8BD1\u8BF7\u6C42\u589E\u52A0\u8D85\u65F6\u4FDD\u62A4\uFF0C\u53D1\u9001\u3001\u5207\u6362\u8F93\u5165\u548C\u7EE7\u7EED\u7F16\u8F91\u65F6\u81EA\u52A8\u6E05\u7406\u72B6\u6001",
      "\u8D26\u53F7\u7BA1\u7406\u5347\u7EA7\u4E3A\u53F3\u4FA7\u7BA1\u7406\u62BD\u5C49\uFF0C\u652F\u6301\u8D44\u6599\u3001\u4F1A\u5458\u3001\u5FEB\u6377\u7EED\u671F\u548C\u8BBE\u5907\u6570\u96C6\u4E2D\u7BA1\u7406",
      "\u7BA1\u7406\u5458\u53EF\u4E3A\u6BCF\u540D\u5458\u5DE5\u5355\u72EC\u52FE\u9009\u53EF\u89C1\u7F51\u7AD9\uFF0C\u672A\u6388\u6743\u7F51\u7AD9\u548C\u65E7\u6807\u7B7E\u4F1A\u88AB\u62E6\u622A",
      "\u5DE5\u4F5C\u53F0\u6807\u7B7E\u652F\u6301\u62D6\u52A8\u8C03\u6574\u987A\u5E8F\uFF0C\u5E76\u53D6\u6D88\u5BB9\u6613\u8BEF\u89E6\u7684\u5C0F\xD7\u5173\u95ED\u6309\u94AE",
      "\u4FDD\u75590.9.2\u4F1A\u5458\u5468\u671F\u3001\u6C38\u4E45\u5220\u9664\u3001\u6743\u9650\u4E0ESupabase\u517C\u5BB9\u903B\u8F91",
    ],
    "0.9.2": [
      "\u8F93\u5165\u7FFB\u8BD1\u65B0\u589E\u81EA\u7136/\u793C\u8C8C/\u7B80\u77ED\u4E09\u79CD\u7F8E\u5F0F\u8868\u8FBE\uFF0C\u5E76\u652F\u6301\u7FFB\u8BD1\u540E\u64A4\u9500\u4E0E\u56DE\u8BD1\u81EA\u52A8\u6536\u8D77",
      "\u666E\u901A\u4F1A\u5458\u65E0\u6743\u9650\u529F\u80FD\u6539\u4E3A\u660E\u786E\u63D0\u793A\u8054\u7CFB\u7BA1\u7406\u5458\u5F00\u901A\u6216\u7EED\u8D39",
      "\u533A\u53F7\u67E5\u8BE2\u589E\u52A0\u56FA\u5B9A\u60AC\u6D6E\u72B6\u6001\u5165\u53E3\uFF0C\u5207\u6362\u5BA2\u6237\u540E\u81EA\u52A8\u66F4\u65B0",
      "\u8D26\u53F7\u7BA1\u7406\u65B0\u589E\u4F1A\u5458/\u72B6\u6001\u7B5B\u9009\u3001\u5269\u4F59\u5929\u6570\u663E\u793A\u548C\u66F4\u7D27\u51D1\u7684\u7BA1\u7406\u5165\u53E3",
      "\u9AD8\u7EA7\u4F1A\u5458\u5230\u671F\u81EA\u52A8\u8FDB\u5165\u7BA1\u7406\u5458\u53EF\u914D\u7F6E\u7684\u666E\u901A\u4F1A\u5458\u7F13\u51B2\u671F\uFF0C\u7F13\u51B2\u671F\u7ED3\u675F\u81EA\u52A8\u6682\u505C",
      "\u666E\u901A\u4F1A\u5458\u9ED8\u8BA4\u6743\u9650\u4FDD\u6301\u5B89\u5168\u6700\u5C0F\u503C\uFF0C\u4F46\u7BA1\u7406\u5458\u53EF\u4EE5\u6309\u9700\u8C03\u6574",
      "\u8D26\u53F7\u4E0E\u8BBE\u7F6E\u65C1\u663E\u793A\u5F53\u524D\u4F1A\u5458\u7B49\u7EA7\u548C\u5269\u4F59\u53EF\u7528\u5929\u6570",
    ],
    "0.9.1": [
      "TN\u65B0\u589E\u72EC\u7ACB\u603B\u6743\u9650\u5E76\u6539\u4E3A\u7F3A\u5931\u5373\u62D2\u7EDD\uFF0C\u4E3B\u8FDB\u7A0B\u3001\u5DE5\u4F5C\u53F0\u548C\u6269\u5C55\u7EDF\u4E00\u4E8C\u6B21\u6821\u9A8C",
      "TN\u6743\u9650\u6216\u5168\u5C40\u5F00\u5173\u5173\u95ED\u540E\u7ACB\u5373\u505C\u6B62\u540E\u53F0\u9875\u9762\u5E76\u5173\u95ED\u5DF2\u6253\u5F00\u7684TN\u6807\u7B7E",
      "\u4FEE\u590D\u529F\u80FD\u5F00\u5173\u4FDD\u5B58\u540E\u7684\u65E7\u7F13\u5B58\u56DE\u8BFB\uFF0C\u5E76\u4E3A\u5BA1\u8BA1\u5931\u8D25\u589E\u52A0\u6570\u636E\u5E93\u56DE\u6EDA",
      "\u8865\u9F50TN\u672C\u673A\u56FA\u5B9AIP\u3001CK\u8BC6\u522B\u3001\u8FC1\u79FB\u548C\u6807\u7B7E\u53EF\u89C1\u6027IPC\u6743\u9650\u6821\u9A8C",
      "\u6743\u9650\u4FDD\u5B58\u7EE7\u7EED\u6267\u884C\u6570\u636E\u5E93\u56DE\u8BFB\u6821\u9A8C\uFF0C\u65E7\u6570\u636E\u5E93\u5347\u7EA7\u6539\u4E3A0.9.1\u517C\u5BB9\u8FC1\u79FB",
    ],
    "0.9.0": [
      "\u65B0\u589ETN\u53D1\u9001\u53F0\u548C\u57FA\u4E8ETN\u5185\u90E8\u8D26\u53F7ID\u7684\u72EC\u7ACBCK\u5B9A\u4F4D\u6D4B\u8BD5",
      "\u65B0\u589ETextNow\u6536\u4EF6\u4EBA\u3001\u8BDD\u672F\u8F93\u5165\u6846\u548C\u53D1\u9001\u6309\u94AE\u7684\u5931\u8D25\u5373\u505C\u6B62\u5B9A\u4F4D\u5668",
      "\u65B0\u589E\u6D4B\u8BD5\u5B9E\u53D1\u7B2C\u4E00\u6761\uFF1A\u53F7\u7801\u4E25\u683C\u6838\u5BF9\u3001\u53EA\u70B9\u51FB\u4E00\u6B21\u3001\u7ED3\u679C\u4E0D\u660E\u4E0D\u91CD\u8BD5",
      "\u6D88\u606F\u6C14\u6CE1\u8DD1\u9A6C\u706F\u65B0\u589E\u72EC\u7ACB\u5F00\u5173\uFF0C\u5173\u95ED\u540E\u4E0D\u5F71\u54CD\u7FFB\u8BD1\u3001\u80CC\u666F\u3001\u8D34\u56FE\u548C\u53F7\u7801\u906E\u6321",
      "\u4FEE\u590D\u53F7\u7801\u906E\u6321\u5C42\u5C3A\u5BF8\u8FC7\u5927\u5BFC\u81F4\u4F4D\u7F6E\u504F\u79FB\uFF0C\u5E76\u53BB\u9664OpenSMS\u91CD\u590D\u5185\u63CF\u8FB9",
      "\u4FEE\u590D\u8F93\u5165\u7FFB\u8BD1\u5F00\u5173\u91CD\u542F\u540E\u88AB\u5F3A\u5236\u6253\u5F00\u548C\u5386\u53F2\u6D88\u606F\u6F0F\u6389\u6D41\u5149\u7684\u95EE\u9898",
      "\u7AD9\u5185\u804A\u5929\u7C98\u8D34\u3001\u9009\u62E9\u6216\u62D6\u5165\u56FE\u7247\u6539\u4E3A\u5F85\u53D1\u9001\u9884\u89C8\uFF0C\u5FC5\u987B\u70B9\u51FB\u53D1\u9001\u5E76\u53EF\u53D6\u6D88",
      "\u7BA1\u7406\u53F7\u65B0\u589E\u7236\u6A21\u5757\u4E0E\u5B50\u529F\u80FD\u8FDC\u7A0B\u5F00\u5173\uFF0C\u5BA2\u6237\u7AEF15\u79D2\u5185\u540C\u6B65\u5E76\u7531\u4E3B\u8FDB\u7A0B\u5F3A\u5236\u62E6\u622A",
      "\u53D6\u6D88\u6807\u7B7E\u9875\u72EC\u7ACB\u7A97\u53E3\u5165\u53E3\u548C\u62D6\u51FA\u5206\u79BB\uFF0C\u907F\u514D\u8BEF\u70B9\u540E\u8981\u6C42\u91CD\u65B0\u767B\u5F55",
      "\u5173\u95ED\u80CC\u666F\u65F6\u9500\u6BC1\u5408\u6210\u5C42\uFF0CTextNow\u89C2\u5BDF\u8303\u56F4\u7F29\u5C0F\u5E76\u5728\u7A97\u53E3\u9690\u85CF\u65F6\u6682\u505C\u626B\u63CF",
    ],
    "0.8.6": [
      "\u4FEE\u590DTN\u65E7\u8D26\u53F7\u9A8C\u8BC1\u6846\u7A7A\u767D\uFF1A\u9A8C\u8BC1\u671F\u95F4\u4EC5\u5BF9\u5F53\u524D\u8D26\u53F7\u4E34\u65F6\u6682\u505C\u5E7F\u544A\u62E6\u622A",
      "\u9A8C\u8BC1\u51FA\u73B0\u65F6\u53EA\u81EA\u52A8\u91CD\u8F7D\u4E00\u6B21\uFF0C\u907F\u514D\u540E\u53F0\u53CD\u590D\u5237\u65B0\u548C\u91CD\u590D\u89E6\u53D1\u9A8C\u8BC1",
      "\u5386\u53F2\u53D1\u9001\u5931\u8D25\u6587\u5B57\u4E0D\u518D\u88AB\u8BEF\u5224\u4E3A\u4ECD\u5904\u4E8E\u9A8C\u8BC1\u7801\u72B6\u6001",
      "\u4FDD\u7559Beta.6\u5B8C\u6574\u4F1A\u8BDD\u4E00\u952E\u8FC1\u79FB\uFF0C\u65E7\u8D26\u53F7\u6CBF\u7528\u5DF2\u9A8C\u8BC1\u7684\u6D4F\u89C8\u5668\u72B6\u6001",
      "TN\u58C1\u7EB8\u3001\u4EAE\u5EA6\u3001\u6A21\u7CCA\u3001\u900F\u660E\u5EA6\u3001\u8BD1\u6587\u989C\u8272\u548C\u6D41\u5149\u8BBE\u7F6E\u5728\u5F53\u524D\u5458\u5DE5\u6240\u6709TN\u8D26\u53F7\u95F4\u81EA\u52A8\u540C\u6B65",
      "\u53F7\u7801\u906E\u6321\u4F1A\u8986\u76D6\u5F53\u524D\u4F1A\u8BDD\u4E2D\u540C\u4E00\u5BA2\u6237\u53F7\u7801\u7684\u5168\u90E8\u53EF\u89C1\u4F4D\u7F6E\uFF0C\u5305\u62EC\u56FE\u7247\u6D88\u606F\u4E0E\u6EDA\u52A8\u52A0\u8F7D\u8BB0\u5F55",
      "\u6062\u590D\u65E7\u7248\u5168\u5E73\u53F0\u7C97\u5F69\u8272\u5206\u6BB5\u8DD1\u9A6C\u706F\uFF0C\u5E76\u8BA9\u5F69\u8679\u5149\u5E26\u771F\u6B63\u6CBF\u6C14\u6CE1\u56DB\u5468\u6301\u7EED\u6D41\u52A8",
      "\u6062\u590DOpenSMS\u6C14\u6CE1\u4E0A\u6CBF\u7684\u5C0F\u4EBA\u7269\u8D34\u7EB8\uFF0C\u5DE6\u53F3\u6D88\u606F\u81EA\u52A8\u955C\u50CF\u4E14\u4E0D\u906E\u6321\u6B63\u6587",
      "\u4FEE\u590D\u901A\u7528\u6C14\u6CE1\u4E0EOpenSMS\u5916\u58F3\u540C\u65F6\u547D\u4E2D\u9020\u6210\u7684\u53CC\u5C42\u6D41\u5149\u6846\uFF0C\u53EA\u4FDD\u7559\u4E00\u4E2A\u5916\u5C42\u8DD1\u9A6C\u706F",
      "\u65B0\u8D26\u53F7\u3001\u65E7\u8D26\u53F7\u548C\u6BCF\u4F4D\u5458\u5DE5\u7684TN\u6D4F\u89C8\u5668\u5206\u533A\u7EE7\u7EED\u4E25\u683C\u9694\u79BB",
    ],
    "0.8.5": [
      "\u4FEE\u590D\u5458\u5DE5\u53D1\u5E03\u8FC7\u516C\u544A\u540E\u65E0\u6CD5\u6C38\u4E45\u5220\u9664\u8D26\u53F7\u7684\u95EE\u9898",
      "\u6062\u590D\u8D26\u53F7\u65F6\u81EA\u52A8\u6E05\u9664\u8BBE\u5907\u64A4\u9500\u72B6\u6001\u548C\u5F3A\u5236\u4E0B\u7EBF\u6807\u8BB0",
      "\u8D26\u53F7\u7BA1\u7406\u65B0\u589E\u91CD\u65B0\u6388\u6743\u6309\u94AE\uFF0C\u539F\u7535\u8111\u53EF\u91CD\u65B0\u767B\u5F55",
      "\u4FDD\u75590.8.4\u7684\u7AD9\u5185\u56FE\u7247\u3001\u6587\u4EF6\u3001\u7C98\u8D34\u622A\u56FE\u3001\u5DF2\u8BFB\u8BC6\u522B\u548C\u6700\u8FD1\u8054\u7CFB\u4EBA\u6392\u5E8F",
      "\u4FDD\u75590.8.3\u7684TN\u8FDE\u63A5\u3001\u5458\u5DE5\u81EA\u5EFAIP\u9009\u62E9\u548C\u8D26\u53F7\u9694\u79BB\u4FEE\u590D",
    ],
    "0.8.4": [
      "\u7AD9\u5185\u79C1\u804A\u652F\u6301\u53D1\u9001\u56FE\u7247\u3001\u5E38\u7528\u6587\u4EF6\u548CCtrl+V\u7C98\u8D34\u622A\u56FE",
      "\u56FE\u7247\u53EF\u5728\u804A\u5929\u4E2D\u9884\u89C8\uFF0C\u666E\u901A\u9644\u4EF6\u663E\u793A\u6587\u4EF6\u540D\u4E0E\u5927\u5C0F\u5E76\u5B89\u5168\u4E0B\u8F7D",
      "\u4FEE\u590D\u505C\u7559\u5728\u5F53\u524D\u5BF9\u8BDD\u65F6\u672A\u81EA\u52A8\u8BC6\u522B\u5DF2\u8BFB\u7684\u95EE\u9898",
      "\u7AD9\u5185\u6D88\u606F\u5B9E\u65F6\u8FDE\u63A5\u652F\u6301\u4EE4\u724C\u540C\u6B65\u3001\u65AD\u7EBF\u91CD\u8FDE\u548C\u5B9A\u65F6\u5237\u65B0\u515C\u5E95",
      "\u804A\u5929\u8BB0\u5F55\u6539\u4E3A\u72EC\u7ACB\u6EDA\u52A8\u533A\u57DF\uFF0C\u4E0D\u518D\u628A\u6574\u4E2A\u7BA1\u7406\u9875\u9762\u8D8A\u6491\u8D8A\u957F",
      "\u9644\u4EF6\u4EC5\u53D1\u9001\u53CC\u65B9\u53EF\u8BBF\u95EE\uFF0C\u7BA1\u7406\u5458\u4E0D\u80FD\u6253\u5F00\u5458\u5DE5\u79C1\u804A\u9644\u4EF6",
    ],
    "0.8.3": [
      "\u4F18\u5148\u4FEE\u590DTN\uFF1A\u540C\u6B65Beta.6\u7A33\u5B9A\u8FDE\u63A5\u751F\u547D\u5468\u671F\uFF0C\u9A8C\u8BC1\u7801\u51FA\u73B0\u65F6\u6682\u505C\u540E\u53F0\u91CD\u590D\u91CD\u8FDE",
      "\u65B0\u589E\u4E00\u6B21\u6027\u5BFC\u5165Beta.6 TN\u72B6\u6001\uFF0C\u540C\u540D\u8D26\u53F7\u8FC1\u5165\u5F53\u524D\u5458\u5DE5\u72EC\u7ACB\u6D4F\u89C8\u5668\u73AF\u5883",
      "\u6BCF\u4E2ATN\u8D26\u53F7\u53EF\u5728\u7BA1\u7406\u5458\u56FA\u5B9A\u5206\u7EC4\u4E0E\u5458\u5DE5\u81EA\u5EFAIP\u4E4B\u95F4\u53CC\u5411\u5207\u6362",
      "\u5458\u5DE5\u81EA\u5EFAIP\u6309\u5458\u5DE5\u9694\u79BB\u4FDD\u5B58\uFF0C\u5176\u4ED6\u5458\u5DE5\u4E0D\u53EF\u89C1\uFF0C\u7BA1\u7406\u5458\u4E5F\u4E0D\u80FD\u6253\u5F00\u5458\u5DE5TN",
      "\u66F4\u6362IP\u65F6\u6821\u9A8C\u5BB9\u91CF\u3001\u6E05\u9664\u65E7\u7EBF\u8DEF\u6A21\u5F0F\u5E76\u53EA\u91CD\u8FDE\u5F53\u524DTN\u8D26\u53F7",
    ],
    "0.8.2": [
      "\u4FEE\u590D\u7F51\u7AD9\u7BA1\u7406\u4FDD\u5B58\u5931\u8D25\uFF0C\u8865\u9F50\u7F51\u7AD9\u56FA\u5B9AIP\u6570\u636E\u5E93\u5B57\u6BB5\u5347\u7EA7",
      "\u65B0\u589EGTP/GPT\u5E73\u53F0\u5185\u7F6E\u9AD8\u6E05\u56FE\u6807\uFF0C\u9996\u9875\u3001\u5E73\u53F0\u9009\u62E9\u548C\u6807\u7B7E\u9875\u7EDF\u4E00\u663E\u793A",
      "\u4FDD\u75590.8.1\u7684\u7F51\u7AD9\u7BA1\u7406\u3001\u516C\u544A\u7F16\u8F91\u5220\u9664\u3001\u5458\u5DE5\u79C1\u804A\u548CTN\u8D26\u53F7\u9694\u79BB\u529F\u80FD",
      "\u4FEE\u590D\u81EA\u52A8\u66F4\u65B0\u6587\u4EF6\u672A\u53D1\u5E03\u65F6\u663E\u793A\u6574\u6BB5\u82F1\u6587\u6280\u672F\u9519\u8BEF\u7684\u95EE\u9898",
      "\u6B63\u5F0F\u53D1\u5E03\u524D\u7EE7\u7EED\u6267\u884C\u6253\u5305\u542F\u52A8\u6587\u4EF6\u4E0E\u6269\u5C55\u8D44\u6E90\u5B8C\u6574\u6027\u68C0\u67E5",
    ],
    "0.8.1": [
      "\u4EE5\u7A33\u5B9A\u76840.7.1\u4E3A\u5E95\u5EA7\u5347\u7EA7\uFF0C\u4FDD\u7559\u539F\u7248\u5168\u5E73\u53F0\u4E94\u5F69\u6D41\u52A8\u8DD1\u9A6C\u706F",
      "\u4FEE\u590D\u906E\u6321\u80CC\u666F\u989C\u8272\u8BBE\u7F6E\u65E0\u6548\uFF0C\u5E76\u7EE7\u7EED\u4FDD\u8BC1\u6587\u5B57\u6E05\u6670",
      "\u6279\u91CFCK\u652F\u6301\u8FDE\u7EED\u6570\u7EC4\u3001\u8FDE\u7EED\u5BF9\u8C61\u3001\u6279\u91CF\u5BF9\u8C61\u548C\u5206\u9694\u7EBF\uFF0C\u5E76\u53EF\u5148\u8BC6\u522B\u6570\u91CF",
      "TN\u8D26\u53F7\u3001Cookie\u5206\u533A\u548C\u5458\u5DE5\u672C\u673AIP\u6309\u5458\u5DE5\u8D26\u53F7\u5F7B\u5E95\u9694\u79BB",
      "\u7BA1\u7406\u5458\u53EA\u80FD\u67E5\u770B\u5458\u5DE5TN\u6570\u91CF\uFF0C\u4E0D\u80FD\u6253\u5F00\u5458\u5DE5TN\u6216\u67E5\u770BCK\u3001\u540D\u79F0\u548CIP",
      "\u65B0\u589E\u7BA1\u7406\u5458\u516C\u544A\u3001\u6307\u5B9A\u5458\u5DE5\u516C\u544A\u548C\u516C\u544A\u5DF2\u8BFB\u72B6\u6001",
      "\u65B0\u589E\u5458\u5DE5\u4E00\u5BF9\u4E00\u79C1\u804A\u3001\u8054\u7CFB\u4EBA\u9009\u62E9\u3001\u672A\u8BFB\u6570\u91CF\u548C\u5DF2\u8BFB\u56DE\u6267",
      "\u65B0\u589E\u6E05\u7A7A\u5F53\u524D\u804A\u5929\u548C\u6E05\u7A7A\u5168\u90E8\u79C1\u804A",
      "\u4FEE\u590D\u7F51\u7AD9\u7BA1\u7406\u7A7A\u767D\uFF0C\u517C\u5BB9\u65B0\u65E7work_sites\u5B57\u6BB5\u5E76\u4FDD\u7559\u539F\u6709\u7F51\u7AD9",
      "\u4FEE\u590D\u4FDD\u5B58\u7F51\u7AD9\u65E0\u53CD\u9988\uFF0C\u6570\u5B57\u6807\u8BC6\u81EA\u52A8\u8F6C\u6362\u5E76\u5728\u5F53\u524D\u9875\u9762\u663E\u793A\u7ED3\u679C",
      "\u516C\u544A\u589E\u52A0\u7F16\u8F91\u3001\u5220\u9664\u548C\u53D6\u6D88\u7F16\u8F91\u529F\u80FD",
      "\u53D1\u73B0\u65B0\u7248\u672C\u65F6\u663E\u793A\u66F4\u65B0\u5185\u5BB9\u5E76\u63D0\u9192\u4E0B\u8F7D",
    ],
  });
function esc(e) {
  return String(e ?? "").replace(
    /[&<>'"]/g,
    (u) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[u],
  );
}
function setAdminPage(e) {
  (document
    .querySelectorAll("#admin-page-area > [data-admin-page]")
    .forEach((u) => u.classList.toggle("active", u.dataset.adminPage === e)),
    document
      .querySelectorAll("[data-admin-nav]")
      .forEach((u) => u.classList.toggle("active", u.dataset.adminNav === e)),
    document.querySelector("#admin-panel")?.scrollIntoView({ block: "start" }));
}
const MANAGED_ACCOUNT_LABELS = {
  whatsapp: "WhatsApp",
  telegram: "Telegram",
  gmail: "Google \u90AE\u7BB1",
};
async function loadManagedAccounts(e) {
  const u = document.querySelector(`[data-account-platform="${e}"]`);
  if (!u) return;
  const t = u.querySelector("[data-managed-account-body]"),
    n = u.querySelector("[data-managed-message]");
  n.textContent = "\u6B63\u5728\u8BFB\u53D6\u8D26\u53F7\u2026";
  const o = await window.orangeApp.listManagedSiteAccounts({ siteId: e });
  if (!o?.ok) {
    ((t.innerHTML = ""),
      (n.textContent = o?.message || "\u8D26\u53F7\u8BFB\u53D6\u5931\u8D25"),
      n.classList.add("error"));
    return;
  }
  (n.classList.remove("error"),
    (n.textContent = o.accounts.length
      ? `\u5171 ${o.accounts.length} \u4E2A\u72EC\u7ACB\u8D26\u53F7`
      : `\u5C1A\u672A\u6DFB\u52A0${MANAGED_ACCOUNT_LABELS[e]}\u8D26\u53F7`),
    (t.innerHTML = o.accounts
      .map(
        (a) => `<tr data-managed-id="${esc(a.id)}">
        <td><input type="checkbox" data-managed-select="${esc(a.id)}" aria-label="\u9009\u62E9${esc(a.name)}" ${a.enabled === !1 ? "disabled" : ""} /></td>
        <td><input data-managed-name value="${esc(a.name)}" maxlength="60" /></td>
        <td><input data-managed-note value="${esc(a.note || "")}" maxlength="120" /></td>
        <td><input data-managed-proxy autocomplete="off" placeholder="${a.hasFixedProxy ? "\u5DF2\u4FDD\u5B58\u56FA\u5B9AIP\uFF1B\u7559\u7A7A\u4FDD\u6301\u4E0D\u53D8" : "\u672A\u8BBE\u7F6E\uFF1B\u53EF\u5728\u6B64\u586B\u5199"}" /><small>${a.hasFixedProxy ? "\u5DF2\u56FA\u5B9A\uFF0C\u4E0D\u81EA\u52A8\u6362IP" : "\u8DDF\u968F\u5E73\u53F0\u7EBF\u8DEF"}</small></td>
        <td><span class="tn-status ${a.enabled === !1 ? "disconnected" : a.isOpen ? "connected" : "saved"}">${a.enabled === !1 ? "\u5DF2\u505C\u7528" : a.isOpen ? "\u5DF2\u6253\u5F00" : "\u672A\u6253\u5F00"}</span></td>
        <td class="actions"><button type="button" data-managed-open ${a.enabled === !1 ? "disabled" : ""}>${a.isOpen ? `\u5207\u6362\u5230${MANAGED_ACCOUNT_LABELS[e]}` : "\u6253\u5F00"}</button><button type="button" data-managed-save>\u4FDD\u5B58</button><button type="button" data-managed-toggle>${a.enabled === !1 ? "\u542F\u7528" : "\u505C\u7528"}</button><button type="button" data-managed-clear-proxy ${a.hasFixedProxy ? "" : "disabled"}>\u6E05\u9664IP</button><button type="button" class="danger" data-managed-delete>\u5220\u9664\u6570\u636E</button></td>
      </tr>`,
      )
      .join("")),
    t.querySelectorAll("tr[data-managed-id]").forEach((a) => {
      const r = a.dataset.managedId,
        s = o.accounts.find((c) => c.id === r);
      ((a.querySelector("[data-managed-open]").onclick = async () => {
        const c = a.querySelector("[data-managed-open]");
        c.disabled = !0;
        const i = await window.orangeApp.openManagedSiteAccount({ siteId: e, id: r });
        if (!i?.ok) {
          (alert(i?.message || "\u8D26\u53F7\u6253\u5F00\u5931\u8D25"), (c.disabled = !1));
          return;
        }
        ((c.textContent =
          e === "gmail" ? "\u5207\u6362\u5230\u90AE\u7BB1" : "\u5207\u6362\u5230\u8D26\u53F7"),
          (c.disabled = !1),
          setTimeout(() => loadManagedAccounts(e), 350));
      }),
        (a.querySelector("[data-managed-save]").onclick = async () => {
          const c = {
              siteId: e,
              id: r,
              name: a.querySelector("[data-managed-name]").value,
              note: a.querySelector("[data-managed-note]").value,
            },
            i = a.querySelector("[data-managed-proxy]").value.trim();
          i && (c.fixedProxy = i);
          const d = await window.orangeApp.updateManagedSiteAccount(c);
          if (!d?.ok) return alert(d?.message || "\u4FDD\u5B58\u5931\u8D25");
          await loadManagedAccounts(e);
        }),
        (a.querySelector("[data-managed-toggle]").onclick = async () => {
          const c = await window.orangeApp.updateManagedSiteAccount({
            siteId: e,
            id: r,
            enabled: s.enabled === !1,
          });
          if (!c?.ok) return alert(c?.message || "\u72B6\u6001\u4FDD\u5B58\u5931\u8D25");
          await loadManagedAccounts(e);
        }),
        (a.querySelector("[data-managed-clear-proxy]").onclick = async () => {
          if (
            !confirm(
              "\u786E\u5B9A\u6E05\u9664\u8FD9\u4E2A\u8D26\u53F7\u7684\u56FA\u5B9AIP\u5417\uFF1F",
            )
          )
            return;
          const c = await window.orangeApp.updateManagedSiteAccount({
            siteId: e,
            id: r,
            fixedProxy: "",
          });
          if (!c?.ok) return alert(c?.message || "\u56FA\u5B9AIP\u6E05\u9664\u5931\u8D25");
          await loadManagedAccounts(e);
        }),
        (a.querySelector("[data-managed-delete]").onclick = async () => {
          if (
            !confirm(
              "\u5C06\u5220\u9664\u8BE5\u8D26\u53F7\u5728\u672C\u673A\u7684\u767B\u5F55\u72B6\u6001\u3001Cookie\u3001\u7F13\u5B58\u3001\u58C1\u7EB8\u548C\u56FA\u5B9AIP\uFF0C\u662F\u5426\u7EE7\u7EED\uFF1F",
            ) ||
            !confirm(
              "\u518D\u6B21\u786E\u8BA4\uFF1A\u5220\u9664\u540E\u9700\u8981\u91CD\u65B0\u767B\u5F55\uFF0C\u4E14\u65E0\u6CD5\u6062\u590D\u3002",
            )
          )
            return;
          const c = await window.orangeApp.deleteSiteAccountData({ siteId: e, siteInstanceId: r });
          if (!c?.ok)
            return alert(
              c?.message || "\u672C\u673A\u8D26\u53F7\u6570\u636E\u5220\u9664\u5931\u8D25",
            );
          await loadManagedAccounts(e);
        }));
    }),
    (() => {
      const a = () => {
          const s = [...t.querySelectorAll("[data-managed-select]:checked")];
          u.querySelector("[data-managed-selected-count]").textContent =
            `\u5DF2\u9009 ${s.length} \u4E2A`;
          const c = [...t.querySelectorAll("[data-managed-select]:not(:disabled)")],
            i = u.querySelector("[data-managed-check-all]");
          ((i.checked = c.length > 0 && s.length === c.length),
            (i.indeterminate = s.length > 0 && s.length < c.length));
        },
        r = [...t.querySelectorAll("[data-managed-select]:not(:disabled)")];
      (r.forEach((s) => s.addEventListener("change", a)),
        (u.querySelector("[data-managed-check-all]").onchange = (s) => {
          (r.forEach((c) => (c.checked = s.target.checked)), a());
        }),
        (u.querySelector("[data-managed-select-all]").onclick = () => {
          const s = !r.length || !r.every((c) => c.checked);
          (r.forEach((c) => (c.checked = s)), a());
        }),
        (u.querySelector("[data-managed-open-selected]").onclick = async (s) => {
          const c = [...t.querySelectorAll("[data-managed-select]:checked")].map(
            (l) => l.dataset.managedSelect,
          );
          if (!c.length)
            return alert("\u8BF7\u5148\u9009\u62E9\u8981\u6253\u5F00\u7684\u8D26\u53F7");
          s.currentTarget.disabled = !0;
          let i = 0;
          const d = [];
          for (const l of c) {
            const m = await window.orangeApp.openManagedSiteAccount({ siteId: e, id: l });
            m?.ok ? (i += 1) : d.push(m?.message || "\u6253\u5F00\u5931\u8D25");
          }
          ((s.currentTarget.disabled = !1),
            (n.textContent = d.length
              ? `\u5DF2\u6253\u5F00 ${i} \u4E2A\uFF0C${d.length} \u4E2A\u5931\u8D25\uFF1A${d.slice(0, 2).join("\uFF1B")}`
              : `\u5DF2\u6253\u5F00 ${i} \u4E2A${MANAGED_ACCOUNT_LABELS[e]}\u8D26\u53F7`),
            setTimeout(() => loadManagedAccounts(e), 450));
        }),
        a());
    })());
}
(document.querySelectorAll("[data-account-platform]").forEach((e) => {
  const u = e.dataset.accountPlatform;
  ((e.querySelector("[data-managed-refresh]").onclick = () => loadManagedAccounts(u)),
    e.querySelector("[data-managed-form]").addEventListener("submit", async (t) => {
      t.preventDefault();
      const n = t.currentTarget,
        o = await window.orangeApp.createManagedSiteAccount({
          siteId: u,
          name: n.elements.name.value,
          note: n.elements.note.value,
          fixedProxy: n.elements.fixedProxy.value,
        });
      if (!o?.ok) return alert(o?.message || "\u8D26\u53F7\u6DFB\u52A0\u5931\u8D25");
      (n.reset(), await loadManagedAccounts(u));
    }));
}),
  window.orangeApp.onShowPlatformPicker?.(() => {
    homeView.classList.contains("hidden") ||
      (document.querySelectorAll("dialog[open]").forEach((e) => e.close()),
      setAdminPage("platform"));
  }));
function arrangeHomeForRole(e) {
  const u = document.querySelector("#admin-page-area"),
    t = document.querySelector("#platform-home"),
    n = document.querySelector(".ai-key-panel");
  (u.prepend(t), u.append(n));
  const a =
      document.querySelector("#tn-managed-pool-panel") ||
      document.querySelector("#tn-group-form")?.closest(".admin-subsection"),
    o = document.querySelector("#tn-proxy-admin-slot");
  (a && o && ((a.id = "tn-managed-pool-panel"), o.append(a)), setAdminPage("platform"));
}
function renderHome(e, u, t = {}) {
  ((activeProfile = e),
    (activePermissions = t || {}),
    Array.isArray(u) && u.length
      ? (sites = u.map((a) => [a.id, a.name, a.host, a.iconUrl || builtinSiteIcon(a.id, a.host)]))
      : (sites = sites.map(([a, r, s, c]) => [a, r, s, c || builtinSiteIcon(a, s)])),
    applyDashboardWallpaper(),
    (document.querySelector("#welcome-title").textContent =
      `\u4F60\u597D\uFF0C${e.display_name || e.username}`),
    (document.querySelector("#account-badge").textContent =
      e.role === "admin"
        ? "\u7BA1\u7406\u5458"
        : e.plan === "advanced"
          ? "\u9AD8\u7EA7\u4F1A\u5458"
          : "\u666E\u901A\u4F1A\u5458"),
    refreshMembershipBadge(),
    Object.keys(MANAGED_ACCOUNT_LABELS).forEach((a) =>
      document
        .querySelector(`[data-admin-nav="${a}"]`)
        ?.classList.toggle("hidden", !sites.some(([r]) => String(r).toLowerCase() === a)),
    ),
    (document.querySelector("#site-grid").innerHTML = sites
      .filter(
        ([a]) =>
          !Object.prototype.hasOwnProperty.call(MANAGED_ACCOUNT_LABELS, String(a).toLowerCase()),
      )
      .map(
        ([a, r, s, c]) => `
    <button class="site-card" data-site="${esc(a)}">${
      c
        ? `<img class="site-card-icon" src="${esc(c)}" alt=""/>`
        : `<i class="site-card-icon">${esc(
            String(r || "?")
              .slice(0, 1)
              .toUpperCase(),
          )}</i>`
    }<strong>${esc(r)}</strong><span>${esc(s)}</span><small>\u8FDB\u5165\u5E73\u53F0 \u2192</small></button>
  `,
      )
      .join("")),
    document.querySelectorAll(".site-card").forEach((a) =>
      a.addEventListener("click", async () => {
        const r = await window.orangeApp.openSite(a.dataset.site);
        r?.ok
          ? document.querySelector("#restore-window-banner")?.classList.add("hidden")
          : alert(
              r?.message ||
                "\u7F51\u7AD9\u6253\u5F00\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u8FDE\u63A5",
            );
      }),
    ),
    document.querySelectorAll(".site-card img.site-card-icon").forEach((a) =>
      a.addEventListener(
        "error",
        () => {
          const r = document.createElement("i");
          ((r.className = "site-card-icon"),
            (r.textContent = String(
              a.closest(".site-card")?.querySelector("strong")?.textContent || "?",
            )
              .slice(0, 1)
              .toUpperCase()),
            a.replaceWith(r));
        },
        { once: !0 },
      ),
    ));
  const n = e.role === "admin";
  (arrangeHomeForRole(n),
    (document.querySelector("#workspace-title").textContent = n
      ? "\u7BA1\u7406\u63A7\u5236\u53F0"
      : "\u5458\u5DE5\u5DE5\u4F5C\u53F0"),
    (document.querySelector("#workspace-hint").textContent = n
      ? "\u6BCF\u4F4D\u7BA1\u7406\u5458\u53EF\u5355\u72EC\u8BBE\u7F6E\u81EA\u5DF1\u7684AI\u6A21\u578B\u987A\u5E8F"
      : "\u53EA\u663E\u793A\u5F53\u524D\u8D26\u53F7\u6709\u6743\u4F7F\u7528\u7684\u529F\u80FD"),
    document.querySelectorAll("[data-admin-only]").forEach((a) => a.classList.toggle("hidden", !n)),
    (document.querySelector("#ai-nav-button").textContent = n
      ? "AI\u6A21\u578B\u7BA1\u7406"
      : "\u6211\u7684AI\u6A21\u578B"),
    document.querySelector("#public-key-field").classList.toggle("hidden", !n),
    document.querySelector("#ai-pool-settings").classList.toggle("hidden", !n),
    document.querySelector("#admin-panel").classList.remove("hidden"),
    loginView.classList.add("hidden"),
    homeView.classList.remove("hidden"),
    n && loadUsers(),
    n &&
      (loadSitesAdmin(),
      loadPermissions(),
      loadFeatureFlags(),
      loadProxyPool(),
      loadProxyLogs(),
      loadAdminTnGroups()));
  const o = n || activePermissions.personal_groq_key === !0;
  (document.querySelector(".ai-key-panel").classList.toggle("hidden", !o),
    document.querySelector("#ai-nav-button").classList.toggle("hidden", !o),
    o && loadAiKeys(),
    populateCredentialSites(),
    loadTnAccounts(),
    loadMessagingCenter(),
    showReleaseNotesOnce(),
    updateRestoreWindowBanner());
}
async function showReleaseNotesOnce() {
  const e = await window.orangeApp.getUpdateState().catch(() => ({})),
    u = String(e?.currentVersion || ""),
    t = RELEASE_NOTES[u];
  if (!t?.length || !activeProfile?.id) return;
  const n = `orangeReleaseNotesSeen:${activeProfile.id}`;
  localStorage.getItem(n) !== u &&
    ((document.querySelector("#release-notes-title").textContent = `\u5DF2\u5347\u7EA7\u5230 ${u}`),
    (document.querySelector("#release-notes-list").innerHTML = t
      .map((a) => `<li>${esc(a)}</li>`)
      .join("")),
    document.querySelector("#release-notes-dialog").showModal(),
    localStorage.setItem(n, u));
}
function formatMessageTime(e) {
  const u = new Date(e);
  return Number.isFinite(u.getTime())
    ? u.toLocaleString("zh-CN", {
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "";
}
function contactLabel(e) {
  return String(e?.display_name || e?.username || "\u5458\u5DE5");
}
function messagesWithPeer(e) {
  const u = messagingSnapshot.currentUser?.id;
  return messagingSnapshot.messages.filter(
    (t) =>
      (t.sender_id === u && t.recipient_id === e) || (t.sender_id === e && t.recipient_id === u),
  );
}
function unreadFromPeer(e) {
  const u = messagingSnapshot.currentUser?.id;
  return messagingSnapshot.messages.filter(
    (t) => t.sender_id === e && t.recipient_id === u && !t.read_at,
  ).length;
}
function formatFileSize(e) {
  const u = Number(e || 0);
  return u < 1024
    ? `${u} B`
    : u < 1024 * 1024
      ? `${(u / 1024).toFixed(1)} KB`
      : `${(u / 1024 / 1024).toFixed(1)} MB`;
}
function renderMessageNavBadge() {
  const e = messagingSnapshot.contacts.reduce((r, s) => r + unreadFromPeer(s.id), 0),
    u = new Set(
      messagingSnapshot.reads
        .filter((r) => r.user_id === messagingSnapshot.currentUser?.id)
        .map((r) => r.announcement_id),
    ),
    t = messagingSnapshot.currentUser?.id,
    n = messagingSnapshot.announcements.filter(
      (r) => (!r.target_user_id || r.target_user_id === t) && !u.has(r.id),
    ).length,
    a = e + n,
    o = document.querySelector("#message-nav-badge");
  ((o.textContent = a > 99 ? "99+" : String(a)),
    o.classList.toggle("hidden", a === 0),
    (document.querySelector("#message-unread-total").textContent = e
      ? `${e} \u6761\u672A\u8BFB`
      : "\u5168\u90E8\u5DF2\u8BFB"));
}
function renderMessageContacts() {
  const e = document.querySelector("#message-contact-list"),
    u = String(document.querySelector("#message-contact-search")?.value || "")
      .trim()
      .toLowerCase(),
    t = new Map();
  messagingSnapshot.messages.forEach((r) => {
    const s = messagingSnapshot.currentUser?.id,
      c = r.sender_id === s ? r.recipient_id : r.sender_id,
      i = new Date(r.created_at).getTime() || 0;
    c && i > (t.get(c) || 0) && t.set(c, i);
  });
  const n = messagingSnapshot.contacts
    .filter((r) => !u || `${r.username} ${r.display_name || ""}`.toLowerCase().includes(u))
    .sort(
      (r, s) =>
        (t.get(s.id) || 0) - (t.get(r.id) || 0) ||
        contactLabel(r).localeCompare(contactLabel(s), "zh-CN"),
    );
  ((e.innerHTML =
    n
      .map((r) => {
        const s = unreadFromPeer(r.id),
          c = contactLabel(r);
        return `<button class="message-contact ${r.id === activeMessagePeerId ? "active" : ""}" type="button" data-message-peer="${esc(r.id)}"><span class="message-avatar">${esc(c.slice(0, 1).toUpperCase())}</span><span class="message-contact-name"><strong>${esc(c)}</strong><small>${esc(r.username || "")}</small></span>${s ? `<span class="message-unread">${s > 99 ? "99+" : s}</span>` : ""}</button>`;
      })
      .join("") || '<div class="message-empty">\u6CA1\u6709\u5339\u914D\u7684\u5458\u5DE5</div>'),
    e
      .querySelectorAll("[data-message-peer]")
      .forEach((r) => r.addEventListener("click", () => selectMessagePeer(r.dataset.messagePeer))));
  const a = document.querySelector("#announcement-target"),
    o = a.value;
  ((a.innerHTML =
    '<option value="">\u5168\u4F53\u5458\u5DE5</option>' +
    messagingSnapshot.contacts
      .map(
        (r) =>
          `<option value="${esc(r.id)}">${esc(contactLabel(r))} \xB7 ${esc(r.username || "")}</option>`,
      )
      .join("")),
    [...a.options].some((r) => r.value === o) && (a.value = o));
}
function renderPrivateConversation() {
  const e = messagingSnapshot.contacts.find((c) => c.id === activeMessagePeerId),
    u = document.querySelector("#private-message-list"),
    t = document.querySelector("#private-message-input"),
    n = document.querySelector("#private-message-send"),
    a = document.querySelector("#private-attachment-button"),
    o = document.querySelector("#clear-current-conversation");
  if (
    ((document.querySelector("#private-chat-title").textContent = e
      ? contactLabel(e)
      : "\u8BF7\u9009\u62E9\u5BF9\u8BDD\u5458\u5DE5"),
    (document.querySelector("#private-chat-status").textContent = e
      ? `\u8D26\u53F7\uFF1A${e.username || ""} \xB7 \u6D88\u606F\u4EC5\u53CC\u65B9\u53EF\u89C1`
      : "\u6D88\u606F\u4EC5\u53CC\u65B9\u53EF\u89C1"),
    (t.disabled = !e),
    (n.disabled = !e),
    (a.disabled = !e),
    (o.disabled = !e),
    !e)
  ) {
    u.innerHTML =
      '<div class="message-empty">\u4ECE\u5DE6\u4FA7\u9009\u62E9\u4E00\u540D\u5458\u5DE5\u5F00\u59CB\u5BF9\u8BDD</div>';
    return;
  }
  const r = messagingSnapshot.currentUser?.id,
    s = messagesWithPeer(e.id);
  ((u.innerHTML =
    s
      .map((c) => {
        const i = c.sender_id === r;
        let d = esc(c.body || "");
        return (
          c.message_type === "image"
            ? (d = `${c.attachment_url ? `<img class="private-attachment-image" src="${esc(c.attachment_url)}" alt="${esc(c.attachment_name || "\u56FE\u7247")}" data-preview-image="${esc(c.attachment_url)}" />` : "<span>\u56FE\u7247\u94FE\u63A5\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u5237\u65B0\u6D88\u606F</span>"}${c.body ? `<div>${esc(c.body)}</div>` : ""}`)
            : c.message_type === "file" &&
              (d = `<button class="private-file-card" type="button" data-open-attachment="${esc(c.attachment_url || "")}"><span class="private-file-icon">\u{1F4CE}</span><span><strong>${esc(c.attachment_name || "\u9644\u4EF6")}</strong><small>${esc(formatFileSize(c.attachment_size))}</small></span></button>${c.body ? `<div>${esc(c.body)}</div>` : ""}`),
          `<article class="private-message ${i ? "mine" : ""}">${d}<div class="private-message-meta"><span>${esc(formatMessageTime(c.created_at))}</span>${i ? `<span>${c.read_at ? "\u5DF2\u8BFB" : "\u5DF2\u53D1\u9001"}</span>` : ""}</div></article>`
        );
      })
      .join("") ||
    '<div class="message-empty">\u8FD8\u6CA1\u6709\u6D88\u606F\uFF0C\u53D1\u9001\u7B2C\u4E00\u6761\u95EE\u5019\u5427</div>'),
    u.querySelectorAll("[data-preview-image]").forEach((c) =>
      c.addEventListener("click", () => {
        ((document.querySelector("#private-image-preview").src = c.dataset.previewImage),
          document.querySelector("#private-image-dialog").showModal());
      }),
    ),
    u.querySelectorAll("[data-open-attachment]").forEach((c) =>
      c.addEventListener("click", async () => {
        if (!c.dataset.openAttachment) {
          document.querySelector("#messaging-message").textContent =
            "\u9644\u4EF6\u94FE\u63A5\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u5237\u65B0\u6D88\u606F";
          return;
        }
        const i = await window.orangeApp.openInternalAttachment(c.dataset.openAttachment);
        i?.ok ||
          (document.querySelector("#messaging-message").textContent =
            i?.message || "\u65E0\u6CD5\u6253\u5F00\u9644\u4EF6");
      }),
    ),
    (u.scrollTop = u.scrollHeight));
}
function renderAnnouncements() {
  const e = new Set(
      messagingSnapshot.reads
        .filter((n) => n.user_id === messagingSnapshot.currentUser?.id)
        .map((n) => n.announcement_id),
    ),
    u = messagingSnapshot.currentUser?.role === "admin",
    t = document.querySelector("#announcement-list");
  ((t.innerHTML =
    messagingSnapshot.announcements
      .map((n) => {
        const a =
            (u && n.target_user_id && n.target_user_id !== messagingSnapshot.currentUser?.id) ||
            e.has(n.id),
          o = u ? messagingSnapshot.reads.filter((r) => r.announcement_id === n.id).length : 0;
        return `<article class="announcement-card ${a ? "" : "unread"} ${n.pinned ? "pinned" : ""}" data-announcement-id="${esc(n.id)}"><div class="announcement-card-head"><div><h3>${n.pinned ? "\u{1F4CC} " : ""}${esc(n.title)}</h3><p>${esc(n.body)}</p><small>${esc(formatMessageTime(n.published_at))}${n.target_user_id ? " \xB7 \u6307\u5B9A\u53D1\u9001" : " \xB7 \u5168\u5458\u516C\u544A"} \xB7 <span class="announcement-read">${u ? `\u5DF2\u8BFB ${o} \u4EBA` : a ? "\u5DF2\u8BFB" : "\u672A\u8BFB"}</span></small></div><div class="announcement-card-actions">${u ? `<button type="button" data-edit-announcement="${esc(n.id)}">\u7F16\u8F91</button><button class="danger" type="button" data-delete-announcement="${esc(n.id)}">\u5220\u9664</button>` : ""}</div></div></article>`;
      })
      .join("") || '<div class="message-empty">\u6682\u65E0\u516C\u544A</div>'),
    t.querySelectorAll("[data-announcement-id]").forEach((n) =>
      n.addEventListener("click", async (a) => {
        a.target.closest("[data-delete-announcement], [data-edit-announcement]") ||
          e.has(n.dataset.announcementId) ||
          ((await window.orangeApp.markAnnouncementRead(n.dataset.announcementId))?.ok &&
            (messagingSnapshot.reads.push({
              announcement_id: n.dataset.announcementId,
              user_id: messagingSnapshot.currentUser?.id,
              read_at: new Date().toISOString(),
            }),
            renderAnnouncements(),
            renderMessageNavBadge()));
      }),
    ),
    t.querySelectorAll("[data-edit-announcement]").forEach((n) =>
      n.addEventListener("click", (a) => {
        a.stopPropagation();
        const o = messagingSnapshot.announcements.find((r) => r.id === n.dataset.editAnnouncement);
        o && beginAnnouncementEdit(o);
      }),
    ),
    t.querySelectorAll("[data-delete-announcement]").forEach((n) =>
      n.addEventListener("click", async (a) => {
        if (
          (a.stopPropagation(),
          !confirm("\u786E\u5B9A\u5220\u9664\u8FD9\u6761\u516C\u544A\u5417\uFF1F"))
        )
          return;
        const o = await window.orangeApp.deleteAnnouncement(n.dataset.deleteAnnouncement);
        o?.ok
          ? (resetAnnouncementForm(),
            (document.querySelector("#messaging-message").textContent =
              "\u516C\u544A\u5DF2\u5220\u9664"),
            await loadMessagingCenter())
          : (document.querySelector("#messaging-message").textContent =
              o?.message || "\u516C\u544A\u5220\u9664\u5931\u8D25");
      }),
    ));
}
function announcementLocalDateTime(e) {
  if (!e) return "";
  const u = new Date(e);
  return Number.isFinite(u.getTime())
    ? new Date(u.getTime() - u.getTimezoneOffset() * 6e4).toISOString().slice(0, 16)
    : "";
}
function resetAnnouncementForm() {
  (document.querySelector("#announcement-form").reset(),
    (document.querySelector("#announcement-id").value = ""),
    (document.querySelector("#announcement-submit").textContent = "\u53D1\u5E03\u516C\u544A"),
    document.querySelector("#announcement-edit-cancel").classList.add("hidden"));
}
function beginAnnouncementEdit(e) {
  ((document.querySelector("#announcement-id").value = e.id),
    (document.querySelector("#announcement-title").value = e.title || ""),
    (document.querySelector("#announcement-target").value = e.target_user_id || ""),
    (document.querySelector("#announcement-expires").value = announcementLocalDateTime(
      e.expires_at,
    )),
    (document.querySelector("#announcement-pinned").checked = e.pinned === !0),
    (document.querySelector("#announcement-body").value = e.body || ""),
    (document.querySelector("#announcement-submit").textContent = "\u4FDD\u5B58\u4FEE\u6539"),
    document.querySelector("#announcement-edit-cancel").classList.remove("hidden"),
    (document.querySelector("#messaging-message").textContent =
      `\u6B63\u5728\u7F16\u8F91\u516C\u544A\uFF1A${e.title || "\u672A\u547D\u540D\u516C\u544A"}`),
    document
      .querySelector("#announcement-form")
      .scrollIntoView({ behavior: "smooth", block: "center" }));
}
function renderMessagingCenter() {
  (renderMessageContacts(),
    renderPrivateConversation(),
    renderAnnouncements(),
    renderMessageNavBadge());
}
async function loadMessagingCenter() {
  const e = await window.orangeApp
    .getMessagingSnapshot()
    .catch((u) => ({ ok: !1, message: u?.message }));
  if (!e?.ok) {
    document.querySelector("#messaging-message").textContent =
      e?.message ||
      "\u6D88\u606F\u4E2D\u5FC3\u6682\u65F6\u4E0D\u53EF\u7528\uFF0C\u8BF7\u5148\u90E8\u7F72\u6D88\u606F\u7CFB\u7EDFSQL";
    return;
  }
  if (
    ((messagingSnapshot = e),
    activeMessagePeerId &&
      !messagingSnapshot.contacts.some((u) => u.id === activeMessagePeerId) &&
      (activeMessagePeerId = ""),
    activeMessagePeerId)
  ) {
    const u = messagingSnapshot.currentUser?.id,
      t = messagingSnapshot.messages.filter(
        (n) => n.sender_id === activeMessagePeerId && n.recipient_id === u && !n.read_at,
      );
    if (t.length) {
      const n = new Date().toISOString();
      (t.forEach((a) => {
        a.read_at = n;
      }),
        window.orangeApp.markConversationRead(activeMessagePeerId));
    }
  }
  ((document.querySelector("#messaging-message").textContent = ""), renderMessagingCenter());
}
async function selectMessagePeer(e) {
  (activeMessagePeerId &&
    activeMessagePeerId !== String(e || "") &&
    pendingPrivateAttachment &&
    clearPendingPrivateAttachment(),
    (activeMessagePeerId = String(e || "")));
  const u = messagingSnapshot.currentUser?.id,
    t = new Date().toISOString();
  (messagingSnapshot.messages.forEach((n) => {
    n.sender_id === activeMessagePeerId && n.recipient_id === u && !n.read_at && (n.read_at = t);
  }),
    renderMessagingCenter(),
    (await window.orangeApp.markConversationRead(activeMessagePeerId))?.ok &&
      (renderMessageContacts(), renderMessageNavBadge()));
}
async function updateRestoreWindowBanner() {
  const e = document.querySelector("#restore-window-banner");
  if (!e) return;
  const u = await window.orangeApp.getRestoreSummary().catch(() => ({ count: 0 }));
  if (!u?.ok || !u.count) {
    e.classList.add("hidden");
    return;
  }
  const t = (u.tabs || [])
    .map((n) => n.title || n.siteId)
    .filter(Boolean)
    .slice(0, 4);
  ((document.querySelector("#restore-window-summary").textContent =
    `\u5171 ${u.count} \u4E2A\u6807\u7B7E${t.length ? `\uFF1A${t.join("\u3001")}${u.count > t.length ? "\u2026" : ""}` : ""}`),
    e.classList.remove("hidden"));
}
(document.querySelector("#restore-window-button").addEventListener("click", async () => {
  const e = document.querySelector("#restore-window-button");
  e.disabled = !0;
  const u = await window.orangeApp.restoreLastWindow();
  ((e.disabled = !1),
    u?.ok
      ? document.querySelector("#restore-window-banner").classList.add("hidden")
      : alert(u?.message || "\u6062\u590D\u5931\u8D25"));
}),
  document
    .querySelector("#restore-window-close")
    .addEventListener("click", () =>
      document.querySelector("#restore-window-banner").classList.add("hidden"),
    ));
function tnStatusLabel(e) {
  const u = String(e.status || "saved"),
    t =
      e.statusText ||
      {
        connected: "\u540E\u53F0\u8FDE\u63A5\u4E2D",
        verification: "\u9700\u8981\u767B\u5F55\u6216\u9A8C\u8BC1",
        disconnected: "\u8FDE\u63A5\u4E2D\u65AD",
        saved: "\u767B\u5F55\u72B6\u6001\u5DF2\u4FDD\u5B58",
      }[u] ||
      "\u7B49\u5F85\u68C0\u6D4B";
  return `<span class="tn-status ${esc(u)}">${esc(t)}</span>`;
}
function selectedTnAccountIds() {
  return [...document.querySelectorAll("#tn-accounts-body [data-tn-select]:checked")].map(
    (e) => e.dataset.tnSelect,
  );
}
function syncTnBulkSelectionUi() {
  const e = [...document.querySelectorAll("#tn-accounts-body [data-tn-select]")],
    u = e.filter((r) => r.checked).length,
    t = document.querySelector("#tn-select-all-checkbox");
  t && ((t.checked = e.length > 0 && u === e.length), (t.indeterminate = u > 0 && u < e.length));
  const n = document.querySelector("#tn-selected-count");
  n && (n.textContent = `\u5DF2\u9009 ${u} \u4E2A`);
  const a = document.querySelector("#tn-select-all");
  a &&
    (a.textContent = e.length > 0 && u === e.length ? "\u53D6\u6D88\u5168\u9009" : "\u5168\u9009");
  const o = document.querySelector("#tn-open-selected");
  o && (o.disabled = u === 0);
}
function tnGroupOptions(e = "") {
  return (
    '<option value="">\u8BF7\u9009\u62E9\u56FA\u5B9AIP\u5206\u7EC4</option>' +
    tnGroupSnapshot
      .map(
        (u) =>
          `<option value="${esc(u.id)}" ${u.id === e ? "selected" : ""}>${esc(u.groupName)} \xB7 ${esc(u.proxyLabel || u.proxyEndpoint)}${u.maxAccounts === null ? " \xB7 \u65E0\u9650\u5236" : ` \xB7 \u6700\u591A${Number(u.maxAccounts)}\u4E2A`}</option>`,
      )
      .join("")
  );
}
const TN_LAST_MANAGED_GROUP_KEY = "orangeTnLastManagedGroupByUser";
function savedTnManagedGroup() {
  try {
    const e = JSON.parse(localStorage.getItem(TN_LAST_MANAGED_GROUP_KEY) || "{}");
    return String(e?.[activeProfile?.id || "local"] || "");
  } catch {
    return "";
  }
}
function saveTnManagedGroup(e) {
  const u = String(e || "");
  if (u)
    try {
      const t = JSON.parse(localStorage.getItem(TN_LAST_MANAGED_GROUP_KEY) || "{}");
      ((t[activeProfile?.id || "local"] = u),
        localStorage.setItem(TN_LAST_MANAGED_GROUP_KEY, JSON.stringify(t)));
    } catch {}
}
function tnLocalProxyOptions(e = "") {
  return (
    '<option value="">\u8BF7\u9009\u62E9\u672C\u673A\u56FA\u5B9AIP</option>' +
    tnLocalProxySnapshot
      .map(
        (u) =>
          `<option value="${esc(u.id)}" ${u.id === e ? "selected" : ""}>${esc(u.label)} \xB7 \u6700\u591A${Number(u.limit || 30)}\u4E2A</option>`,
      )
      .join("")
  );
}
function tnAccountProxyOptions(e) {
  const u = e.proxyMode === "local" ? `local:${e.localProxyKey}` : `managed:${e.proxyGroupId}`,
    t = tnGroupSnapshot
      .map((o) => {
        const a = `managed:${o.id}`;
        return `<option value="${esc(a)}" ${a === u ? "selected" : ""}>\u7BA1\u7406\u5458\u5206\u7EC4 \xB7 ${esc(o.groupName)} \xB7 ${esc(o.proxyLabel || o.proxyEndpoint)}</option>`;
      })
      .join(""),
    n = tnLocalProxySnapshot
      .map((o) => {
        const a = `local:${o.id}`;
        return `<option value="${esc(a)}" ${a === u ? "selected" : ""}>\u5458\u5DE5\u81EA\u5EFAIP \xB7 ${esc(o.endpoint)} \xB7 \u6700\u591A${Number(o.limit || 30)}\u4E2A</option>`;
      })
      .join("");
  return `<option value="">\u8BF7\u9009\u62E9\u56FA\u5B9AIP</option>${t ? `<optgroup label="\u7BA1\u7406\u5458\u56FA\u5B9A\u5206\u7EC4">${t}</optgroup>` : ""}${n ? `<optgroup label="\u5458\u5DE5\u81EA\u5EFAIP">${n}</optgroup>` : ""}`;
}
function syncTnProxyMode() {
  const e = document.querySelector("#tn-proxy-mode")?.value === "local";
  (document.querySelector("#tn-managed-proxy-row")?.classList.toggle("hidden", e),
    document.querySelector("#tn-local-proxy-row")?.classList.toggle("hidden", !e),
    document.querySelector("#tn-local-limit-row")?.classList.toggle("hidden", !e),
    (document.querySelector("#tn-proxy-group").required = !e),
    (document.querySelector("#tn-local-proxy").required = e));
}
async function loadSavedTnLocalProxy() {
  const e = await window.orangeApp.getSavedTnLocalProxy().catch(() => ({ ok: !1 }));
  if (!e?.ok) return;
  tnLocalProxySnapshot = Array.isArray(e.proxies) ? e.proxies : [];
  const u = document.querySelector("#tn-local-proxy-id").value,
    t =
      tnLocalProxySnapshot.find((n) => n.id === u) ||
      (document.querySelector("#tn-local-proxy").value ? null : tnLocalProxySnapshot[0]);
  (t &&
    ((document.querySelector("#tn-local-proxy-id").value = t.id),
    (document.querySelector("#tn-local-proxy").value = t.raw),
    (document.querySelector("#tn-local-proxy-limit").value = String(t.limit || 30)),
    (document.querySelector("#tn-local-proxy-message").textContent =
      "\u5DF2\u8BFB\u53D6\u8FD9\u53F0\u7535\u8111\u4FDD\u5B58\u7684\u56FA\u5B9AIP\uFF0C\u53EF\u76F4\u63A5\u5BFC\u5165CK")),
    renderTnLocalProxies());
}
function selectTnLocalProxy(e) {
  ((document.querySelector("#tn-proxy-mode").value = "local"),
    syncTnProxyMode(),
    (document.querySelector("#tn-local-proxy-id").value = e.id),
    (document.querySelector("#tn-local-proxy").value = e.raw),
    (document.querySelector("#tn-local-proxy-limit").value = String(e.limit || 30)),
    (document.querySelector("#tn-local-proxy-message").textContent =
      `\u5DF2\u9009\u62E9 ${e.label}\uFF1B\u4FEE\u6539\u540E\u70B9\u201C\u4FDD\u5B58 / \u66F4\u65B0\u8FD9\u6761IP\u201D`),
    document
      .querySelector("#tn-local-proxy-row")
      .scrollIntoView({ behavior: "smooth", block: "center" }));
}
function renderTnLocalProxies() {
  const e = document.querySelector("#tn-local-proxies-body");
  e &&
    ((e.innerHTML =
      tnLocalProxySnapshot
        .map(
          (u) =>
            `<tr><td><strong>${esc(u.label)}</strong><small>${esc(u.endpoint)}</small></td><td>${Number(u.limit || 30)} \u4E2A\u9875\u9762</td><td>${Number(u.usageCount || 0)} \u4E2A\u8D26\u53F7</td><td class="actions"><button data-tn-local-select="${esc(u.id)}" type="button">\u9009\u62E9 / \u66F4\u6362</button><button data-tn-local-delete="${esc(u.id)}" class="danger" type="button">\u5220\u9664</button></td></tr>`,
        )
        .join("") ||
      '<tr><td colspan="4">\u5C1A\u672A\u4FDD\u5B58\u5458\u5DE5\u672C\u673A\u56FA\u5B9AIP</td></tr>'),
    e.querySelectorAll("[data-tn-local-select]").forEach((u) =>
      u.addEventListener("click", () => {
        const t = tnLocalProxySnapshot.find((n) => n.id === u.dataset.tnLocalSelect);
        t && selectTnLocalProxy(t);
      }),
    ),
    e.querySelectorAll("[data-tn-local-delete]").forEach((u) =>
      u.addEventListener("click", async () => {
        const t = tnLocalProxySnapshot.find((o) => o.id === u.dataset.tnLocalDelete);
        if (!t || !confirm(`\u786E\u5B9A\u5220\u9664 ${t.label} \u5417\uFF1F`)) return;
        const n = await window.orangeApp.deleteTnLocalProxy(t.id),
          a = document.querySelector("#tn-local-proxy-list-message");
        (a.classList.toggle("error", !n?.ok),
          (a.textContent = n?.ok
            ? "\u56FA\u5B9AIP\u5DF2\u5220\u9664"
            : n?.message || "\u5220\u9664\u5931\u8D25"),
          n?.ok &&
            document.querySelector("#tn-local-proxy-id").value === t.id &&
            ((document.querySelector("#tn-local-proxy-id").value = ""),
            (document.querySelector("#tn-local-proxy").value = "")),
          await loadSavedTnLocalProxy());
      }),
    ));
}
(document.querySelector("#tn-proxy-mode")?.addEventListener("change", () => {
  (syncTnProxyMode(),
    document.querySelector("#tn-proxy-mode").value === "local" && loadSavedTnLocalProxy());
}),
  document
    .querySelector("#tn-proxy-group")
    ?.addEventListener("change", (e) => saveTnManagedGroup(e.target.value)),
  syncTnProxyMode(),
  document.querySelector("#tn-local-proxy-save")?.addEventListener("click", async () => {
    const e = document.querySelector("#tn-local-proxy-message");
    e.textContent = "\u6B63\u5728\u5B89\u5168\u4FDD\u5B58\u2026";
    const u = await window.orangeApp.saveTnLocalProxy({
      presetId: document.querySelector("#tn-local-proxy-id").value,
      proxy: document.querySelector("#tn-local-proxy").value,
      limit: Number(document.querySelector("#tn-local-proxy-limit").value || 30),
    });
    ((e.textContent = u?.ok
      ? `\u5DF2\u4FDD\u5B58\uFF1A${u.label}\uFF0C\u6700\u591A ${u.limit} \u4E2A\u9875\u9762${u.changed ? `\uFF1B${u.changed} \u4E2A\u8D26\u53F7\u5DF2\u540C\u6B65\u66F4\u6362` : ""}`
      : u?.message || "\u4FDD\u5B58\u5931\u8D25"),
      u?.ok &&
        ((document.querySelector("#tn-local-proxy-id").value = u.id),
        await loadSavedTnLocalProxy(),
        await loadTnAccounts()));
  }),
  document
    .querySelector("#refresh-tn-local-proxies")
    ?.addEventListener("click", loadSavedTnLocalProxy));
function renderTnAccounts(e = []) {
  const u = document.querySelector("#tn-accounts-body");
  u &&
    ((u.innerHTML =
      e
        .map(
          (t) =>
            `<tr data-tn-row="${esc(t.id)}"><td><input data-tn-select="${esc(t.id)}" type="checkbox" aria-label="\u9009\u62E9${esc(t.name)}" /></td><td><strong>${esc(t.name)}</strong><small>${esc(t.id.slice(0, 8))}</small></td><td><select data-tn-account-proxy>${tnAccountProxyOptions(t)}</select><small>${t.proxyMode === "local" ? `\u5458\u5DE5\u81EA\u5EFAIP \xB7 \u5BB9\u91CF ${Number(t.localProxyLimit || 30)} \u4E2A\u9875\u9762` : "\u7BA1\u7406\u5458\u56FA\u5B9AIP\u5206\u7EC4"}</small><small>${esc(t.proxyLabel || "\u56FA\u5B9AIP\u5C1A\u672A\u68C0\u6D4B")}</small></td><td><strong>${esc(t.exitIp || "\u5F85\u68C0\u6D4B")}</strong></td><td>${tnStatusLabel(t)}</td><td><label class="check-line"><input data-tn-keep-alive type="checkbox" ${t.keepAlive ? "checked" : ""}/>\u540E\u53F0\u5E38\u9A7B</label></td><td class="actions"><button data-tn-open type="button">\u6253\u5F00</button><button data-tn-cookie type="button">\u66FF\u6362Cookie</button><button data-tn-clear class="danger" type="button">\u6E05\u9664Cookie</button><button data-tn-delete class="danger" type="button">\u5220\u9664\u8D26\u53F7</button></td></tr>`,
        )
        .join("") || '<tr><td colspan="7">\u5C1A\u672A\u6DFB\u52A0TN\u8D26\u53F7</td></tr>'),
    u
      .querySelectorAll("[data-tn-select]")
      .forEach((t) => t.addEventListener("change", syncTnBulkSelectionUi)),
    u.querySelectorAll("[data-tn-row]").forEach((t) => {
      const n = t.dataset.tnRow;
      (t.querySelector("[data-tn-open]").addEventListener("click", async () => {
        const o = await window.orangeApp.openTnAccount(n);
        o?.ok || alert(o?.message || "\u6253\u5F00\u5931\u8D25");
      }),
        t.querySelector("[data-tn-cookie]").addEventListener("click", () => {
          ((document.querySelector("#tn-cookie-account-id").value = n),
            (document.querySelector("#tn-cookie-replace").value = ""),
            (document.querySelector("#tn-cookie-message").textContent = ""),
            document.querySelector("#tn-cookie-dialog").showModal());
        }),
        t.querySelector("[data-tn-keep-alive]").addEventListener("change", async (o) => {
          const a = await window.orangeApp.updateTnAccount({
            accountId: n,
            keepAlive: o.target.checked,
          });
          (a?.ok ||
            ((o.target.checked = !o.target.checked),
            alert(a?.message || "\u4FDD\u5B58\u5931\u8D25")),
            await loadTnAccounts());
        }),
        t.querySelector("[data-tn-account-proxy]")?.addEventListener("change", async (o) => {
          const a = e.find((d) => d.id === n),
            r =
              a?.proxyMode === "local"
                ? `local:${a.localProxyKey}`
                : `managed:${a?.proxyGroupId || ""}`,
            [s, c] = String(o.target.value || "").split(":");
          if (
            !c ||
            !confirm(
              "\u66F4\u6362\u56FA\u5B9AIP\u4F1A\u8BA9\u8FD9\u4E2ATN\u8D26\u53F7\u4F7F\u7528\u65B0\u7EBF\u8DEF\u5E76\u91CD\u65B0\u8FDE\u63A5\uFF0C\u662F\u5426\u7EE7\u7EED\uFF1F",
            )
          ) {
            o.target.value = r;
            return;
          }
          let i;
          if (s === "local") {
            const d = tnLocalProxySnapshot.find((l) => l.id === c);
            if (!d) {
              (alert(
                "\u5458\u5DE5\u81EA\u5EFAIP\u4E0D\u5B58\u5728\uFF0C\u8BF7\u5148\u4FDD\u5B58\u6216\u5237\u65B0IP\u5217\u8868",
              ),
                await loadTnAccounts());
              return;
            }
            i = await window.orangeApp.updateTnAccount({
              accountId: n,
              proxyMode: "local",
              localProxy: d.raw,
              localProxyLimit: d.limit,
            });
          } else
            i = await window.orangeApp.updateTnAccount({
              accountId: n,
              proxyMode: "managed",
              proxyGroupId: c,
            });
          (i?.ok || alert(i?.message || "\u66F4\u6362\u56FA\u5B9AIP\u5931\u8D25"),
            await loadTnAccounts());
        }),
        t.querySelector("[data-tn-clear]").addEventListener("click", async () => {
          if (
            !confirm(
              "\u53EA\u6E05\u9664\u8FD9\u4E2ATN\u8D26\u53F7\u7684Cookie\u5417\uFF1F\u8D26\u53F7\u540D\u79F0\u548C\u5206\u7EC4\u4ECD\u4F1A\u4FDD\u7559\u3002",
            )
          )
            return;
          const o = await window.orangeApp.clearTnCookies(n);
          (alert(o?.ok ? "Cookie\u5DF2\u6E05\u9664" : o?.message || "\u6E05\u9664\u5931\u8D25"),
            await loadTnAccounts());
        }),
        t.querySelector("[data-tn-delete]").addEventListener("click", async () => {
          if (
            !confirm(
              "\u786E\u5B9A\u5220\u9664\u8FD9\u4E2ATN\u8D26\u53F7\u5417\uFF1F\u8FD9\u4F1A\u6E05\u9664\u8BE5\u8D26\u53F7\u7684Cookie\u548C\u672C\u673A\u6D4F\u89C8\u5668\u6570\u636E\uFF0C\u65E0\u6CD5\u6062\u590D\u3002",
            )
          )
            return;
          const o = await window.orangeApp.deleteTnAccount(n);
          (alert(
            o?.ok ? "TN\u8D26\u53F7\u5DF2\u5220\u9664" : o?.message || "\u5220\u9664\u5931\u8D25",
          ),
            await loadTnAccounts());
        }));
    }),
    syncTnBulkSelectionUi());
}
(document.querySelector("#tn-select-all-checkbox")?.addEventListener("change", (e) => {
  (document.querySelectorAll("#tn-accounts-body [data-tn-select]").forEach((u) => {
    u.checked = e.target.checked;
  }),
    syncTnBulkSelectionUi());
}),
  document.querySelector("#tn-select-all")?.addEventListener("click", () => {
    const e = [...document.querySelectorAll("#tn-accounts-body [data-tn-select]")],
      u = e.length ? !e.every((t) => t.checked) : !1;
    (e.forEach((t) => {
      t.checked = u;
    }),
      syncTnBulkSelectionUi());
  }),
  document.querySelector("#tn-open-selected")?.addEventListener("click", async () => {
    const e = selectedTnAccountIds();
    if (!e.length) return;
    const u = document.querySelector("#tn-open-selected"),
      t = document.querySelector("#tn-message");
    ((u.disabled = !0),
      (t.textContent = `\u6B63\u5728\u6253\u5F00 ${e.length} \u4E2ATN\u8D26\u53F7\u2026`));
    let n = 0;
    const o = [];
    for (const a of e) {
      const r = await window.orangeApp
        .openTnAccount(a)
        .catch((s) => ({ ok: !1, message: s?.message }));
      r?.ok ? (n += 1) : o.push(r?.message || "\u6253\u5F00\u5931\u8D25");
    }
    ((t.textContent = o.length
      ? `\u5DF2\u6253\u5F00 ${n} \u4E2A\uFF0C\u5931\u8D25 ${o.length} \u4E2A\uFF1A${o[0]}`
      : `\u5DF2\u6253\u5F00 ${n} \u4E2ATN\u8D26\u53F7`),
      syncTnBulkSelectionUi());
  }));
async function loadTnAccounts() {
  const e = await window.orangeApp.listTnGroups().catch((t) => ({ ok: !1, message: t?.message }));
  if (e?.ok) {
    tnGroupSnapshot = Array.isArray(e.groups) ? e.groups : [];
    const t = document.querySelector("#tn-proxy-group");
    if (t) {
      const n = t.value || savedTnManagedGroup(),
        o = tnGroupSnapshot.some((a) => a.id === n)
          ? n
          : tnGroupSnapshot.length === 1
            ? tnGroupSnapshot[0].id
            : "";
      ((t.innerHTML = tnGroupOptions(o)), o && saveTnManagedGroup(o));
    }
  }
  await loadSavedTnLocalProxy();
  const u = await window.orangeApp.listTnAccounts().catch((t) => ({ ok: !1, message: t?.message }));
  u?.ok
    ? renderTnAccounts(u.accounts || [])
    : document.querySelector("#tn-message") &&
      (document.querySelector("#tn-message").textContent =
        u?.message || "\u8BFB\u53D6TN\u8D26\u53F7\u5931\u8D25");
}
(document.querySelector("#tn-account-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const u = document.querySelector("#tn-message"),
    t = document.querySelector("#tn-cookie-input").value;
  u.textContent = t.trim()
    ? "\u6B63\u5728\u521B\u5EFA\u72EC\u7ACB\u6D4F\u89C8\u5668\u73AF\u5883\u5E76\u5BFC\u5165Cookie\u2026"
    : "\u6B63\u5728\u521B\u5EFA\u7A7A\u767DTN\u72EC\u7ACB\u6D4F\u89C8\u5668\u73AF\u5883\u2026";
  const n = document.querySelector("#tn-proxy-mode").value,
    o = document.querySelector("#tn-proxy-group").value;
  n === "managed" && saveTnManagedGroup(o);
  const a = await window.orangeApp.addTnAccount({
    name: document.querySelector("#tn-account-name").value,
    proxyMode: document.querySelector("#tn-proxy-mode").value,
    proxyGroupId: document.querySelector("#tn-proxy-group").value,
    localProxy: document.querySelector("#tn-local-proxy").value,
    localProxyLimit: Number(document.querySelector("#tn-local-proxy-limit").value || 30),
    keepAlive: document.querySelector("#tn-keep-alive").checked,
    cookies: t,
  });
  ((u.textContent = a?.ok
    ? a.blank
      ? "\u5DF2\u521B\u5EFA1\u4E2A\u7A7A\u767DTN\u8D26\u53F7\uFF0C\u6253\u5F00\u540E\u53EF\u624B\u52A8\u767B\u5F55"
      : `\u5DF2\u6DFB\u52A0 ${Number(a.count || 1)} \u4E2ATN\u8D26\u53F7\uFF1BCookie\u53EA\u4FDD\u5B58\u5728\u672C\u673A`
    : a?.message || "\u6DFB\u52A0\u5931\u8D25"),
    a?.ok &&
      (e.target.reset(),
      (document.querySelector("#tn-keep-alive").checked = !0),
      (document.querySelector("#tn-proxy-mode").value = n),
      (document.querySelector("#tn-proxy-group").innerHTML = tnGroupOptions(o)),
      n === "managed" && o && (document.querySelector("#tn-proxy-group").value = o),
      syncTnProxyMode(),
      await loadSavedTnLocalProxy()),
    await loadTnAccounts());
}),
  document.querySelector("#tn-cookie-inspect").addEventListener("click", async () => {
    const e = document.querySelector("#tn-cookie-inspection");
    e.textContent = "\u6B63\u5728\u9010\u4EFD\u8BC6\u522BCK\u2026";
    const u = await window.orangeApp.inspectTnCookies(
      document.querySelector("#tn-cookie-input").value,
    );
    if (!u?.ok) {
      e.textContent = u?.message || "CK\u8BC6\u522B\u5931\u8D25";
      return;
    }
    const t = Array.isArray(u.cookieCounts) ? u.cookieCounts.join("\u3001") : "",
      n =
        Array.isArray(u.errors) && u.errors[0]?.message
          ? `\uFF1B\u7B2C${u.errors[0].index || 1}\u4EFD\uFF1A${u.errors[0].message}`
          : "";
    e.textContent = u.invalid
      ? `\u8BC6\u522B\u5230 ${u.detected} \u4EFD\uFF1A\u683C\u5F0F\u901A\u8FC7 ${u.valid} \u4EFD\uFF0C\u683C\u5F0F\u89E3\u6790\u5931\u8D25 ${u.invalid} \u4EFD\uFF08\u5C1A\u672A\u68C0\u6D4B\u767B\u5F55\u6709\u6548\u6027\uFF0C\u4E0D\u4F1A\u5F00\u59CB\u5BFC\u5165\uFF09${n}`
      : `\u8BC6\u522B\u6210\u529F\uFF1A\u5171 ${u.valid} \u4EFDCK${t ? `\uFF0C\u6BCF\u4EFDCookie\u6761\u6570\uFF1A${t}` : ""}`;
  }),
  document.querySelector("#refresh-tn-accounts").addEventListener("click", loadTnAccounts),
  document.querySelector("#import-beta6-tn-state")?.addEventListener("click", async () => {
    if (
      !confirm(
        "\u8BF7\u5148\u5B8C\u5168\u5173\u95ED Beta.6\u3002\u6B64\u64CD\u4F5C\u4F1A\u590D\u5236\u540C\u540DTN\u8D26\u53F7\u7684\u5B8C\u6574\u6D4F\u89C8\u5668\u72B6\u6001\uFF08\u4E0D\u53EA\u662FCookie\uFF09\uFF0C\u7528\u4E8E\u6062\u590D\u65E7\u8D26\u53F7\u5DF2\u7ECF\u901A\u8FC7\u7684\u767B\u5F55\u4E0E\u9A8C\u8BC1\u72B6\u6001\uFF1B\u6B63\u5F0F\u7248\u968F\u540E\u81EA\u52A8\u91CD\u542F\u3002\u662F\u5426\u7EE7\u7EED\uFF1F",
      )
    )
      return;
    const e = document.querySelector("#tn-message");
    e.textContent = "\u6B63\u5728\u51C6\u5907\u5BFC\u5165 Beta.6 TN\u72B6\u6001\u2026";
    const u = await window.orangeApp.importBeta6TnState();
    (e.classList.toggle("error", !u?.ok),
      (e.textContent = u?.ok
        ? `\u5DF2\u5339\u914D ${u.count} \u4E2ATN\u8D26\u53F7\uFF0C\u8F6F\u4EF6\u5373\u5C06\u81EA\u52A8\u91CD\u542F\u5E76\u5B8C\u6210\u5BFC\u5165`
        : u?.message || "Beta.6 TN\u72B6\u6001\u5BFC\u5165\u5931\u8D25"));
  }),
  document
    .querySelector("#tn-cookie-close")
    .addEventListener("click", () => document.querySelector("#tn-cookie-dialog").close()),
  document.querySelector("#tn-cookie-save").addEventListener("click", async () => {
    const e = document.querySelector("#tn-cookie-message");
    e.textContent = "\u6B63\u5728\u5BFC\u5165\u2026";
    const u = await window.orangeApp.importTnCookies({
      accountId: document.querySelector("#tn-cookie-account-id").value,
      cookies: document.querySelector("#tn-cookie-replace").value,
    });
    ((e.textContent = u?.ok
      ? `\u5DF2\u5199\u5165 ${u.count} \u6761Cookie\uFF0C\u6B63\u5728\u91CD\u65B0\u6253\u5F00TN\u9A8C\u8BC1\u767B\u5F55`
      : u?.message || "\u5BFC\u5165\u5931\u8D25"),
      u?.ok &&
        (setTimeout(() => document.querySelector("#tn-cookie-dialog").close(), 500),
        await loadTnAccounts()));
  }),
  window.orangeApp.onTnAccountsChanged(renderTnAccounts));
function refreshAdminTnGroupControls() {
  if (activeProfile?.role !== "admin") return;
  const e = document.querySelector("#tn-group-user"),
    u = document.querySelector("#tn-group-proxy");
  if (e) {
    const t = e.value;
    ((e.innerHTML =
      '<option value="">\u8BF7\u9009\u62E9\u8D26\u53F7</option>' +
      userSnapshot
        .map(
          (n) =>
            `<option value="${esc(n.id)}">${esc(n.username)}${n.display_name ? ` \xB7 ${esc(n.display_name)}` : ""}</option>`,
        )
        .join("")),
      [...e.options].some((n) => n.value === t) && (e.value = t));
  }
  if (u) {
    const t = u.value;
    ((u.innerHTML =
      '<option value="">\u8BF7\u9009\u62E9TN\u6C60\u56FA\u5B9AIP</option>' +
      proxyPoolSnapshot.proxies
        .filter((n) => n.enabled && n.pool_kind === "tn")
        .map(
          (n) =>
            `<option value="${esc(n.id)}">${esc(n.label || n.host)} \xB7 ${esc(n.host)}:${Number(n.port)}</option>`,
        )
        .join("")),
      [...u.options].some((n) => n.value === t) && (u.value = t));
  }
}
async function loadAdminTnGroups() {
  if (activeProfile?.role !== "admin") return;
  const e = document.querySelector("#tn-group-message");
  try {
    const u = await adminCall({ action: "list_tn_groups" });
    ((adminTnGroupSnapshot = Array.isArray(u.groups) ? u.groups : []),
      (document.querySelector("#tn-groups-body").innerHTML =
        adminTnGroupSnapshot
          .map(
            (t) =>
              `<tr><td><strong>${esc(t.username)}</strong><small>${esc(t.display_name || "")}</small></td><td>${esc(t.group_name)}</td><td>${esc(t.proxy_label || t.proxy_endpoint || "\u4E0D\u53EF\u7528")}<small>${esc(t.proxy_endpoint || "")}</small></td><td>${t.max_accounts === null ? "\u65E0\u9650\u5236" : Number(t.max_accounts)}</td><td>${t.proxy_enabled ? "\u56FA\u5B9A \xB7 \u7981\u6B62\u8F6E\u6362" : "\u56FA\u5B9AIP\u5DF2\u505C\u7528"}</td><td><button class="danger" data-tn-group-delete="${esc(t.id)}">\u5220\u9664</button></td></tr>`,
          )
          .join("") ||
        '<tr><td colspan="6">\u5C1A\u672A\u5EFA\u7ACBTN\u56FA\u5B9AIP\u5206\u7EC4</td></tr>'),
      document.querySelectorAll("[data-tn-group-delete]").forEach((t) =>
        t.addEventListener("click", async () => {
          if (
            confirm(
              "\u5220\u9664\u5206\u7EC4\u540E\uFF0C\u4F7F\u7528\u8BE5\u5206\u7EC4\u7684\u672C\u673ATN\u8D26\u53F7\u5C06\u65E0\u6CD5\u6253\u5F00\u3002\u786E\u5B9A\u5220\u9664\u5417\uFF1F",
            )
          )
            try {
              (await adminCall({
                action: "delete_tn_group",
                groupId: t.dataset.tnGroupDelete,
              }),
                await loadAdminTnGroups(),
                await loadTnAccounts());
            } catch (n) {
              ((e.textContent = n.message), e.classList.add("error"));
            }
        }),
      ),
      e.classList.remove("error"),
      (e.textContent = `\u5171 ${adminTnGroupSnapshot.length} \u4E2A\u56FA\u5B9AIP\u5206\u7EC4`));
  } catch (u) {
    (e.classList.add("error"), (e.textContent = u.message));
  }
}
(document.querySelector("#tn-group-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const u = document.querySelector("#tn-group-message");
  try {
    (await adminCall({
      action: "save_tn_group",
      groupUserId: document.querySelector("#tn-group-user").value,
      groupName: document.querySelector("#tn-admin-group-name").value,
      groupProxyId: document.querySelector("#tn-group-proxy").value,
      maxAccounts: Number(document.querySelector("#tn-group-max").value || 0),
    }),
      u.classList.remove("error"),
      (u.textContent = "\u56FA\u5B9AIP\u5206\u7EC4\u5DF2\u5EFA\u7ACB"),
      await loadAdminTnGroups(),
      await loadTnAccounts());
  } catch (t) {
    (u.classList.add("error"), (u.textContent = t.message));
  }
}),
  document.querySelector("#refresh-tn-groups")?.addEventListener("click", loadAdminTnGroups));
async function aiCall(e) {
  const u = await window.orangeApp.aiInvoke(e);
  if (!u.ok) throw new Error(u.message);
  return u.data;
}
async function loadAiKeys() {
  const e = document.querySelector("#ai-key-message");
  try {
    const u = await aiCall({ action: "list_keys" }),
      t = Array.isArray(u.keys) ? u.keys : [],
      n = (a, r = {}) =>
        a === "openai_compatible" &&
        /api\.openai\.com/i.test(String(r.endpoint_url || r.endpointUrl || ""))
          ? "OpenAI API"
          : {
              deepl: "DeepL",
              groq: "Groq",
              gemini: "Gemini",
              openai_compatible: "\u517C\u5BB9API",
            }[a] || a;
    ((document.querySelector("#ai-keys-body").innerHTML =
      t
        .map(
          (a) => `
      <tr data-key-row="${a.id}"><td>${esc(a.display_name)}${a.cooldown_until && new Date(a.cooldown_until).getTime() > Date.now() ? `<small>\u51B7\u5374\u81F3 ${shortDateTime(a.cooldown_until)}</small>` : ""}</td><td>${esc(n(a.provider, a))}</td><td><input data-key-model value="${esc(a.model)}" /></td><td><label class="check-line"><input data-key-proxy type="checkbox" ${a.use_proxy_pool ? "checked" : ""}/> ${a.use_proxy_pool ? "\u7FFB\u8BD1IP\u6C60" : "\u672C\u673A\u76F4\u8FDE"}</label></td><td>${a.owner_user_id ? "\u4E2A\u4EBA" : "\u516C\u5171\u6C60"}</td>
      <td><label class="check-line"><input data-key-enabled type="checkbox" ${a.enabled ? "checked" : ""}/>\u542F\u7528</label>${a.last_error ? `<small title="${esc(a.last_error)}">${esc(String(a.last_error).slice(0, 45))}</small>` : ""}</td><td><input data-key-employee-priority type="number" min="1" max="9999" value="${Number(a.employee_priority || a.priority || 100)}" ${activeProfile?.role === "admin" ? "" : "disabled"}/></td><td><input data-key-admin-priority type="number" min="1" max="9999" value="${Number(a.my_admin_priority || a.admin_priority || a.priority || 100)}" ${activeProfile?.role === "admin" ? "" : "disabled"}/></td><td><input data-key-limit type="number" min="0" max="1000000" value="${Number(a.daily_request_limit || 0)}" title="0\u8868\u793A\u4E0D\u53E6\u8BBE\u8F6F\u4EF6\u9650\u5236"/></td><td><button data-ai-key-save="${a.id}">\u4FDD\u5B58</button><button data-ai-key-delete="${a.id}">\u5220\u9664</button></td></tr>`,
        )
        .join("") || '<tr><td colspan="10">\u5C1A\u672A\u6DFB\u52A0AI\u6A21\u578B</td></tr>'),
      document.querySelectorAll("[data-ai-key-save]").forEach((a) =>
        a.addEventListener("click", async () => {
          const r = a.closest("[data-key-row]");
          (await aiCall({
            action: "update_key",
            keyId: a.dataset.aiKeySave,
            model: r.querySelector("[data-key-model]").value,
            useProxyPool: r.querySelector("[data-key-proxy]").checked,
            enabled: r.querySelector("[data-key-enabled]").checked,
            employeePriority: Number(r.querySelector("[data-key-employee-priority]").value),
            adminPriority: Number(r.querySelector("[data-key-admin-priority]").value),
            dailyRequestLimit: Number(r.querySelector("[data-key-limit]").value) || null,
          }),
            (e.textContent = "Key\u8BBE\u7F6E\u5DF2\u4FDD\u5B58"),
            await loadAiKeys());
        }),
      ),
      document.querySelectorAll("[data-ai-key-delete]").forEach((a) =>
        a.addEventListener("click", async () => {
          confirm("\u786E\u5B9A\u5220\u9664\u8FD9\u4E2AAPI Key\u5417\uFF1F") &&
            (await aiCall({ action: "delete_key", keyId: a.dataset.aiKeyDelete }),
            await loadAiKeys());
        }),
      ),
      (e.textContent = `\u5171 ${t.length} \u4E2A\u53EF\u7BA1\u7406Key\uFF08\u5B8C\u6574\u5BC6\u94A5\u4E0D\u4F1A\u663E\u793A\uFF09`));
    const o = await aiCall({ action: "settings" });
    ((document.querySelector("#allow-employee-keys").checked =
      o.settings?.allowEmployeeKeys !== !1),
      (document.querySelector("#personal-key-first").checked = o.settings?.personalKeyFirst !== !1),
      (document.querySelector("#allow-public-fallback").checked =
        o.settings?.allowPublicFallback !== !1),
      (document.querySelector("#default-groq-model").value =
        o.settings?.defaultModel || "groq/compound-mini"));
  } catch (u) {
    ((e.textContent = u.message), e.classList.add("error"));
  }
}
document.querySelector("#ai-pool-settings").addEventListener("submit", async (e) => {
  e.preventDefault();
  const u = document.querySelector("#ai-key-message");
  try {
    (await aiCall({
      action: "save_settings",
      allowEmployeeKeys: document.querySelector("#allow-employee-keys").checked,
      personalKeyFirst: document.querySelector("#personal-key-first").checked,
      allowPublicFallback: document.querySelector("#allow-public-fallback").checked,
      model: document.querySelector("#default-groq-model").value,
    }),
      u.classList.remove("error"),
      (u.textContent = "AI\u6C60\u89C4\u5219\u5DF2\u4FDD\u5B58"));
  } catch (t) {
    (u.classList.add("error"), (u.textContent = t.message));
  }
});
function showAdminMessage(e, u = !1) {
  const t = document.querySelector("#admin-message");
  ((t.textContent = e), t.classList.toggle("error", u));
}
async function adminCall(e) {
  const u = await window.orangeApp.adminInvoke(e);
  if (!u.ok) throw new Error(u.message);
  return u.data;
}
function dateLabel(e) {
  return e ? new Date(e).toLocaleDateString("zh-CN") : "\u6C38\u4E45";
}
function remainingDays(e) {
  if (!e) return null;
  const u = new Date(e).getTime() - Date.now();
  return Math.max(0, Math.ceil(u / 864e5));
}
function membershipLabel(e = {}) {
  if (e.role === "admin") return "\u7BA1\u7406\u5458";
  const u = e.plan === "advanced" ? "\u9AD8\u7EA7\u4F1A\u5458" : "\u666E\u901A\u4F1A\u5458",
    t = remainingDays(e.valid_until);
  return t === null ? `${u} \xB7 \u957F\u671F` : `${u} \xB7 \u5269\u4F59 ${t} \u5929`;
}
function refreshMembershipBadge() {
  const e = document.querySelector("#membership-countdown");
  e && (e.textContent = membershipLabel(activeProfile || {}));
}
setInterval(() => {
  activeProfile && refreshMembershipBadge();
}, 6e4);
function onlineLabel(e) {
  const u = e.last_seen_at ? shortDateTime(e.last_seen_at) : "\u4ECE\u672A\u4E0A\u7EBF",
    t = e.last_ip
      ? `<small>\u516C\u7F51IP\uFF1A${esc(e.last_ip)}${e.ip_blocked ? " \xB7 \u5DF2\u5C01\u7981" : ""}</small>`
      : "";
  if (e.online) {
    const n = Number(e.active_device_count || 1);
    return `<span class="presence presence-online">\u5728\u7EBF</span><small>${esc(e.device_name || "\u5F53\u524D\u8BBE\u5907")}${n > 1 ? ` \xB7 ${n}\u53F0` : ""}</small>${t}`;
  }
  return `<span class="presence presence-offline">\u79BB\u7EBF</span><small>\u6700\u540E\u5728\u7EBF\uFF1A${esc(u)}</small>${t}`;
}
async function loadUsers() {
  try {
    const [e, u] = await Promise.all([
      adminCall({ action: "list_users" }),
      window.orangeApp.listAdminTnCounts().catch((t) => ({ ok: !1, message: t?.message })),
    ]);
    ((userSnapshot = Array.isArray(e.users) ? e.users : []),
      (blockedIpSnapshot = Array.isArray(e.blockedIps) ? e.blockedIps : []),
      (adminTnCountSnapshot = new Map(
        (u?.ok ? u.counts : []).map((t) => [String(t.user_id), Number(t.account_count || 0)]),
      )),
      renderUsers(),
      renderBlockedIps(),
      refreshAdminTnGroupControls());
  } catch (e) {
    showAdminMessage(e.message, !0);
  }
}
function renderUsers() {
  const e = String(document.querySelector("#user-search")?.value || "")
      .trim()
      .toLocaleLowerCase(),
    u = String(document.querySelector("#user-filter")?.value || "all");
  let t = userSnapshot.filter(
    (n) => !e || `${n.username || ""} ${n.display_name || ""}`.toLocaleLowerCase().includes(e),
  );
  ((t = t.filter((n) => {
    if (u === "all") return !0;
    if (u === "advanced") return n.role !== "admin" && n.plan === "advanced";
    if (u === "basic") return n.role !== "admin" && n.plan === "basic";
    if (u === "online") return n.online === !0;
    if (u === "paused") return n.account_status !== "active";
    if (u === "expiring") {
      const a = remainingDays(n.valid_until);
      return a !== null && a <= 7;
    }
    return !0;
  })),
    (document.querySelector("#users-body").innerHTML =
      t
        .map((n) => {
          const a = remainingDays(n.valid_until),
            o =
              n.role === "admin"
                ? "\u7BA1\u7406\u5458"
                : n.plan === "advanced"
                  ? "\u9AD8\u7EA7\u4F1A\u5458"
                  : "\u666E\u901A\u4F1A\u5458",
            r = n.role === "admin" ? "\u2014" : a === null ? "\u957F\u671F" : `${a} \u5929`;
          return `<tr><td><strong>${esc(n.username)}</strong><small>${esc(n.display_name || "")}</small></td>
      <td><strong>${o}</strong><small>${n.role === "admin" ? "\u7BA1\u7406\u8D26\u53F7" : `\u53EF\u4F7F\u7528\uFF1A${r}`}</small></td><td>${onlineLabel(n)}</td><td><strong>${adminTnCountSnapshot.has(String(n.id)) ? adminTnCountSnapshot.get(String(n.id)) : "\u2014"}</strong><small>\u4EC5\u6570\u91CF\uFF0C\u4E0D\u53EF\u6253\u5F00</small></td><td>${esc(n.account_status)}</td>
      <td>${dateLabel(n.valid_until)}<small>${n.role === "admin" ? "" : r}</small></td><td>${n.device_limit}</td><td class="actions account-actions">
      <button data-action="edit" data-id="${n.id}">\u7BA1\u7406</button>${n.role !== "admin" ? `<button data-action="renew" data-id="${n.id}">\u7EED\u671F</button><button data-action="status" data-id="${n.id}" data-value="${n.account_status === "active" ? "paused" : "active"}">${n.account_status === "active" ? "\u6682\u505C" : "\u6062\u590D"}</button><details class="account-more"><summary>\u66F4\u591A</summary><div><button data-action="plan" data-id="${n.id}" data-value="${n.plan === "advanced" ? "basic" : "advanced"}">\u5207\u6362\u4F1A\u5458</button><button data-action="restore" data-id="${n.id}">\u91CD\u65B0\u6388\u6743</button>${n.last_ip ? `<button data-action="${n.ip_blocked ? "ip-unblock" : "ip-block"}" data-id="${n.id}" data-ip="${esc(n.last_ip)}">${n.ip_blocked ? "\u6062\u590DIP" : "\u5C01\u7981IP"}</button>` : ""}<button data-action="reset" data-id="${n.id}">\u91CD\u7F6E\u5BC6\u7801</button><button data-action="logout" data-id="${n.id}">\u5F3A\u5236\u4E0B\u7EBF</button><button class="danger" data-action="delete" data-id="${n.id}" data-name="${esc(n.username)}">\u6C38\u4E45\u5220\u9664</button></div></details>` : n.id !== activeProfile?.id ? `<button class="danger" data-action="delete" data-id="${n.id}" data-name="${esc(n.username)}">\u5220\u9664\u7BA1\u7406\u5458</button>` : "<small>\u5F53\u524D\u8D26\u53F7</small>"}</td></tr>`;
        })
        .join("") || '<tr><td colspan="8">\u6CA1\u6709\u5339\u914D\u7684\u8D26\u53F7</td></tr>'),
    document
      .querySelectorAll("#users-body button")
      .forEach((n) => n.addEventListener("click", handleUserAction)),
    (document.querySelector("#user-search-count").textContent =
      `\u663E\u793A ${t.length} / ${userSnapshot.length}`),
    showAdminMessage(
      `\u5171 ${userSnapshot.length} \u4E2A\u8D26\u53F7\uFF0C\u5F53\u524D\u663E\u793A ${t.length} \u4E2A`,
    ));
}
(document.querySelector("#user-search").addEventListener("input", renderUsers),
  document.querySelector("#user-filter")?.addEventListener("change", renderUsers),
  document.querySelector("#block-ip-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = e.submitter;
    u.disabled = !0;
    try {
      (await adminCall({
        action: "block_client_ip",
        clientIp: document.querySelector("#manual-block-ip").value,
        reason: document.querySelector("#manual-block-reason").value,
      }),
        e.target.reset(),
        await loadUsers(),
        showAdminMessage("\u8BE5\u516C\u7F51IP\u5DF2\u7981\u6B62\u4F7F\u7528"));
    } catch (t) {
      showAdminMessage(t.message, !0);
    } finally {
      u.disabled = !1;
    }
  }));
function renderBlockedIps() {
  const e = document.querySelector("#blocked-ips-body");
  e &&
    ((e.innerHTML =
      blockedIpSnapshot
        .map(
          (u) =>
            `<tr><td><strong>${esc(u.ip_address)}</strong></td><td>${esc(u.reason || "\u7BA1\u7406\u5458\u5C01\u7981")}</td><td>${esc(shortDateTime(u.created_at))}</td><td><button data-unblock-ip="${esc(u.ip_address)}">\u6062\u590D\u4F7F\u7528</button></td></tr>`,
        )
        .join("") || '<tr><td colspan="4">\u5F53\u524D\u6CA1\u6709\u5C01\u7981IP</td></tr>'),
    e.querySelectorAll("[data-unblock-ip]").forEach((u) =>
      u.addEventListener("click", async () => {
        try {
          (await adminCall({
            action: "unblock_client_ip",
            clientIp: u.dataset.unblockIp,
          }),
            await loadUsers(),
            showAdminMessage("\u8BE5IP\u5DF2\u6062\u590D\u4F7F\u7528"));
        } catch (t) {
          showAdminMessage(t.message, !0);
        }
      }),
    ));
}
function proxyHealthLabel(e) {
  return e.enabled
    ? {
        healthy: "\u6B63\u5E38",
        failing: "\u5931\u6548",
        unknown: "\u5F85\u6D4B\u8BD5",
        disabled: "\u5DF2\u6682\u505C",
      }[e.health_status] || "\u672A\u77E5"
    : "\u5DF2\u6682\u505C";
}
function shortDateTime(e) {
  return e ? new Date(e).toLocaleString("zh-CN", { hour12: !1 }) : "\u2014";
}
async function loadProxyLogs() {
  const e = document.querySelector("#proxy-logs-body");
  if (!(!e || activeProfile?.role !== "admin"))
    try {
      const u = await adminCall({ action: "list_proxy_logs" }),
        t = Array.isArray(u.logs) ? u.logs : [];
      e.innerHTML =
        t
          .map(
            (n) =>
              `<tr><td>${shortDateTime(n.created_at)}</td><td>${esc(n.source || "\u2014")}</td><td>${esc(n.event_type || "\u2014")}</td><td>${esc(n.target || "\u2014")}</td><td>${esc(n.proxy_label || n.proxy_endpoint || "\u2014")}</td><td><small>${esc(n.message || (n.status_code ? `HTTP ${n.status_code}` : "\u2014"))}</small></td></tr>`,
          )
          .join("") || '<tr><td colspan="6">\u6682\u65E0\u8FD0\u884C\u8BB0\u5F55</td></tr>';
    } catch (u) {
      e.innerHTML = `<tr><td colspan="6">${esc(u.message)}</td></tr>`;
    }
}
async function loadProxyPool() {
  const e = document.querySelector("#proxy-pool-message");
  try {
    const u = await adminCall({ action: "list_proxy_pool" });
    ((proxyPoolSnapshot = {
      proxies: Array.isArray(u.proxies) ? u.proxies : [],
      assignments: Array.isArray(u.assignments) ? u.assignments : [],
      users: Array.isArray(u.users) ? u.users : [],
      settings: u.settings || {},
    }),
      proxyPoolSnapshot.proxies.sort((r, s) => {
        const c = Number(r.assignment_count || 0) - Number(s.assignment_count || 0);
        if (c) return c;
        const i = (d) => ({ healthy: 0, unknown: 1, failing: 2, disabled: 3 })[d] ?? 4;
        return (
          i(r.health_status) - i(s.health_status) ||
          String(r.label || r.host).localeCompare(String(s.label || s.host), "zh-CN")
        );
      }),
      refreshAdminTnGroupControls(),
      (document.querySelector("#proxy-pool-enabled").checked =
        proxyPoolSnapshot.settings.enabled !== !1),
      (document.querySelector("#proxy-failure-threshold").value = Number(
        proxyPoolSnapshot.settings.failure_threshold || 2,
      )),
      (document.querySelector("#proxy-health-interval").value = Number(
        proxyPoolSnapshot.settings.health_check_interval_minutes || 10,
      )));
    const t = new Map(proxyPoolSnapshot.proxies.map((r) => [r.id, r]));
    refreshSiteFixedProxyOptions();
    const n = (r) => `
      <tr><td><strong>${esc(r.label || "\u672A\u547D\u540D")}</strong><small>${esc(r.id.slice(0, 8))}</small></td>
      <td>${esc(r.host)}:${Number(r.port)}</td><td>${r.pool_kind === "tn" ? "TN\u6C60" : r.pool_kind === "shared" ? "\u5171\u7528\u6C60" : "\u7FFB\u8BD1\u6C60"}<small>${esc(String(r.protocol).toUpperCase())}${r.tn_capacity ? ` \xB7 \u5BB9\u91CF${Number(r.tn_capacity)}` : ""}</small></td>
      <td><span class="proxy-health proxy-${esc(r.health_status)}">${proxyHealthLabel(r)}</span><small>\u5931\u8D25 ${Number(r.failure_count || 0)} \u6B21</small></td>
      <td>${Number(r.total_binding_count ?? r.assignment_count ?? 0)}<small>\u5458\u5DE5 ${Number(r.assignment_count || 0)} \xB7 TN\u5206\u7EC4 ${Number(r.tn_group_count || 0)}</small></td><td><small>${esc(r.last_error || "\u5C1A\u672A\u6D4B\u8BD5")}</small><small>${shortDateTime(r.last_checked_at)}</small></td>
      <td class="actions"><button data-proxy-test="${r.id}">\u6D4B\u8BD5</button><button data-proxy-toggle="${r.id}" data-enabled="${!r.enabled}">${r.enabled ? "\u6682\u505C" : "\u542F\u7528"}</button><button class="danger" data-proxy-delete="${r.id}">\u5220\u9664</button></td></tr>`,
      o = proxyPoolSnapshot.proxies.filter((r) => r.pool_kind !== "tn"),
      a = proxyPoolSnapshot.proxies.filter((r) => r.pool_kind === "tn");
    ((document.querySelector("#proxy-pool-body").innerHTML =
      o.map(n).join("") ||
      '<tr><td colspan="7">\u5C1A\u672A\u5BFC\u5165\u7FFB\u8BD1/\u7F51\u7AD9\u4EE3\u7406</td></tr>'),
      (document.querySelector("#tn-proxy-pool-body").innerHTML =
        a.map(n).join("") ||
        '<tr><td colspan="7">\u5C1A\u672A\u5BFC\u5165TN\u56FA\u5B9AIP</td></tr>'),
      (document.querySelector("#tn-proxy-pool-message").textContent =
        `TN\u4E13\u7528IP ${a.length} \u6761\uFF1B\u4E0D\u4F1A\u53C2\u4E0E\u7FFB\u8BD1\u6216\u7F51\u7AD9\u6C60\u8F6E\u6362`),
      (document.querySelector("#proxy-assignment-user").innerHTML = proxyPoolSnapshot.users
        .map(
          (r) =>
            `<option value="${r.id}">${esc(r.username)}${r.display_name ? ` \xB7 ${esc(r.display_name)}` : ""}</option>`,
        )
        .join("")),
      (document.querySelector("#gmail-proxy-assignment-user").innerHTML = proxyPoolSnapshot.users
        .map(
          (r) =>
            `<option value="${r.id}">${esc(r.username)}${r.display_name ? ` \xB7 ${esc(r.display_name)}` : ""}</option>`,
        )
        .join("")),
      syncProxyAssignmentUser(),
      syncGmailProxyAssignmentUser(),
      (document.querySelector("#proxy-assignment-body").innerHTML =
        proxyPoolSnapshot.assignments
          .map((r) => {
            const s = t.get(r.proxy_id);
            return `<tr><td><strong>${esc(r.username)}</strong><small>${esc(r.display_name || "")}</small></td><td>${r.allowed_by_admin === !1 ? "\u7981\u6B62" : "\u5141\u8BB8"}</td><td>${r.assignment_mode === "fixed" ? "\u6307\u5B9A\u7EBF\u8DEF" : "\u81EA\u52A8\u56FA\u5B9A"}</td><td>${s ? `${esc(s.label || s.host)} \xB7 ${esc(s.host)}:${Number(s.port)}` : "\u7B49\u5F85\u81EA\u52A8\u5206\u914D"}</td><td>${shortDateTime(r.assigned_at)}</td><td><button class="danger" data-assignment-delete="${r.user_id}">\u89E3\u9664\u5206\u914D</button></td></tr>`;
          })
          .join("") ||
        '<tr><td colspan="6">\u6682\u65E0\u5458\u5DE5\u5206\u914D\u8BB0\u5F55</td></tr>'),
      document.querySelectorAll("[data-proxy-test]").forEach((r) =>
        r.addEventListener("click", async () => {
          ((r.disabled = !0),
            e.classList.remove("error"),
            (e.textContent = "\u6B63\u5728\u6D4B\u8BD5\u4EE3\u7406\u51FA\u53E3\u2026"));
          const s = await window.orangeApp.testManagedProxy(r.dataset.proxyTest);
          (s.ok
            ? (e.textContent = s.data.healthy
                ? `\u6D4B\u8BD5\u6210\u529F\uFF1A\u51FA\u53E3IP ${s.data.exitIp}\uFF0C${s.data.latencyMs}ms`
                : `\u6D4B\u8BD5\u5931\u8D25\uFF1A${s.data.errorMessage}`)
            : (e.classList.add("error"), (e.textContent = s.message)),
            await loadProxyPool());
        }),
      ),
      document.querySelectorAll("[data-proxy-toggle]").forEach((r) =>
        r.addEventListener("click", async () => {
          (await adminCall({
            action: "toggle_proxy",
            proxyId: r.dataset.proxyToggle,
            enabled: r.dataset.enabled === "true",
          }),
            await loadProxyPool());
        }),
      ),
      document.querySelectorAll("[data-proxy-delete]").forEach((r) =>
        r.addEventListener("click", async () => {
          const s = proxyPoolSnapshot.proxies.find((d) => d.id === r.dataset.proxyDelete),
            c = Number(s?.total_binding_count ?? s?.assignment_count ?? 0),
            i = c
              ? `\u6B64\u4EE3\u7406\u4ECD\u7ED1\u5B9A ${Number(s?.assignment_count || 0)} \u4E2A\u5458\u5DE5\u5206\u914D\u3001${Number(s?.tn_group_count || 0)} \u4E2ATN\u5206\u7EC4\u3002\u7EE7\u7EED\u4F1A\u5148\u89E3\u9664\u7ED1\u5B9A\u518D\u5220\u9664\uFF0C\u786E\u5B9A\u5417\uFF1F`
              : "\u786E\u5B9A\u5220\u9664\u8FD9\u6761\u4EE3\u7406\u5417\uFF1F";
          if (confirm(i)) {
            r.disabled = !0;
            try {
              const d = await adminCall({
                action: "delete_proxy",
                proxyId: r.dataset.proxyDelete,
                forceUnbind: c > 0,
              });
              (e.classList.remove("error"),
                (e.textContent = d.unbound
                  ? `\u4EE3\u7406\u5DF2\u5220\u9664\uFF0C\u5E76\u89E3\u9664 ${d.unbound} \u4E2A\u7ED1\u5B9A`
                  : "\u4EE3\u7406\u5DF2\u5220\u9664"),
                await loadProxyPool());
            } catch (d) {
              ((r.disabled = !1),
                e.classList.add("error"),
                (e.textContent = `\u5220\u9664\u5931\u8D25\uFF1A${d.message}`));
            }
          }
        }),
      ),
      document.querySelectorAll("[data-assignment-delete]").forEach((r) =>
        r.addEventListener("click", async () => {
          (await adminCall({
            action: "delete_proxy_assignment",
            userId: r.dataset.assignmentDelete,
          }),
            await loadProxyPool());
        }),
      ),
      e.classList.remove("error"),
      (e.textContent = `\u7FFB\u8BD1/\u7F51\u7AD9IP ${o.length} \u6761\uFF0C${proxyPoolSnapshot.assignments.length} \u4E2A\u5458\u5DE5\u5206\u914D`));
  } catch (u) {
    (e.classList.add("error"),
      (e.textContent = `${u.message}\u3002\u8BF7\u5148\u8FD0\u884C0.5.0 SQL\u5E76\u90E8\u7F72\u4E24\u4E2AEdge Function\u3002`));
  }
}
function refreshSiteFixedProxyOptions(e) {
  const u = document.querySelector("#site-fixed-proxy-id");
  if (!u) return;
  const t = e !== void 0 ? String(e || "") : u.value;
  ((u.innerHTML =
    '<option value="">\u8BF7\u9009\u62E9\u56FA\u5B9AIP</option>' +
    proxyPoolSnapshot.proxies
      .filter((n) => n.enabled)
      .map(
        (n) =>
          `<option value="${esc(n.id)}">${esc(n.label || n.host)} \xB7 ${esc(n.host)}:${Number(n.port)}</option>`,
      )
      .join("")),
    [...u.options].some((n) => n.value === t) && (u.value = t));
}
function normalizedSiteKey(e) {
  let u = String(e || "")
    .trim()
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 39);
  return (
    u || (u = "site"),
    /^[a-z]/.test(u) || (u = `site-${u}`.slice(0, 39)),
    u.length < 2 && (u = `${u}-site`.slice(0, 39)),
    u
  );
}
async function loadSitesAdmin() {
  const e = document.querySelector("#site-admin-message");
  (e.classList.remove("error"),
    (e.textContent = "\u6B63\u5728\u8BFB\u53D6\u539F\u6709\u7F51\u7AD9\u2026"));
  try {
    const u = await window.orangeApp.listAdminSites();
    if (!u?.ok) throw new Error(u?.message || "\u8BFB\u53D6\u7F51\u7AD9\u5931\u8D25");
    const t = Array.isArray(u.sites) ? u.sites : [];
    ((document.querySelector("#sites-body").innerHTML = t
      .map(
        (n) => `
      <tr><td><strong>${esc(n.display_name)}</strong><small>${esc(n.site_key)}</small></td>
      <td>${esc(n.url)}</td><td>${n.enabled ? "\u542F\u7528" : "\u4E0B\u67B6"} \xB7 ${n.minimum_plan === "advanced" ? "\u9AD8\u7EA7\u4F1A\u5458" : "\u666E\u901A\u4F1A\u5458"}</td><td>${n.proxy_mode === "fixed" ? "\u56FA\u5B9AIP \xB7 \u6C38\u4E0D\u8F6E\u6362" : n.proxy_mode === "tn_pool" ? "TN IP\u6C60 \xB7 \u6C60\u5185\u8F6E\u6362" : n.proxy_mode === "automatic" || n.proxy_required ? "\u7FFB\u8BD1/\u7F51\u7AD9\u6C60 \xB7 \u81EA\u52A8\u6362\u7EBF" : "\u672C\u673A\u76F4\u8FDE"}</td><td>${n.sort_order}</td><td class="actions">
      <button data-site-edit='${JSON.stringify(n).replace(/'/g, "&#39;")}'>\u7F16\u8F91</button>
      <button data-site-toggle="${n.id}" data-enabled="${!n.enabled}">${n.enabled ? "\u4E0B\u67B6" : "\u542F\u7528"}</button>
      <button data-site-delete="${n.id}">\u5220\u9664</button></td></tr>`,
      )
      .join("")),
      document
        .querySelectorAll("[data-site-edit]")
        .forEach((n) =>
          n.addEventListener("click", () => fillSiteForm(JSON.parse(n.dataset.siteEdit))),
        ),
      document.querySelectorAll("[data-site-toggle]").forEach((n) =>
        n.addEventListener("click", async () => {
          try {
            const a = t.find((o) => o.id === n.dataset.siteToggle);
            ((e.textContent = "\u6B63\u5728\u66F4\u65B0\u7F51\u7AD9\u72B6\u6001\u2026"),
              await adminCall({
                action: "save_site",
                siteId: a.id,
                siteKey: a.site_key,
                siteName: a.display_name,
                siteUrl: a.url,
                siteIconUrl: a.icon_url || "",
                siteProxyMode: a.proxy_mode || (a.proxy_required ? "automatic" : "direct"),
                siteFixedProxyId: a.fixed_proxy_id || null,
                chatContainerSelector: a.chat_container_selector || "",
                messageSelector: a.message_selector || "",
                inputSelector: a.input_selector || "",
                phoneSelector: a.phone_selector || "",
                sortOrder: a.sort_order,
                siteEnabled: n.dataset.enabled === "true",
                minimumPlan: a.minimum_plan,
              }),
              await loadSitesAdmin());
          } catch (a) {
            (e.classList.add("error"),
              (e.textContent = `\u7F51\u7AD9\u72B6\u6001\u66F4\u65B0\u5931\u8D25\uFF1A${a.message}`));
          }
        }),
      ),
      document.querySelectorAll("[data-site-delete]").forEach((n) =>
        n.addEventListener("click", async () => {
          if (confirm("\u786E\u5B9A\u5220\u9664\u8FD9\u4E2A\u7F51\u7AD9\u5417\uFF1F"))
            try {
              ((e.textContent = "\u6B63\u5728\u5220\u9664\u7F51\u7AD9\u2026"),
                await adminCall({
                  action: "delete_site",
                  siteId: n.dataset.siteDelete,
                }),
                await loadSitesAdmin());
            } catch (a) {
              (e.classList.add("error"),
                (e.textContent = `\u7F51\u7AD9\u5220\u9664\u5931\u8D25\uFF1A${a.message}`));
            }
        }),
      ),
      (e.textContent = t.length
        ? `\u5DF2\u6062\u590D\u8BFB\u53D6 ${t.length} \u4E2A\u7F51\u7AD9`
        : "\u6570\u636E\u5E93\u5F53\u524D\u8FD4\u56DE0\u4E2A\u7F51\u7AD9\uFF1B\u672C\u6B21\u5347\u7EA7\u6CA1\u6709\u5220\u9664\u7F51\u7AD9\uFF0C\u8BF7\u5148\u4E0D\u8981\u65B0\u5EFA\u5E76\u68C0\u67E5\u9879\u76EE\u8FDE\u63A5"));
  } catch (u) {
    (e.classList.add("error"),
      (e.textContent = `\u7F51\u7AD9\u8BFB\u53D6\u5931\u8D25\uFF1A${u.message}`));
  }
}
function fillSiteForm(e) {
  ((document.querySelector("#site-id").value = e.id || ""),
    (document.querySelector("#site-key").value = e.site_key || ""),
    (document.querySelector("#site-name").value = e.display_name || ""),
    (document.querySelector("#site-url").value = e.url || ""),
    (document.querySelector("#site-icon-url").value = e.icon_url || ""),
    (document.querySelector("#site-order").value = e.sort_order ?? 100),
    (document.querySelector("#site-enabled").value = String(e.enabled !== !1)),
    (document.querySelector("#site-minimum-plan").value = e.minimum_plan || "basic"),
    (document.querySelector("#site-proxy-mode").value =
      e.proxy_mode || (e.proxy_required ? "automatic" : "direct")),
    (document.querySelector("#site-chat-container-selector").value =
      e.chat_container_selector || ""),
    (document.querySelector("#site-message-selector").value = e.message_selector || ""),
    (document.querySelector("#site-input-selector").value = e.input_selector || ""),
    (document.querySelector("#site-phone-selector").value = e.phone_selector || ""),
    refreshSiteFixedProxyOptions(e.fixed_proxy_id || ""),
    document
      .querySelector("#site-fixed-proxy-field")
      .classList.toggle("hidden", document.querySelector("#site-proxy-mode").value !== "fixed"));
}
async function handleUserAction(e) {
  const u = e.currentTarget;
  u.disabled = !0;
  try {
    if (u.dataset.action === "edit") {
      ((u.disabled = !1), openEditUser(u.dataset.id));
      return;
    }
    if (
      (u.dataset.action === "plan" &&
        (await adminCall({
          action: "update_user",
          userId: u.dataset.id,
          plan: u.dataset.value,
        })),
      u.dataset.action === "status" &&
        (await adminCall({
          action: "update_user",
          userId: u.dataset.id,
          accountStatus: u.dataset.value,
        })),
      u.dataset.action === "logout" &&
        (await adminCall({ action: "force_logout", userId: u.dataset.id })),
      u.dataset.action === "restore")
    ) {
      const t = await adminCall({
        action: "restore_access",
        userId: u.dataset.id,
      });
      showAdminMessage(t.message || "\u8D26\u53F7\u4E0E\u8BBE\u5907\u6743\u9650\u5DF2\u6062\u590D");
    }
    if (u.dataset.action === "ip-block") {
      const t = prompt(
        `\u5C01\u7981\u516C\u7F51IP ${u.dataset.ip} \u7684\u539F\u56E0\uFF1A`,
        "\u7BA1\u7406\u5458\u7981\u6B62\u6B64\u7F51\u7EDC\u767B\u5F55",
      );
      if (t === null) {
        u.disabled = !1;
        return;
      }
      await adminCall({
        action: "block_client_ip",
        clientIp: u.dataset.ip,
        reason: t,
      });
    }
    if (
      (u.dataset.action === "ip-unblock" &&
        (await adminCall({
          action: "unblock_client_ip",
          clientIp: u.dataset.ip,
        })),
      u.dataset.action === "renew")
    ) {
      openAdminAction("renew", u.dataset.id);
      return;
    }
    if (u.dataset.action === "reset") {
      openAdminAction("reset", u.dataset.id);
      return;
    }
    if (u.dataset.action === "delete") {
      if (
        !confirm(`\u786E\u5B9A\u6C38\u4E45\u5220\u9664\u8D26\u53F7 ${u.dataset.name} \u5417\uFF1F

\u5C06\u5220\u9664\u767B\u5F55\u8D26\u53F7\u3001\u5458\u5DE5\u8D44\u6599\u3001\u8BBE\u5907\u3001\u6743\u9650\u8986\u76D6\u3001\u4EE3\u7406\u5206\u914D\u548CTN\u5206\u7EC4\uFF0C\u6B64\u64CD\u4F5C\u4E0D\u53EF\u6062\u590D\u3002`)
      )
        return;
      if (!(await adminCall({ action: "delete_user", userId: u.dataset.id }))?.permanentlyDeleted)
        throw new Error(
          "\u670D\u52A1\u5668\u6CA1\u6709\u786E\u8BA4\u8D26\u53F7\u5DF2\u6C38\u4E45\u5220\u9664",
        );
      if ((await loadUsers(), userSnapshot.some((t) => t.id === u.dataset.id)))
        throw new Error(
          "\u5220\u9664\u540E\u590D\u6838\u5931\u8D25\uFF1A\u8D26\u53F7\u4ECD\u5728\u5458\u5DE5\u5217\u8868\u4E2D",
        );
      showAdminMessage(`\u8D26\u53F7 ${u.dataset.name} \u5DF2\u6C38\u4E45\u5220\u9664`);
      return;
    }
    await loadUsers();
  } catch (t) {
    (showAdminMessage(t.message, !0), (u.disabled = !1));
  }
}
const editUserDialog = document.querySelector("#edit-user-dialog");
function openEditUser(e) {
  const u = userSnapshot.find((n) => n.id === e);
  if (!u) return;
  ((document.querySelector("#edit-user-id").value = u.id),
    (document.querySelector("#edit-user-username").value = u.username || ""),
    (document.querySelector("#edit-user-display-name").value = u.display_name || ""),
    (document.querySelector("#edit-user-plan").value = u.plan || "basic"),
    (document.querySelector("#edit-user-plan").disabled = u.role === "admin"),
    (document.querySelector("#edit-user-status").value = u.account_status || "active"),
    (document.querySelector("#edit-user-valid-until").value = u.valid_until
      ? new Date(u.valid_until).toISOString().slice(0, 10)
      : ""),
    (document.querySelector("#edit-user-valid-until").disabled = u.role === "admin"),
    (document.querySelector("#edit-user-device-limit").value = Number(u.device_limit || 50)));
  const t = u.display_name || u.username || "\u7528\u6237";
  ((document.querySelector("#edit-user-title").textContent = t),
    (document.querySelector("#edit-user-avatar").textContent = Array.from(t)[0] || "\u6A58"),
    (document.querySelector("#edit-user-summary").textContent =
      u.role === "admin"
        ? "\u7BA1\u7406\u5458 \xB7 \u56FA\u5B9A\u62E5\u6709\u7BA1\u7406\u6743\u9650"
        : `${u.plan === "advanced" ? "\u9AD8\u7EA7\u4F1A\u5458" : "\u666E\u901A\u4F1A\u5458"} \xB7 ${remainingDays(u.valid_until) ?? "\u957F\u671F"}${remainingDays(u.valid_until) === null ? "" : " \u5929"}`),
    (document.querySelector("#edit-user-message").textContent = ""),
    (document.querySelector("#user-site-access-message").textContent = ""),
    loadUserSiteAccess(e),
    editUserDialog.open || editUserDialog.showModal());
}
document.querySelector("#edit-user-close").addEventListener("click", () => editUserDialog.close());
async function loadUserSiteAccess(e = document.querySelector("#edit-user-id").value) {
  const u = document.querySelector("#user-site-access-list"),
    t = document.querySelector("#user-site-access-message");
  ((u.innerHTML = "<span>\u6B63\u5728\u8BFB\u53D6\u7F51\u7AD9\u6743\u9650\u2026</span>"),
    (t.textContent = ""));
  try {
    const n = await adminCall({ action: "list_user_site_access", userId: e }),
      a = userSnapshot.find((r) => r.id === e),
      o = {
        whatsapp: "platform_whatsapp",
        telegram: "platform_telegram",
        gmail: "platform_gmail",
      };
    ((u.innerHTML =
      (n.sites || [])
        .map((r) => {
          const s = n.adminLocked || r.enabled === !1,
            c = o[String(r.site_key || "").toLowerCase()],
            i =
              !n.adminLocked && !n.hasExplicitRules && c
                ? typeof permissionSnapshot?.[a?.plan || "basic"]?.[c] == "boolean"
                  ? permissionSnapshot[a?.plan || "basic"][c]
                  : c === "platform_gmail"
                : r.allowed,
            d =
              r.enabled === !1
                ? "\u5DF2\u5168\u5C40\u4E0B\u67B6"
                : c
                  ? i
                    ? "\u4F1A\u5458\u9ED8\u8BA4\u5F00\u653E"
                    : "\u9700\u7BA1\u7406\u5458\u5355\u72EC\u5F00\u653E"
                  : r.minimum_plan === "advanced"
                    ? "\u9AD8\u7EA7\u4F1A\u5458\u7F51\u7AD9"
                    : "\u666E\u901A\u4F1A\u5458\u7F51\u7AD9";
          return `<label class="user-site-access-item ${s ? "is-disabled" : ""}"><input type="checkbox" data-user-site-id="${esc(r.id)}" ${i ? "checked" : ""} ${s ? "disabled" : ""}/><span><strong>${esc(r.display_name || r.site_key)}</strong><small>${esc(d)}</small></span></label>`;
        })
        .join("") || "<span>\u5F53\u524D\u6CA1\u6709\u53EF\u5206\u914D\u7684\u7F51\u7AD9</span>"),
      (document.querySelector("#save-user-sites").disabled = n.adminLocked === !0),
      (t.textContent = n.adminLocked
        ? "\u7BA1\u7406\u5458\u56FA\u5B9A\u62E5\u6709\u5168\u90E8\u7F51\u7AD9\u6743\u9650\u3002"
        : n.hasExplicitRules
          ? "\u5F53\u524D\u4F7F\u7528\u8BE5\u5458\u5DE5\u7684\u72EC\u7ACB\u7F51\u7AD9\u6743\u9650\u3002"
          : "\u5F53\u524D\u6CBF\u7528\u4F1A\u5458\u9ED8\u8BA4\u6743\u9650\uFF1B\u4FDD\u5B58\u540E\u5207\u6362\u4E3A\u72EC\u7ACB\u6743\u9650\u3002"));
  } catch (n) {
    ((u.innerHTML = "<span>\u7F51\u7AD9\u6743\u9650\u8BFB\u53D6\u5931\u8D25</span>"),
      (t.textContent = `${n.message}\u3002\u8BF7\u5148\u90E8\u7F720.9.3\u7F51\u7AD9\u6743\u9650SQL\u548Cadmin-users\u51FD\u6570\u3002`));
  }
}
(document
  .querySelector("#refresh-user-sites")
  .addEventListener("click", () => loadUserSiteAccess()),
  document.querySelector("#save-user-sites").addEventListener("click", async (e) => {
    const u = e.currentTarget,
      t = document.querySelector("#edit-user-id").value,
      n = document.querySelector("#user-site-access-message"),
      o = [...document.querySelectorAll("[data-user-site-id]")];
    ((u.disabled = !0), (n.textContent = "\u6B63\u5728\u4FDD\u5B58\u5E76\u590D\u6838\u2026"));
    try {
      (await adminCall({
        action: "save_user_site_access",
        userId: t,
        siteAccess: o.map((a) => ({ siteId: a.dataset.userSiteId, allowed: a.checked })),
      }),
        await loadUserSiteAccess(t),
        (n.textContent =
          "\u7F51\u7AD9\u6743\u9650\u5DF2\u4FDD\u5B58\uFF1B\u5458\u5DE5\u5BA2\u6237\u7AEF\u5C06\u5728\u5FC3\u8DF3\u5237\u65B0\u540E\u81EA\u52A8\u66F4\u65B0\u3002"));
    } catch (a) {
      n.textContent = a.message;
    } finally {
      userSnapshot.find((a) => a.id === t && a.role === "admin") || (u.disabled = !1);
    }
  }),
  document.querySelectorAll("[data-drawer-renew-days]").forEach((e) =>
    e.addEventListener("click", async () => {
      const u = document.querySelector("#edit-user-id").value,
        t = document.querySelector("#edit-user-message");
      ((e.disabled = !0), (t.textContent = "\u6B63\u5728\u7EED\u671F\u2026"));
      try {
        (await adminCall({
          action: "renew_user",
          userId: u,
          validDays: Number(e.dataset.drawerRenewDays),
        }),
          await loadUsers(),
          userSnapshot.find((n) => n.id === u) && openEditUser(u),
          (t.textContent = `\u5DF2\u589E\u52A0 ${e.dataset.drawerRenewDays} \u5929\uFF0C\u8BB0\u5F97\u4FDD\u5B58\u5176\u4ED6\u4FEE\u6539\u3002`));
      } catch (n) {
        t.textContent = n.message;
      } finally {
        e.disabled = !1;
      }
    }),
  ),
  document.querySelector("#edit-user-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = document.querySelector("#edit-user-id").value,
      t = userSnapshot.find((o) => o.id === u),
      n = {
        action: "update_user",
        userId: u,
        displayName: document.querySelector("#edit-user-display-name").value,
        accountStatus: document.querySelector("#edit-user-status").value,
        deviceLimit: Number(document.querySelector("#edit-user-device-limit").value),
      };
    if (t?.role !== "admin") {
      n.plan = document.querySelector("#edit-user-plan").value;
      const o = document.querySelector("#edit-user-valid-until").value;
      n.validUntil = o ? `${o}T23:59:59.999Z` : null;
    }
    try {
      (await adminCall(n),
        editUserDialog.close(),
        showAdminMessage("\u8D26\u53F7\u8D44\u6599\u5DF2\u66F4\u65B0"),
        await loadUsers());
    } catch (o) {
      document.querySelector("#edit-user-message").textContent = o.message;
    }
  }));
const adminActionDialog = document.querySelector("#admin-action-dialog");
function openAdminAction(e, u) {
  ((document.querySelector("#admin-action-message").textContent = ""),
    document.querySelector("#renew-user-form").classList.toggle("hidden", e !== "renew"),
    document.querySelector("#reset-user-form").classList.toggle("hidden", e !== "reset"),
    (document.querySelector("#admin-action-title").textContent =
      e === "renew" ? "\u8D26\u53F7\u7EED\u671F" : "\u91CD\u7F6E\u4E34\u65F6\u5BC6\u7801"),
    (document.querySelector(e === "renew" ? "#renew-user-id" : "#reset-user-id").value = u),
    adminActionDialog.showModal());
}
(document.querySelectorAll("[data-renew-days]").forEach((e) =>
  e.addEventListener("click", () => {
    document.querySelector("#renew-days").value = e.dataset.renewDays;
  }),
),
  document.querySelector("#renew-user-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = Number(document.querySelector("#renew-days").value);
    try {
      (await adminCall({
        action: "renew_user",
        userId: document.querySelector("#renew-user-id").value,
        validDays: u,
      }),
        adminActionDialog.close(),
        await loadUsers());
    } catch (t) {
      document.querySelector("#admin-action-message").textContent = t.message;
    }
  }),
  document.querySelector("#show-reset-password").addEventListener("change", (e) => {
    const u = e.target.checked ? "text" : "password";
    ((document.querySelector("#reset-user-password").type = u),
      (document.querySelector("#reset-user-password-confirm").type = u));
  }),
  document.querySelector("#reset-user-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = document.querySelector("#reset-user-password").value,
      t = document.querySelector("#reset-user-password-confirm").value,
      n = document.querySelector("#admin-action-message");
    if (u !== t) {
      n.textContent = "\u4E24\u6B21\u8F93\u5165\u7684\u5BC6\u7801\u4E0D\u4E00\u81F4";
      return;
    }
    if (u.length < 6) {
      n.textContent = "\u5BC6\u7801\u81F3\u5C116\u4F4D\uFF0C\u53EF\u4F7F\u7528\u7EAF\u6570\u5B57";
      return;
    }
    try {
      (await adminCall({
        action: "reset_password",
        userId: document.querySelector("#reset-user-id").value,
        password: u,
      }),
        e.target.reset(),
        adminActionDialog.close(),
        showAdminMessage(
          "\u5BC6\u7801\u5DF2\u91CD\u7F6E\uFF0C\u8BE5\u5458\u5DE5\u9700\u8981\u4F7F\u7528\u65B0\u4E34\u65F6\u5BC6\u7801\u91CD\u65B0\u767B\u5F55",
        ));
    } catch (o) {
      n.textContent = o.message;
    }
  }),
  document
    .querySelector("#admin-action-close")
    .addEventListener("click", () => adminActionDialog.close()),
  form.addEventListener("submit", async (e) => {
    (e.preventDefault(),
      (errorText.textContent = ""),
      (loginButton.disabled = !0),
      (loginButton.textContent = "\u6B63\u5728\u9A8C\u8BC1\u2026"));
    const u = document.querySelector("#username").value,
      t = document.querySelector("#password").value,
      n = await window.orangeApp.login({ username: u, password: t });
    if (((loginButton.disabled = !1), (loginButton.textContent = "\u767B\u5F55"), !n.ok)) {
      errorText.textContent = n.message;
      return;
    }
    (await window.orangeApp.saveRememberedLogin({
      username: u,
      password: t,
      rememberUsername:
        document.querySelector("#remember-username").checked ||
        document.querySelector("#remember-password").checked,
      rememberPassword: document.querySelector("#remember-password").checked,
    }),
      form.reset(),
      renderHome(n.profile, n.sites, n.permissions),
      applyFeatureFlags(n.featureFlags || {}),
      scheduleTnSendRunner(500));
  }),
  document.querySelector("#logout-button").addEventListener("click", async () => {
    (clearTimeout(tnSendRunnerTimer),
      await window.orangeApp.logout(),
      (activeProfile = null),
      (activePermissions = {}),
      (activeFeatureFlags = {}),
      (tnSendAccounts = []),
      (tnSendRunnerBusy = !1),
      homeView.classList.add("hidden"),
      loginView.classList.remove("hidden"));
  }),
  document.querySelectorAll("[data-admin-nav]").forEach((e) =>
    e.addEventListener("click", () => {
      (setAdminPage(e.dataset.adminNav),
        e.dataset.adminNav === "messages" && loadMessagingCenter(),
        MANAGED_ACCOUNT_LABELS[e.dataset.adminNav] && loadManagedAccounts(e.dataset.adminNav));
    }),
  ),
  document
    .querySelector("[data-admin-settings]")
    .addEventListener("click", () => document.querySelector("#account-settings-button").click()),
  document.querySelector("#refresh-messages").addEventListener("click", loadMessagingCenter),
  document
    .querySelector("#message-contact-search")
    .addEventListener("input", renderMessageContacts),
  document.querySelector("#private-message-form").addEventListener("submit", async (e) => {
    if ((e.preventDefault(), !activeMessagePeerId)) return;
    const u = document.querySelector("#private-message-input"),
      t = String(u.value || "").trim();
    if (pendingPrivateAttachment) {
      await sendPrivateAttachment(pendingPrivateAttachment, t);
      return;
    }
    if (!t) return;
    const n = document.querySelector("#private-message-send");
    n.disabled = !0;
    const o = await window.orangeApp.sendInternalMessage({
      recipientId: activeMessagePeerId,
      body: t,
    });
    if (((n.disabled = !1), !o?.ok)) {
      document.querySelector("#messaging-message").textContent =
        o?.message || "\u6D88\u606F\u53D1\u9001\u5931\u8D25";
      return;
    }
    ((u.value = ""),
      messagingSnapshot.messages.push(o.message),
      renderPrivateConversation(),
      renderMessageContacts());
  }),
  document.querySelector("#private-message-input").addEventListener("keydown", (e) => {
    e.key !== "Enter" ||
      e.shiftKey ||
      (e.preventDefault(), document.querySelector("#private-message-form").requestSubmit());
  }));
function clearPendingPrivateAttachment() {
  ((pendingPrivateAttachment = null),
    pendingPrivateAttachmentUrl && URL.revokeObjectURL(pendingPrivateAttachmentUrl),
    (pendingPrivateAttachmentUrl = ""),
    document.querySelector("#private-attachment-pending").classList.add("hidden"));
  const e = document.querySelector("#private-attachment-pending-image");
  (e.classList.add("hidden"),
    e.removeAttribute("src"),
    (document.querySelector("#private-attachment-input").value = ""));
}
function stagePrivateAttachment(e) {
  if (!e || !activeMessagePeerId) return;
  const u = document.querySelector("#private-upload-status");
  if (e.size > 20 * 1024 * 1024) {
    u.textContent = "\u5355\u4E2A\u6587\u4EF6\u4E0D\u80FD\u8D85\u8FC720MB";
    return;
  }
  (clearPendingPrivateAttachment(),
    (pendingPrivateAttachment = e),
    (document.querySelector("#private-attachment-pending-name").textContent =
      e.name || "\u7C98\u8D34\u7684\u622A\u56FE"));
  const t = document.querySelector("#private-attachment-pending-image");
  (e.type.startsWith("image/") &&
    ((pendingPrivateAttachmentUrl = URL.createObjectURL(e)),
    (t.src = pendingPrivateAttachmentUrl),
    t.classList.remove("hidden")),
    document.querySelector("#private-attachment-pending").classList.remove("hidden"),
    (u.textContent =
      "\u9644\u4EF6\u5DF2\u52A0\u5165\u5F85\u53D1\u9001\u533A\uFF0C\u70B9\u51FB\u53D1\u9001\u540E\u624D\u4F1A\u4E0A\u4F20"));
}
async function sendPrivateAttachment(e, u = "") {
  if (!e || !activeMessagePeerId) return;
  const t = document.querySelector("#private-upload-status");
  if (e.size > 20 * 1024 * 1024) {
    t.textContent = "\u5355\u4E2A\u6587\u4EF6\u4E0D\u80FD\u8D85\u8FC720MB";
    return;
  }
  const n = document.querySelector("#private-attachment-button");
  ((n.disabled = !0),
    (t.textContent = `\u6B63\u5728\u53D1\u9001\uFF1A${e.name || "\u7C98\u8D34\u7684\u622A\u56FE"}`));
  try {
    const a = new Uint8Array(await e.arrayBuffer()),
      o = await window.orangeApp.sendInternalAttachment({
        recipientId: activeMessagePeerId,
        body: u,
        name: e.name || `\u622A\u56FE-${Date.now()}.png`,
        mime: e.type || "application/octet-stream",
        bytes: a,
      });
    if (!o?.ok) {
      t.textContent = o?.message || "\u9644\u4EF6\u53D1\u9001\u5931\u8D25";
      return;
    }
    (messagingSnapshot.messages.push(o.message),
      (document.querySelector("#private-message-input").value = ""),
      clearPendingPrivateAttachment(),
      (t.textContent = "\u53D1\u9001\u6210\u529F"),
      renderPrivateConversation(),
      renderMessageContacts());
  } catch (a) {
    t.textContent = a?.message || "\u9644\u4EF6\u53D1\u9001\u5931\u8D25";
  } finally {
    ((n.disabled = !activeMessagePeerId),
      (document.querySelector("#private-attachment-input").value = ""));
  }
}
(document
  .querySelector("#private-attachment-button")
  .addEventListener("click", () => document.querySelector("#private-attachment-input").click()),
  document
    .querySelector("#private-attachment-input")
    .addEventListener("change", (e) => stagePrivateAttachment(e.target.files?.[0])),
  document
    .querySelector("#private-attachment-cancel")
    .addEventListener("click", clearPendingPrivateAttachment),
  document.querySelector("#private-message-input").addEventListener("paste", (e) => {
    const u = [...(e.clipboardData?.files || [])].find((n) => n.type.startsWith("image/"));
    if (!u) return;
    e.preventDefault();
    const t = new File([u], `\u622A\u56FE-${new Date().toISOString().replace(/[:.]/g, "-")}.png`, {
      type: u.type || "image/png",
    });
    stagePrivateAttachment(t);
  }),
  document.querySelector("#private-message-form").addEventListener("dragover", (e) => {
    (e.preventDefault(), (e.dataTransfer.dropEffect = "copy"));
  }),
  document.querySelector("#private-message-form").addEventListener("drop", (e) => {
    (e.preventDefault(), stagePrivateAttachment(e.dataTransfer?.files?.[0]));
  }),
  document
    .querySelector("#private-image-close")
    .addEventListener("click", () => document.querySelector("#private-image-dialog").close()),
  document.querySelector("#private-image-dialog").addEventListener("click", (e) => {
    e.target.id === "private-image-dialog" && e.currentTarget.close();
  }),
  document.querySelector("#clear-current-conversation").addEventListener("click", async () => {
    if (
      !activeMessagePeerId ||
      !confirm(
        "\u786E\u5B9A\u6E05\u7A7A\u5F53\u524D\u804A\u5929\u5417\uFF1F\u53EA\u4F1A\u4ECE\u4F60\u81EA\u5DF1\u7684\u6D88\u606F\u5217\u8868\u9690\u85CF\uFF0C\u5BF9\u65B9\u8BB0\u5F55\u4E0D\u53D7\u5F71\u54CD\u3002",
      )
    )
      return;
    const e = await window.orangeApp.clearConversation(activeMessagePeerId);
    if (!e?.ok) {
      document.querySelector("#messaging-message").textContent =
        e?.message || "\u6E05\u7A7A\u5931\u8D25";
      return;
    }
    await loadMessagingCenter();
  }),
  document.querySelector("#clear-all-messages").addEventListener("click", async () => {
    if (
      !confirm(
        "\u786E\u5B9A\u6E05\u7A7A\u81EA\u5DF1\u7684\u5168\u90E8\u79C1\u804A\u5417\uFF1F\u6B64\u64CD\u4F5C\u4E0D\u4F1A\u5220\u9664\u5BF9\u65B9\u7684\u8BB0\u5F55\u3002",
      )
    )
      return;
    const e = await window.orangeApp.clearAllMessages();
    if (!e?.ok) {
      document.querySelector("#messaging-message").textContent =
        e?.message || "\u6E05\u7A7A\u5931\u8D25";
      return;
    }
    ((activeMessagePeerId = ""), await loadMessagingCenter());
  }),
  document.querySelector("#announcement-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = e.submitter;
    u.disabled = !0;
    const t = document.querySelector("#announcement-id").value,
      n = document.querySelector("#announcement-expires").value,
      o = {
        announcementId: t,
        title: document.querySelector("#announcement-title").value,
        body: document.querySelector("#announcement-body").value,
        targetUserId: document.querySelector("#announcement-target").value,
        expiresAt: n ? new Date(n).toISOString() : "",
        pinned: document.querySelector("#announcement-pinned").checked,
      },
      a = t
        ? await window.orangeApp.updateAnnouncement(o)
        : await window.orangeApp.createAnnouncement(o);
    if (((u.disabled = !1), !a?.ok)) {
      document.querySelector("#messaging-message").textContent =
        a?.message ||
        (t ? "\u516C\u544A\u7F16\u8F91\u5931\u8D25" : "\u516C\u544A\u53D1\u5E03\u5931\u8D25");
      return;
    }
    (resetAnnouncementForm(),
      await loadMessagingCenter(),
      (document.querySelector("#messaging-message").textContent = t
        ? "\u516C\u544A\u4FEE\u6539\u6210\u529F"
        : "\u516C\u544A\u53D1\u5E03\u6210\u529F"));
  }),
  document.querySelector("#announcement-edit-cancel").addEventListener("click", () => {
    (resetAnnouncementForm(),
      (document.querySelector("#messaging-message").textContent =
        "\u5DF2\u53D6\u6D88\u7F16\u8F91"));
  }),
  window.orangeApp.onMessagingChanged?.(() => {
    (clearTimeout(messagingRefreshTimer),
      (messagingRefreshTimer = setTimeout(loadMessagingCenter, 250)));
  }),
  setInterval(() => {
    const e = document.querySelector('[data-admin-page="messages"]');
    activeProfile &&
      e?.classList.contains("active") &&
      document.visibilityState === "visible" &&
      loadMessagingCenter();
  }, 7e3),
  window.orangeApp.onShowMessages?.((e) => {
    (setAdminPage("messages"),
      e?.peerId && (activeMessagePeerId = String(e.peerId)),
      loadMessagingCenter());
  }),
  window.orangeApp.onNetworkWarning?.((e) => {
    const u =
      document.querySelector("#admin-message") || document.querySelector("#settings-message");
    u &&
      (u.textContent =
        e?.message ||
        "\u7F51\u7EDC\u6682\u65F6\u4E0D\u7A33\u5B9A\uFF0C\u6B63\u5728\u81EA\u52A8\u91CD\u8BD5");
  }),
  document.querySelector("#refresh-users").addEventListener("click", loadUsers),
  document.querySelector("#refresh-sites").addEventListener("click", loadSitesAdmin),
  document.querySelector("#refresh-proxies").addEventListener("click", loadProxyPool),
  document.querySelector("#refresh-proxy-logs").addEventListener("click", loadProxyLogs),
  document.querySelector("#delete-failed-proxies").addEventListener("click", async () => {
    if (
      !confirm(
        "\u786E\u5B9A\u5220\u9664\u5168\u90E8\u6807\u8BB0\u4E3A\u5931\u6548\u7684\u4EE3\u7406\u5417\uFF1F",
      )
    )
      return;
    const e = await adminCall({ action: "delete_failed_proxies" });
    ((document.querySelector("#proxy-pool-message").textContent =
      `\u5DF2\u5220\u9664 ${Number(e.deleted || 0)} \u6761\u5931\u6548\u4EE3\u7406`),
      await loadProxyPool());
  }),
  document.querySelector("#proxy-pool-settings-form").addEventListener("submit", async (e) => {
    (e.preventDefault(),
      await adminCall({
        action: "save_proxy_settings",
        enabled: document.querySelector("#proxy-pool-enabled").checked,
        failureThreshold: Number(document.querySelector("#proxy-failure-threshold").value),
        healthCheckIntervalMinutes: Number(document.querySelector("#proxy-health-interval").value),
      }),
      (document.querySelector("#proxy-pool-message").textContent =
        "\u4EE3\u7406\u6C60\u89C4\u5219\u5DF2\u4FDD\u5B58"),
      await loadProxyPool());
  }),
  document.querySelector("#proxy-import-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = e.submitter;
    u.disabled = !0;
    const t = document.querySelector("#proxy-pool-message");
    try {
      const n = await adminCall({
        action: "import_proxies",
        proxyProtocol: document.querySelector("#proxy-import-protocol").value,
        proxyPoolKind: document.querySelector("#proxy-import-kind").value,
        tnCapacity: Number(document.querySelector("#proxy-import-tn-capacity").value || 30),
        proxyLabel: document.querySelector("#proxy-import-label").value,
        importText: document.querySelector("#proxy-import-text").value,
      });
      (e.target.reset(),
        t.classList.remove("error"),
        (t.textContent = `\u5DF2\u52A0\u5BC6\u5BFC\u5165 ${Number(n.imported || 0)} \u6761\u4EE3\u7406`),
        await loadProxyPool());
    } catch (n) {
      (t.classList.add("error"), (t.textContent = n.message));
    }
    u.disabled = !1;
  }),
  document.querySelector("#tn-proxy-import-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = e.submitter;
    u.disabled = !0;
    const t = document.querySelector("#tn-proxy-pool-message");
    try {
      const n = await adminCall({
        action: "import_proxies",
        proxyProtocol: document.querySelector("#tn-proxy-import-protocol").value,
        proxyPoolKind: "tn",
        tnCapacity: Number(document.querySelector("#tn-proxy-import-capacity").value || 30),
        proxyLabel: document.querySelector("#tn-proxy-import-label").value,
        importText: document.querySelector("#tn-proxy-import-text").value,
      });
      (e.target.reset(),
        (document.querySelector("#tn-proxy-import-protocol").value = "socks5"),
        (document.querySelector("#tn-proxy-import-capacity").value = "30"),
        t.classList.remove("error"),
        (t.textContent = `\u5DF2\u5BFC\u5165 ${Number(n.imported || 0)} \u6761TN\u4E13\u7528\u56FA\u5B9AIP`),
        await loadProxyPool());
    } catch (n) {
      (t.classList.add("error"), (t.textContent = n.message));
    }
    u.disabled = !1;
  }),
  document.querySelector("#refresh-tn-proxies").addEventListener("click", loadProxyPool));
function syncProxyAssignmentMode() {
  const e = document.querySelector("#proxy-assignment-mode").value === "fixed",
    u = document.querySelector("#proxy-assignment-proxy");
  if (((u.required = e), (u.disabled = !e), e || (u.value = ""), e && !u.value)) {
    const t = Array.from(u.options).find((n) => n.value && n.dataset.unbound === "true");
    t && (u.value = t.value);
  }
}
function renderProxyOptions(e, u = "") {
  const t = proxyPoolSnapshot.assignments.find((o) => o.user_id === e)?.proxy_id || "",
    n = proxyPoolSnapshot.proxies
      .filter((o) => o.enabled && o.pool_kind !== "tn")
      .sort((o, a) => {
        const r = Math.max(0, Number(o.assignment_count || 0) - (o.id === t ? 1 : 0)),
          s = Math.max(0, Number(a.assignment_count || 0) - (a.id === t ? 1 : 0));
        return r - s || String(o.label || o.host).localeCompare(String(a.label || a.host), "zh-CN");
      });
  ((document.querySelector("#proxy-assignment-proxy").innerHTML =
    '<option value="">\u81EA\u52A8\u9009\u62E9</option>' +
    n
      .map((o) => {
        const a = Math.max(0, Number(o.assignment_count || 0) - (o.id === t ? 1 : 0)),
          r = a === 0 ? "\u672A\u7ED1\u5B9A \xB7 \u4F18\u5148" : `\u5DF2\u7ED1\u5B9A ${a} \u4EBA`;
        return `<option value="${o.id}" data-unbound="${a === 0}">${esc(o.label || o.host)} \xB7 ${esc(o.host)}:${Number(o.port)} \xB7 ${r}</option>`;
      })
      .join("")),
    (document.querySelector("#proxy-assignment-proxy").value = u || ""));
}
function syncProxyAssignmentUser() {
  const e = document.querySelector("#proxy-assignment-user").value,
    u = proxyPoolSnapshot.assignments.find((t) => t.user_id === e);
  (renderProxyOptions(e, u?.proxy_id || ""),
    (document.querySelector("#proxy-assignment-allowed").checked = u?.allowed_by_admin !== !1),
    (document.querySelector("#proxy-assignment-mode").value =
      u?.assignment_mode === "fixed" ? "fixed" : "automatic"),
    syncProxyAssignmentMode());
}
function renderGmailProxyOptions(e, u = "") {
  const t = proxyPoolSnapshot.assignments.find((a) => a.user_id === e)?.proxy_id || "",
    n = proxyPoolSnapshot.proxies
      .filter((a) => a.enabled && a.pool_kind !== "tn")
      .sort(
        (a, r) =>
          Math.max(0, Number(a.assignment_count || 0) - (a.id === t ? 1 : 0)) -
            Math.max(0, Number(r.assignment_count || 0) - (r.id === t ? 1 : 0)) ||
          String(a.label || a.host).localeCompare(String(r.label || r.host), "zh-CN"),
      ),
    o = document.querySelector("#gmail-proxy-assignment-proxy");
  ((o.innerHTML =
    '<option value="">\u81EA\u52A8\u9009\u62E9</option>' +
    n
      .map((a) => {
        const r = Math.max(0, Number(a.assignment_count || 0) - (a.id === t ? 1 : 0));
        return `<option value="${a.id}" data-unbound="${r === 0}">${esc(a.label || a.host)} \xB7 ${esc(a.host)}:${Number(a.port)} \xB7 ${r === 0 ? "\u672A\u7ED1\u5B9A \xB7 \u4F18\u5148" : `\u5DF2\u7ED1\u5B9A ${r} \u4EBA`}</option>`;
      })
      .join("")),
    (o.value = u || ""));
}
function syncGmailProxyAssignmentMode() {
  const e = document.querySelector("#gmail-proxy-assignment-mode").value === "fixed",
    u = document.querySelector("#gmail-proxy-assignment-proxy");
  if (((u.required = e), (u.disabled = !e), e || (u.value = ""), e && !u.value)) {
    const t = Array.from(u.options).find((n) => n.value && n.dataset.unbound === "true");
    t && (u.value = t.value);
  }
}
function syncGmailProxyAssignmentUser() {
  const e = document.querySelector("#gmail-proxy-assignment-user").value,
    u = proxyPoolSnapshot.assignments.find((t) => t.user_id === e);
  (renderGmailProxyOptions(e, u?.proxy_id || ""),
    (document.querySelector("#gmail-proxy-assignment-allowed").checked =
      u?.allowed_by_admin !== !1),
    (document.querySelector("#gmail-proxy-assignment-mode").value =
      u?.assignment_mode === "fixed" ? "fixed" : "automatic"),
    syncGmailProxyAssignmentMode());
}
(document
  .querySelector("#proxy-assignment-mode")
  .addEventListener("change", syncProxyAssignmentMode),
  document
    .querySelector("#proxy-assignment-user")
    .addEventListener("change", syncProxyAssignmentUser),
  document
    .querySelector("#gmail-proxy-assignment-mode")
    .addEventListener("change", syncGmailProxyAssignmentMode),
  document
    .querySelector("#gmail-proxy-assignment-user")
    .addEventListener("change", syncGmailProxyAssignmentUser),
  document.querySelector("#gmail-proxy-assignment-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = document.querySelector("#gmail-proxy-assignment-message");
    try {
      const t = await adminCall({
        action: "save_proxy_assignment",
        userId: document.querySelector("#gmail-proxy-assignment-user").value,
        assignmentMode: document.querySelector("#gmail-proxy-assignment-mode").value,
        proxyId: document.querySelector("#gmail-proxy-assignment-proxy").value || void 0,
        allowedByAdmin: document.querySelector("#gmail-proxy-assignment-allowed").checked,
      });
      (u.classList.remove("error"),
        (u.textContent = t.assigned
          ? "\u5458\u5DE5Google\u90AE\u7BB1IP\u5DF2\u7ED1\u5B9A\u5E76\u7ACB\u5373\u751F\u6548"
          : "\u5206\u914D\u89C4\u5219\u5DF2\u4FDD\u5B58\uFF1B\u6709\u53EF\u7528IP\u540E\u4F1A\u81EA\u52A8\u7ED1\u5B9A"),
        await loadProxyPool());
    } catch (t) {
      (u.classList.add("error"), (u.textContent = t.message));
    }
  }),
  document.querySelector("#proxy-assignment-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = await adminCall({
      action: "save_proxy_assignment",
      userId: document.querySelector("#proxy-assignment-user").value,
      assignmentMode: document.querySelector("#proxy-assignment-mode").value,
      proxyId: document.querySelector("#proxy-assignment-proxy").value || void 0,
      allowedByAdmin: document.querySelector("#proxy-assignment-allowed").checked,
    });
    ((document.querySelector("#proxy-pool-message").textContent = u.assigned
      ? "\u5DF2\u81EA\u52A8\u7ED1\u5B9A\u4F18\u5148\u672A\u5360\u7528\u7684\u53EF\u7528IP"
      : "\u89C4\u5219\u5DF2\u4FDD\u5B58\uFF0C\u5F53\u524D\u6682\u65F6\u6CA1\u6709\u53EF\u7528IP\uFF0C\u7CFB\u7EDF\u4F1A\u7EE7\u7EED\u81EA\u52A8\u68C0\u6D4B"),
      await loadProxyPool());
  }),
  setInterval(() => {
    activeProfile?.role !== "admin" ||
      homeView.classList.contains("hidden") ||
      document.querySelector("#proxy-assignment-form")?.contains(document.activeElement) ||
      loadProxyPool();
  }, 60 * 1e3),
  setInterval(() => {
    activeProfile?.role !== "admin" ||
      homeView.classList.contains("hidden") ||
      !document.querySelector('[data-admin-page="accounts"]')?.classList.contains("active") ||
      loadUsers();
  }, 30 * 1e3),
  syncProxyAssignmentMode(),
  document.querySelector("#refresh-ai-keys").addEventListener("click", loadAiKeys),
  document
    .querySelector("#deepl-api-key-link")
    .addEventListener("click", () =>
      window.orangeApp.openExternal("https://www.deepl.com/your-account/keys"),
    ),
  document
    .querySelector("#openai-api-key-link")
    .addEventListener("click", () =>
      window.orangeApp.openExternal("https://platform.openai.com/api-keys"),
    ),
  document
    .querySelector("#groq-register-link")
    .addEventListener("click", () => window.orangeApp.openExternal("https://console.groq.com/")),
  document
    .querySelector("#groq-create-key-link")
    .addEventListener("click", () =>
      window.orangeApp.openExternal("https://console.groq.com/keys"),
    ),
  document
    .querySelector("#gemini-api-key-link")
    .addEventListener("click", () =>
      window.orangeApp.openExternal("https://aistudio.google.com/api-keys"),
    ),
  document
    .querySelector("#groq-guide-link")
    .addEventListener("click", () =>
      window.orangeApp.openExternal("https://console.groq.com/docs/quickstart"),
    ));
const AI_MODEL_PRESETS = Object.freeze({
    deepl: ["deepl-pro", "deepl-free"],
    openai_official: [
      "gpt-5.4-mini",
      "gpt-5.4",
      "gpt-5.2",
      "gpt-5-mini",
      "gpt-4.1-mini",
      "gpt-4.1-nano",
    ],
    groq: [
      "groq/compound-mini",
      "groq/compound",
      "openai/gpt-oss-120b",
      "openai/gpt-oss-20b",
      "llama-3.3-70b-versatile",
      "llama-3.1-8b-instant",
      "meta-llama/llama-4-scout-17b-16e-instruct",
      "qwen/qwen3-32b",
      "moonshotai/kimi-k2-instruct",
    ],
    gemini: [
      "gemini-3.8-flash",
      "gemini-3.7-flash",
      "gemini-3.5-flash",
      "gemini-3.1-flash-lite",
      "gemini-2.5-flash",
      "gemini-2.5-flash-lite",
      "gemini-2.5-pro",
      "gemini-2.0-flash",
    ],
    deepseek: ["deepseek-chat", "deepseek-reasoner"],
    xai: ["grok-4-fast", "grok-4", "grok-3-mini", "grok-code-fast-1"],
    mistral: [
      "mistral-small-latest",
      "mistral-medium-latest",
      "mistral-large-latest",
      "ministral-8b-latest",
      "codestral-latest",
    ],
    openrouter: [
      "google/gemini-2.5-flash",
      "google/gemini-2.5-flash-lite",
      "deepseek/deepseek-chat",
      "deepseek/deepseek-r1",
      "openai/gpt-oss-120b",
      "openai/gpt-oss-20b",
      "qwen/qwen3-32b",
      "meta-llama/llama-3.3-70b-instruct",
      "mistralai/mistral-small-3.2-24b-instruct",
      "anthropic/claude-sonnet-4",
      "openai/gpt-5-mini",
    ],
    together: [
      "openai/gpt-oss-20b",
      "openai/gpt-oss-120b",
      "meta-llama/Llama-3.3-70B-Instruct-Turbo",
      "meta-llama/Llama-3.1-8B-Instruct-Turbo",
      "Qwen/Qwen2.5-72B-Instruct-Turbo",
      "deepseek-ai/DeepSeek-V3",
    ],
    azure_openai: ["\u586B\u5199Azure\u90E8\u7F72\u540D\u79F0"],
    anthropic_reserved: ["claude-sonnet-4", "claude-haiku-4"],
    openai_compatible: [],
  }),
  AI_MODEL_LABELS = Object.freeze({
    "deepl-pro": "DeepL API Pro \xB7 WhatsApp\u4F18\u5148",
    "deepl-free": "DeepL API Free \xB7 WhatsApp\u4F18\u5148",
    "groq/compound-mini": "Compound Mini \xB7 \u6781\u901F\u63A8\u8350",
    "groq/compound": "Compound \xB7 \u5DE5\u5177\u589E\u5F3A",
    "openai/gpt-oss-120b": "GPT-OSS 120B \xB7 \u7FFB\u8BD1\u8D28\u91CF\u4F18\u5148",
    "openai/gpt-oss-20b": "GPT-OSS 20B \xB7 \u901F\u5EA6\u4F18\u5148",
    "gemini-2.5-flash": "Gemini 2.5 Flash \xB7 \u5747\u8861",
    "gemini-2.5-flash-lite": "Gemini 2.5 Flash-Lite \xB7 \u4F4E\u4EF7\u9AD8\u901F",
    "deepseek-chat": "DeepSeek Chat \xB7 \u4E2D\u6587\u63A8\u8350",
    "deepseek-reasoner": "DeepSeek Reasoner \xB7 \u6DF1\u5EA6\u63A8\u7406",
  });
function refreshAiModelSuggestions(e, u = !1) {
  const t = AI_MODEL_PRESETS[e] || [],
    n = document.querySelector("#groq-model"),
    o = n.value;
  (n.replaceChildren(
    ...t.map((a) =>
      Object.assign(document.createElement("option"), {
        value: a,
        textContent: AI_MODEL_LABELS[a] || a,
      }),
    ),
    Object.assign(document.createElement("option"), {
      value: "__custom__",
      textContent: "\uFF0B \u81EA\u5B9A\u4E49\u6A21\u578BID",
    }),
  ),
    (n.value = !u && [...n.options].some((a) => a.value === o) ? o : t[0] || "__custom__"),
    syncCustomAiModelField());
}
function syncCustomAiModelField() {
  const e = document.querySelector("#groq-model").value === "__custom__";
  (document.querySelector("#ai-custom-model-field").classList.toggle("hidden", !e),
    (document.querySelector("#ai-custom-model").required = e));
}
function selectedAiModel() {
  const e = document.querySelector("#groq-model").value;
  return (e === "__custom__" ? document.querySelector("#ai-custom-model").value : e).trim();
}
const AI_COMPATIBLE_ENDPOINTS = Object.freeze({
  deepl: "https://api.deepl.com/v2/translate",
  openai_official: "https://api.openai.com/v1",
  deepseek: "https://api.deepseek.com/v1",
  xai: "https://api.x.ai/v1",
  mistral: "https://api.mistral.ai/v1",
  openrouter: "https://openrouter.ai/api/v1",
  together: "https://api.together.xyz/v1",
});
(document.querySelector("#ai-provider").addEventListener("change", (e) => {
  const u = e.target.value,
    t = document.querySelector("#groq-model"),
    n = document.querySelector("#ai-endpoint-url"),
    o = document.querySelector("#ai-use-proxy-pool");
  (refreshAiModelSuggestions(u, !0),
    (n.value = AI_COMPATIBLE_ENDPOINTS[u] || ""),
    (o.checked = u === "gemini"));
}),
  document.querySelector("#groq-model").addEventListener("change", (e) => {
    syncCustomAiModelField();
    const u = selectedAiModel(),
      t = document.querySelector("#ai-provider");
    !u ||
      e.target.value === "__custom__" ||
      (/^deepl-/i.test(u)
        ? (t.value = "deepl")
        : /^gemini-/i.test(u)
          ? (t.value = "gemini")
          : /^(groq\/|openai\/gpt-oss|llama-)/i.test(u)
            ? (t.value = "groq")
            : /^gpt-/i.test(u) && (t.value = "openai_official"),
      refreshAiModelSuggestions(t.value, !1),
      (document.querySelector("#ai-endpoint-url").value =
        u === "deepl-free"
          ? "https://api-free.deepl.com/v2/translate"
          : AI_COMPATIBLE_ENDPOINTS[t.value] || ""));
  }),
  refreshAiModelSuggestions(document.querySelector("#ai-provider").value, !1),
  document.querySelector("#ai-key-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = document.querySelector("#ai-key-message");
    try {
      const t = document.querySelector("#ai-provider").value,
        n = selectedAiModel();
      if (t === "anthropic_reserved")
        throw new Error(
          "Anthropic\u5DF2\u9884\u7559\uFF1B\u5F53\u524D\u8BF7\u5148\u901A\u8FC7OpenRouter\u9009\u62E9Claude\u6A21\u578B",
        );
      if (t === "openai_official" && !/^gpt-/i.test(n))
        throw new Error("OpenAI\u5B98\u65B9\u63A5\u53E3\u5FC5\u987B\u9009\u62E9GPT\u6A21\u578B");
      if (t === "groq" && /^gpt-(?!oss)/i.test(n))
        throw new Error("\u8BE5GPT\u6A21\u578B\u4E0D\u80FD\u4F7F\u7528Groq\u63A5\u53E3");
      if (t === "gemini" && !/^gemini-/i.test(n))
        throw new Error("Gemini\u63A5\u53E3\u5FC5\u987B\u9009\u62E9Gemini\u6A21\u578B");
      if (t === "deepl" && !/^deepl-(?:pro|free)$/i.test(n))
        throw new Error("DeepL\u8BF7\u9009\u62E9Pro\u6216Free\u63A5\u53E3");
      (await aiCall({
        action: "add_key",
        displayName: document.querySelector("#groq-key-name").value,
        provider: [
          "openai_official",
          "deepseek",
          "xai",
          "mistral",
          "openrouter",
          "together",
          "azure_openai",
        ].includes(t)
          ? "openai_compatible"
          : t,
        apiKey: document.querySelector("#groq-api-key").value,
        model: n,
        endpointUrl: document.querySelector("#ai-endpoint-url").value,
        useProxyPool: document.querySelector("#ai-use-proxy-pool").checked,
        makePublic: document.querySelector("#groq-key-public").value === "true",
      }),
        e.target.reset(),
        (document.querySelector("#ai-provider").value = "groq"),
        refreshAiModelSuggestions("groq", !0),
        (document.querySelector("#ai-endpoint-url").value = ""),
        u.classList.remove("error"),
        (u.textContent = "AI\u6A21\u578B\u548CKey\u5DF2\u52A0\u5BC6\u4FDD\u5B58"),
        await loadAiKeys());
    } catch (t) {
      ((u.textContent = t.message), u.classList.add("error"));
    }
  }),
  document.querySelector("#site-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = e.submitter || e.currentTarget.querySelector('button[type="submit"]'),
      t = document.querySelector("#site-admin-message"),
      n = document.querySelector("#site-key").value,
      o = normalizedSiteKey(n);
    ((document.querySelector("#site-key").value = o),
      (u.disabled = !0),
      t.classList.remove("error"),
      (t.textContent =
        n.trim().toLowerCase() === o
          ? "\u6B63\u5728\u4FDD\u5B58\u7F51\u7AD9\u2026"
          : `\u7F51\u7AD9\u6807\u8BC6\u5DF2\u81EA\u52A8\u8C03\u6574\u4E3A ${o}\uFF0C\u6B63\u5728\u4FDD\u5B58\u2026`));
    try {
      const a = await window.orangeApp.saveAdminSite({
        siteId: document.querySelector("#site-id").value || void 0,
        siteKey: o,
        siteName: document.querySelector("#site-name").value,
        siteUrl: document.querySelector("#site-url").value,
        sortOrder: Number(document.querySelector("#site-order").value),
        siteIconUrl: document.querySelector("#site-icon-url").value,
        siteProxyMode: document.querySelector("#site-proxy-mode").value,
        siteFixedProxyId: document.querySelector("#site-fixed-proxy-id").value || null,
        chatContainerSelector: document.querySelector("#site-chat-container-selector").value,
        messageSelector: document.querySelector("#site-message-selector").value,
        inputSelector: document.querySelector("#site-input-selector").value,
        phoneSelector: document.querySelector("#site-phone-selector").value,
        siteEnabled: document.querySelector("#site-enabled").value === "true",
        minimumPlan: document.querySelector("#site-minimum-plan").value,
      });
      if (!a?.ok) throw new Error(a?.message || "\u7F51\u7AD9\u6CA1\u6709\u4FDD\u5B58\u6210\u529F");
      (e.target.reset(),
        (document.querySelector("#site-order").value = "100"),
        (document.querySelector("#site-id").value = ""),
        await loadSitesAdmin(),
        (t.textContent = `\u7F51\u7AD9\u5DF2\u5199\u5165\u6570\u636E\u5E93\uFF08\u6807\u8BC6\uFF1A${a.siteKey || o}\uFF09`));
    } catch (a) {
      (t.classList.add("error"),
        (t.textContent = `\u7F51\u7AD9\u4FDD\u5B58\u5931\u8D25\uFF1A${a.message}`));
    } finally {
      u.disabled = !1;
    }
  }),
  document.querySelector("#site-proxy-mode").addEventListener("change", (e) => {
    document
      .querySelector("#site-fixed-proxy-field")
      .classList.toggle("hidden", e.target.value !== "fixed");
  }),
  document.querySelector("#create-user-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = e.submitter;
    u.disabled = !0;
    try {
      const t = Number(document.querySelector("#new-valid-days").value);
      (await adminCall({
        action: "create_user",
        username: document.querySelector("#new-username").value,
        displayName: document.querySelector("#new-display-name").value,
        password: document.querySelector("#new-password").value,
        role: document.querySelector("#new-role").value,
        plan: document.querySelector("#new-plan").value,
        validDays: t,
        deviceLimit: Number(document.querySelector("#new-device-limit").value),
      }),
        e.target.reset(),
        (document.querySelector("#new-device-limit").value = "1"),
        syncNewAccountRole(),
        showAdminMessage("\u8D26\u53F7\u521B\u5EFA\u6210\u529F"),
        await loadUsers());
    } catch (t) {
      showAdminMessage(t.message, !0);
    }
    u.disabled = !1;
  }));
function syncNewAccountRole() {
  const e = document.querySelector("#new-role").value === "admin",
    u = document.querySelector("#new-plan"),
    t = document.querySelector("#new-valid-days");
  (e ? ((u.value = "advanced"), (t.value = "0")) : t.value === "0" && (t.value = "30"),
    (u.disabled = e),
    (t.disabled = e));
}
(document.querySelector("#new-role").addEventListener("change", syncNewAccountRole),
  syncNewAccountRole(),
  window.orangeApp.onRevoked((e) => {
    (alert(e || "\u8D26\u53F7\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55"),
      homeView.classList.add("hidden"),
      loginView.classList.remove("hidden"));
  }));
const dialog = document.querySelector("#renew-dialog");
function openAccountServiceDialog(e) {
  ((document.querySelector("#renew-dialog-title").textContent =
    `\u8054\u7CFB${e}\u7EED\u8D39 / \u5145\u503C`),
    (document.querySelector("#renew-dialog-message").textContent =
      `\u5982\u9700\u8D26\u53F7\u7EED\u8D39\u3001\u5145\u503C\u3001\u5EF6\u957F\u671F\u9650\u6216\u589E\u52A0\u989D\u5EA6\uFF0C\u8BF7\u8054\u7CFB${e}\u529E\u7406\u3002`),
    dialog.showModal());
}
(document
  .querySelector("#orange-service-button")
  .addEventListener("click", () => openAccountServiceDialog("\u6A58\u5B50")),
  document
    .querySelector("#anan-service-button")
    .addEventListener("click", () => openAccountServiceDialog("\u963F\u5357")),
  document.querySelector("#renew-close").addEventListener("click", () => dialog.close()));
let credentialAccounts = [];
function populateCredentialSites() {
  document.querySelector("#credential-site").innerHTML = sites
    .map(([e, u]) => `<option value="${esc(e)}">${esc(u)}</option>`)
    .join("");
}
function renderCredentialAccount(e = "") {
  const u = credentialAccounts.find((t) => t.id === e) || null;
  ((document.querySelector("#credential-profile").value = u?.id || ""),
    (document.querySelector("#credential-label").value = u?.label || ""),
    (document.querySelector("#credential-username").value = u?.username || ""),
    (document.querySelector("#credential-password").value = u?.password || ""));
}
async function loadCredential() {
  const e = await window.orangeApp.getSiteCredential(
    document.querySelector("#credential-site").value,
  );
  ((credentialAccounts = Array.isArray(e.accounts) ? e.accounts : []),
    (document.querySelector("#credential-profile").innerHTML =
      `<option value="">\uFF0B \u65B0\u589E\u8D26\u53F7</option>${credentialAccounts.map((u) => `<option value="${esc(u.id)}">${esc(u.label || u.username || "\u672A\u547D\u540D\u8D26\u53F7")}</option>`).join("")}`),
    renderCredentialAccount(credentialAccounts[0]?.id || ""));
}
(document.querySelector("#site-credentials-button").addEventListener("click", async () => {
  (populateCredentialSites(),
    await loadCredential(),
    document.querySelector("#site-credentials-dialog").showModal());
}),
  document.querySelector("#credential-site").addEventListener("change", loadCredential),
  document
    .querySelector("#credential-profile")
    .addEventListener("change", (e) => renderCredentialAccount(e.target.value)),
  document
    .querySelector("#credential-new")
    .addEventListener("click", () => renderCredentialAccount("")),
  document.querySelector("#site-credentials-form").addEventListener("submit", async (e) => {
    (e.preventDefault(),
      await window.orangeApp.saveSiteCredential({
        siteId: document.querySelector("#credential-site").value,
        credentialId: document.querySelector("#credential-profile").value,
        label: document.querySelector("#credential-label").value,
        username: document.querySelector("#credential-username").value,
        password: document.querySelector("#credential-password").value,
      }),
      await loadCredential(),
      alert("\u6B64\u7F51\u7AD9\u8D26\u53F7\u5DF2\u52A0\u5BC6\u4FDD\u5B58"));
  }),
  document.querySelector("#credential-clear").addEventListener("click", async () => {
    const e = document.querySelector("#credential-profile").value;
    e &&
      confirm("\u786E\u5B9A\u5220\u9664\u5F53\u524D\u4FDD\u5B58\u7684\u8D26\u53F7\u5417\uFF1F") &&
      (await window.orangeApp.saveSiteCredential({
        siteId: document.querySelector("#credential-site").value,
        credentialId: e,
        clear: !0,
      }),
      await loadCredential());
  }),
  document
    .querySelector("#credential-close")
    .addEventListener("click", () => document.querySelector("#site-credentials-dialog").close()),
  document.querySelector("#account-settings-button").addEventListener("click", async () => {
    const e = await window.orangeApp.getProxy();
    if (
      ((document.querySelector("#employee-proxy-enabled").checked = e.enabled === !0),
      renderManagedProxyState(e),
      syncDashboardWallpaperControls(),
      document
        .querySelector("#membership-policy-panel")
        ?.classList.toggle("hidden", activeProfile?.role !== "admin"),
      activeProfile?.role === "admin")
    )
      try {
        const u = await adminCall({ action: "get_membership_settings" });
        document.querySelector("#basic-grace-days").value = String(
          u.settings?.basicGraceDays || 30,
        );
      } catch (u) {
        document.querySelector("#membership-policy-message").textContent = u.message;
      }
    document.querySelector("#settings-dialog").showModal();
  }));
const WALLPAPER_PREFIX = "orangeDashboardWallpaper:";
function dashboardWallpaperKey() {
  return `${WALLPAPER_PREFIX}${activeProfile?.id || "default"}`;
}
function readDashboardWallpaper() {
  try {
    return JSON.parse(localStorage.getItem(dashboardWallpaperKey()) || "null") || {};
  } catch {
    return {};
  }
}
function applyDashboardWallpaper() {
  const e = readDashboardWallpaper();
  (document.body.classList.toggle("dashboard-wallpaper", !!e.image),
    document.body.style.setProperty(
      "--dashboard-wallpaper-image",
      e.image ? `url("${e.image}")` : "none",
    ),
    document.body.style.setProperty(
      "--dashboard-wallpaper-opacity",
      String(Math.max(0.2, Math.min(1, Number(e.opacity || 0.82)))),
    ));
}
function syncDashboardWallpaperControls() {
  const e = readDashboardWallpaper(),
    u = Math.round(Math.max(0.2, Math.min(1, Number(e.opacity || 0.82))) * 100);
  ((document.querySelector("#dashboard-wallpaper-opacity").value = String(u)),
    (document.querySelector("#dashboard-wallpaper-opacity-value").textContent = `${u}%`),
    (document.querySelector("#dashboard-wallpaper-status").textContent = e.image
      ? "\u5DF2\u4F7F\u7528\u672C\u673A\u81EA\u5B9A\u4E49\u58C1\u7EB8"
      : "\u5F53\u524D\u4F7F\u7528\u9ED8\u8BA4\u80CC\u666F"));
}
async function imageFileToWallpaper(e) {
  const u = await new Promise((o, r) => {
      const s = new FileReader();
      ((s.onload = () => o(s.result)),
        (s.onerror = () => r(new Error("\u56FE\u7247\u8BFB\u53D6\u5931\u8D25"))),
        s.readAsDataURL(e));
    }),
    t = await new Promise((o, r) => {
      const s = new Image();
      ((s.onload = () => o(s)),
        (s.onerror = () => r(new Error("\u65E0\u6CD5\u8BC6\u522B\u8FD9\u5F20\u56FE\u7247"))),
        (s.src = u));
    }),
    n = Math.min(1, 1920 / t.naturalWidth, 1080 / t.naturalHeight),
    a = document.createElement("canvas");
  return (
    (a.width = Math.max(1, Math.round(t.naturalWidth * n))),
    (a.height = Math.max(1, Math.round(t.naturalHeight * n))),
    a.getContext("2d").drawImage(t, 0, 0, a.width, a.height),
    a.toDataURL("image/jpeg", 0.86)
  );
}
(document.querySelector("#dashboard-wallpaper-file").addEventListener("change", async (e) => {
  const u = e.target.files?.[0];
  if (u) {
    try {
      const t = await imageFileToWallpaper(u),
        n = Number(document.querySelector("#dashboard-wallpaper-opacity").value) / 100;
      (localStorage.setItem(dashboardWallpaperKey(), JSON.stringify({ image: t, opacity: n })),
        applyDashboardWallpaper(),
        syncDashboardWallpaperControls());
    } catch (t) {
      document.querySelector("#dashboard-wallpaper-status").textContent = t.message;
    }
    e.target.value = "";
  }
}),
  document.querySelector("#dashboard-wallpaper-opacity").addEventListener("input", (e) => {
    const u = Number(e.target.value) / 100,
      t = readDashboardWallpaper();
    ((document.querySelector("#dashboard-wallpaper-opacity-value").textContent =
      `${e.target.value}%`),
      t.image &&
        localStorage.setItem(dashboardWallpaperKey(), JSON.stringify({ ...t, opacity: u })),
      applyDashboardWallpaper());
  }),
  document.querySelector("#dashboard-wallpaper-reset").addEventListener("click", () => {
    (localStorage.removeItem(dashboardWallpaperKey()),
      applyDashboardWallpaper(),
      syncDashboardWallpaperControls());
  }),
  document.querySelector("#employee-proxy-enabled").addEventListener("change", async (e) => {
    const u = e.currentTarget;
    u.disabled = !0;
    const t = await window.orangeApp.saveProxy({ enabled: u.checked });
    if (((u.disabled = !1), !t.ok)) {
      ((u.checked = !u.checked),
        (document.querySelector("#managed-proxy-status").textContent =
          t.message || "\u7FFB\u8BD1IP\u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25"));
      return;
    }
    ((u.checked = t.enabled === !0), renderManagedProxyState(t));
  }),
  document.querySelector("#save-membership-policy")?.addEventListener("click", async () => {
    const e = document.querySelector("#save-membership-policy"),
      u = document.querySelector("#membership-policy-message");
    e.disabled = !0;
    try {
      const t = Number(document.querySelector("#basic-grace-days").value || 30),
        n = await adminCall({ action: "save_membership_settings", basicGraceDays: t });
      u.textContent = `\u5DF2\u4FDD\u5B58\uFF1A\u9AD8\u7EA7\u4F1A\u5458\u5230\u671F\u540E\u81EA\u52A8\u83B7\u5F97 ${n.settings?.basicGraceDays || t} \u5929\u666E\u901A\u4F1A\u5458\u7F13\u51B2\u671F`;
    } catch (t) {
      ((u.textContent = t.message), u.classList.add("error"));
    } finally {
      e.disabled = !1;
    }
  }),
  document
    .querySelector("#settings-close")
    .addEventListener("click", () => document.querySelector("#settings-dialog").close()),
  document
    .querySelector("#release-notes-close")
    .addEventListener("click", () => document.querySelector("#release-notes-dialog").close()));
function renderUpdateState(e = {}) {
  ((document.querySelector("#current-version").textContent = e.currentVersion || "\u672A\u77E5"),
    (document.querySelector("#update-message").textContent =
      e.message ||
      "\u8F6F\u4EF6\u4F1A\u81EA\u52A8\u68C0\u67E5\u5E76\u5728\u540E\u53F0\u4E0B\u8F7D\u66F4\u65B0"),
    (document.querySelector("#update-progress-bar").style.width =
      `${Math.max(0, Math.min(100, Number(e.percent || 0)))}%`),
    document.querySelector("#download-update").classList.toggle("hidden", e.status !== "available"),
    document.querySelector("#install-update").classList.toggle("hidden", e.status !== "downloaded"),
    (document.querySelector("#check-update").disabled = ["checking", "downloading"].includes(
      e.status,
    )));
}
(document
  .querySelector("#check-update")
  .addEventListener("click", async () =>
    renderUpdateState(await window.orangeApp.checkForUpdates()),
  ),
  document
    .querySelector("#download-update")
    .addEventListener("click", async () =>
      renderUpdateState(await window.orangeApp.downloadUpdate()),
    ),
  document
    .querySelector("#install-update")
    .addEventListener("click", () => window.orangeApp.installUpdate()),
  window.orangeApp.onUpdateState(renderUpdateState),
  window.orangeApp.getUpdateState().then(renderUpdateState),
  document.querySelector("#password-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = document.querySelector("#new-self-password").value;
    if (u !== document.querySelector("#confirm-self-password").value)
      return alert("\u4E24\u6B21\u65B0\u5BC6\u7801\u4E0D\u4E00\u81F4");
    const t = await window.orangeApp.changePassword({
      oldPassword: document.querySelector("#old-password").value,
      newPassword: u,
    });
    ((document.querySelector("#settings-message").textContent = t.ok
      ? "\u5BC6\u7801\u4FEE\u6539\u6210\u529F"
      : t.message),
      t.ok && e.target.reset());
  }));
function renderManagedProxyState(e = {}) {
  const u = document.querySelector("#managed-proxy-status");
  u &&
    ((document.querySelector("#employee-proxy-enabled").checked = e.enabled === !0),
    (u.textContent =
      e.message ||
      (e?.active
        ? `\u5DF2\u5206\u914D\uFF1A${e.label || "\u7BA1\u7406\u5458\u7EBF\u8DEF"} \xB7 ${String(e.protocol || "").toUpperCase()} ${e.endpoint || ""}${e.switched ? "\uFF08\u5DF2\u81EA\u52A8\u5207\u6362\uFF09" : ""}`
        : "\u7FFB\u8BD1IP\u5DF2\u5173\u95ED\uFF0C\u5F53\u524D\u4F7F\u7528\u672C\u673A\u7F51\u7EDC")));
}
window.orangeApp.onManagedProxyState?.(renderManagedProxyState);
function renderPermissions(e = {}) {
  const u = document.querySelector("#permission-grid"),
    t = [
      { plan: "admin", label: "\u7BA1\u7406\u5458", locked: !0 },
      { plan: "advanced", label: "\u9AD8\u7EA7\u4F1A\u5458" },
      { plan: "basic", label: "\u666E\u901A\u4F1A\u5458" },
    ];
  ((permissionSnapshot = JSON.parse(JSON.stringify(e || { basic: {}, advanced: {} }))),
    pendingPermissionChanges.clear(),
    (document.querySelector("#save-permissions").disabled = !0),
    (document.querySelector("#discard-permissions").disabled = !0),
    (u.innerHTML = t
      .map(
        (n) =>
          `<section><h3>${n.label}</h3><p>${n.locked ? "\u56FA\u5B9A\u62E5\u6709\u5168\u90E8\u7BA1\u7406\u548C\u4E1A\u52A1\u529F\u80FD" : n.plan === "basic" ? "\u9ED8\u8BA4\u4EC5\u5F00\u653ETN\u8D26\u53F7/IP\u767B\u5F55\uFF1B\u7BA1\u7406\u5458\u53EF\u6309\u9700\u52FE\u9009\u5176\u4ED6\u529F\u80FD" : "\u52FE\u9009\u8BE5\u7B49\u7EA7\u5141\u8BB8\u4F7F\u7528\u7684\u529F\u80FD"}</p>${Object.entries(
            FEATURES,
          )
            .map(([a, o]) => {
              const r = n.locked || e?.[n.plan]?.[a] === !0;
              return `<label><input type="checkbox" data-permission-plan="${n.plan}" data-permission-code="${a}" ${r ? "checked" : ""} ${n.locked ? "disabled" : ""}/> ${o}</label>`;
            })
            .join("")}</section>`,
      )
      .join("")),
    u.querySelectorAll("[data-permission-code]:not(:disabled)").forEach((n) =>
      n.addEventListener("change", () => {
        const a = `${n.dataset.permissionPlan}:${n.dataset.permissionCode}`,
          o = permissionSnapshot?.[n.dataset.permissionPlan]?.[n.dataset.permissionCode] === !0;
        n.checked === o
          ? pendingPermissionChanges.delete(a)
          : pendingPermissionChanges.set(a, {
              plan: n.dataset.permissionPlan,
              featureCode: n.dataset.permissionCode,
              enabled: n.checked,
            });
        const r = pendingPermissionChanges.size > 0;
        ((document.querySelector("#save-permissions").disabled = !r),
          (document.querySelector("#discard-permissions").disabled = !r),
          (document.querySelector("#permission-save-message").textContent = r
            ? `\u6709 ${pendingPermissionChanges.size} \u9879\u4F1A\u5458\u6743\u9650\u5C1A\u672A\u4FDD\u5B58`
            : "\u6CA1\u6709\u5F85\u4FDD\u5B58\u7684\u4F1A\u5458\u6743\u9650\u4FEE\u6539"));
      }),
    ));
}
function applyFeatureFlags(e = {}) {
  activeFeatureFlags = { ...e };
  const u = (s) => activeFeatureFlags[s] !== !1,
    t = (s) => activeProfile?.role === "admin" || activePermissions[s] === !0,
    n = u("module_tn") && u("tn_accounts") && t("tn_accounts"),
    a = n && t("tn_assistant");
  (document.querySelector('[data-admin-nav="textnow"]')?.classList.toggle("hidden", !n),
    document.querySelector('[data-admin-page="textnow"]')?.classList.toggle("hidden", !n),
    document
      .querySelector('[data-admin-nav="tn-send"]')
      ?.classList.toggle("hidden", !a || !u("tn_sender") || !t("tn_sender")),
    document
      .querySelector('[data-admin-page="tn-send"]')
      ?.classList.toggle("hidden", !a || !u("tn_sender") || !t("tn_sender")),
    document
      .querySelector('[data-admin-nav="messages"]')
      ?.classList.toggle("hidden", !u("module_messaging")),
    document
      .querySelector('[data-admin-page="messages"]')
      ?.classList.toggle("hidden", !u("module_messaging")));
  const o = document.querySelector("#tn-send-dom-test");
  o && (o.disabled = !a || !u("tn_dom_test") || !t("tn_dom_test"));
  const r = document.querySelector("#tn-send-live-test");
  r && (r.disabled = !a || !u("tn_live_test") || !t("tn_live_test"));
}
async function loadFeatureFlags() {
  const e = document.querySelector("#feature-flag-grid");
  if (!(!e || activeProfile?.role !== "admin"))
    try {
      const u = await adminCall({ action: "list_feature_flags" }),
        t = Array.isArray(u.flags) ? u.flags : [];
      ((featureFlagRows = t.map((a) => ({ ...a }))),
        pendingFeatureFlagChanges.clear(),
        (document.querySelector("#save-feature-flags").disabled = !0),
        (document.querySelector("#discard-feature-flags").disabled = !0));
      const n = t.filter((a) => !a.parent_key);
      ((e.innerHTML = n
        .map((a) => {
          const o = t.filter((s) => s.parent_key === a.feature_key),
            r = (s) =>
              `<label title="${esc(s.reason || "")}"><input type="checkbox" data-feature-flag="${esc(s.feature_key)}" ${s.enabled ? "checked" : ""}/> ${esc(s.label)}${s.fail_closed ? "\uFF08\u6545\u969C\u65F6\u81EA\u52A8\u5173\u95ED\uFF09" : ""}</label>`;
          return `<section><h3>${esc(a.label)}</h3><p>${r(a)}</p>${o.map(r).join("")}</section>`;
        })
        .join("")),
        e.querySelectorAll("[data-feature-flag]").forEach((a) =>
          a.addEventListener("change", () => {
            const o =
              featureFlagRows.find((s) => s.feature_key === a.dataset.featureFlag)?.enabled === !0;
            a.checked === o
              ? pendingFeatureFlagChanges.delete(a.dataset.featureFlag)
              : pendingFeatureFlagChanges.set(a.dataset.featureFlag, a.checked);
            const r = pendingFeatureFlagChanges.size > 0;
            ((document.querySelector("#save-feature-flags").disabled = !r),
              (document.querySelector("#discard-feature-flags").disabled = !r),
              (document.querySelector("#feature-flag-message").textContent = r
                ? `\u6709 ${pendingFeatureFlagChanges.size} \u9879\u4FEE\u6539\u5C1A\u672A\u4FDD\u5B58`
                : "\u6CA1\u6709\u5F85\u4FDD\u5B58\u7684\u4FEE\u6539"));
          }),
        ));
    } catch (u) {
      document.querySelector("#feature-flag-message").textContent =
        `\u5F00\u5173\u8BFB\u53D6\u5931\u8D25\uFF1A${u.message}`;
    }
}
async function loadPermissions() {
  try {
    const e = await adminCall({ action: "list_permissions" });
    renderPermissions(e.permissions || {});
  } catch (e) {
    showAdminMessage(
      `\u6743\u9650\u8BFB\u53D6\u5931\u8D25\uFF1A${e.message}\u3002\u8BF7\u90E8\u7F72\u65B0\u7248 admin-users \u5E76\u8FD0\u884C\u5347\u7EA7SQL\u3002`,
      !0,
    );
  }
}
(document.querySelector("#refresh-permissions").addEventListener("click", () => {
  (pendingPermissionChanges.size &&
    !confirm(
      "\u5F53\u524D\u6709\u672A\u4FDD\u5B58\u7684\u4F1A\u5458\u6743\u9650\u4FEE\u6539\uFF0C\u786E\u5B9A\u653E\u5F03\u5E76\u91CD\u65B0\u8BFB\u53D6\u5417\uFF1F",
    )) ||
    loadPermissions();
}),
  document.querySelector("#discard-permissions")?.addEventListener("click", () => {
    (!pendingPermissionChanges.size ||
      confirm(
        "\u786E\u5B9A\u653E\u5F03\u6240\u6709\u672A\u4FDD\u5B58\u7684\u4F1A\u5458\u6743\u9650\u4FEE\u6539\u5417\uFF1F",
      )) &&
      loadPermissions();
  }),
  document.querySelector("#save-permissions")?.addEventListener("click", async (e) => {
    const u = document.querySelector("#permission-save-message");
    if (!pendingPermissionChanges.size) {
      u.textContent =
        "\u6CA1\u6709\u9700\u8981\u4FDD\u5B58\u7684\u4F1A\u5458\u6743\u9650\u4FEE\u6539";
      return;
    }
    ((e.currentTarget.disabled = !0),
      (document.querySelector("#discard-permissions").disabled = !0));
    try {
      const t = [...pendingPermissionChanges.values()];
      for (const a of t)
        if ((await adminCall({ action: "save_permission", ...a }))?.saved?.enabled !== a.enabled)
          throw new Error(
            `${FEATURES[a.featureCode] || a.featureCode}\u4FDD\u5B58\u56DE\u8BFB\u4E0D\u4E00\u81F4`,
          );
      const n = await adminCall({ action: "list_permissions" }),
        o = t.find((a) => n?.permissions?.[a.plan]?.[a.featureCode] !== a.enabled);
      if (o)
        throw new Error(
          `${o.plan} \xB7 ${FEATURES[o.featureCode] || o.featureCode}\u6570\u636E\u5E93\u590D\u6838\u4E0D\u4E00\u81F4`,
        );
      ((u.textContent = "\u4F1A\u5458\u6743\u9650\u5DF2\u5168\u90E8\u4FDD\u5B58\u3002"),
        renderPermissions(n.permissions || {}));
    } catch (t) {
      ((u.textContent = `\u4FDD\u5B58\u5931\u8D25\uFF1A${t.message}\u3002\u8BF7\u5237\u65B0\u540E\u786E\u8BA4\u5DF2\u4FDD\u5B58\u9879\u76EE\u3002`),
        (e.currentTarget.disabled = !1),
        (document.querySelector("#discard-permissions").disabled = !1));
    }
  }),
  window.orangeApp.onPermissionsChanged?.((e) => {
    activePermissions = e || {};
    const u = activeProfile?.role === "admin" || activePermissions.personal_groq_key === !0;
    (document.querySelector(".ai-key-panel")?.classList.toggle("hidden", !u),
      document.querySelector("#ai-nav-button")?.classList.toggle("hidden", !u),
      applyFeatureFlags(activeFeatureFlags));
  }),
  document.querySelector("#refresh-feature-flags")?.addEventListener("click", () => {
    (pendingFeatureFlagChanges.size &&
      !confirm(
        "\u5F53\u524D\u6709\u672A\u4FDD\u5B58\u7684\u5F00\u5173\u4FEE\u6539\uFF0C\u786E\u5B9A\u653E\u5F03\u5E76\u91CD\u65B0\u8BFB\u53D6\u5417\uFF1F",
      )) ||
      loadFeatureFlags();
  }),
  document.querySelector("#discard-feature-flags")?.addEventListener("click", () => {
    (!pendingFeatureFlagChanges.size ||
      confirm(
        "\u786E\u5B9A\u653E\u5F03\u6240\u6709\u672A\u4FDD\u5B58\u7684\u5F00\u5173\u4FEE\u6539\u5417\uFF1F",
      )) &&
      loadFeatureFlags();
  }),
  document.querySelector("#save-feature-flags")?.addEventListener("click", async (e) => {
    const u =
        document.querySelector("#feature-flag-reason").value.trim() ||
        "\u7BA1\u7406\u5458\u624B\u52A8\u4FEE\u6539\u529F\u80FD\u5F00\u5173",
      t = document.querySelector("#feature-flag-message");
    if (!pendingFeatureFlagChanges.size) {
      t.textContent = "\u6CA1\u6709\u9700\u8981\u4FDD\u5B58\u7684\u4FEE\u6539";
      return;
    }
    ((e.currentTarget.disabled = !0),
      (document.querySelector("#discard-feature-flags").disabled = !0));
    try {
      for (const [o, a] of pendingFeatureFlagChanges)
        await adminCall({ action: "save_feature_flag", featureKey: o, enabled: a, reason: u });
      ((document.querySelector("#feature-flag-reason").value = ""),
        (t.textContent =
          "\u5168\u90E8\u5F00\u5173\u5DF2\u4FDD\u5B58\uFF0C\u5BA2\u6237\u7AEF\u5C06\u572815\u79D2\u5185\u540C\u6B65\u3002"),
        await loadFeatureFlags());
      const n = await window.orangeApp.getFeatureFlags();
      applyFeatureFlags(n.flags || {});
    } catch (n) {
      ((t.textContent = `\u4FDD\u5B58\u5931\u8D25\uFF1A${n.message}\u3002\u5DF2\u4FDD\u5B58\u7684\u9879\u76EE\u4FDD\u7559\uFF0C\u8BF7\u5237\u65B0\u540E\u786E\u8BA4\u3002`),
        (e.currentTarget.disabled = !1),
        (document.querySelector("#discard-feature-flags").disabled = !1));
    }
  }),
  window.orangeApp.onFeatureFlagsChanged?.(applyFeatureFlags),
  window.orangeApp.getRememberedLogin().then((e) => {
    ((document.querySelector("#username").value = e.username || ""),
      (document.querySelector("#password").value = e.password || ""),
      (document.querySelector("#remember-username").checked = e.rememberUsername),
      (document.querySelector("#remember-password").checked = e.rememberPassword));
  }),
  window.orangeApp
    .status()
    .then((e) => {
      e?.authenticated &&
        e.profile &&
        (renderHome(e.profile, e.sites || [], e.permissions || {}),
        applyFeatureFlags(e.featureFlags || {}));
    })
    .catch((e) => console.error("Unable to restore login after reload", e)));
const TN_SEND_STORAGE_PREFIX = "orange:tn-send-tasks:v2:",
  TN_SEND_LAST_AT_PREFIX = "orange:tn-send-last-at:v2:";
let tnSendAccounts = [],
  tnSendRunnerTimer = 0,
  tnSendRunnerBusy = !1;
function tnSendOwnerId() {
  return String(activeProfile?.id || "signed-out");
}
function tnSendStorageKey() {
  return `${TN_SEND_STORAGE_PREFIX}${tnSendOwnerId()}`;
}
function tnSendLastAtKey() {
  return `${TN_SEND_LAST_AT_PREFIX}${tnSendOwnerId()}`;
}
function tnSendLines(e) {
  return document
    .querySelector(e)
    .value.split(/\r?\n/)
    .map((u) => u.trim())
    .filter(Boolean);
}
function tnSendNormalizeNumber(e) {
  return (String(e).trim().startsWith("+") ? "+" : "") + String(e).replace(/\D/g, "");
}
function tnSendMaskNumber(e) {
  const u = tnSendNormalizeNumber(e);
  return u.length > 4
    ? `${u.slice(0, 2)}\u2022\u2022\u2022\u2022${u.slice(-4)}`
    : "\u2022\u2022\u2022\u2022";
}
function tnSendReadTasks() {
  try {
    const e = JSON.parse(localStorage.getItem(tnSendStorageKey()) || "[]");
    return Array.isArray(e)
      ? e
          .filter(
            (u) =>
              u && Array.isArray(u.assignments) && (!u.ownerId || u.ownerId === tnSendOwnerId()),
          )
          .slice(0, 50)
          .map((u) => {
            const t = u.assignments.some((a) => a?.status === "sending"),
              n = u.assignments.map((a) =>
                a?.status === "sending"
                  ? {
                      ...a,
                      status: "uncertain",
                      resultReason: "interrupted_before_confirmation",
                    }
                  : a,
              );
            return t && !["completed", "stopped"].includes(u.status)
              ? { ...u, status: "paused_uncertain", assignments: n }
              : { ...u, assignments: n };
          })
      : [];
  } catch {
    return [];
  }
}
function tnSendWriteTasks(e) {
  localStorage.setItem(tnSendStorageKey(), JSON.stringify(e.slice(0, 50)));
}
function tnSendReadLastAt() {
  try {
    const e = JSON.parse(localStorage.getItem(tnSendLastAtKey()) || "{}");
    return e && typeof e == "object" ? e : {};
  } catch {
    return {};
  }
}
function tnSendWriteLastAt(e) {
  localStorage.setItem(tnSendLastAtKey(), JSON.stringify(e || {}));
}
function tnSendSelectedAccounts() {
  const e = document.querySelector("#tn-send-scope").value;
  return e === "single"
    ? tnSendAccounts.filter((u) => u.id === document.querySelector("#tn-send-account").value)
    : e === "count"
      ? tnSendAccounts.slice(
          0,
          Math.max(1, Number(document.querySelector("#tn-send-count").value) || 1),
        )
      : tnSendAccounts.slice();
}
function tnSendAssignments() {
  const e = [
      ...new Set(
        tnSendLines("#tn-send-numbers")
          .map(tnSendNormalizeNumber)
          .filter((a) => /^\+?\d{7,15}$/.test(a)),
      ),
    ],
    u = tnSendLines("#tn-send-scripts"),
    t = tnSendSelectedAccounts(),
    n = Math.max(
      15,
      Math.min(300, Number(document.querySelector("#tn-send-interval").value) || 30),
    );
  return e.map((a, o) => ({
    id: crypto.randomUUID(),
    number: a,
    script: u[o % Math.max(1, u.length)] || "",
    accountId: t[o % Math.max(1, t.length)]?.id || "",
    accountName: t[o % Math.max(1, t.length)]?.name || `TN${o + 1}`,
    intervalSeconds: n,
    status: "queued",
    attempts: 0,
  }));
}
function renderTnSendPreview() {
  const e = document.querySelector("#tn-send-preview-body"),
    u = tnSendAssignments();
  return (
    (e.innerHTML = u.length
      ? u
          .map(
            (t) =>
              `<tr><td>${esc(t.accountName)}</td><td>${esc(tnSendMaskNumber(t.number))}</td><td>${esc(t.script)}</td><td>${t.intervalSeconds}\u79D2 / TN</td></tr>`,
          )
          .join("")
      : '<tr><td colspan="4">\u8BF7\u8F93\u5165\u6709\u6548\u53F7\u7801\u3001\u8BDD\u672F\uFF0C\u5E76\u786E\u4FDD\u5DF2\u6709TN\u8D26\u53F7</td></tr>'),
    u
  );
}
function tnSendTaskStatusLabel(e) {
  return (
    {
      queued: "\u7B49\u5F85\u53D1\u9001",
      scheduled: "\u7B49\u5F85\u5B9A\u65F6",
      running: "\u53D1\u9001\u4E2D",
      completed: "\u5DF2\u5B8C\u6210",
      stopped: "\u5DF2\u505C\u6B62",
      paused_uncertain: "\u5DF2\u6682\u505C\xB7\u7ED3\u679C\u4E0D\u660E\u786E",
      paused_error: "\u5DF2\u6682\u505C\xB7\u9700\u68C0\u67E5",
    }[e.status] || String(e.status || "\u7B49\u5F85\u53D1\u9001")
  );
}
function renderTnSendTasks() {
  const e = tnSendReadTasks();
  ((document.querySelector("#tn-send-task-body").innerHTML = e.length
    ? e
        .map((u) => {
          const t = u.assignments.filter((n) => n.status === "sent").length;
          return `<tr><td>${esc(new Date(u.createdAt).toLocaleString())}</td><td>${esc(tnSendTaskStatusLabel(u))}</td><td>${t}/${u.assignments.length}</td><td>${esc(new Date(u.scheduledAt).toLocaleString())}</td><td><button class="secondary" data-tn-send-cancel="${u.id}" type="button" ${["completed", "stopped"].includes(u.status) ? "disabled" : ""}>\u505C\u6B62</button></td></tr>`;
        })
        .join("")
    : '<tr><td colspan="5">\u6682\u65E0\u672C\u673A\u4EFB\u52A1</td></tr>'),
    document.querySelectorAll("[data-tn-send-cancel]").forEach((u) =>
      u.addEventListener("click", () => {
        const t = tnSendReadTasks().map((n) =>
          n.id === u.dataset.tnSendCancel
            ? { ...n, status: "stopped", stoppedAt: new Date().toISOString() }
            : n,
        );
        (tnSendWriteTasks(t), renderTnSendTasks());
      }),
    ));
}
function scheduleTnSendRunner(e = 1e3) {
  (clearTimeout(tnSendRunnerTimer),
    (tnSendRunnerTimer = setTimeout(
      () => {
        runNextTnSendAssignment();
      },
      Math.max(250, e),
    )));
}
async function runNextTnSendAssignment() {
  if (tnSendRunnerBusy || !activeProfile?.id) {
    scheduleTnSendRunner(1500);
    return;
  }
  tnSendRunnerBusy = !0;
  let e = 1500;
  try {
    const u = tnSendReadTasks(),
      t = Date.now(),
      n = tnSendReadLastAt();
    let a = null,
      o = null;
    for (const i of u) {
      if (["completed", "stopped", "paused_uncertain", "paused_error"].includes(i.status)) continue;
      const d = new Date(i.scheduledAt).getTime();
      if (!Number.isFinite(d) || d > t) {
        e = Math.min(e, Math.max(500, d - t || 1500));
        continue;
      }
      for (const l of i.assignments) {
        if (l.status !== "queued") continue;
        const F = Math.max(15e3, Math.min(3e5, Number(l.intervalSeconds || 30) * 1e3)),
          m = Math.max(0, Number(n[l.accountId] || 0) + F - t);
        if (m > 0) {
          e = Math.min(e, Math.max(500, m));
          continue;
        }
        ((a = i), (o = l));
        break;
      }
      if (o) break;
      i.assignments.every((l) => l.status !== "queued") && (i.status = "completed");
    }
    if (!a || !o) {
      (tnSendWriteTasks(u), renderTnSendTasks());
      return;
    }
    ((a.status = "running"),
      (o.status = "sending"),
      (o.attempts = Number(o.attempts || 0) + 1),
      (o.startedAt = new Date().toISOString()),
      tnSendWriteTasks(u),
      renderTnSendTasks());
    const r = await window.orangeApp.sendTnMessage({
        accountId: o.accountId,
        phone: o.number,
        message: o.script,
      }),
      s = new Date().toISOString();
    ((o.finishedAt = s),
      (o.resultReason = String(r?.reason || r?.code || "")),
      (o.resultMessage = String(r?.message || "").slice(0, 300)),
      r?.status === "sent"
        ? ((o.status = "sent"),
          (o.fingerprint = r.fingerprint || ""),
          (n[o.accountId] = Date.now()),
          tnSendWriteLastAt(n),
          (a.status = a.assignments.some((i) => i.status === "queued") ? "queued" : "completed"))
        : r?.reason === "duplicate_recipient"
          ? ((o.status = "duplicate"),
            (a.status = a.assignments.some((i) => i.status === "queued") ? "queued" : "completed"))
          : r?.status === "uncertain"
            ? ((o.status = "uncertain"), (a.status = "paused_uncertain"))
            : ((o.status = "blocked"), (a.status = "paused_error")),
      tnSendWriteTasks(u),
      renderTnSendTasks());
    const c = document.querySelector("#tn-send-message");
    a.status === "completed"
      ? ((c.dataset.kind = "ok"),
        (c.textContent =
          "TN\u53D1\u9001\u4EFB\u52A1\u5DF2\u5B8C\u6210\uFF1B\u5DF2\u786E\u8BA4\u53D1\u9001\u7684\u53F7\u7801\u5DF2\u5199\u5165\u4E3B\u8FDB\u7A0B\u9632\u91CD\u590D\u8BB0\u5F55\u3002"))
      : a.status === "paused_uncertain"
        ? ((c.dataset.kind = "error"),
          (c.textContent =
            "\u53D1\u9001\u7ED3\u679C\u4E0D\u660E\u786E\uFF0C\u4EFB\u52A1\u5DF2\u81EA\u52A8\u6682\u505C\u4E14\u4E0D\u4F1A\u91CD\u8BD5\u3002\u8BF7\u4EBA\u5DE5\u68C0\u67E5TextNow\u540E\u91CD\u65B0\u521B\u5EFA\u5269\u4F59\u4EFB\u52A1\u3002"))
        : a.status === "paused_error" &&
          ((c.dataset.kind = "error"),
          (c.textContent = `\u4EFB\u52A1\u56E0 ${o.resultMessage || o.resultReason || "\u9875\u9762\u6821\u9A8C\u5931\u8D25"} \u81EA\u52A8\u6682\u505C\u3002`));
  } catch (u) {
    const t = document.querySelector("#tn-send-message");
    (t &&
      ((t.dataset.kind = "error"),
      (t.textContent =
        u.message ||
        "TN\u4EFB\u52A1\u6267\u884C\u5931\u8D25\uFF0C\u5DF2\u505C\u6B62\u672C\u8F6E\u53D1\u9001\u3002")),
      (e = 2500));
  } finally {
    ((tnSendRunnerBusy = !1), scheduleTnSendRunner(e));
  }
}
async function loadTnSendAccounts() {
  const e = await window.orangeApp.listTnAccounts();
  ((tnSendAccounts = e?.ok ? e.accounts || [] : Array.isArray(e) ? e : []),
    (document.querySelector("#tn-send-account").innerHTML = tnSendAccounts
      .map((u, t) => `<option value="${esc(u.id)}">${esc(u.name || `TN${t + 1}`)}</option>`)
      .join("")),
    renderTnSendPreview());
}
(document.querySelector("#tn-send-scope")?.addEventListener("change", (e) => {
  (document
    .querySelector("#tn-send-count-row")
    .classList.toggle("hidden", e.target.value !== "count"),
    document
      .querySelector("#tn-send-account-row")
      .classList.toggle("hidden", e.target.value !== "single"),
    renderTnSendPreview());
}),
  document
    .querySelector("#tn-send-timing")
    ?.addEventListener("change", (e) =>
      document
        .querySelector("#tn-send-scheduled-row")
        .classList.toggle("hidden", e.target.value !== "scheduled"),
    ),
  document.querySelector("#tn-send-preview-button")?.addEventListener("click", renderTnSendPreview),
  document.querySelector("#tn-send-dom-test")?.addEventListener("click", async (e) => {
    const u = e.currentTarget,
      t = document.querySelector("#tn-send-message"),
      n = tnSendSelectedAccounts();
    if (!n.length) {
      ((t.dataset.kind = "error"),
        (t.textContent = "\u6CA1\u6709\u53EF\u6D4B\u8BD5\u7684TN\u8D26\u53F7\u3002"));
      return;
    }
    ((u.disabled = !0),
      (t.dataset.kind = ""),
      (t.textContent = `\u6B63\u5728\u68C0\u67E5 ${n.length} \u4E2ATN\u9875\u9762\uFF0C\u53EA\u8BFB\u53D6DOM\uFF0C\u4E0D\u4F1A\u586B\u5199\u6216\u53D1\u9001\u2026`));
    try {
      const o = await window.orangeApp.testTnDom({ accountIds: n.map((s) => s.id) }),
        a = (o.results || []).filter((s) => s.ok && s.ready).length,
        r = (o.results || [])
          .map((s) =>
            s.ok
              ? `${s.accountName}\uFF1A${s.ready ? "\u6838\u5FC3\u5B9A\u4F4D\u901A\u8FC7" : "\u9875\u9762\u7ED3\u6784\u4E0D\u5B8C\u6574"}${s.newConversationOpen ? "\uFF0C\u65B0\u77ED\u4FE1\u6846\u5DF2\u6253\u5F00" : ""}`
              : `${s.accountName}\uFF1A${s.message || "\u5B9A\u4F4D\u5931\u8D25"}`,
          )
          .join("\uFF1B");
      ((t.dataset.kind = a === n.length ? "ok" : "error"),
        (t.textContent = `\u5B9A\u4F4D\u901A\u8FC7 ${a}/${n.length}\u3002${r}`));
    } catch (o) {
      ((t.dataset.kind = "error"),
        (t.textContent = o.message || "TN\u5B9A\u4F4D\u6D4B\u8BD5\u5931\u8D25"));
    } finally {
      u.disabled = !1;
    }
  }),
  document.querySelector("#tn-send-live-test")?.addEventListener("click", async (e) => {
    const u = e.currentTarget,
      t = document.querySelector("#tn-send-message"),
      n = renderTnSendPreview()[0];
    if (!n?.accountId || !n.number || !n.script) {
      ((t.dataset.kind = "error"),
        (t.textContent =
          "\u8BF7\u5148\u51C6\u5907\u81F3\u5C11\u4E00\u7EC4TN\u3001\u53F7\u7801\u548C\u8BDD\u672F\u3002"));
      return;
    }
    if (
      confirm(
        `\u5C06\u7531 ${n.accountName} \u5411 ${tnSendMaskNumber(n.number)} \u5B9E\u9645\u53D1\u9001\u7B2C\u4E00\u6761\u6D4B\u8BD5\u6D88\u606F\u3002\u786E\u8BA4\u7EE7\u7EED\uFF1F`,
      )
    ) {
      ((u.disabled = !0),
        (t.dataset.kind = ""),
        (t.textContent =
          "\u6B63\u5728\u6D4B\u8BD5\u5B9E\u53D1\uFF1B\u53D1\u9001\u7ED3\u679C\u4E0D\u660E\u786E\u65F6\u4E0D\u4F1A\u91CD\u8BD5\u2026"));
      try {
        const o = await window.orangeApp.testTnSend({
          accountId: n.accountId,
          phone: n.number,
          message: n.script,
        });
        if (o.status === "sent") {
          const a = tnSendLines("#tn-send-numbers").filter(
            (r) => tnSendNormalizeNumber(r) !== tnSendNormalizeNumber(n.number),
          );
          ((document.querySelector("#tn-send-numbers").value = a.join(`
`)),
            renderTnSendPreview(),
            (t.dataset.kind = "ok"),
            (t.textContent = `${n.accountName} \u6D4B\u8BD5\u53D1\u9001\u5DF2\u786E\u8BA4\uFF1B\u8BE5\u53F7\u7801\u5DF2\u4ECE\u6D3B\u52A8\u5217\u8868\u5220\u9664\u3002`));
        } else if (o.status === "uncertain")
          ((t.dataset.kind = "error"),
            (t.textContent =
              "\u9875\u9762\u5DF2\u70B9\u51FB\u53D1\u9001\uFF0C\u4F4615\u79D2\u5185\u672A\u786E\u8BA4\u65B0\u589E\u53D1\u51FA\u6D88\u606F\uFF1B\u53F7\u7801\u4FDD\u7559\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u91CD\u8BD5\u3002"));
        else {
          const a = {
            duplicate_recipient:
              "\u8BE5\u53F7\u7801\u6B64\u524D\u5DF2\u7ECF\u786E\u8BA4\u53D1\u9001\u8FC7\uFF0C\u5DF2\u963B\u6B62\u91CD\u590D\u53D1\u9001",
            recipient_input_missing: "\u672A\u627E\u5230\u6536\u4EF6\u4EBA\u8F93\u5165\u6846",
            recipient_not_confirmed: "TextNow\u672A\u786E\u8BA4\u6536\u4EF6\u4EBA",
            recipient_mismatch: "\u6536\u4EF6\u4EBA\u6838\u5BF9\u4E0D\u4E00\u81F4",
            message_input_missing: "\u672A\u627E\u5230\u8BDD\u672F\u8F93\u5165\u6846",
            send_button_unavailable: "\u53D1\u9001\u6309\u94AE\u4E0D\u53EF\u7528",
          };
          ((t.dataset.kind = "error"),
            (t.textContent =
              o.message || a[o.reason] || "\u6D4B\u8BD5\u53D1\u9001\u5DF2\u963B\u6B62\u3002"));
        }
      } catch (o) {
        ((t.dataset.kind = "error"),
          (t.textContent = o.message || "\u6D4B\u8BD5\u53D1\u9001\u5931\u8D25"));
      } finally {
        u.disabled = !1;
      }
    }
  }),
  document.querySelector("#tn-send-create")?.addEventListener("click", () => {
    const e = document.querySelector("#tn-send-message"),
      u = renderTnSendPreview();
    if (!tnSendAccounts.length || !u.length || u.some((s) => !s.script || !s.accountId)) {
      ((e.dataset.kind = "error"),
        (e.textContent =
          "\u9700\u8981\u81F3\u5C11\u4E00\u4E2ATN\u8D26\u53F7\u3001\u4E00\u4E2A\u6709\u6548\u53F7\u7801\u548C\u4E00\u6761\u8BDD\u672F\u3002"));
      return;
    }
    const t = document.querySelector("#tn-send-timing").value,
      n = document.querySelector("#tn-send-scheduled-at").value;
    if (t === "scheduled" && (!n || Number.isNaN(new Date(n).getTime()))) {
      ((e.dataset.kind = "error"),
        (e.textContent = "\u8BF7\u9009\u62E9\u6709\u6548\u7684\u5B9A\u65F6\u65F6\u95F4\u3002"));
      return;
    }
    const o = t === "scheduled" ? new Date(n).toISOString() : new Date().toISOString();
    if (new Date(o).getTime() < Date.now() - 5e3) {
      ((e.dataset.kind = "error"),
        (e.textContent =
          "\u5B9A\u65F6\u65F6\u95F4\u4E0D\u80FD\u65E9\u4E8E\u5F53\u524D\u65F6\u95F4\u3002"));
      return;
    }
    const a =
      t === "scheduled"
        ? `\u5C06\u5728 ${new Date(o).toLocaleString()} \u5F00\u59CB\u5B9E\u9645\u53D1\u9001`
        : "\u5C06\u7ACB\u5373\u5F00\u59CB\u5B9E\u9645\u53D1\u9001";
    if (
      !confirm(
        `${a}\uFF0C\u5171 ${u.length} \u6761\uFF1B\u6BCF\u6761\u53D1\u9001\u524D\u90FD\u4F1A\u518D\u6B21\u6821\u9A8C\u6743\u9650\u3001\u6536\u4EF6\u4EBA\u548C\u9632\u91CD\u590D\u8BB0\u5F55\u3002\u786E\u8BA4\u521B\u5EFA\u4EFB\u52A1\uFF1F`,
      )
    )
      return;
    const r = tnSendReadTasks();
    (r.unshift({
      id: crypto.randomUUID(),
      ownerId: tnSendOwnerId(),
      createdAt: new Date().toISOString(),
      scheduledAt: o,
      status: t === "scheduled" ? "scheduled" : "queued",
      assignments: u,
    }),
      tnSendWriteTasks(r),
      renderTnSendTasks(),
      scheduleTnSendRunner(250),
      (e.dataset.kind = "ok"),
      (e.textContent =
        t === "scheduled"
          ? "\u5B9A\u65F6\u4EFB\u52A1\u5DF2\u4FDD\u5B58\uFF1B\u8F6F\u4EF6\u4FDD\u6301\u767B\u5F55\u8FD0\u884C\u65F6\u4F1A\u6309\u8BBE\u5B9A\u65F6\u95F4\u5F00\u59CB\u3002"
          : "\u4EFB\u52A1\u5DF2\u5F00\u59CB\uFF1B\u53D1\u9001\u95F4\u9694\u6309\u6BCF\u4E2ATN\u8D26\u53F7\u5206\u522B\u8BA1\u7B97\u3002"));
  }),
  document.querySelector("#tn-send-stop")?.addEventListener("click", () => {
    (tnSendWriteTasks(
      tnSendReadTasks().map((u) =>
        ["completed", "stopped"].includes(u.status)
          ? u
          : { ...u, status: "stopped", stoppedAt: new Date().toISOString() },
      ),
    ),
      renderTnSendTasks());
    const e = document.querySelector("#tn-send-message");
    ((e.dataset.kind = "error"),
      (e.textContent =
        "\u6240\u6709\u5F53\u524D\u5458\u5DE5\u7684\u672C\u673ATN\u4EFB\u52A1\u5DF2\u505C\u6B62\u3002"));
  }),
  loadTnSendAccounts().catch(() => {}),
  renderTnSendTasks(),
  scheduleTnSendRunner(1e3));
