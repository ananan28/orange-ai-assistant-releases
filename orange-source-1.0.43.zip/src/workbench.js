const tabsNode = document.querySelector("#tabs"),
  viewsNode = document.querySelector("#views"),
  empty = document.querySelector("#empty"),
  statusNode = document.querySelector("#status"),
  tabs = new Map();
let activeId = "",
  serial = 0,
  restoring = !0,
  saveTimer = null;
const pendingOpens = [],
  selectedTabIds = new Set();
let contextTabId = "";
function askFixedProxy(e) {
  return new Promise((n) => {
    const t = document.createElement("dialog");
    t.style.cssText =
      "border:0;border-radius:16px;padding:22px;width:min(520px,calc(100vw - 48px));box-shadow:0 24px 70px #2d160955;background:#fffaf6;color:#382114";
    const o = document.createElement("strong");
    ((o.textContent = "\u8D26\u53F7\u56FA\u5B9A IP"),
      (o.style.cssText = "display:block;font-size:20px;margin-bottom:10px"));
    const s = document.createElement("p");
    ((s.textContent = e), (s.style.cssText = "white-space:pre-line;line-height:1.6;color:#765643"));
    const u = document.createElement("input");
    ((u.placeholder = "host:port \u6216 host:port:user:pass\uFF08\u53EF\u7559\u7A7A\uFF09"),
      (u.autocomplete = "off"),
      (u.style.cssText =
        "box-sizing:border-box;width:100%;height:44px;border:1px solid #e5b995;border-radius:10px;padding:0 12px;margin:8px 0 18px"));
    const a = document.createElement("div");
    a.style.cssText = "display:flex;justify-content:flex-end;gap:10px";
    const c = document.createElement("button");
    ((c.type = "button"), (c.textContent = "\u53D6\u6D88"));
    const i = document.createElement("button");
    ((i.type = "button"), (i.textContent = "\u786E\u5B9A"));
    const r = (d) => {
      (t.close(), t.remove(), n(d));
    };
    ((c.onclick = () => r(null)),
      (i.onclick = () => r(u.value.trim())),
      t.addEventListener(
        "cancel",
        (d) => {
          (d.preventDefault(), r(null));
        },
        { once: !0 },
      ),
      u.addEventListener("keydown", (d) => {
        d.key === "Enter" && i.click();
      }),
      a.append(c, i),
      t.append(o, s, u, a),
      document.body.append(t),
      t.showModal(),
      u.focus());
  });
}
function askTabName(e) {
  return new Promise((n) => {
    const t = document.createElement("dialog");
    t.style.cssText =
      "border:0;border-radius:16px;padding:22px;width:min(480px,calc(100vw - 48px));box-shadow:0 24px 70px #2d160955;background:#fffaf6;color:#382114";
    const o = document.createElement("strong");
    ((o.textContent = "\u4FEE\u6539\u672C\u673A\u540D\u79F0"),
      (o.style.cssText = "display:block;font-size:20px;margin-bottom:8px"));
    const c = document.createElement("p");
    ((c.textContent =
      "\u8FD9\u4E2A\u540D\u79F0\u53EA\u4FDD\u5B58\u5728\u5F53\u524D\u7535\u8111\uFF0C\u5E76\u4F1A\u7ACB\u5373\u663E\u793A\u5728\u6807\u7B7E\u548C\u6807\u7B7E\u4E2D\u5FC3\u3002"),
      (c.style.cssText = "margin:0 0 12px;line-height:1.6;color:#765643"));
    const i = document.createElement("input");
    ((i.type = "text"),
      (i.value = String(e || "")),
      (i.maxLength = 120),
      (i.placeholder = "\u8BF7\u8F93\u5165\u65B0\u7684\u6807\u7B7E\u540D\u79F0"),
      (i.autocomplete = "off"),
      (i.style.cssText =
        "box-sizing:border-box;width:100%;height:44px;border:1px solid #e5b995;border-radius:10px;padding:0 12px;margin:0 0 18px;font-size:15px"));
    const a = document.createElement("div");
    a.style.cssText = "display:flex;justify-content:flex-end;gap:10px";
    const s = document.createElement("button");
    ((s.type = "button"), (s.textContent = "\u53D6\u6D88"));
    const r = document.createElement("button");
    ((r.type = "button"),
      (r.textContent = "\u4FDD\u5B58"),
      (r.style.cssText = "background:#ff7318;color:#fff;border-color:#ff7318"));
    const u = (d) => {
      (t.open && t.close(), t.remove(), n(d));
    };
    ((s.onclick = () => u(null)),
      (r.onclick = () => {
        const d = i.value.trim();
        if (!d) {
          (i.setCustomValidity("\u540D\u79F0\u4E0D\u80FD\u4E3A\u7A7A"), i.reportValidity());
          return;
        }
        u(d.slice(0, 120));
      }),
      t.addEventListener(
        "cancel",
        (d) => {
          (d.preventDefault(), u(null));
        },
        { once: !0 },
      ),
      i.addEventListener("input", () => i.setCustomValidity("")),
      i.addEventListener("keydown", (d) => {
        d.key === "Enter" && r.click();
      }),
      a.append(s, r),
      t.append(o, c, i, a),
      document.body.append(t),
      t.showModal(),
      i.focus(),
      i.select());
  });
}
const accountProxyButton = document.createElement("button");
((accountProxyButton.id = "account-proxy-context-tab"),
  (accountProxyButton.type = "button"),
  accountProxyButton.setAttribute("role", "menuitem"),
  (accountProxyButton.textContent = "\u8BBE\u7F6E / \u66F4\u6362\u56FA\u5B9AIP\u2026"),
  document
    .querySelector("#tab-context-menu")
    ?.insertBefore(accountProxyButton, document.querySelector("#block-chinese-context-tab")));
const accountWallpaperButton = document.createElement("button");
((accountWallpaperButton.id = "account-wallpaper-context-tab"),
  (accountWallpaperButton.type = "button"),
  accountWallpaperButton.setAttribute("role", "menuitem"),
  (accountWallpaperButton.textContent = "\u4FEE\u6539\u804A\u5929\u80CC\u666F\u2026"),
  document
    .querySelector("#tab-context-menu")
    ?.insertBefore(accountWallpaperButton, document.querySelector("#block-chinese-context-tab")));
function esc(e) {
  return String(e ?? "").replace(
    /[&<>\"']/g,
    (n) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[n],
  );
}
const BUILTIN_FAVICONS = Object.freeze({
    textnow: "./assets/textnow.svg",
    opensms: "./assets/site-icons/opensms.png",
    skt1: "./assets/site-icons/skt1.png",
    xhsim: "./assets/site-icons/xhsim.png",
    xinghan: "./assets/site-icons/xinghan.png",
    c2c: "./assets/site-icons/c2c.png",
    gtp: "./assets/site-icons/gtp.png",
    gpt: "./assets/site-icons/gtp.png",
    number_lookup: "./assets/site-icons/phone-lookup.png",
    phone_lookup: "./assets/site-icons/phone-lookup.png",
    truepeoplesearch: "./assets/site-icons/phone-lookup.png",
    ip_lookup: "./assets/site-icons/ip-lookup.png",
    ip138: "./assets/site-icons/ip-lookup.png",
  }),
  PLATFORM_LABELS = Object.freeze({
    textnow: "TN",
    opensms: "OPE",
    skt1: "SKT",
    xhsim: "\u661F\u6CB3",
    xinghan: "\u661F\u701A",
    c2c: "C2C",
    gtp: "GPT",
    gpt: "GPT",
    number_lookup: "\u533A\u53F7",
    phone_lookup: "\u533A\u53F7",
    truepeoplesearch: "\u53F7\u7801",
    ip_lookup: "IP",
    ip138: "IP",
    whatsapp: "WhatsApp",
    telegram: "Telegram",
    gmail: "Gmail",
  });
function platformLabel(e, n = "\u5E73\u53F0") {
  return PLATFORM_LABELS[String(e || "").toLowerCase()] || String(n || e || "\u5E73\u53F0").trim();
}
function builtInFavicon(e) {
  return BUILTIN_FAVICONS[String(e || "").toLowerCase()] || "";
}
function tabLetter(e) {
  return (
    String(e?.title || e?.siteId || "?")
      .trim()
      .slice(0, 1)
      .toUpperCase() || "?"
  );
}
function installImageFallback(e, n, t = null) {
  e &&
    e.addEventListener("error", () => {
      const o = builtInFavicon(n?.siteId);
      if (o && e.getAttribute("src") !== o) {
        e.src = o;
        return;
      }
      ((e.hidden = !0), t && (t.hidden = !1));
    });
}
function notify(e) {
  ((statusNode.textContent = e),
    statusNode.classList.add("show"),
    setTimeout(() => statusNode.classList.remove("show"), 1800));
}
function hideTabContextMenu() {
  ((contextTabId = ""), document.querySelector("#tab-context-menu")?.classList.add("hidden"));
}
function showTabContextMenu(e, n) {
  (e.preventDefault(), e.stopPropagation());
  const t = document.querySelector("#tab-context-menu");
  if (!t || !tabs.has(n)) return;
  contextTabId = n;
  const o = tabs.get(n),
    c = document.querySelector("#delete-context-account"),
    i = document.querySelector("#detach-context-tab"),
    a = document.querySelector("#block-chinese-context-tab"),
    s = document.querySelector("#account-wallpaper-context-tab"),
    r = document.querySelector("#account-proxy-context-tab");
  (c && (c.hidden = !o?.siteInstanceId),
    i && (i.hidden = !!o?.siteInstanceId),
    s &&
      (s.hidden = !["whatsapp", "telegram", "gmail"].includes(
        String(o?.siteId || "").toLowerCase(),
      )),
    r &&
      (r.hidden =
        !o?.siteInstanceId ||
        !["whatsapp", "telegram", "gmail"].includes(String(o?.siteId || "").toLowerCase())),
    a &&
      ((a.hidden = !["whatsapp", "telegram"].includes(String(o?.siteId || "").toLowerCase())),
      (a.textContent = `\u7981\u6B62\u53D1\u9001\u4E2D\u6587\uFF1A${o?.blockChinese ? "\u5DF2\u5F00\u542F" : "\u5DF2\u5173\u95ED"}`),
      a.setAttribute("aria-checked", o?.blockChinese ? "true" : "false")),
    t.classList.remove("hidden"));
  const u = t.offsetWidth || 168,
    d = t.offsetHeight || 50;
  ((t.style.left = `${Math.max(8, Math.min(e.clientX, innerWidth - u - 8))}px`),
    (t.style.top = `${Math.max(8, Math.min(e.clientY, innerHeight - d - 8))}px`),
    document.querySelector("#close-context-tab")?.focus({ preventScroll: !0 }));
}
function activeView() {
  return tabs.get(activeId)?.view || null;
}
async function applyWebAccountWallpaper(e, n = "") {
  if (!e?.siteInstanceId || e.nativeKind === "signal" || !e.view?.executeJavaScript) return;
  const t = n
    ? { ok: !0, dataUrl: n }
    : await window.orangeApp.getSiteWallpaper({
        siteInstanceId: e.siteInstanceId,
      });
  if (!t?.ok || !t.dataUrl) return;
  const o = JSON.stringify(t.dataUrl);
  await e.view
    .executeJavaScript(
      `(()=>{let s=document.getElementById('orange-account-wallpaper');if(!s){s=document.createElement('style');s.id='orange-account-wallpaper';document.documentElement.appendChild(s)}s.textContent='html,body{background-image:url('+${o}+')!important;background-size:cover!important;background-position:center!important;background-attachment:fixed!important}';})()`,
    )
    .catch(() => {});
}
function updateZoomLabel() {
  const e = tabs.get(activeId);
  document.querySelector("#zoom-reset").textContent = `${Math.round((e?.zoom || 1) * 100)}%`;
}
function workspaceSnapshot() {
  const e = [...tabs.values()];
  return {
    tabs: e.map((n) => ({
      siteId: n.siteId,
      accountId: n.accountId || "",
      siteInstanceId: n.siteInstanceId || "",
      nativeKind: n.nativeKind || "",
      partition: n.partition || "",
      url: n.url || n.view?.getURL?.() || n.initialUrl,
      title: n.title || n.siteId,
      customTitle: n.customTitle || "",
      favicon: n.favicon || "",
      zoom: n.zoom || 1,
      blockChinese: n.blockChinese === !0,
    })),
    activeIndex: Math.max(
      0,
      e.findIndex((n) => n.id === activeId),
    ),
  };
}
function saveWorkspaceNow(e = !1) {
  if ((clearTimeout(saveTimer), restoring)) return;
  const n = workspaceSnapshot();
  e ? window.orangeApp.saveWorkspaceStateSync(n) : window.orangeApp.saveWorkspaceState(n);
}
function scheduleWorkspaceSave() {
  (clearTimeout(saveTimer), (saveTimer = setTimeout(saveWorkspaceNow, 220)));
}
function setZoom(e) {
  const n = tabs.get(activeId);
  n &&
    ((n.zoom = Math.min(2, Math.max(0.5, Number(e) || 1))),
    n.view.setZoomFactor?.(n.zoom),
    updateZoomLabel(),
    scheduleWorkspaceSave());
}
function activate(e, n = !0) {
  if (tabs.has(e)) {
    activeId = e;
    for (const [t, o] of tabs)
      (o.tab.classList.toggle("active", t === e), o.view.classList.toggle("active", t === e));
    ((empty.hidden = !0), updateZoomLabel(), renderTabCenter(), n && scheduleWorkspaceSave());
  }
}
function switchTab(e = 1) {
  const n = [...tabs.keys()];
  if (!n.length) return;
  const t = Math.max(0, n.indexOf(activeId));
  activate(n[(t + e + n.length) % n.length]);
}
function reorderTab(e, n) {
  if (!e || !n || e === n || !tabs.has(e) || !tabs.has(n)) return;
  const t = [...tabs.entries()],
    o = t.find(([a]) => a === e),
    s = t.filter(([a]) => a !== e),
    u = s.findIndex(([a]) => a === n);
  (s.splice(Math.max(0, u), 0, o), tabs.clear());
  for (const [a, c] of s)
    (tabs.set(a, c), tabsNode.appendChild(c.tab), viewsNode.appendChild(c.view));
  (renderTabCenter(), saveWorkspaceNow(!0));
}
async function choosePlatform() {
  const e = document.querySelector("#platform-picker"),
    n = document.querySelector("#platform-grid");
  ((n.innerHTML = '<div class="platform-loading">\u6B63\u5728\u8BFB\u53D6\u5E73\u53F0\u2026</div>'),
    e.open || e.showModal());
  const t = await window.orangeApp.listPlatforms();
  if (!t?.ok) {
    n.innerHTML = `<div class="platform-loading">${esc(t?.message || "\u5E73\u53F0\u5217\u8868\u8BFB\u53D6\u5931\u8D25")}</div>`;
    return;
  }
  const o = Array.isArray(t.sites) ? t.sites : [];
  ((n.innerHTML =
    o
      .map((s) => {
        const u = String(s.iconUrl || builtInFavicon(s.id) || ""),
          a = String(s.name || s.id || "\u5E73\u53F0");
        return `<button class="platform-card" type="button" data-platform-id="${esc(s.id)}" data-platform-name="${esc(a)}" data-multi-account="${s.multiAccount ? "1" : "0"}">${u ? `<img src="${esc(u)}" alt=""/>` : `<span class="platform-letter">${esc(a.slice(0, 1).toUpperCase())}</span>`}<strong>${esc(a)}</strong><small>${esc(s.multiAccount ? "\u4E00\u8D26\u53F7\u4E00\u7A97\u53E3 \xB7 \u767B\u5F55\u957F\u671F\u4FDD\u7559" : s.host || "")}</small></button>`;
      })
      .join("") ||
    '<div class="platform-loading">\u5F53\u524D\u8D26\u53F7\u6CA1\u6709\u53EF\u7528\u5E73\u53F0</div>'),
    n.querySelectorAll("[data-platform-id]").forEach((s) =>
      s.addEventListener("click", async () => {
        s.disabled = !0;
        const u = s.dataset.platformId.toLowerCase(),
          a = ["whatsapp", "telegram", "gmail"].includes(u)
            ? await askFixedProxy(`\u6B64\u8D26\u53F7\u7ED1\u5B9A\u56FA\u5B9AIP\uFF08\u53EF\u7559\u7A7A\uFF09\uFF1A
\u652F\u6301 host:port\u3001host:port:user:pass\u3001protocol://user:pass@host:port`)
            : "";
        if (a === null) {
          s.disabled = !1;
          return;
        }
        const c =
          s.dataset.multiAccount === "1"
            ? await window.orangeApp.openSiteAccount({
                siteId: s.dataset.platformId,
                baseLabel: s.dataset.platformName,
                fixedProxy: a,
              })
            : await window.orangeApp.openSite(s.dataset.platformId);
        if (((s.disabled = !1), !c?.ok)) {
          notify(c?.message || "\u5E73\u53F0\u6253\u5F00\u5931\u8D25");
          return;
        }
        e.close();
      }),
    ));
}
function closeTab(e, n = {}) {
  const t = tabs.get(e);
  if (!t) return;
  const o = [...tabs.keys()],
    s = o.indexOf(e);
  if (
    (t.tab.remove(),
    t.view.remove(),
    tabs.delete(e),
    selectedTabIds.delete(e),
    t.accountId &&
      !n.keepVisible &&
      window.orangeApp.setTnTabVisibility({ accountId: t.accountId, open: !1 }),
    activeId === e)
  ) {
    const u = o[s + 1] || o[s - 1];
    ((activeId = ""), u && tabs.has(u) ? activate(u, !1) : (empty.hidden = !1));
  }
  (saveWorkspaceNow(!0), renderTabCenter());
}
function renderTabCenter() {
  const e = document.querySelector("#tab-center-grid");
  if (!e) return;
  const n = String(document.querySelector("#tab-center-search")?.value || "")
    .trim()
    .toLowerCase();
  ((e.innerHTML = [...tabs.values()]
    .filter((t) => !n || `${t.title} ${t.siteId}`.toLowerCase().includes(n))
    .map(
      (t) =>
        `<div role="button" tabindex="0" class="tab-center-item ${t.id === activeId ? "active" : ""} ${selectedTabIds.has(t.id) ? "selected" : ""}" data-center-tab="${t.id}" title="${esc(t.title)}"><input class="tab-check" data-center-check type="checkbox" ${selectedTabIds.has(t.id) ? "checked" : ""}/>${t.favicon ? `<img class="center-favicon" src="${esc(t.favicon)}" alt=""/><span class="center-letter" hidden>${esc(tabLetter(t))}</span>` : `<span class="center-letter">${esc(tabLetter(t))}</span>`}<small>${esc(t.title || t.siteId)}</small></div>`,
    )
    .join("")),
    e.querySelectorAll("[data-center-tab]").forEach((t) => {
      const o = tabs.get(t.dataset.centerTab);
      installImageFallback(
        t.querySelector(".center-favicon"),
        o,
        t.querySelector(".center-letter"),
      );
    }),
    e.querySelectorAll("[data-center-tab]").forEach((t) =>
      t.addEventListener("click", (o) => {
        o.target.closest("[data-center-check]")
          ? (o.stopPropagation(),
            o.target.checked
              ? selectedTabIds.add(t.dataset.centerTab)
              : selectedTabIds.delete(t.dataset.centerTab),
            renderTabCenter())
          : activate(t.dataset.centerTab);
      }),
    ));
}
function refreshTabs(e) {
  const n = [...e].map((o) => tabs.get(o)).filter((o) => o && o.nativeKind !== "signal"),
    t = 5;
  (n.forEach((o, s) => {
    const u = Math.floor(s / t),
      a = s % t;
    setTimeout(
      () => {
        tabs.has(o.id) && o.view.reload();
      },
      u * 3e3 + a * 420,
    );
  }),
    notify(
      `\u6B63\u5728\u6BCF\u6279${t}\u4E2A\u7F13\u6162\u5237\u65B0\uFF0C\u5171 ${n.length} \u4E2A\u6807\u7B7E`,
    ));
}
function openTab(e, n = {}) {
  if (String(e?.siteId || "").toLowerCase() === "signal") return "";
  if (e.accountId) {
    const i = [...tabs.values()].find((r) => r.accountId === String(e.accountId));
    if (i) return (activate(i.id), i.id);
  }
  if (e.siteInstanceId) {
    const i = [...tabs.values()].find(
      (r) =>
        r.siteId.toLowerCase() === String(e.siteId || "").toLowerCase() &&
        r.siteInstanceId === String(e.siteInstanceId),
    );
    if (i) return (activate(i.id), i.id);
  }
  if (String(e.siteId || "").toLowerCase() === "gmail")
    try {
      const i = new URL(String(e.url || ""));
      /^(?:www\.)?google\.com$/i.test(i.hostname) &&
        i.pathname === "/" &&
        (e = { ...e, url: "https://mail.google.com/" });
    } catch {}
  const t = `tab-${++serial}`,
    o = document.createElement("button"),
    s = String(e.nativeKind || (String(e.siteId).toLowerCase() === "signal" ? "signal" : "")),
    u = document.createElement(s === "signal" ? "section" : "webview"),
    a = {
      id: t,
      tab: o,
      view: u,
      siteId: String(e.siteId || ""),
      accountId: String(e.accountId || ""),
      siteInstanceId: String(
        e.siteInstanceId ||
          (s === "signal" && globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID() : ""),
      ),
      nativeKind: s,
      partition: String(
        e.partition || (e.accountId ? `persist:orange-tn-${e.accountId}` : "persist:orange-work"),
      ),
      initialUrl: String(e.url || ""),
      url: String(e.url || ""),
      customTitle: String(e.customTitle || ""),
      title: e.customTitle
        ? String(e.customTitle).trim()
        : e.accountId
          ? `TN ${String(e.title || "")
              .replace(/^TN\s*[·-]?\s*/i, "")
              .trim()}`.trim()
          : e.siteInstanceId
            ? String(e.title || platformLabel(e.siteId, e.title)).trim()
            : platformLabel(e.siteId, e.title),
      zoom: Math.min(2, Math.max(0.5, Number(e.zoom || 1))),
      favicon: String(builtInFavicon(e.siteId) || e.favicon || ""),
      blockChinese: e.blockChinese === !0,
      gmailHomeRedirected: !1,
    };
  ((o.className = "tab"),
    (o.title = a.title),
    (o.innerHTML = '<span class="tab-title"></span>'),
    (o.draggable = !0),
    (o.dataset.tabId = t),
    o.addEventListener("contextmenu", (i) => showTabContextMenu(i, t)),
    (o.querySelector(".tab-title").textContent = a.title),
    (u.className = `work-view${a.nativeKind === "signal" ? " signal-native-view" : ""}`),
    a.nativeKind === "signal"
      ? (u.innerHTML =
          '<div class="signal-loading"><strong>Signal</strong><span>\u6B63\u5728\u542F\u52A8\u72EC\u7ACB\u8D26\u53F7\u5E76\u5D4C\u5165\u6807\u7B7E\u2026</span></div>')
      : (u.setAttribute("partition", a.partition),
        u.setAttribute("src", a.url),
        u.setAttribute("allowpopups", "false")),
    o.addEventListener("click", () => activate(t)),
    o.addEventListener("dragstart", (i) => {
      (o.classList.add("is-dragging"),
        (i.dataTransfer.effectAllowed = "move"),
        i.dataTransfer.setData("text/plain", t));
    }),
    o.addEventListener("dragover", (i) => {
      (i.preventDefault(), (i.dataTransfer.dropEffect = "move"), o.classList.add("is-drag-target"));
    }),
    o.addEventListener("dragleave", () => o.classList.remove("is-drag-target")),
    o.addEventListener("drop", (i) => {
      (i.preventDefault(),
        o.classList.remove("is-drag-target"),
        reorderTab(i.dataTransfer.getData("text/plain"), t));
    }),
    o.addEventListener("dragend", () => {
      (o.classList.remove("is-dragging"),
        document
          .querySelectorAll(".tab.is-drag-target")
          .forEach((i) => i.classList.remove("is-drag-target")));
    }),
    a.nativeKind !== "signal" &&
      u.addEventListener("page-title-updated", (i) => {
        ((a.pageTitle = i.title || a.pageTitle || ""),
          (o.title = a.title),
          (o.querySelector(".tab-title").textContent = a.title),
          scheduleWorkspaceSave());
      }),
    a.nativeKind !== "signal" &&
      u.addEventListener("page-favicon-updated", (i) => {
        const r = String(i.favicons?.[0] || "");
        r && ((a.favicon = r), scheduleWorkspaceSave());
      }));
  const c = (i) => {
    ((a.url = i?.url || u.getURL?.() || a.url), scheduleWorkspaceSave());
  };
  return (
    a.nativeKind !== "signal" && u.addEventListener("did-navigate", c),
    a.nativeKind !== "signal" && u.addEventListener("did-navigate-in-page", c),
    a.nativeKind !== "signal" &&
      u.addEventListener("did-start-loading", () => notify("\u6B63\u5728\u52A0\u8F7D\u2026")),
    a.nativeKind !== "signal" &&
      u.addEventListener("did-stop-loading", () => {
        const i = u.getURL?.() || a.url;
        if (a.siteId.toLowerCase() === "gmail")
          try {
            const r = new URL(i);
            if (
              !a.gmailHomeRedirected &&
              /^(?:www\.)?google\.com$/i.test(r.hostname) &&
              r.pathname === "/"
            ) {
              ((a.gmailHomeRedirected = !0), u.loadURL("https://mail.google.com/"));
              return;
            }
            /(^|\.)mail\.google\.com$/i.test(r.hostname) && (a.gmailHomeRedirected = !1);
          } catch {}
        ((a.url = i),
          u.setZoomFactor(a.zoom),
          ["whatsapp", "telegram"].includes(a.siteId.toLowerCase()) &&
            u.send("orange:set-send-policy", { blockChinese: a.blockChinese }),
          ["whatsapp", "telegram", "gmail"].includes(a.siteId.toLowerCase()) &&
            applyWebAccountWallpaper(a),
          notify("\u52A0\u8F7D\u5B8C\u6210"),
          scheduleWorkspaceSave());
      }),
    a.nativeKind !== "signal" &&
      u.addEventListener("did-fail-load", (i) => {
        if (i.errorCode === -3 || i.isMainFrame === !1) return;
        const r = String(i.errorDescription || "\u672A\u77E5\u7F51\u7EDC\u9519\u8BEF");
        if (
          (notify(`\u52A0\u8F7D\u5931\u8D25\uFF1A${r}`),
          !/^data:/i.test(String(u.getURL?.() || "")))
        ) {
          const d = `<!doctype html><meta charset="utf-8"><style>body{margin:0;display:grid;place-content:center;min-height:100vh;font-family:Microsoft YaHei,system-ui;background:#fffaf6;color:#5c321f}.box{max-width:620px;padding:34px;border:1px solid #f0c6a4;border-radius:18px;background:white;box-shadow:0 20px 60px #6b35151f}h2{margin:0 0 12px;color:#d65300}p{line-height:1.7;margin:8px 0}.error{font-family:Consolas,monospace;color:#a13220;word-break:break-all}</style><div class="box"><h2>\u7F51\u9875\u65E0\u6CD5\u6253\u5F00</h2><p>\u8BF7\u68C0\u67E5\u8BE5\u8D26\u53F7\u7684\u56FA\u5B9AIP\uFF0C\u6216\u8BA9\u7BA1\u7406\u5458\u91CD\u65B0\u5206\u914D\u53EF\u7528IP\u540E\u70B9\u51FB\u53F3\u4E0A\u89D2\u5237\u65B0\u3002</p><p class="error">${esc(r)}</p></div>`;
          u.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(d)}`);
        }
      }),
    a.nativeKind !== "signal" &&
      u.addEventListener("before-input-event", (i) => {
        const r = i.input || i;
        r.control &&
          String(r.key || "").toLowerCase() === "tab" &&
          (i.preventDefault?.(), switchTab(r.shift ? -1 : 1));
      }),
    tabsNode.appendChild(o),
    viewsNode.appendChild(u),
    tabs.set(t, a),
    a.accountId && window.orangeApp.setTnTabVisibility({ accountId: a.accountId, open: !0 }),
    activate(t, !n.restoring),
    renderTabCenter(),
    t
  );
}
function acceptWorkTabOpen(e) {
  restoring ? pendingOpens.push(e) : openTab(e);
}
(window.orangeApp.onOpenWorkTab(acceptWorkTabOpen),
  window.orangeApp.onSwitchWorkTab((e) => switchTab(Number(e) < 0 ? -1 : 1)),
  window.orangeApp.onActivateAccount((e) => {
    const n = [...tabs.values()].find((t) => t.accountId === String(e || ""));
    n && activate(n.id);
  }),
  document.querySelector("#new-tab").addEventListener("click", choosePlatform),
  document
    .querySelector("#platform-picker-close")
    .addEventListener("click", () => document.querySelector("#platform-picker").close()));
function setTabCenterOpen(e) {
  (document.querySelector("#tab-center").classList.toggle("hidden", !e),
    document.body.classList.toggle("tab-center-open", e),
    localStorage.setItem("orangeTabCenterOpen", e ? "1" : "0"),
    renderTabCenter());
}
(document
  .querySelector("#tab-center-toggle")
  .addEventListener("click", () =>
    setTabCenterOpen(document.querySelector("#tab-center").classList.contains("hidden")),
  ),
  document.querySelector("#tab-center-close").addEventListener("click", () => setTabCenterOpen(!1)),
  document.querySelector("#tab-center-search").addEventListener("input", renderTabCenter),
  document
    .querySelector("#refresh-selected-tabs")
    .addEventListener("click", () => refreshTabs(selectedTabIds)),
  document
    .querySelector("#refresh-all-tabs")
    .addEventListener("click", () => refreshTabs(tabs.keys())),
  document.querySelector("#close-context-tab").addEventListener("click", () => {
    const e = contextTabId;
    (hideTabContextMenu(), e && closeTab(e));
  }),
  document.querySelector("#rename-context-tab").addEventListener("click", async () => {
    const e = tabs.get(contextTabId);
    if ((hideTabContextMenu(), !e)) return;
    const n = await askTabName(e.title);
    if (n === null) return;
    const t = String(n).trim().slice(0, 120);
    if (!t) {
      notify("\u540D\u79F0\u4E0D\u80FD\u4E3A\u7A7A");
      return;
    }
    ((e.title = t),
      (e.customTitle = t),
      (e.tab.title = t),
      (e.tab.querySelector(".tab-title").textContent = t),
      renderTabCenter(),
      saveWorkspaceNow(!0),
      notify("\u540D\u79F0\u5DF2\u4FDD\u5B58\u5728\u8FD9\u53F0\u7535\u8111"));
  }),
  document.querySelector("#block-chinese-context-tab").addEventListener("click", () => {
    const e = tabs.get(contextTabId);
    (hideTabContextMenu(),
      !(!e || !["whatsapp", "telegram"].includes(e.siteId.toLowerCase())) &&
        ((e.blockChinese = !e.blockChinese),
        ["whatsapp", "telegram"].includes(e.siteId.toLowerCase()) &&
          e.view?.send?.("orange:set-send-policy", { blockChinese: e.blockChinese }),
        saveWorkspaceNow(!0),
        notify(
          e.blockChinese
            ? "\u5DF2\u5F00\u542F\uFF1A\u7981\u6B62\u53D1\u9001\u4E2D\u6587"
            : "\u5DF2\u5173\u95ED\uFF1A\u5141\u8BB8\u53D1\u9001\u4E2D\u6587",
        )));
  }),
  document.querySelector("#account-proxy-context-tab").addEventListener("click", async () => {
    const e = tabs.get(contextTabId);
    if ((hideTabContextMenu(), !e?.siteInstanceId)) return;
    const n =
      await askFixedProxy(`\u586B\u5199\u6B64\u8D26\u53F7\u4E13\u7528\u56FA\u5B9AIP\uFF1B\u7559\u7A7A\u5E76\u786E\u5B9A\u8868\u793A\u53D6\u6D88\u56FA\u5B9AIP\uFF1A
host:port\u3001host:port:user:pass\u3001protocol://user:pass@host:port`);
    if (n === null) return;
    const t = await window.orangeApp.setSiteAccountProxy({
      siteId: e.siteId,
      siteInstanceId: e.siteInstanceId,
      fixedProxy: n,
    });
    if (!t?.ok) {
      notify(t?.message || "\u56FA\u5B9AIP\u4FDD\u5B58\u5931\u8D25");
      return;
    }
    (e.view?.reload?.(),
      notify(
        n.trim()
          ? "\u6B64\u8D26\u53F7\u5DF2\u7ED1\u5B9A\u56FA\u5B9AIP"
          : "\u6B64\u8D26\u53F7\u5DF2\u6062\u590D\u9ED8\u8BA4\u7EBF\u8DEF",
      ));
  }),
  document.querySelector("#account-wallpaper-context-tab").addEventListener("click", async () => {
    const e = tabs.get(contextTabId);
    if (
      (hideTabContextMenu(),
      !e || !["whatsapp", "telegram", "gmail"].includes(e.siteId.toLowerCase()))
    )
      return;
    const n = await window.orangeApp.chooseSiteWallpaper({ siteInstanceId: e.siteInstanceId });
    if (!n?.canceled) {
      if (!n?.ok) {
        notify(n?.message || "\u80CC\u666F\u4FDD\u5B58\u5931\u8D25");
        return;
      }
      (await applyWebAccountWallpaper(e, n.dataUrl),
        notify("\u8D26\u53F7\u80CC\u666F\u5DF2\u4FDD\u5B58"));
    }
  }),
  document.querySelector("#delete-context-account").addEventListener("click", async () => {
    const e = tabs.get(contextTabId);
    if ((hideTabContextMenu(), !e?.siteInstanceId)) {
      notify("\u5F53\u524D\u6807\u7B7E\u4E0D\u662F\u72EC\u7ACB\u8D26\u53F7\u7A97\u53E3");
      return;
    }
    if (
      !confirm(`\u786E\u5B9A\u5220\u9664\u201C${e.title}\u201D\u5728\u8FD9\u53F0\u7535\u8111\u4E0A\u7684\u767B\u5F55\u72B6\u6001\u548C\u672C\u5730\u6570\u636E\u5417\uFF1F

\u5220\u9664\u540E\u4E0B\u6B21\u5FC5\u987B\u91CD\u65B0\u767B\u5F55\uFF1B\u5176\u4ED6\u8D26\u53F7\u4E0D\u53D7\u5F71\u54CD\u3002`)
    )
      return;
    const n = { siteId: e.siteId, siteInstanceId: e.siteInstanceId };
    closeTab(e.id);
    const t = await window.orangeApp.deleteSiteAccountData(n);
    notify(
      t?.ok
        ? "\u672C\u673A\u8D26\u53F7\u6570\u636E\u5DF2\u5220\u9664"
        : t?.message || "\u5220\u9664\u5931\u8D25",
    );
  }),
  document.querySelector("#detach-context-tab").addEventListener("click", async () => {
    const e = tabs.get(contextTabId);
    if ((hideTabContextMenu(), !e)) return;
    const n = await window.orangeApp.openDetachedTab({
      siteId: e.siteId,
      accountId: e.accountId || "",
      url: e.url || e.view?.getURL?.() || e.initialUrl,
      title: e.title,
    });
    notify(
      n?.ok
        ? "\u5DF2\u5728\u72EC\u7ACB\u7A97\u53E3\u6253\u5F00"
        : n?.message || "\u72EC\u7ACB\u7A97\u53E3\u6253\u5F00\u5931\u8D25",
    );
  }),
  document.addEventListener("pointerdown", (e) => {
    e.target.closest("#tab-context-menu") || hideTabContextMenu();
  }),
  window.addEventListener("blur", hideTabContextMenu),
  document.addEventListener("keydown", (e) => {
    e.key === "Escape" && hideTabContextMenu();
  }),
  document.querySelector("#choose-site").addEventListener("click", choosePlatform),
  document.querySelector("#reload").addEventListener("click", () => {
    tabs.get(activeId)?.view?.reload?.();
  }),
  document.querySelector("#back").addEventListener("click", () => {
    const e = activeView();
    e?.canGoBack() && e.goBack();
  }),
  document.querySelector("#forward").addEventListener("click", () => {
    const e = activeView();
    e?.canGoForward() && e.goForward();
  }),
  document
    .querySelector("#zoom-out")
    .addEventListener("click", () => setZoom((tabs.get(activeId)?.zoom || 1) - 0.1)),
  document
    .querySelector("#zoom-in")
    .addEventListener("click", () => setZoom((tabs.get(activeId)?.zoom || 1) + 0.1)),
  document.querySelector("#zoom-reset").addEventListener("click", () => setZoom(1)),
  addEventListener("keydown", (e) => {
    const n = e.key.toLowerCase();
    if (e.ctrlKey && n === "tab") {
      (e.preventDefault(), switchTab(e.shiftKey ? -1 : 1));
      return;
    }
    if (e.ctrlKey && n === "t") {
      (e.preventDefault(), choosePlatform());
      return;
    }
    if (e.ctrlKey && (n === "+" || n === "=")) {
      (e.preventDefault(), setZoom((tabs.get(activeId)?.zoom || 1) + 0.1));
      return;
    }
    if (e.ctrlKey && n === "-") {
      (e.preventDefault(), setZoom((tabs.get(activeId)?.zoom || 1) - 0.1));
      return;
    }
    if (e.ctrlKey && n === "0") {
      (e.preventDefault(), setZoom(1));
      return;
    }
    if (n === "f5" || (e.ctrlKey && n === "r")) {
      e.preventDefault();
      const t = activeView();
      if (!t) return;
      e.ctrlKey && e.shiftKey ? t.reloadIgnoringCache() : t.reload();
    }
    e.ctrlKey && n === "w" && (e.preventDefault(), activeId && closeTab(activeId));
  }),
  addEventListener("beforeunload", () => {
    saveWorkspaceNow(!0);
    for (const e of tabs.values())
      e.accountId && window.orangeApp.setTnTabVisibility({ accountId: e.accountId, open: !1 });
  }),
  setInterval(saveWorkspaceNow, 3e4));
const tabCenter = document.querySelector("#tab-center");
new ResizeObserver((e) => {
  const n = Math.round(e[0]?.contentRect?.width || 340);
  (document.documentElement.style.setProperty("--tab-center-width", `${n}px`),
    localStorage.setItem("orangeTabCenterWidth", String(n)));
}).observe(tabCenter);
const rememberedCenterWidth = Math.max(
  260,
  Math.min(520, Number(localStorage.getItem("orangeTabCenterWidth") || 340)),
);
((tabCenter.style.width = `${rememberedCenterWidth}px`),
  setTabCenterOpen(localStorage.getItem("orangeTabCenterOpen") !== "0"),
  (async () => {
    const e = await window.orangeApp.getWorkspaceState().catch(() => ({ tabs: [] })),
      n = [];
    for (const o of e?.tabs || [])
      String(o?.url || "").toLowerCase() !== "about:blank" && n.push(openTab(o, { restoring: !0 }));
    const t = n[Math.max(0, Math.min(n.length - 1, Number(e?.activeIndex || 0)))];
    (t && activate(t, !1), (restoring = !1));
    for (const o of pendingOpens.splice(0)) openTab(o);
    n.length &&
      (notify(`\u5DF2\u6062\u590D ${n.length} \u4E2A\u7F51\u7AD9`), scheduleWorkspaceSave());
  })(),
  window.orangeApp.onTnAccessRevoked?.((e) => {
    const n = [...tabs.values()].filter((t) => t.siteId === "textnow" || t.accountId);
    for (const t of n) closeTab(t.id, { keepVisible: !0 });
    n.length && notify(e?.reason || "TN\u6743\u9650\u5DF2\u5173\u95ED");
  }));
