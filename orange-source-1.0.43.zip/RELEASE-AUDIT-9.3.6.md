# Orange AI Assistant 9.3.6 Release Audit

## Release scope

- TN Cookie universal import with Beta.6-compatible non-destructive merge.
- Remember the last managed TN fixed-IP group per signed-in software user.
- TN account select-all and bulk open.
- Area-code card viewport correction after maximize, restore, or resize without forcing a hidden card to appear.
- Beta.6 native TextNow lifecycle restored: no user-agent override, CAPTCHA monitor, forced refresh, or synthetic verification window.
- Every keep-alive TN account remains online; hidden pages mute audio, stop visual animation, and skip image/media/font requests while message networking and notification observers remain active.
- TN partitions use the formal extension for translation, area lookup, AI, visuals, message recognition, and notifications; only the underlying session/CK/proxy/lifecycle behavior is restored from Beta.6.

## TN Cookie formats covered

- Cookie request header and `Cookie:` header.
- cURL `-b/--cookie` and `-H/--header 'Cookie: ...'`.
- Multiple `Set-Cookie` response headers.
- Cookie-Editor, EditThisCookie, Chrome/Firefox-style JSON arrays.
- Playwright/Puppeteer storage-state wrappers and nested cookie objects.
- Chrome/Edge DevTools TSV and CSV exports.
- Netscape HTTP Cookie File.
- HAR request/response cookies.
- Name/value object maps, JSON encoded inside JSON, continuous JSON values, and multi-account batches separated by `---` or `===`.
- Excel clipboard rows from either a single CK column or account/password/CK columns; one physical row becomes one account.
- JSON objects embedded inside Cookie values are preserved as values and never counted as separate CK batches.
- Hard-wrapped signature, Base64, encoded-token, and JSON values are rejoined without inserting spaces.

## Safety behavior

- Only TextNow domains are accepted.
- Expired cookies are not silently extended.
- Domain, path, Secure, HttpOnly, SameSite, HostOnly, and expiration are preserved when present.
- Header-only cookies use the Beta.6-compatible `.textnow.com` domain so TextNow-owned subdomains receive the same session.
- Re-import merges supplied cookies and never deletes browser-generated device, verification, or risk cookies.
- Each supplied cookie is verified after writing; existing site storage and unrelated TextNow cookies remain intact.
- CK format recognition and actual TN login verification are separate states.

## Automated verification

- `npm run check`: passed.
- UI regression protections: 40 passed.
- TN DOM locator test: passed.
- TN Cookie parser matrix: passed.
- Release staging: minified desktop prepared; 22 extension runtime files staged; 18 manifest dependencies verified.
- `release-app/main.js` and `release-app/tn-cookie-parser.js`: syntax passed.

## Windows release

Run `publish-update.bat` on Windows after `npm ci`. It builds and publishes:

- `dist/Orange-AI-Assistant-Setup-9.3.6.exe`
- `dist/Orange-AI-Assistant-Setup-9.3.6.exe.blockmap`
- `dist/latest.yml`
# 9.3.6 内测 TN 底座融合审计

- TN 稳定来源：`0.7.0-beta.6`
- 正式版本：`9.3.6`
- TN 核心契约：`tn-stable-core.js`
- 正式账号、权限、群发、翻译、区号、AI、美化、通知及后台管理：保留
- 更新通道：正式版，禁止预发布版本自动下发
- TN分区：全部直接采用内测版账号级分区，不运行旧正式TN双轨兼容代码
- 打粉台：正式版外围任务模块，调用内测TN页面，不改写内测TN运行环境
- 验证原则：不自动刷新、不伪装 User-Agent、不创建替代验证窗口；官方验证出现时允许人工完成
