// Supabase Edge Function: session-control (0.9.2)
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { withSupabase } from "jsr:@supabase/server@^1";

type Payload = { action?:"register"|"heartbeat"; deviceHash?:string; deviceName?:string; platform?:string };
const KNOWN_PERMISSION_CODES = [
  "platform_whatsapp","platform_telegram","platform_gmail",
  "tn_assistant","tn_accounts","tn_sender","tn_dom_test","tn_live_test",
  "chat_translate","page_translate","input_translate","ai_reply","reengage","area_lookup",
  "phone_mask","phone_mask_custom_text","phone_mask_custom_color","bubble_effect","custom_background",
  "personal_groq_key","public_groq_pool"
] as const;

function fail(message:string, code:string, status=403) { return Response.json({ ok:false,message,code },{ status }); }
function clientIp(req:Request) {
  const forwarded = String(req.headers.get("x-forwarded-for") || "").split(",")[0].trim();
  const value = String(req.headers.get("cf-connecting-ip") || req.headers.get("x-real-ip") || forwarded || "").trim().toLowerCase();
  return value.length <= 45 && /^[0-9a-f:.]+$/.test(value) ? value : "";
}

async function membershipGraceDays(admin:any) {
  const { data, error } = await admin.from("membership_settings").select("basic_grace_days").eq("singleton", true).maybeSingle();
  if (error && String(error.code || "") !== "42P01") throw error;
  return Math.max(1, Math.min(365, Number(data?.basic_grace_days || 30)));
}

export default {
  fetch: withSupabase({
    auth:"user",
    env:{
      url:Deno.env.get("SUPABASE_URL")!,
      publishableKeys:{ default:Deno.env.get("SUPABASE_ANON_KEY")! },
      secretKeys:{ default:Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")! },
    },
  }, async (req,ctx) => {
    try {
      const userId=String(ctx.jwtClaims?.sub ?? ctx.userClaims?.id ?? "");
      if(!userId) return fail("登录状态无效","INVALID_SESSION",401);
      const body=await req.json() as Payload;
      const action=String(body.action||"");
      const deviceHash=String(body.deviceHash||"");
      if(!/^[a-f0-9]{64}$/.test(deviceHash)) return fail("设备标识不正确","INVALID_DEVICE",400);
      const admin=ctx.supabaseAdmin;
      const ip=clientIp(req);
      if(ip) {
        const {data:blocked,error:blockError}=await admin.from("blocked_client_ips").select("id,reason").eq("ip_address",ip).maybeSingle();
        if(blockError) throw blockError;
        if(blocked) return fail(`当前公网IP已被管理员禁止使用${blocked.reason?`：${blocked.reason}`:""}`,"IP_BLOCKED",403);
      }
      const {data:profile,error:profileError}=await admin.from("profiles")
        .select("id,role,plan,account_status,valid_from,valid_until,device_limit,force_logout_after")
        .eq("id",userId).single();
      if(profileError||!profile) return fail("账号资料不存在","PROFILE_NOT_FOUND",403);
      if(profile.account_status!=="active") return fail("账号已停用或暂停",String(profile.account_status||"ACCOUNT_DISABLED").toUpperCase(),403);
      const now=Date.now();
      const nowIso=new Date(now).toISOString();
      let membershipDowngraded=false;
      if(profile.valid_from&&new Date(profile.valid_from).getTime()>now) return fail("账号尚未生效","ACCOUNT_DISABLED",403);
      if(profile.valid_until&&new Date(profile.valid_until).getTime()<=now) {
        // Business rule: an expired Advanced member falls back to Basic instead
        // of being locked out. Basic keeps platform/TN-account access only; all
        // assistant/translation/AI permissions are hard-capped below.
        if(profile.role!=="admin"&&profile.plan==="advanced") {
          const graceDays=await membershipGraceDays(admin);
          const basicUntil=new Date(now + graceDays*86400000).toISOString();
          const {error:downgradeError}=await admin.from("profiles")
            .update({plan:"basic",valid_until:basicUntil,account_status:"active",updated_at:nowIso})
            .eq("id",userId).eq("plan","advanced");
          if(downgradeError) throw downgradeError;
          profile.plan="basic";
          profile.valid_until=basicUntil;
          membershipDowngraded=true;
        } else if(profile.role!=="admin"&&profile.plan==="basic") {
          await admin.from("profiles").update({account_status:"paused",updated_at:nowIso}).eq("id",userId);
          return fail("普通会员体验期已结束，请联系管理员续费","MEMBERSHIP_GRACE_EXPIRED",403);
        } else {
          return fail("账号已到期","EXPIRED",403);
        }
      }
      const issuedAt=Number(ctx.jwtClaims?.iat||0)*1000;
      if(profile.force_logout_after&&issuedAt&&new Date(profile.force_logout_after).getTime()>issuedAt) return fail("管理员已强制此账号下线","FORCE_LOGOUT",403);

      const {data:existing}=await admin.from("devices").select("id,revoked_at").eq("user_id",userId).eq("device_hash",deviceHash).maybeSingle();
      if(existing?.revoked_at) return fail("此设备已被管理员解绑","DEVICE_REVOKED",403);
      const timestamp=new Date().toISOString();
      if(action==="register") {
        if(!existing) {
          const {count}=await admin.from("devices").select("id",{count:"exact",head:true}).eq("user_id",userId).is("revoked_at",null);
          if(Number(count||0)>=Number(profile.device_limit||1)) return fail("已达到允许登录的设备数量","DEVICE_LIMIT",403);
          const {error}=await admin.from("devices").insert({ user_id:userId,device_hash:deviceHash,device_name:String(body.deviceName||"").slice(0,100),platform:String(body.platform||"").slice(0,100),first_seen_at:timestamp,last_seen_at:timestamp,last_ip:ip||null });
          if(error) throw error;
        } else {
          const {error}=await admin.from("devices").update({ device_name:String(body.deviceName||"").slice(0,100),platform:String(body.platform||"").slice(0,100),last_seen_at:timestamp,last_ip:ip||null }).eq("id",existing.id);
          if(error) throw error;
        }
        await admin.from("profiles").update({last_login_at:timestamp,updated_at:timestamp}).eq("id",userId);
      } else if(action==="heartbeat") {
        if(!existing) return fail("当前设备尚未登记","DEVICE_REVOKED",403);
        const {error}=await admin.from("devices").update({last_seen_at:timestamp,last_ip:ip||null}).eq("id",existing.id).is("revoked_at",null);
        if(error) throw error;
      } else return fail("不支持的操作","INVALID_ACTION",400);

      const [planResult,overrideResult]=await Promise.all([
        admin.from("plan_permissions").select("feature_code,enabled").eq("plan",profile.plan),
        admin.from("user_permission_overrides").select("feature_code,enabled").eq("user_id",userId),
      ]);
      if(planResult.error) throw planResult.error;
      if(overrideResult.error) throw overrideResult.error;
      // Fail closed: every known permission starts false. A missing DB row can
      // never silently grant access after an upgrade or partial migration.
      const permissions:Record<string,boolean>=Object.fromEntries(KNOWN_PERMISSION_CODES.map(code=>[code,false]));
      for(const row of planResult.data||[]) permissions[String(row.feature_code)]=row.enabled===true;
      if(profile.role==="admin") {
        for(const key of KNOWN_PERMISSION_CODES) permissions[key]=true;
      } else {
        // 0.9.2: both Advanced and Basic follow administrator-managed plan
        // defaults plus optional per-user overrides. The migration keeps Basic
        // safe by default (only tn_accounts=true), while admins may explicitly
        // enable additional functions when needed.
        for(const row of overrideResult.data||[]) permissions[String(row.feature_code)]=row.enabled===true;
      }
      return Response.json({ok:true,permissions,clientIp:ip,profilePlan:profile.plan,membershipDowngraded});
    } catch(error) {
      console.error("session-control",error);
      return fail(error instanceof Error?error.message:String(error),"SERVER_ERROR",500);
    }
  }),
};
