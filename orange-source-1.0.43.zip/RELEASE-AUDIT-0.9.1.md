# Orange AI Assistant 0.9.1 修复审计

## 本轮目标

在尽量不改动原有正常功能的前提下，重点加固权限系统与 TN（TextNow）链路，并把 0.9.0 已知缺口修复到 0.9.1 源码中。

## 已完成的核心修复

### 权限系统

- 新增 `tn_assistant` 独立总权限；session-control 对所有已知权限采用“缺失即 false”的失败关闭策略。
- TN 主进程 IPC 统一使用 `tnFeatureAllowed()` 进行总开关 + TN 总权限 + TN 子权限二次校验。
- 翻译 IPC 不再只检查全局开关，同时检查对应会员权限；TN 页面额外受 TN 总权限约束。
- 扩展 content/background/AI background 在执行翻译、AI 动作前再次检查权限，避免仅隐藏按钮造成绕过。
- 全局 TN 或 TN 账号开关关闭时，扩展侧 `tn_assistant` 有效权限同步为 false。
- 权限/功能开关变化后，主进程立即停止 TN 后台窗口，并通知工作台关闭 TN 标签。
- 新 TN webview 附加前再次检查 TN 权限，防止权限收回后重新建立 TN 页面。
- 会员权限保存后执行数据库回读复核；功能开关保存后回读，并在审计写入失败时自动回滚。

### TN 账号与隔离

- TN 账号仍按当前员工 ID 保存；浏览器 partition 使用员工作用域哈希 + TN 账号 ID 隔离。
- TN 本机固定 IP、Cookie 识别/导入/清除、Beta.6 迁移、标签可见性等入口补齐权限检查。
- 删除 Beta.6 迁移请求重复写入。
- TN 外观同步和新消息通知在权限被收回后不再继续处理。
- 工作台收到权限收回事件后关闭当前所有 TN 标签。

### TN 发送台

- `tn_sender` 已接入真实单条发送 IPC，不再只是保存预览。
- 支持立即任务和定时开始任务（软件需保持登录运行）。
- 按每个 TN 账号分别执行 15–300 秒发送间隔。
- 每次发送前由主进程重新校验 TN 权限、TN 账号归属、10 位北美号码、收件人 DOM 和实际选中号码。
- 发送前按“员工 ID + 标准化号码”计算 SHA-256 指纹并强制查重。
- 只有 DOM 明确确认新增发出消息时才写入已发送指纹。
- 结果不明确时任务自动暂停且不重试，避免重复发送。
- DOM/收件人/发送按钮等校验失败时任务自动暂停，避免错发。
- 应用或渲染器中断时遗留的 `sending` 项在恢复后视为 `uncertain`，不会自动重试。
- TN 发送任务和每账号最近发送时间改为按员工 ID 分区保存，避免同机不同员工看到或继承彼此任务。

### 数据库升级

新增 `SUPABASE-0.9.1-PERMISSIONS-TN-FIX.sql`：

- 补建权限/功能开关相关表（缺失时）。
- 增加 TN 总权限默认项。
- 默认只补缺失记录，不覆盖管理员已经保存的权限选择。
- 调整历史公告创建者外键为 `ON DELETE SET NULL`，为员工永久删除兼容旧数据。

## 版本与发布文件

- `package.json` -> `0.9.1`
- `package-lock.json` 根版本 -> `0.9.1`
- 新增 `CHANGES-0.9.1.txt`
- 新增 `START-HERE-0.9.1.txt`

## 自动检查结果

- `npm run check`：通过，27 项保护性回归检查通过。
- TN DOM locator 测试：通过。
- `npm run test:ope`：通过，61 个禁词守卫用例通过。
- 全部 21 个 JavaScript 文件执行 `node --check`：通过。
- 版本一致性检查：`package.json` / `package-lock.json` 均为 0.9.1。

## 必须在真实环境继续验证

以下项目不能仅靠当前离线源码环境确认：

1. 在现有生产/测试 Supabase 库执行 0.9.1 SQL 的实际兼容性。
2. 部署新版 `SUPABASE-session-control.ts` 和 `SUPABASE-admin-users.ts` 后的权限实时回读。
3. 管理员实时关闭 `tn_assistant`、`tn_accounts`、`tn_sender` 后员工端的 15–60 秒同步链路。
4. 使用真实 TextNow 测试账号验证 DOM 定位、Cookie 登录、人工验证码、单条实发和发送确认 DOM。
5. 定时 TN 任务要求桌面端保持登录运行；Windows 睡眠/关机期间不会执行，恢复后会继续处理尚未开始的任务。
6. 安装包构建与自动更新发布链路需在带依赖和 Windows 打包环境中验证。

## 变更范围

本轮共涉及 16 个源码/配置/升级文件（相对 0.9.0），约 525 行新增、88 行删除。未对无关页面布局、站内消息业务、代理池业务等做无目的重构。


0.9.1 final hardening update:
- proxy-control now revalidates module_tn + tn_accounts global flags before any TN group/fixed-proxy action.
- Non-admin TN proxy access now revalidates tn_assistant + tn_accounts from plan_permissions plus user_permission_overrides, with missing/error states denied.
- Removed duplicate valid_from check in proxy-control.
- Regression suite expanded to 28 protected checks.

- 会员到期策略调整：高级会员到期自动降级为普通会员并保持登录；普通会员固定仅保留平台访问与 TN 账号/IP 登录，助手、翻译、AI、发送与测试功能全部关闭。
- TN 账号/IP 登录与 `tn_assistant` 解耦：`tn_accounts` 控制进入 TN，`tn_assistant` 仅控制 TN 内助手能力。
