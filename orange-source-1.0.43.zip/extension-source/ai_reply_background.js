(() => {
  "use strict";
  const O = "orangeGeminiApiKey",
    N = "orangeGeminiModel",
    $ = "gemini-3.5-flash-lite",
    q = "https://generativelanguage.googleapis.com/v1beta/models",
    G = {
      type: "object",
      additionalProperties: !1,
      properties: {
        heat: {
          type: "object",
          additionalProperties: !1,
          properties: {
            level: { type: "integer", minimum: 1, maximum: 5 },
            label: { type: "string" },
            reason: { type: "string" },
          },
          required: ["level", "label", "reason"],
        },
        relationshipStage: { type: "string" },
        topic: { type: "string" },
        reminder: { type: "string" },
        continuation: {
          type: "object",
          additionalProperties: !1,
          properties: {
            signal: {
              type: "string",
              enum: ["open", "polite_close", "temporary_busy", "explicit_stop"],
            },
            strategy: { type: "string" },
          },
          required: ["signal", "strategy"],
        },
        resonance: {
          type: "object",
          additionalProperties: !1,
          properties: {
            primary: { type: "string" },
            secondary: { type: "string" },
            reason: { type: "string" },
          },
          required: ["primary", "secondary", "reason"],
        },
        knownProfile: {
          type: "object",
          additionalProperties: !1,
          properties: {
            name: { type: "string" },
            location: { type: "string" },
            occupation: { type: "string" },
            age: { type: "string" },
            interests: { type: "array", items: { type: "string" }, maxItems: 12 },
            food: { type: "array", items: { type: "string" }, maxItems: 10 },
            sports: { type: "array", items: { type: "string" }, maxItems: 10 },
            travel: { type: "array", items: { type: "string" }, maxItems: 10 },
            lifestyle: { type: "array", items: { type: "string" }, maxItems: 10 },
            importantStories: { type: "array", items: { type: "string" }, maxItems: 10 },
          },
          required: [
            "name",
            "location",
            "occupation",
            "age",
            "interests",
            "food",
            "sports",
            "travel",
            "lifestyle",
            "importantStories",
          ],
        },
        kellyDisclosed: { type: "array", items: { type: "string" }, maxItems: 20 },
        reciprocalDisclosure: { type: "string" },
        replies: {
          type: "array",
          minItems: 3,
          maxItems: 3,
          items: {
            type: "object",
            additionalProperties: !1,
            properties: {
              style: { type: "string", enum: ["natural", "warm", "light_humor"] },
              label: { type: "string" },
              text: { type: "string" },
              zh: { type: "string" },
            },
            required: ["style", "label", "text", "zh"],
          },
        },
        directions: {
          type: "array",
          minItems: 3,
          maxItems: 4,
          items: {
            type: "object",
            additionalProperties: !1,
            properties: {
              label: { type: "string" },
              priority: { type: "string", enum: ["high", "medium", "low"] },
              reason: { type: "string" },
            },
            required: ["label", "priority", "reason"],
          },
        },
        avoid: { type: "string" },
      },
      required: [
        "heat",
        "relationshipStage",
        "topic",
        "reminder",
        "continuation",
        "resonance",
        "knownProfile",
        "kellyDisclosed",
        "reciprocalDisclosure",
        "replies",
        "directions",
        "avoid",
      ],
    };
  function B(e) {
    return String(e || "")
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, "")
      .trim();
  }
  function L(e) {
    for (const o of Array.isArray(e?.candidates) ? e.candidates : []) {
      const r = (Array.isArray(o?.content?.parts) ? o.content.parts : [])
        .filter((s) => s?.thought !== !0)
        .map((s) => (typeof s?.text == "string" ? s.text : ""))
        .join(
          `
`,
        )
        .trim();
      if (r) return r;
    }
    return "";
  }
  function U(e) {
    const o = String(e || ""),
      r = o.indexOf("{");
    if (r < 0) return "";
    let s = 0,
      i = !1,
      n = !1;
    for (let t = r; t < o.length; t += 1) {
      const u = o[t];
      if (i) {
        n ? (n = !1) : u === "\\" ? (n = !0) : u === '"' && (i = !1);
        continue;
      }
      if (u === '"') {
        i = !0;
        continue;
      }
      if ((u === "{" && (s += 1), u === "}" && ((s -= 1), s === 0))) return o.slice(r, t + 1);
    }
    return "";
  }
  function y(e) {
    const o = B(e)
        .replace(/^\uFEFF/, "")
        .trim(),
      r = [];
    o && r.push(o);
    const s = U(o);
    s && s !== o && r.push(s);
    for (const i of r) {
      try {
        const n = JSON.parse(i);
        return typeof n == "string"
          ? y(n)
          : (n && typeof n.content == "string" && !n.replies && y(n.content)) || n;
      } catch {}
      try {
        const n = i.replace(/,\s*([}\]])/g, "$1"),
          t = JSON.parse(n);
        return typeof t == "string"
          ? y(t)
          : (t && typeof t.content == "string" && !t.replies && y(t.content)) || t;
      } catch {}
    }
    return null;
  }
  function a(e, o = 1e3) {
    return String(e ?? "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, o);
  }
  function A(e, o = 160) {
    const r = a(e, o);
    return !r || /^(null|unknown|未知|n\/a)$/i.test(r) ? null : r;
  }
  function m(e, o = 10, r = 140) {
    return (Array.isArray(e) ? e : [])
      .map((s) => a(s, r))
      .filter(Boolean)
      .filter((s, i, n) => n.findIndex((t) => t.toLowerCase() === s.toLowerCase()) === i)
      .slice(0, o);
  }
  function z(e) {
    const o = a(e, 1200);
    if (!o) return "";
    const r = o
        .split(/(?<=[.!?。！？])\s+/)
        .map((i) => i.trim())
        .filter(Boolean),
      s =
        /^(who|what|where|when|why|how|which|whose|do|does|did|are|is|am|was|were|can|could|would|will|have|has|had|should|may|mind|tell me|let me know|share|explain)\b/i;
    return r
      .filter(
        (i) =>
          !(
            /[?？]/.test(i) ||
            s.test(i) ||
            /\b(i wonder|i['’]?d love to know|curious (?:where|what|how|when|if|whether)|tell me|let me know|would love to hear)\b/i.test(
              i,
            )
          ),
      )
      .join(" ")
      .replace(/[?？]/g, ".")
      .replace(/\.{2,}/g, ".")
      .trim();
  }
  function H(e) {
    const o = Math.max(1, Math.min(5, Number.parseInt(e?.level, 10) || 1));
    return {
      level: o,
      label: a(
        e?.label ||
          [
            "\u964C\u751F/\u8C28\u614E",
            "\u613F\u610F\u804A\u5929",
            "\u5F00\u59CB\u6709\u5171\u540C\u70B9",
            "\u660E\u663E\u719F\u6089",
            "\u670B\u53CB\u5F0F\u4EA4\u6D41",
          ][o - 1],
        60,
      ),
      reason: a(e?.reason, 220),
    };
  }
  function W(e, o) {
    const r = z(e);
    if (!r || o === "explicit_stop") return r;
    const s =
        /\b(have (?:a |an )?(?:good|great|nice|wonderful) (?:day|evening|night|weekend)|take care|nice (?:talking|chatting) (?:to|with) you|enjoy (?:the )?(?:rest of )?(?:your )?(?:day|evening|night|weekend)|talk (?:to you )?later|catch you later|speak soon|goodbye|bye for now)\b/i,
      i = r
        .split(/(?<=[.!。！])\s+/)
        .map((n) => n.trim())
        .filter(Boolean)
        .filter((n) => !s.test(n));
    return (i.length ? i.join(" ") : r).trim();
  }
  function k(e) {
    const o = ["open", "polite_close", "temporary_busy", "explicit_stop"].includes(
        e?.continuation?.signal,
      )
        ? e.continuation.signal
        : "open",
      r = Array.isArray(e?.replies) ? e.replies : [],
      s = [
        ["natural", "\u81EA\u7136\u5171\u9E23"],
        ["warm", "\u6E29\u6696\u81EA\u7136"],
        ["light_humor", "\u8F7B\u677E\u5E7D\u9ED8"],
      ]
        .map(([n, t], u) => {
          const l = r.find((p) => p?.style === n) || r[u] || {};
          return {
            style: n,
            label: a(l?.label || t, 30) || t,
            text: W(l?.text, o),
            zh: a(l?.zh, 500),
          };
        })
        .filter((n) => n.text);
    if (s.length < 3 || s.some((n) => !n.zh))
      throw new Error("AI\u8FD4\u56DE\u7684\u4E09\u6761\u53CC\u8BED\u56DE\u590D\u4E0D\u5B8C\u6574");
    const i = (Array.isArray(e?.directions) ? e.directions : [])
      .slice(0, 4)
      .map((n) => ({
        label: a(n?.label, 80),
        priority: ["high", "medium", "low"].includes(n?.priority) ? n.priority : "medium",
        reason: a(n?.reason, 220),
      }))
      .filter((n) => n.label);
    return {
      heat: H(e?.heat),
      relationshipStage: a(e?.relationshipStage, 80),
      topic: a(e?.topic, 120),
      reminder: a(e?.reminder, 300),
      continuation: { signal: o, strategy: a(e?.continuation?.strategy, 260) },
      resonance: {
        primary: a(e?.resonance?.primary, 180),
        secondary: a(e?.resonance?.secondary, 180),
        reason: a(e?.resonance?.reason, 280),
      },
      knownProfile: {
        name: A(e?.knownProfile?.name),
        location: A(e?.knownProfile?.location),
        occupation: A(e?.knownProfile?.occupation),
        age: A(e?.knownProfile?.age, 60),
        interests: m(e?.knownProfile?.interests, 12, 90),
        food: m(e?.knownProfile?.food, 10, 90),
        sports: m(e?.knownProfile?.sports, 10, 90),
        travel: m(e?.knownProfile?.travel, 10, 120),
        lifestyle: m(e?.knownProfile?.lifestyle, 10, 120),
        importantStories: m(e?.knownProfile?.importantStories, 10, 180),
      },
      kellyDisclosed: m(e?.kellyDisclosed, 20, 120),
      reciprocalDisclosure: a(e?.reciprocalDisclosure, 220),
      replies: s,
      directions: i,
      avoid: a(e?.avoid, 260),
    };
  }
  async function R() {
    const e = await chrome.storage.local.get([O, N]);
    return { apiKey: String(e?.[O] || "").trim(), model: String(e?.[N] || $).trim() || $ };
  }
  function Y(e) {
    return String(e || "")
      .toLowerCase()
      .startsWith("gemini-2.5")
      ? { thinkingBudget: 0 }
      : { thinkingLevel: "minimal", includeThoughts: !1 };
  }
  function V(e) {
    const o = globalThis.ORANGE_AI_CULTURE_KNOWLEDGE || {},
      r = String(e || "").toLowerCase(),
      s = (t, u) => {
        let l = 0;
        for (const g of u) {
          const D = Array.isArray(t?.[g]) ? t[g] : [];
          for (const b of D) {
            const E = String(b || "")
              .toLowerCase()
              .trim();
            E && r.includes(E) && (l += g === "cues" ? 4 : 1);
          }
        }
        const p = String(t?.key || "")
          .toLowerCase()
          .trim();
        return (p && r.includes(p) && (l += 3), l);
      },
      i = (Array.isArray(o.regions) ? o.regions : [])
        .map((t) => ({ entry: t, score: s(t, ["cues", "culture", "food", "interests"]) }))
        .filter((t) => t.score > 0)
        .sort((t, u) => u.score - t.score)
        .slice(0, 3)
        .map((t) => t.entry),
      n = (Array.isArray(o.interests) ? o.interests : [])
        .map((t) => {
          const u = String(t?.key || "")
              .toLowerCase()
              .trim(),
            l = u && r.includes(u) ? 5 : s(t, ["resonance"]);
          return { entry: t, score: l };
        })
        .filter((t) => t.score > 0)
        .sort((t, u) => u.score - t.score)
        .slice(0, 6)
        .map((t) => t.entry);
    return !i.length && !n.length
      ? {
          note: "No specific U.S. region or hobby cue detected. Use only explicit conversation facts; do not stereotype.",
        }
      : { regions: i, interests: n };
  }
  async function X(e) {
    const { apiKey: o, model: r } = await R(),
      s = String(e?.context || "").trim();
    if (!s)
      throw new Error(
        "\u6CA1\u6709\u8BFB\u53D6\u5230\u804A\u5929\u5185\u5BB9\uFF0C\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u804A\u5929\u4F1A\u8BDD",
      );
    const i = a(e?.pageTitle, 300),
      n = a(e?.pageHost, 120),
      t = a(e?.localDate, 160),
      u = String(e?.draft || "").trim(),
      l = e?.contactMemory && typeof e.contactMemory == "object" ? e.contactMemory : null,
      p = e?.mode === "reengage" ? "reengage" : "reply",
      g = e?.phoneRegionHint && typeof e.phoneRegionHint == "object" ? e.phoneRegionHint : null,
      D = e?.reengagementMeta && typeof e.reengagementMeta == "object" ? e.reengagementMeta : null,
      b = [
        p === "reengage"
          ? "MODE = REENGAGE. Generate a natural friendship re-engagement after silence, using stored memory and old topics without guilt, pressure, fake coincidence, or a question."
          : "MODE = REPLY. Analyze the full active conversation and return the structured social-copilot JSON requested by the system instruction. Be concise and fast.",
        "The latest message is the immediate context, but use the full history to avoid repeating known facts and to preserve relationship continuity.",
        "Priority: resonance first. Replies must contain no questions. Next-step information-gathering ideas belong only in directions.",
        p === "reengage"
          ? "Re-engagement must feel fresh and easy to answer. Prefer a remembered interest/story/location cue or one authentic Kelly observation. Never mention silence duration unless the person themselves brought it up."
          : "Keep the conversational thread open unless the latest message is an explicit request to stop contact. Do not use routine farewell language in normal/polite-close/busy cases.",
        p === "reengage"
          ? "Do not use: why haven't you replied, haven't heard from you, you disappeared, are you ignoring me, checking in again, or any guilt/urgency language."
          : "When they reveal a meaningful fact, consider one matching Kelly self-disclosure that has not already been disclosed, then extend with a callback or observation.",
        "Bilingual rule: every operator-facing field must be Chinese or bilingual; every replies item must contain English text plus an accurate natural Chinese zh translation.",
        "Reply length rule: each reply should be 2-4 natural sentences (roughly 35-90 English words), with warmth, one concrete callback, and an open conversational hook; do not make it abrupt.",
        "Keep analysis concise and return only 3-4 directions.",
        t ? `Browser local date/time: ${t}` : "",
        n ? `Current site: ${n}` : "",
        i ? `Page title: ${i}` : "",
        g
          ? `PHONE AREA-CODE HINT (weak cue only; not verified residence):
${JSON.stringify(g)}`
          : "",
        p === "reengage" && D
          ? `RE-ENGAGEMENT STATUS (do not invent missing timing):
${JSON.stringify(D)}`
          : "",
        l
          ? `Stored contact memory from earlier interactions (current visible conversation wins on conflict):
${JSON.stringify(l)}`
          : "",
        "",
        "Full current conversation, oldest to newest:",
        s,
        u
          ? `
Current unsent draft in the input box; treat only as optional operator intent, not as sent history:
${u}`
          : "",
      ].filter(Boolean).join(`
`),
      E = V(`${s}
${l ? JSON.stringify(l) : ""}
${g ? JSON.stringify(g) : ""}`),
      f = await chrome.storage.local.get([
        "orangeSupabaseUrl",
        "orangeSupabasePublishableKey",
        "orangeSupabaseAccessToken",
      ]);
    if (f.orangeSupabaseUrl && f.orangeSupabasePublishableKey && f.orangeSupabaseAccessToken) {
      const c = async (S, h = 2200, te = 0.7) => {
          let I = null;
          for (let T = 0; T < 2; T += 1) {
            const M = new AbortController(),
              re = setTimeout(() => M.abort(), 48e3);
            try {
              return await fetch(`${f.orangeSupabaseUrl}/functions/v1/ai-gateway`, {
                method: "POST",
                signal: M.signal,
                headers: {
                  "Content-Type": "application/json",
                  apikey: f.orangeSupabasePublishableKey,
                  Authorization: `Bearer ${f.orangeSupabaseAccessToken}`,
                },
                body: JSON.stringify({
                  action: "generate",
                  messages: S,
                  maxTokens: h,
                  temperature: te,
                }),
              });
            } catch (K) {
              if (((I = K), K?.name === "AbortError"))
                throw new Error(
                  "AI\u5DF2\u5C1D\u8BD5\u591A\u4E2AKey\u548C\u6A21\u578B\u4F46\u4ECD\u8D85\u8FC748\u79D2\uFF0C\u8BF7\u91CD\u65B0\u751F\u6210",
                );
              if (T === 0) {
                await new Promise((ne) => setTimeout(ne, 700));
                continue;
              }
            } finally {
              clearTimeout(re);
            }
          }
          throw new Error(
            `\u65E0\u6CD5\u8FDE\u63A5AI\u7F51\u5173\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u6216\u91CD\u65B0\u767B\u5F55${I?.message ? ` \xB7 ${I.message}` : ""}`,
          );
        },
        P = await c([
          {
            role: "system",
            content: `${String(globalThis.ORANGE_AI_SYSTEM_PROMPT || "")}

Relevant U.S. culture reference (optional cues only):
${JSON.stringify(E)}
Return only valid JSON matching the requested structure.`,
          },
          { role: "user", content: b },
        ]),
        d = await P.json().catch(() => null);
      if (!P.ok || !d?.ok)
        throw new Error(
          d?.message ||
            `\u591A\u6A21\u578BAI\u7F51\u5173\u8BF7\u6C42\u5931\u8D25\uFF1AHTTP ${P.status}`,
        );
      const J = B(String(d.content || ""));
      let F = y(J);
      try {
        if (!F) throw new Error("AI\u8FD4\u56DE\u4E0D\u662F\u6709\u6548JSON");
        return {
          advice: k(F),
          model: `${d.provider || "AI"} \xB7 ${d.model || "\u81EA\u52A8\u6A21\u578B"}`,
        };
      } catch {
        const S = await c(
            [
              {
                role: "system",
                content: `Repair the supplied model output into valid JSON matching this schema. Preserve meaning, supply exactly three complete bilingual replies, and output JSON only. Schema: ${JSON.stringify(G)}`,
              },
              { role: "user", content: J.slice(0, 18e3) },
            ],
            1800,
            0.15,
          ),
          h = await S.json().catch(() => null);
        if (!S.ok || !h?.ok)
          throw new Error(
            h?.message || "AI\u8FD4\u56DE\u683C\u5F0F\u81EA\u52A8\u4FEE\u590D\u5931\u8D25",
          );
        if (((F = y(String(h.content || ""))), !F))
          throw new Error(
            "AI\u8FD4\u56DE\u683C\u5F0F\u5F02\u5E38\uFF0C\u81EA\u52A8\u4FEE\u590D\u540E\u4ECD\u65E0\u6CD5\u8BC6\u522B",
          );
        return {
          advice: k(F),
          model: `${h.provider || d.provider || "AI"} \xB7 ${h.model || d.model || "\u81EA\u52A8\u6A21\u578B"}`,
        };
      }
    }
    if (!o)
      throw new Error(
        "\u6CA1\u6709\u53EF\u7528\u7684Groq Key\uFF1B\u5982\u9700\u4F7F\u7528Gemini\u5907\u7528\uFF0C\u8BF7\u5148\u5728\u63D2\u4EF6\u8BBE\u7F6E\u4FDD\u5B58Google AI Studio API Key",
      );
    const Z = `${q}/${encodeURIComponent(r)}:generateContent`,
      _ = new AbortController(),
      ee = setTimeout(() => _.abort(), 5e4);
    let C;
    try {
      C = await fetch(Z, {
        method: "POST",
        signal: _.signal,
        headers: { "Content-Type": "application/json", "x-goog-api-key": o },
        body: JSON.stringify({
          systemInstruction: {
            parts: [
              { text: String(globalThis.ORANGE_AI_SYSTEM_PROMPT || "") },
              {
                text: `
# Relevant U.S. Culture / Interest Reference
Use only as optional rapport cues, never as stereotypes:
${JSON.stringify(E)}`,
              },
            ],
          },
          contents: [{ role: "user", parts: [{ text: b }] }],
          generationConfig: {
            maxOutputTokens: 1900,
            responseMimeType: "application/json",
            responseJsonSchema: G,
            thinkingConfig: Y(r),
          },
        }),
      });
    } catch (c) {
      throw c?.name === "AbortError"
        ? new Error(
            "Gemini \u751F\u6210\u8D85\u8FC7 50 \u79D2\uFF0C\u5DF2\u81EA\u52A8\u505C\u6B62\u3002\u5EFA\u8BAE\u5207\u6362 Gemini 3.5 Flash-Lite \u540E\u91CD\u8BD5",
          )
        : c;
    } finally {
      clearTimeout(ee);
    }
    const v = await C.text();
    let w = null;
    try {
      w = v ? JSON.parse(v) : null;
    } catch {}
    if (!C.ok) {
      const c = w?.error?.message || v || `HTTP ${C.status}`;
      throw new Error(`Google Gemini \u8BF7\u6C42\u5931\u8D25\uFF1A${c}`);
    }
    const x = B(L(w));
    if (!x) {
      const c = w?.promptFeedback?.blockReason || w?.candidates?.[0]?.finishReason;
      throw new Error(
        c
          ? `Gemini \u6CA1\u6709\u8FD4\u56DE\u53EF\u7528\u5185\u5BB9\uFF1A${c}`
          : "Gemini \u6CA1\u6709\u8FD4\u56DE\u53EF\u7528\u5185\u5BB9\uFF0C\u8BF7\u518D\u8BD5\u4E00\u6B21",
      );
    }
    const j = y(x);
    if (!j) {
      const c = a(w?.candidates?.[0]?.finishReason, 80);
      throw (
        console.error("[Orange AI Copilot] JSON parse failed", { finishReason: c, modelText: x }),
        c === "MAX_TOKENS"
          ? new Error("Gemini \u8F93\u51FA\u88AB\u622A\u65AD\uFF0C\u8BF7\u518D\u8BD5\u4E00\u6B21")
          : new Error(
              "Gemini \u8FD4\u56DE\u683C\u5F0F\u5F02\u5E38\uFF0C\u5DF2\u542F\u7528\u5BB9\u9519\u89E3\u6790\u4F46\u4ECD\u65E0\u6CD5\u8BC6\u522B",
            )
      );
    }
    return { advice: k(j), model: r };
  }
  async function Q(e, o) {
    const r = await chrome.storage.local.get(["orangePermissions", "orangeIsAdmin"]),
      s = r.orangePermissions || {},
      i = r.orangeIsAdmin === !0,
      n = (u) => i || s[u] === !0;
    let t = !1;
    try {
      t = /(^|\.)textnow\.com$/i.test(new URL(e?.url || "").hostname);
    } catch {}
    return t && !n("tn_assistant") ? !1 : n(o);
  }
  chrome.runtime.onMessage.addListener((e, o, r) => {
    if (e?.type === "ORANGE_AI_GET_SETTINGS")
      return (
        R()
          .then((i) =>
            r({ ok: !0, configured: !!i.apiKey, model: i.model, provider: "google-ai-studio" }),
          )
          .catch((i) =>
            r({ ok: !1, error: i?.message || "\u8BFB\u53D6 Gemini \u8BBE\u7F6E\u5931\u8D25" }),
          ),
        !0
      );
    if (e?.type !== "ORANGE_AI_GENERATE_ADVICE") return !1;
    const s = e?.mode === "reengage" ? "reengage" : "ai_reply";
    return (
      Q(o, s)
        .then((i) => {
          if (!i)
            throw new Error("\u5F53\u524D\u8D26\u53F7\u6CA1\u6709\u8BE5AI\u529F\u80FD\u6743\u9650");
          return X(e);
        })
        .then((i) => r({ ok: !0, ...i }))
        .catch((i) => {
          (console.error("[Orange AI Copilot] Gemini request failed", i),
            r({
              ok: !1,
              error: i?.message || "Gemini \u667A\u80FD\u63D0\u9192\u751F\u6210\u5931\u8D25",
            }));
        }),
      !0
    );
  });
})();
