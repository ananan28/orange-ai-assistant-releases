(() => {
  "use strict";
  const T = "ORANGE_OPE_FORBIDDEN_GUARD",
    d = "orange-ope-forbidden-dialog",
    z = /(^|\.)(?:opensms\.xin|opensms\.cc)$/i,
    E = "orangeOpeForbiddenGuardEnabled",
    F = new WeakMap();
  let i = !0;
  const N = [
      "hi",
      "hello",
      "hell0",
      "hey",
      "oh",
      "work",
      "w0rk",
      "working",
      "job",
      "jobs",
      "j0b",
      "foot",
      "contacts",
      "management",
      "email",
      "office",
      "coffee",
      "usa",
      "america",
      "company",
      "country",
      "phone",
      "number",
      "remember",
      "howdy",
      "whatsapp",
      "crypto",
      "cryptocurrency",
      "bitcoin",
      "usdt",
      "stock",
      "stocks",
      "shares",
      "equity",
      "investment",
      "invest",
      "trading",
      "gambling",
      "casino",
      "politics",
      "political",
      "porn",
      "sexual",
      "sex",
      "hookup",
    ],
    G = [
      "guess who i am",
      "how about you",
      "how are you",
      "how old are you",
      "are you okay",
      "what's your name",
      "do you remember it now",
      "long time no see",
      "long time",
      "how about",
      "how are",
      "extra income",
      "part-time",
      "part time",
      "hook up",
      "government official",
      "public official",
      "apply for official",
    ],
    I = [
      "\u7CBE\u804A",
      "\u517C\u804C",
      "\u80A1\u7968",
      "\u52A0\u5BC6\u8D27\u5E01",
      "\u989D\u5916\u6536\u5165",
      "\u8272\u60C5",
      "\u653F\u6CBB",
      "\u8D4C\u535A",
      "\u56FD\u5BB6\u540D",
      "\u7F8E\u56FD",
      "\u7533\u8BF7\u5B98\u5458",
      "\u7EA6\u70AE",
      "\u53CD\u8BC8",
      "\u53CD\u6B3A\u8BC8",
      "\u8BC8\u9A97",
      "\u53F7\u7801",
      "\u865F\u78BC",
      "\u7535\u8BDD",
      "\u96FB\u8A71",
      "\u901A\u8BAF\u5F55",
      "\u901A\u8A0A\u9304",
    ],
    P = [
      "Afghanistan",
      "Albania",
      "Algeria",
      "Andorra",
      "Angola",
      "Antigua and Barbuda",
      "Argentina",
      "Armenia",
      "Australia",
      "Austria",
      "Azerbaijan",
      "Bahamas",
      "Bahrain",
      "Bangladesh",
      "Barbados",
      "Belarus",
      "Belgium",
      "Belize",
      "Benin",
      "Bhutan",
      "Bolivia",
      "Bosnia and Herzegovina",
      "Botswana",
      "Brazil",
      "Brunei",
      "Bulgaria",
      "Burkina Faso",
      "Burundi",
      "Cabo Verde",
      "Cape Verde",
      "Cambodia",
      "Cameroon",
      "Canada",
      "Central African Republic",
      "Chad",
      "Chile",
      "China",
      "Colombia",
      "Comoros",
      "Congo",
      "Costa Rica",
      "Croatia",
      "Cuba",
      "Cyprus",
      "Czechia",
      "Czech Republic",
      "Denmark",
      "Djibouti",
      "Dominica",
      "Dominican Republic",
      "Ecuador",
      "Egypt",
      "El Salvador",
      "Equatorial Guinea",
      "Eritrea",
      "Estonia",
      "Eswatini",
      "Swaziland",
      "Ethiopia",
      "Fiji",
      "Finland",
      "France",
      "Gabon",
      "Gambia",
      "Georgia",
      "Germany",
      "Ghana",
      "Greece",
      "Grenada",
      "Guatemala",
      "Guinea",
      "Guinea-Bissau",
      "Guyana",
      "Haiti",
      "Honduras",
      "Hungary",
      "Iceland",
      "India",
      "Indonesia",
      "Iran",
      "Iraq",
      "Ireland",
      "Israel",
      "Italy",
      "Ivory Coast",
      "Cote d'Ivoire",
      "Jamaica",
      "Japan",
      "Jordan",
      "Kazakhstan",
      "Kenya",
      "Kiribati",
      "North Korea",
      "South Korea",
      "Kuwait",
      "Kyrgyzstan",
      "Laos",
      "Latvia",
      "Lebanon",
      "Lesotho",
      "Liberia",
      "Libya",
      "Liechtenstein",
      "Lithuania",
      "Luxembourg",
      "Madagascar",
      "Malawi",
      "Malaysia",
      "Maldives",
      "Mali",
      "Malta",
      "Marshall Islands",
      "Mauritania",
      "Mauritius",
      "Mexico",
      "Micronesia",
      "Moldova",
      "Monaco",
      "Mongolia",
      "Montenegro",
      "Morocco",
      "Mozambique",
      "Myanmar",
      "Burma",
      "Namibia",
      "Nauru",
      "Nepal",
      "Netherlands",
      "New Zealand",
      "Nicaragua",
      "Niger",
      "Nigeria",
      "North Macedonia",
      "Macedonia",
      "Norway",
      "Oman",
      "Pakistan",
      "Palau",
      "Palestine",
      "Panama",
      "Papua New Guinea",
      "Paraguay",
      "Peru",
      "Philippines",
      "Poland",
      "Portugal",
      "Qatar",
      "Romania",
      "Russia",
      "Rwanda",
      "Saint Kitts and Nevis",
      "Saint Lucia",
      "Saint Vincent and the Grenadines",
      "Samoa",
      "San Marino",
      "Sao Tome and Principe",
      "Saudi Arabia",
      "Senegal",
      "Serbia",
      "Seychelles",
      "Sierra Leone",
      "Singapore",
      "Slovakia",
      "Slovenia",
      "Solomon Islands",
      "Somalia",
      "South Africa",
      "South Sudan",
      "Spain",
      "Sri Lanka",
      "Sudan",
      "Suriname",
      "Sweden",
      "Switzerland",
      "Syria",
      "Taiwan",
      "Tajikistan",
      "Tanzania",
      "Thailand",
      "Timor-Leste",
      "East Timor",
      "Togo",
      "Tonga",
      "Trinidad and Tobago",
      "Tunisia",
      "Turkey",
      "Turkiye",
      "Turkmenistan",
      "Tuvalu",
      "Uganda",
      "Ukraine",
      "United Arab Emirates",
      "UAE",
      "United Kingdom",
      "UK",
      "United States",
      "United States of America",
      "USA",
      "America",
      "Uruguay",
      "Uzbekistan",
      "Vanuatu",
      "Vatican City",
      "Holy See",
      "Venezuela",
      "Vietnam",
      "Yemen",
      "Zambia",
      "Zimbabwe",
    ],
    K =
      /(?:https?:\/\/|www\.)\S+|\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:com|net|org|io|ai|co|us|cn|me|app|info|biz|xyz|site|link)\b/iu,
    _ = /[\u3400-\u9fff]/u,
    q =
      /(?:anti[-\s]?fraud|investment\s+(?:fraud|scam)|recover\s+the\s+funds|victim\s+of\s+investment)/iu;
  function v(e) {
    return String(e || "")
      .normalize("NFKC")
      .replace(/[’‘]/g, "'")
      .replace(/[‐‑‒–—]/g, "-")
      .replace(/\s+/g, " ")
      .trim();
  }
  function O(e) {
    return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function b(e, t) {
    return new RegExp(`(^|[^A-Za-z0-9])${O(t)}(?=$|[^A-Za-z0-9])`, "i").test(e);
  }
  function r(e, t) {
    e.some((n) => n.code === t.code && n.value.toLowerCase() === t.value.toLowerCase()) ||
      e.push(t);
  }
  function S(e, t = {}) {
    const n = v(e);
    if (!n) return [];
    const a = [];
    if (t.includeForbiddenWords !== !1) {
      for (const u of G)
        b(n, u) && r(a, { code: "phrase", value: u, reason: "\u7981\u7528\u8BDD\u672F" });
      for (const u of N)
        b(n, u) && r(a, { code: "word", value: u, reason: "\u7981\u7528\u5173\u952E\u8BCD" });
      for (const u of I)
        n.includes(u) &&
          r(a, {
            code: "chinese-keyword",
            value: u,
            reason: "\u4E2D\u6587\u7981\u7528\u5173\u952E\u8BCD",
          });
      const g = P.filter((u) => b(n, u));
      for (const u of g.slice(0, 5))
        r(a, { code: "country", value: u, reason: "\u56FD\u5BB6/\u5730\u533A\u540D\u79F0" });
      (q.test(n) &&
        r(a, {
          code: "anti-fraud",
          value: "Anti-Fraud / investment scam",
          reason: "\u53CD\u8BC8\u6216\u8FFD\u56DE\u8D44\u91D1\u8BDD\u672F",
        }),
        K.test(n) &&
          r(a, {
            code: "url",
            value: "\u94FE\u63A5/\u7F51\u5740",
            reason: "\u7981\u6B62\u53D1\u9001\u94FE\u63A5",
          }),
        _.test(n) &&
          r(a, {
            code: "chinese",
            value: "\u4E2D\u6587\u5185\u5BB9",
            reason: "OPE \u7981\u6B62\u53D1\u9001\u4E2D\u6587\u5185\u5BB9",
          }));
    }
    const o = Array.from(n).length;
    return (
      o > 300 &&
        r(a, {
          code: "length",
          value: `${o} \u4E2A\u5B57\u7B26`,
          reason: "\u8D85\u8FC7 300 \u4E2A\u5B57\u7B26\u9650\u5236",
        }),
      a
    );
  }
  function f(e) {
    if (!(e instanceof Element) || e.closest(`#${d}, #ai-bt-root, #orange-ai-reply-root`))
      return !1;
    if (e instanceof HTMLTextAreaElement) return !e.disabled && !e.readOnly;
    if (e instanceof HTMLInputElement) {
      const t = String(e.type || "text").toLowerCase();
      return ["text", "search"].includes(t) && !e.disabled && !e.readOnly && t !== "search";
    }
    return !!e.isContentEditable;
  }
  function R(e) {
    return e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement
      ? String(e.value || "")
      : String(e?.innerText || e?.textContent || "");
  }
  function m() {
    return document.querySelector(
      "#v-im-app .main-content .right, #v-im-app .main.content .right, #im-app .main-content .right, #im-app .main_content .right, #v-im-app .right, #im-app .right",
    );
  }
  function p(e = m()) {
    if (!(e instanceof Element)) return null;
    const t = document.activeElement;
    if (f(t) && e.contains(t)) return t;
    const n = [
      ".chat_message_operates textarea",
      ".chat_message_operates input[type='text']",
      ".chat_message_operates [contenteditable='true']",
      ".im-chat-input textarea",
      ".im-chat-input [contenteditable='true']",
      "textarea",
      "[contenteditable='true']",
      "input[type='text']",
    ];
    for (const a of n) {
      const o = Array.from(e.querySelectorAll(a)).filter(f);
      if (o.length) return o[o.length - 1];
    }
    return null;
  }
  function w(e, t) {
    if (!(e instanceof Element) || !t) return !1;
    const n = m();
    if (n && (!n.contains(e) || !n.contains(t))) return !1;
    const a = v(
      [
        e.textContent,
        e.getAttribute("aria-label"),
        e.getAttribute("title"),
        e.getAttribute("name"),
        e.getAttribute("id"),
        e.getAttribute("class"),
      ]
        .filter(Boolean)
        .join(" "),
    ).toLowerCase();
    return /(^|[\s_-])(send|sending|submit|发送|发出)([\s_-]|$)/i.test(a)
      ? !0
      : e.matches("button[type='submit'], input[type='submit']")
        ? !!e.closest("form")?.contains(t)
        : !!(
            t
              .closest(
                "form, .chat_message_operates, .im-chat-input, [class*='message-operate'], [class*='chat-input']",
              )
              ?.contains(e) && /el-button--primary|primary|submit/i.test(a)
          );
  }
  function h() {
    document.getElementById(d)?.remove();
  }
  function U(e, t, n) {
    h();
    const a = document.createElement("div");
    ((a.id = d), a.setAttribute("role", "dialog"), a.setAttribute("aria-modal", "true"));
    const o = document.createElement("div");
    o.className = "orange-ope-forbidden-card";
    const g = document.createElement("h2");
    g.textContent = "\u26A0\uFE0F OPE \u53D1\u9001\u63D0\u9192";
    const u = document.createElement("p");
    u.textContent =
      "\u672C\u6B21\u6D88\u606F\u547D\u4E2D\u4EE5\u4E0B\u63D0\u9192\uFF0C\u8BF7\u68C0\u67E5\u540E\u9009\u62E9\u662F\u5426\u7EE7\u7EED\u53D1\u9001\uFF1A";
    const C = document.createElement("ul");
    for (const c of e.slice(0, 12)) {
      const x = document.createElement("li"),
        M = document.createElement("strong");
      ((M.textContent = c.value),
        x.append(M, document.createTextNode(` \u2014 ${c.reason}`)),
        C.appendChild(x));
    }
    if (e.length > 12) {
      const c = document.createElement("li");
      ((c.textContent = `\u53E6\u6709 ${e.length - 12} \u9879\u547D\u4E2D\uFF0C\u8BF7\u7EE7\u7EED\u68C0\u67E5\u539F\u6587\u3002`),
        C.appendChild(c));
    }
    const B = document.createElement("p");
    ((B.className = "orange-ope-forbidden-note"),
      (B.textContent =
        "\u9009\u62E9\u201C\u8FD4\u56DE\u4FEE\u6539\u201D\u4E0D\u4F1A\u6539\u53D8\u8F93\u5165\u5185\u5BB9\uFF1B\u9009\u62E9\u201C\u786E\u5B9A\u53D1\u9001\u201D\u5C06\u6309\u539F\u6587\u7EE7\u7EED\u3002"));
    const A = document.createElement("div");
    A.className = "orange-ope-forbidden-actions";
    const s = document.createElement("button");
    ((s.type = "button"),
      (s.className = "orange-ope-return-edit"),
      (s.textContent = "\u8FD4\u56DE\u4FEE\u6539"),
      s.addEventListener("click", () => {
        (h(), t?.focus?.({ preventScroll: !0 }));
      }));
    const l = document.createElement("button");
    ((l.type = "button"),
      (l.className = "orange-ope-confirm-send"),
      (l.textContent = "\u786E\u5B9A\u53D1\u9001"),
      l.addEventListener("click", () => {
        (F.set(t, Date.now() + 1500), h(), n?.());
      }),
      A.append(s, l),
      o.append(g, u, C, B, A),
      a.appendChild(o),
      a.addEventListener("click", (c) => {
        c.target === a && s.click();
      }),
      document.body.appendChild(a),
      s.focus({ preventScroll: !0 }));
  }
  function y(e, t, n) {
    if (Date.now() < Number(F.get(t) || 0)) return !1;
    const a = S(R(t), { includeForbiddenWords: i });
    return a.length
      ? (e.preventDefault(), e.stopPropagation(), e.stopImmediatePropagation?.(), U(a, t, n), !0)
      : !1;
  }
  function D(e) {
    if (!e) return;
    (e.classList.toggle("is-active", i), e.setAttribute("aria-pressed", i ? "true" : "false"));
    const t = e.querySelector("small");
    t &&
      (t.textContent = i
        ? "\u5DF2\u5F00\u542F \xB7 \u53D1\u9001\u524D\u63D0\u9192"
        : "\u5DF2\u5173\u95ED \xB7 \u4E0D\u68C0\u67E5\u8FDD\u7981\u8BCD");
  }
  function k() {
    const e = document.querySelector("#ai-bt-root .ai-bt-actions");
    if (!e || e.querySelector("[data-orange-ope-guard-toggle]")) return !1;
    const t = document.createElement("button");
    return (
      (t.type = "button"),
      (t.dataset.orangeOpeGuardToggle = "true"),
      (t.innerHTML =
        '<span class="ai-bt-action-icon">\u{1F6E1}\uFE0F</span><span><strong>\u8FDD\u7981\u8BCD\u63D0\u9192</strong><small></small></span><span class="ai-bt-mode-switch"><i></i></span>'),
      t.addEventListener("click", (n) => {
        (n.preventDefault(),
          n.stopPropagation(),
          (i = !i),
          D(t),
          chrome.storage.local.set({ [E]: i }));
      }),
      e.appendChild(t),
      D(t),
      !0
    );
  }
  function L() {
    if (z.test(location.hostname)) {
      if (
        (chrome.storage.local.get([E], (e) => {
          ((i = e?.[E] !== !1), D(document.querySelector("[data-orange-ope-guard-toggle]")));
        }),
        !k())
      ) {
        const e = new MutationObserver(() => {
          k() && e.disconnect();
        });
        (e.observe(document.documentElement, { childList: !0, subtree: !0 }),
          setTimeout(() => e.disconnect(), 3e4));
      }
      (document.addEventListener(
        "keydown",
        (e) => {
          if (
            e.key !== "Enter" ||
            e.shiftKey ||
            e.ctrlKey ||
            e.altKey ||
            e.metaKey ||
            e.isComposing
          )
            return;
          const t = e.target instanceof Element && f(e.target) ? e.target : p(),
            n = m();
          t &&
            n?.contains(t) &&
            y(e, t, () => {
              const a = Array.from(
                n.querySelectorAll("button, input[type='submit'], [role='button'], .el-button"),
              ).find((o) => w(o, t));
              a
                ? a.click()
                : t.dispatchEvent(
                    new KeyboardEvent("keydown", {
                      key: "Enter",
                      code: "Enter",
                      bubbles: !0,
                      cancelable: !0,
                    }),
                  );
            });
        },
        !0,
      ),
        document.addEventListener(
          "click",
          (e) => {
            const t =
              e.target instanceof Element
                ? e.target.closest("button, input[type='submit'], [role='button'], .el-button")
                : null;
            if (!t || t.closest(`#${d}`)) return;
            const n = p();
            w(t, n) && y(e, n, () => t.click());
          },
          !0,
        ),
        document.addEventListener(
          "submit",
          (e) => {
            const t = m();
            if (!t) return;
            const n =
              (e.target instanceof Element && t.contains(e.target) ? p(e.target) : null) || p(t);
            n &&
              y(e, n, () => {
                typeof e.target.requestSubmit == "function"
                  ? e.target.requestSubmit()
                  : e.target.submit?.();
              });
          },
          !0,
        ));
    }
  }
  ((globalThis[T] = Object.freeze({ detect: S, MAX_MESSAGE_CHARACTERS: 300 })),
    typeof document < "u" &&
      (document.readyState === "loading"
        ? document.addEventListener("DOMContentLoaded", L, { once: !0 })
        : L()));
})();
