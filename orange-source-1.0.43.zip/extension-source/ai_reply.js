(() => {
  "use strict";
  const S = "orange-ai-reply-root",
    Y = "ai-bt-root",
    be = `#${Y} .ai-bt-actions`,
    Z = "data-orange-ai-reply",
    k = "data-orange-ai-reflow",
    oe = "orange-ai-reply-toast",
    I = "orange-ai-copilot-panel",
    U = { test: () => !0 },
    ye = "orangeAiContactMemory:v1:",
    Ae = "orangeAutoCleanSendBreaks",
    Be = "orangePreserveSendParagraphs";
  let W = !1,
    N = null,
    O = 0,
    re = {},
    ie = !1;
  function P(e) {
    return ie || re[String(e || "")] === !0;
  }
  function G() {
    return !/(^|\.)textnow\.com$/i.test(location.hostname) || P("tn_assistant");
  }
  function h(e) {
    return String(e || "")
      .replace(/\s+/g, " ")
      .trim();
  }
  function p(e) {
    if (!(e instanceof Element)) return !1;
    const t = getComputedStyle(e);
    if (t.display === "none" || t.visibility === "hidden" || Number(t.opacity) === 0) return !1;
    const n = e.getBoundingClientRect();
    return n.width >= 20 && n.height >= 14 && n.bottom >= 0 && n.top <= innerHeight;
  }
  function Ce(e) {
    if (!(e instanceof Element) || !p(e) || e.closest(`#${Y}, #${S}`)) return !1;
    if (e instanceof HTMLTextAreaElement) return !e.disabled && !e.readOnly;
    if (e instanceof HTMLInputElement) {
      const t = String(e.type || "text").toLowerCase();
      return ["text", "search", "email", "url", "tel"].includes(t) && !e.disabled && !e.readOnly;
    }
    return !!e.isContentEditable;
  }
  function K(e) {
    return e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement
      ? String(e.value || "")
      : String(e?.innerText || e?.textContent || "");
  }
  function se(e) {
    const t = String(e || "")
      .replace(
        /\r\n?/g,
        `
`,
      )
      .replace(/[\u200B-\u200D\u2060\uFEFF]/g, "")
      .replace(/\u00A0/g, " ")
      .replace(
        /[ \t]+\n/g,
        `
`,
      )
      .replace(
        /\n[ \t]+/g,
        `
`,
      )
      .trim();
    return localStorage.getItem(Be) !== "false"
      ? t
          .split(/\n\s*\n+/)
          .map((n) =>
            n
              .replace(/\s*\n\s*/g, " ")
              .replace(/[ \t]{2,}/g, " ")
              .trim(),
          )
          .filter(Boolean).join(`
`)
      : t
          .replace(/\s*\n+\s*/g, " ")
          .replace(/[ \t]{2,}/g, " ")
          .trim();
  }
  function V() {
    if (localStorage.getItem(Ae) === "false") return;
    const e = w();
    if (!e) return;
    const t = K(e),
      n = se(t);
    n && n !== t && ce(e, n);
  }
  function X(e) {
    if (e?.isConnected) {
      if (
        (e.focus({ preventScroll: !0 }),
        e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement)
      ) {
        const t = String(e.value || "").length;
        try {
          e.setSelectionRange(t, t);
        } catch {}
        return;
      }
      if (e.isContentEditable) {
        const t = window.getSelection(),
          n = document.createRange();
        (n.selectNodeContents(e), n.collapse(!1), t?.removeAllRanges(), t?.addRange(n));
      }
    }
  }
  function ce(e, t) {
    const n = se(t);
    if (e instanceof HTMLInputElement) {
      const u = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      u ? u.call(e, n) : (e.value = n);
    } else if (e instanceof HTMLTextAreaElement) {
      const u = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      u ? u.call(e, n) : (e.value = n);
    } else if (e?.isContentEditable) e.textContent = n;
    else return !1;
    try {
      e.dispatchEvent(
        new InputEvent("input", { bubbles: !0, composed: !0, inputType: "insertText", data: n }),
      );
    } catch {
      e.dispatchEvent(new Event("input", { bubbles: !0, composed: !0 }));
    }
    return (X(e), requestAnimationFrame(() => X(e)), setTimeout(() => X(e), 0), !0);
  }
  function H() {
    return (
      document.querySelector("#v-im-app .main-content .right") ||
      document.querySelector("#v-im-app .main.content .right") ||
      document.querySelector("#im-app .main-content .right") ||
      document.querySelector("#im-app .main_content .right") ||
      document.querySelector("div.main-content div.right") ||
      document.querySelector("#v-im-app .right, #im-app .right") ||
      null
    );
  }
  function F(e) {
    if (!Ce(e)) return !1;
    if (!/(^|\.)(?:opensms\.xin|opensms\.cc)$/i.test(location.hostname)) return !0;
    const t = H();
    return !t || t.contains(e);
  }
  function w() {
    const e = document.activeElement;
    if (F(e)) return e;
    if (F(N) && N.isConnected) return N;
    const t = typeof Q < "u" ? Q.find((r) => r.host.test(location.hostname)) : null;
    if (t?.editors?.length)
      for (const r of t.editors) {
        const a = Array.from(document.querySelectorAll(r)).filter((s) => F(s) && p(s));
        if (a.length) return a[a.length - 1];
      }
    const n = (/(^|\.)(?:opensms\.xin|opensms\.cc)$/i.test(location.hostname) && H()) || document,
      u = ["textarea", "[contenteditable='true']", "input[type='text']", "input:not([type])"],
      o = [];
    for (const r of u)
      n.querySelectorAll(r).forEach((a) => {
        F(a) && o.push(a);
      });
    return o.length
      ? (o.sort((r, a) => {
          const s = r.getBoundingClientRect(),
            i = a.getBoundingClientRect(),
            l = s.bottom + Math.min(s.width, 900) * 0.1;
          return i.bottom + Math.min(i.width, 900) * 0.1 - l;
        }),
        o[0] || null)
      : null;
  }
  function ve(e, t, n) {
    const u = `${e?.className || ""} ${t?.className || ""}`.toLowerCase();
    if (/im-chat-other|incoming|receive|received|opponent|customer/.test(u)) return "Them";
    if (/im-chat-user|im-chat-self|im-chat-mine|outgoing|sent|mine|self/.test(u)) return "You";
    if (n && t instanceof Element) {
      const o = n.getBoundingClientRect(),
        r = t.getBoundingClientRect();
      return r.left + r.width / 2 >= o.left + o.width / 2 ? "You" : "Them";
    }
    return "Chat";
  }
  function R(e) {
    if (!(e instanceof Element)) return "";
    const t = e.cloneNode(!0);
    t.querySelectorAll(
      ".ai-bt-chat-translation, .ai-bt-page-translation, .ai-bt-generated, .ai-bt-phone-mask-layer, .oz-bubble-character, .oz-time-character, .oz-time-character-img, button, svg, img",
    ).forEach((u) => u.remove());
    let n = h(t.textContent || "");
    return (
      (n = n
        .replace(/\b20\d{2}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?\b/g, " ")
        .replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g, " ")
        .replace(/(?:已发送|已送达|发送中|送达|发送失败|delivered|sent)\b/gi, " ")
        .replace(/\s+/g, " ")
        .trim()),
      n
    );
  }
  function xe() {
    const e = H();
    if (!e) return "";
    const t = [
      ".im-chat-other .im-chat-text",
      ".im-chat-user .im-chat-text",
      ".im-chat-self .im-chat-text",
      ".im-chat-mine .im-chat-text",
    ];
    let n = Array.from(e.querySelectorAll(t.join(", ")));
    n.length ||
      (n = Array.from(
        e.querySelectorAll(
          ".im-chat-text, .message-content, [class*='message-content'], [class*='message-text']",
        ),
      ));
    const u = [],
      o = new Set();
    for (const r of n) {
      if (!(r instanceof Element) || o.has(r)) continue;
      o.add(r);
      const a = R(r);
      if (!a) continue;
      const s = r.closest(
          ".im-chat-other, .im-chat-user, .im-chat-self, .im-chat-mine, .chat-message, .chat_message, .message-item, .message_item, [class*='chat-message'], [class*='message-item']",
        ),
        i = ve(s, r, e);
      u.push(`${i}: ${a}`);
    }
    return u.join(`
`);
  }
  const Q = [
      {
        host: /(^|\.)textnow\.com$/i,
        containers: ["#messageView", "#messageView ul"],
        messages: ["li.chat-item.incoming", "li.chat-item.outgoing", "li.chat-item"],
        editors: ["textarea#text-input", "textarea[placeholder*='Type a message' i]"],
        platform: "textnow",
      },
      {
        host: /(^|\.)xinghansms\.net$/i,
        containers: [
          ".chat_right_body .chat_message .el-scrollbar__view",
          ".chat_right_body .chat_message",
          ".chat_right .chat_message .el-scrollbar__view",
          ".chat_right .chat_message",
        ],
        messages: [
          ":scope > *",
          "[class*='message-item']",
          "[class*='message-row']",
          "[class*='message-content']",
          "[class*='message-text']",
        ],
        editors: [
          ".chat_right_body .chat_message_operates textarea",
          ".chat_right_body .chat_message_operates input[type='text']",
          ".chat_right_body .chat_message_operates [contenteditable='true']",
          ".chat_message_operates textarea",
          ".chat_message_operates input[type='text']",
          ".chat_message_operates [contenteditable='true']",
        ],
        platform: "xinghan",
      },
      {
        host: /(^|\.)client\.xhsim\.ai$/i,
        containers: ["#messageParent"],
        messages: [":scope > [id^='chatMessage_']", "[id^='chatMessage_']"],
        editors: [
          "#kt_chat_messenger_footer textarea",
          "#kt_chat_messenger_footer [contenteditable='true']",
          "#kt_chat_messenger_footer input[type='text']",
          "textarea[placeholder*='Type a message' i]",
        ],
        platform: "xhsim",
      },
      {
        host: /(^|\.)c2csms\.com$/i,
        containers: [
          ".chat-panel .chat-content .messages-area .messages-list",
          ".chat-content .messages-area .messages-list",
          ".messages-area .messages-list",
          ".messages-list",
        ],
        messages: [
          ":scope > *",
          "[class*='message-item']",
          "[class*='message-row']",
          "[class*='message-content']",
          "[class*='message-text']",
          "[class*='bubble']",
        ],
        editors: [
          ".chat-panel .input-area textarea",
          ".chat-panel .input-area input[type='text']",
          ".chat-panel .input-area [contenteditable='true']",
          ".input-area textarea",
          ".input-area input[type='text']",
          ".input-area [contenteditable='true']",
        ],
        platform: "c2c",
      },
      {
        host: /(^|\.)skt1\.net$/i,
        containers: [
          ".chat_right_body .chat_message .el-scrollbar__view",
          ".chat_right_body .chat_message",
          ".chat_right .chat_message .el-scrollbar__view",
          ".chat_right .chat_message",
        ],
        messages: [
          ":scope > div",
          "[class*='message-item']",
          "[class*='message-row']",
          "[class*='message-content']",
          "[class*='message-text']",
        ],
        editors: [
          ".chat_right_body .chat_message_operates .inputchat_message_operate_text",
          ".chat_message_operates .inputchat_message_operate_text",
          ".chat_right_body .chat_message_operates input[type='text']",
        ],
        platform: "skt1",
      },
    ],
    $e = {
      host: /.*/,
      containers: [
        ".chat_message",
        ".messages-list",
        ".messages-area",
        ".chat-content",
        ".conversation-content",
        ".chat-panel",
        "[class*='chat-message']",
        "[class*='messages-list']",
        "[class*='conversation-content']",
      ],
      messages: [
        ":scope > *",
        "[class*='message-item']",
        "[class*='message-row']",
        "[class*='message-content']",
        "[class*='message-text']",
        "[class*='bubble']",
        ".im-chat-text",
      ],
      editors: [
        "textarea",
        "[contenteditable='true']",
        ".input-area input[type='text']",
        ".chat-input input[type='text']",
        "[class*='input-area'] input[type='text']",
        "[class*='chat-input'] input[type='text']",
      ],
      platform: "generic",
    };
  function _e() {
    const e = Q.find((u) => u.host.test(location.hostname)) || $e,
      t = w(),
      n = [];
    for (const u of e.containers)
      document.querySelectorAll(u).forEach((o) => {
        if (!(o instanceof Element) || n.includes(o)) return;
        let r = 0;
        (t && o.contains(t) && (r += 1e5),
          p(o) && (r += 1e4),
          (r += Math.min(o.querySelectorAll("[class*='message'], p").length, 1e3)),
          n.push(o),
          (o.__orangeAiScopeScore = r));
      });
    return (
      n.sort((u, o) => (o.__orangeAiScopeScore || 0) - (u.__orangeAiScopeScore || 0)),
      n[0] ? { scope: n[0], config: e } : null
    );
  }
  function Se(e, t) {
    if (!(e instanceof Element)) return e?.getBoundingClientRect?.() || null;
    const n = t?.getBoundingClientRect?.(),
      u = [e, ...e.querySelectorAll("p, span, div")];
    let o = null,
      r = 1 / 0;
    for (const a of u) {
      if (!(a instanceof Element) || !p(a)) continue;
      const s = R(a);
      if (!s || s.length > 1800) continue;
      const i = a.getBoundingClientRect();
      if (
        i.width < 8 ||
        i.height < 8 ||
        (n && (i.width > n.width * 0.94 || i.height > Math.max(220, n.height * 0.55)))
      )
        continue;
      const l = Array.from(a.children).filter((E) => {
          if (!(E instanceof Element)) return !1;
          const m = R(E);
          return m && m.length >= Math.max(4, s.length * 0.55);
        }).length,
        c = i.width * i.height + l * 1e5;
      c < r && ((o = i), (r = c));
    }
    return o || e.getBoundingClientRect();
  }
  function ke(e, t, n) {
    const u = String(e?.className || "").toLowerCase();
    if (/incoming|receive|received|other|customer|left/.test(u)) return "Them";
    if (/outgoing|sent|mine|self|right/.test(u)) return "You";
    if (n?.platform === "xhsim" && e instanceof HTMLElement) {
      const a = String(e.getAttribute("style") || "").toLowerCase(),
        s = parseFloat(e.style.marginRight || "0") || 0,
        i = parseFloat(e.style.marginLeft || "0") || 0;
      if ((/margin-right/.test(a) && s > 0 && i <= 0) || /text-align\s*:\s*right/.test(a))
        return "You";
      if ((/margin-left/.test(a) && i > 0 && s <= 0) || /text-align\s*:\s*left/.test(a))
        return "Them";
    }
    const o = t?.getBoundingClientRect?.(),
      r = Se(e, t);
    if (o && r) {
      const a = o.left + o.width / 2;
      return r.left + r.width / 2 >= a ? "You" : "Them";
    }
    return "Chat";
  }
  function we() {
    const e = _e();
    if (!e) return "";
    const { scope: t, config: n } = e;
    let u = [];
    for (const a of n.messages) {
      const s = Array.from(t.querySelectorAll(a));
      if (s.length) {
        u = s;
        break;
      }
    }
    if (!u.length) return "";
    const o = [],
      r = new Set();
    for (const a of u) {
      if (!(a instanceof Element) || r.has(a)) continue;
      r.add(a);
      const s = R(a);
      if (!s) continue;
      const i = a.closest(
          ".chat-message, .chat_message, .message-item, .message_item, [class*='chat-message'], [class*='message-item'], [class*='message-row'], [id^='chatMessage_']",
        ),
        l = ke(i && i !== t ? i : a, t, n);
      o.push(`${l}: ${s}`);
    }
    return o.join(`
`);
  }
  function L() {
    return /(^|\.)(?:opensms\.xin|opensms\.cc)$/i.test(location.hostname) ? xe() : we();
  }
  function Le() {
    return (
      document.querySelector("#v-im-app .main-content .left") ||
      document.querySelector("#v-im-app .main.content .left") ||
      document.querySelector("#im-app .main-content .left") ||
      document.querySelector("#im-app .main_content .left") ||
      document.querySelector("div.main-content div.left") ||
      null
    );
  }
  function Te(e) {
    const t = String(e || "");
    let n = 2166136261;
    for (let u = 0; u < t.length; u += 1) ((n ^= t.charCodeAt(u)), (n = Math.imul(n, 16777619)));
    return (n >>> 0).toString(36);
  }
  function y(e) {
    return h(e)
      .replace(/未读|回复|发送|发信人|收信人/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 180);
  }
  function g(e) {
    try {
      return globalThis.ORANGE_NANP_LOOKUP?.normalizeNanpPhone?.(e) || "";
    } catch {
      return "";
    }
  }
  function Me(e) {
    try {
      return globalThis.ORANGE_NANP_LOOKUP?.lookup?.(e) || null;
    } catch {
      return null;
    }
  }
  function qe() {
    const e = document.querySelector("#v-im-app, #im-app") || document.body;
    if (!(e instanceof Element)) return null;
    function t(a) {
      const s = h(a),
        i = s.search(/对方号码\s*[:：]?/i);
      if (i < 0) return "";
      let l = s.slice(i).replace(/^.*?对方号码\s*[:：]?\s*/i, "");
      return ((l = l.split(/我方号码|搜索收信人号码|发信人|收信人/i)[0] || l), g(l));
    }
    const n = document.createTreeWalker(e, NodeFilter.SHOW_TEXT);
    let u;
    for (; (u = n.nextNode()); ) {
      const a = String(u.nodeValue || "");
      if (!/对方号码/i.test(a)) continue;
      let s = u.parentElement;
      for (
        let i = 0;
        s && i < 5 && !s.closest?.(`#${S}, #${Y}, #${I}`);
        i += 1, s = s.parentElement
      ) {
        const l = h(s.innerText || s.textContent || "");
        if (!l || l.length > 500) continue;
        const c = t(l);
        if (c) return { phone: c, source: "opponent-number-field", label: l };
      }
    }
    const o = h(e.innerText || e.textContent || ""),
      r = t(o);
    return r
      ? { phone: r, source: "opponent-number-label", label: `\u5BF9\u65B9\u53F7\u7801 ${r}` }
      : null;
  }
  function Ie() {
    if (!/(^|\.)skt1\.net$/i.test(location.hostname)) return null;
    const e = Array.from(
      document.querySelectorAll(
        ".chat_right_container .header, .chat_right .header, .chat_right_body .header",
      ),
    );
    for (const u of e) {
      if (!(u instanceof Element) || !p(u)) continue;
      const o = h(u.innerText || u.textContent || "");
      if (!o || !o.includes(">")) continue;
      const r = o.split(">").pop() || "",
        a = g(r);
      if (a) return { phone: a, source: "skt1-chat-header", label: o };
    }
    const t = document.querySelector(".chat_right_body, .chat_right, [class*='chat_right']");
    if (t instanceof Element)
      for (const u of t.querySelectorAll("div,span,p")) {
        if (!p(u)) continue;
        const o = h(u.innerText || u.textContent || "");
        if (!o || o.length > 100 || !/(?:>|→|->)/.test(o)) continue;
        const r = o.split(/(?:>|→|->)/).pop() || "",
          a = g(r);
        if (a) return { phone: a, source: "skt1-current-chat-generic-header", label: o };
      }
    const n = document.querySelector(".chat_left, .chat-left, [class*='chat_left']");
    if (n) {
      const u = Array.from(
        n.querySelectorAll(
          ".is-active, .active, .selected, [aria-selected='true'], [aria-current='true'], [data-selected='true']",
        ),
      );
      for (const o of u) {
        if (!(o instanceof Element) || !p(o)) continue;
        const r = h(o.innerText || o.textContent || ""),
          a = g(r);
        if (a) return { phone: a, source: "skt1-selected-contact", label: r };
      }
    }
    return null;
  }
  function Ne() {
    if (!/(^|\.)xinghansms\.net$/i.test(location.hostname)) return null;
    const e = [
      ".chat_right .chat_right_header",
      ".chat_right_header",
      ".chat_right_body .chat_right_container .header",
      ".chat_right_container .header",
      ".chat_right_body .header",
    ];
    for (const n of e)
      for (const u of document.querySelectorAll(n)) {
        if (!(u instanceof Element) || !p(u)) continue;
        const o = h(u.innerText || u.textContent || "");
        if (!o || !/(?:->|→|>)/.test(o)) continue;
        const r = o.split(/(?:->|→|>)/).pop() || "",
          a = g(r);
        if (a) return { phone: a, source: "xinghan-chat-header", label: o };
      }
    const t = document.querySelector(".chat_right, [class*='chat_right']");
    if (t instanceof Element) {
      const n = Array.from(t.querySelectorAll("div, span, p"));
      for (const u of n) {
        if (!p(u)) continue;
        const o = h(u.innerText || u.textContent || "");
        if (!o || o.length > 120 || !/(?:->|→|>)/.test(o)) continue;
        const r = o.split(/(?:->|→|>)/).pop() || "",
          a = g(r);
        if (a) return { phone: a, source: "xinghan-current-chat-fallback", label: o };
      }
    }
    return null;
  }
  function Oe() {
    if (!/(^|\.)c2csms\.com$/i.test(location.hostname)) return null;
    const e = Array.from(
      document.querySelectorAll(
        ".chat-panel .chat-content .chat-header, .chat-content .chat-header, .chat-panel .chat-header, .chat-header",
      ),
    );
    for (const n of e) {
      if (!(n instanceof Element) || !p(n)) continue;
      const u = h(n.innerText || n.textContent || "");
      if (!u || u.length > 350) continue;
      const o = g(u);
      if (o) return { phone: o, source: "c2c-chat-header", label: u };
    }
    const t = Array.from(
      document.querySelectorAll(
        ".conversation-panel, [class*='conversation-panel'], [class*='conversation-list']",
      ),
    );
    for (const n of t) {
      const u = n.querySelector(
        ".active, .is-active, .selected, [aria-selected='true'], [aria-current='true'], [data-selected='true']",
      );
      if (!(u instanceof Element) || !p(u)) continue;
      const o = h(u.innerText || u.textContent || ""),
        r = o.match(/收信人\s*[:：]?\s*(?:\+?1[\s().-]*)?(?:\(?\d{3}\)?[\s.-]*)\d{3}[\s.-]*\d{4}/i),
        a = g(r?.[0] || "");
      if (a) return { phone: a, source: "c2c-selected-recipient", label: o };
    }
    return null;
  }
  function Pe() {
    if (!/(^|\.)client\.xhsim\.ai$/i.test(location.hostname)) return null;
    const e = document.querySelector("#messageParent"),
      t = [];
    let n = e?.parentElement;
    for (let u = 0; n && u < 6; u += 1, n = n.parentElement) t.push(n);
    for (const u of t) {
      const o = Array.from(u.querySelectorAll("input,button,span,div,p"));
      for (const r of o) {
        if (!(r instanceof Element) || !p(r) || e?.contains(r)) continue;
        const a = y(r.value || r.innerText || r.textContent || "");
        if (!a || a.length > 80 || /[*]{2,}/.test(a)) continue;
        const s = g(a);
        if (s) return { phone: s, source: "xhsim-current-chat-header", label: a };
      }
    }
    return null;
  }
  function T(e) {
    let t = "",
      n = "\u5F53\u524D\u8054\u7CFB\u4EBA",
      u = "";
    if (/(^|\.)textnow\.com$/i.test(location.hostname)) {
      const a = document.querySelector(
          ".conversation-title__name[data-number], .conversation-title_name[data-number]",
        ),
        s = a?.getAttribute("data-number") || "",
        i = y(a?.textContent || ""),
        l = g(s) || g(i);
      l && ((t = l), (n = i || l), (u = "textnow-conversation-title"));
    }
    if (/(^|\.)client\.xhsim\.ai$/i.test(location.hostname)) {
      const a = Pe();
      a?.phone && ((t = a.phone), (n = a.label || a.phone), (u = a.source));
    }
    if (/(^|\.)xinghansms\.net$/i.test(location.hostname)) {
      const a = Ne();
      a?.phone && ((t = a.phone), (n = a.label || a.phone), (u = a.source));
    }
    if (!t && /(^|\.)c2csms\.com$/i.test(location.hostname)) {
      const a = Oe();
      a?.phone && ((t = a.phone), (n = a.label || a.phone), (u = a.source));
    }
    if (!t && /(^|\.)skt1\.net$/i.test(location.hostname)) {
      const a = Ie();
      a?.phone && ((t = a.phone), (n = a.label || a.phone), (u = a.source));
    }
    if (!t && U.test(location.hostname)) {
      const a = qe();
      a?.phone && ((t = a.phone), (n = a.label || a.phone), (u = a.source));
    }
    if (!t && /(^|\.)(?:opensms\.xin|opensms\.cc)$/i.test(location.hostname)) {
      const a = Le(),
        s =
          a?.querySelector(".oz-contact-card.oz-selected") ||
          a?.querySelector(
            "[aria-selected='true'], [aria-current='true'], [data-selected='true']",
          ) ||
          a?.querySelector(
            ".oz-contact-card.is-active, .oz-contact-card.active, .oz-contact-card.selected",
          );
      if (s) {
        const i = y(s.innerText || s.textContent || ""),
          l = g(i);
        ((t = l || i), (n = i || l || n), l && (u = "selected-contact-fallback"));
      }
      if (!t) {
        const i = H()?.querySelector(
            ".chat-header, .conversation-header, [class*='chat-header'], [class*='conversation-header'], [class*='user-info'], [class*='contact-info']",
          ),
          l = y(i?.innerText || i?.textContent || ""),
          c = g(l);
        ((t = c || l), (n = l || c || n), c && (u = "conversation-header-fallback"));
      }
    }
    if (!t) {
      const a = document.querySelector(
          ".active[aria-selected], .selected[aria-selected], [aria-selected='true'], [aria-current='true'], [data-selected='true']",
        ),
        s = document.querySelector(
          ".chat-header, .conversation-header, [class*='chat-header'], [class*='conversation-header'], [class*='recipient-info'], [class*='contact-info']",
        );
      for (const i of [s, a]) {
        if (!(i instanceof Element) || !p(i)) continue;
        const l = y(i.innerText || i.textContent || ""),
          c = g(l);
        if (c) {
          ((t = c), (n = l || c), (u = "generic-current-conversation"));
          break;
        }
      }
    }
    if (!t) {
      const a = `${location.hostname}|${location.pathname}|${location.hash}`,
        s =
          String(e || "")
            .split(
              `
`,
            )
            .find((i) => /^Them:\s*/.test(i)) || "";
      ((t = `${a}|${s.slice(0, 160)}`), (n = y(s.replace(/^Them:\s*/, "")) || n));
    }
    const o = g(t) || g(n),
      r = o ? Me(o) : null;
    return (
      r && o && ((r.scannedPhone = o), (r.phoneSource = u || "fallback")),
      {
        key: `${ye}${location.hostname}:${Te(o || t)}`,
        label: n.slice(0, 120),
        rawHint: t.slice(0, 160),
        phoneDigits: o,
        phoneSource: u,
        areaLookup: r,
      }
    );
  }
  globalThis.ORANGE_GET_CURRENT_IDENTITY = () => T(L());
  function le(e, t = 20) {
    const n = [],
      u = new Set();
    for (const o of Array.isArray(e) ? e : []) {
      const r = h(o);
      if (!r) continue;
      const a = r.toLowerCase();
      if (!u.has(a) && (u.add(a), n.push(r), n.length >= t)) break;
    }
    return n;
  }
  function j(e, t) {
    const n = `${t}: `,
      u = String(e || "")
        .split(
          `
`,
        )
        .map((o) => o.trim())
        .filter(Boolean);
    for (let o = u.length - 1; o >= 0; o -= 1)
      if (u[o].startsWith(n)) return u[o].slice(n.length).trim();
    return "";
  }
  function de(e) {
    const t = String(e || "")
        .split(
          `
`,
        )
        .map((u) => u.trim())
        .filter(Boolean),
      n = t[t.length - 1] || "";
    return n.startsWith("Them: ") ? "Them" : n.startsWith("You: ") ? "You" : "Chat";
  }
  function He(e) {
    return /\b(stop (?:texting|messaging|contacting)|do not contact|don['’]?t contact|don['’]?t text|leave me alone|not interested in (?:talking|chatting)|remove my number|unsubscribe)\b/i.test(
      String(e || ""),
    );
  }
  function J(e, t) {
    const n = e?.activity && typeof e.activity == "object" ? e.activity : {},
      u = new Date().toISOString(),
      o = j(t, "Them"),
      r = j(t, "You"),
      a = { ...n };
    return (
      !a.lastCustomerMessage && o
        ? ((a.lastCustomerMessage = o), (a.lastCustomerReplyAt = a.lastCustomerReplyAt || ""))
        : o &&
          o !== a.lastCustomerMessage &&
          ((a.lastCustomerMessage = o), (a.lastCustomerReplyAt = u)),
      !a.lastOutgoingMessage && r
        ? ((a.lastOutgoingMessage = r), (a.lastOutgoingAt = a.lastOutgoingAt || ""))
        : r && r !== a.lastOutgoingMessage && ((a.lastOutgoingMessage = r), (a.lastOutgoingAt = u)),
      (a.lastSpeaker = de(t)),
      (a.lastObservedAt = u),
      (a.explicitStop = He(o) || e?.continuationSignal === "explicit_stop"),
      a
    );
  }
  function Re(e) {
    const t = e?.lastCustomerReplyAt || e?.lastOutgoingAt || "";
    if (!t) return { label: "\u65F6\u957F\u672A\u77E5", hours: null, bucket: "unknown" };
    const n = Date.now() - Date.parse(t);
    if (!Number.isFinite(n) || n < 0)
      return { label: "\u65F6\u957F\u672A\u77E5", hours: null, bucket: "unknown" };
    const u = n / 36e5;
    if (u < 24)
      return {
        label: `${Math.max(1, Math.round(u))} \u5C0F\u65F6\u5185`,
        hours: u,
        bucket: "under_1d",
      };
    const o = Math.floor(u / 24);
    return o <= 3
      ? { label: `${o} \u5929`, hours: u, bucket: "1_3d" }
      : o <= 14
        ? { label: `${o} \u5929`, hours: u, bucket: "4_14d" }
        : o <= 45
          ? { label: `${o} \u5929`, hours: u, bucket: "15_45d" }
          : { label: `${o} \u5929\u4EE5\u4E0A`, hours: u, bucket: "over_45d" };
  }
  function je(e, t) {
    const n = e?.activity || J(e, t),
      u = Re(n);
    return {
      latestSpeaker: de(t),
      silenceLabel: u.label,
      silenceBucket: u.bucket,
      lastCustomerMessage: n?.lastCustomerMessage || j(t, "Them"),
      lastOutgoingMessage: n?.lastOutgoingMessage || j(t, "You"),
      explicitStop: !!(n?.explicitStop || e?.continuationSignal === "explicit_stop"),
    };
  }
  async function ze(e) {
    try {
      const t = (await chrome.storage.local.get(e.key))?.[e.key];
      return t && typeof t == "object" ? t : null;
    } catch (t) {
      return (console.debug("[Orange AI Copilot] contact memory read failed", t), null);
    }
  }
  function Ye(e = {}, t = {}) {
    const n = (r) => t?.[r] || e?.[r] || null,
      u = ["interests", "food", "sports", "travel", "lifestyle", "importantStories"],
      o = { name: n("name"), location: n("location"), occupation: n("occupation"), age: n("age") };
    for (const r of u)
      o[r] = le([...(e?.[r] || []), ...(t?.[r] || [])], r === "importantStories" ? 12 : 10);
    return o;
  }
  async function Ze(e, t, n, u) {
    if (!e?.key || !t) return null;
    const o = {
      version: 1,
      identityLabel: e.label,
      knownProfile: Ye(n?.knownProfile, t.knownProfile),
      kellyDisclosed: le([...(n?.kellyDisclosed || []), ...(t.kellyDisclosed || [])], 24),
      relationshipStage: t.relationshipStage || n?.relationshipStage || "",
      lastTopic: t.topic || n?.lastTopic || "",
      heat: t.heat || n?.heat || null,
      continuationSignal: t?.continuation?.signal || n?.continuationSignal || "open",
      areaCodeHint: e?.areaLookup || n?.areaCodeHint || null,
      activity: J(n, u || ""),
      updatedAt: new Date().toISOString(),
    };
    try {
      return (await chrome.storage.local.set({ [e.key]: o }), o);
    } catch (r) {
      return (console.debug("[Orange AI Copilot] contact memory save failed", r), o);
    }
  }
  function f(e, t = "info") {
    let n = document.getElementById(oe);
    (n ||
      ((n = document.createElement("div")),
      (n.id = oe),
      n.setAttribute("role", "status"),
      document.documentElement.appendChild(n)),
      (n.className = `orange-ai-reply-toast ${t}`),
      (n.textContent = String(e || "")),
      n.classList.add("show"),
      clearTimeout(f._timer),
      (f._timer = setTimeout(() => n?.classList.remove("show"), t === "error" ? 4600 : 2400)));
  }
  function d(e) {
    return String(e ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
  function Ue(e) {
    return [
      "\u8C28\u614E",
      "\u613F\u610F\u804A",
      "\u6709\u5171\u540C\u70B9",
      "\u660E\u663E\u719F\u6089",
      "\u670B\u53CB\u611F",
    ][Math.max(1, Math.min(5, Number(e) || 1)) - 1];
  }
  function We(e) {
    return e === "high" ? "\u4F18\u5148" : e === "low" ? "\u5907\u7528" : "\u53EF\u9009";
  }
  function Ge(e) {
    const t = [];
    (e?.name && t.push(["\u540D\u5B57", e.name]),
      e?.location && t.push(["\u5730\u533A", e.location]),
      e?.occupation && t.push(["\u5DE5\u4F5C", e.occupation]),
      e?.age && t.push(["\u5E74\u9F84", e.age]));
    const n = [
      ["\u5174\u8DA3", e?.interests],
      ["\u7F8E\u98DF", e?.food],
      ["\u8FD0\u52A8", e?.sports],
      ["\u65C5\u884C", e?.travel],
      ["\u751F\u6D3B", e?.lifestyle],
    ];
    for (const [u, o] of n)
      Array.isArray(o) && o.length && t.push([u, o.slice(0, 5).join(" \xB7 ")]);
    return (
      Array.isArray(e?.importantStories) &&
        e.importantStories.length &&
        t.push(["\u8BB0\u5FC6", e.importantStories.slice(-3).join(" \xB7 ")]),
      t
    );
  }
  let A = null,
    M = null,
    Ke = null;
  function ee() {
    document.getElementById(I)?.remove();
  }
  function Ve(e, t) {
    ee();
    const n = document.createElement("aside");
    ((n.id = I),
      n.setAttribute("role", "dialog"),
      n.setAttribute("aria-label", "AI\u667A\u80FD\u5171\u9E23\u63D0\u9192"));
    const u = Number(e?.heat?.level) || 1,
      o = Ge(e?.knownProfile),
      r = Array.isArray(e?.replies) ? e.replies : [],
      a = Array.isArray(e?.directions) ? e.directions : [],
      s = Array.isArray(e?.kellyDisclosed) ? e.kellyDisclosed : [],
      i = e?.continuation || {},
      l = e?._mode === "reengage",
      c = e?.areaLookup || null,
      E = e?.reengagementMeta || null;
    ((n.innerHTML = `
      <div class="orange-ai-copilot-head">
        <div>
          <span class="orange-ai-kicker">AI SOCIAL COPILOT</span>
          <h3>${l ? "\u5BA2\u6237\u56DE\u6D41\u5EFA\u8BAE" : "\u667A\u80FD\u5171\u9E23\u63D0\u9192"}</h3>
        </div>
        <button type="button" class="orange-ai-close" aria-label="\u5173\u95ED">\xD7</button>
      </div>

      <div class="orange-ai-meta-row">
        <span class="orange-ai-heat heat-${Math.max(1, Math.min(5, u))}">\u70ED\u5EA6 ${u}/5 \xB7 ${d(e?.heat?.label || Ue(u))}</span>
        ${e?.topic ? `<span class="orange-ai-topic">${d(e.topic)}</span>` : ""}
      </div>

      ${
        c
          ? `
        <section class="orange-ai-card orange-ai-area-hint">
          <div class="orange-ai-card-title">\u{1F4CD} \u533A\u53F7\u5730\u70B9\u7EBF\u7D22</div>
          ${c.scannedPhone ? `<div class="orange-ai-resonance"><b>\u8BC6\u522B\u53F7\u7801</b><span>${d(`+1 ${c.scannedPhone.slice(0, 3)} ${c.scannedPhone.slice(3, 6)} ${c.scannedPhone.slice(6)}`)}</span></div>` : ""}
          <div class="orange-ai-resonance primary"><b>${d(c.areaCode || "")}</b><span>${d(c.labelZh || c.regionZh || "")}<br>${d(c.label || c.region || "")}</span></div>
          ${c.citiesEn?.length || c.nearbyCitiesEn?.length ? `<div class="orange-ai-resonance"><b>\u57CE\u5E02 / Cities</b><span>${d((c.citiesZh || []).join("\u3001"))}<br>${d((c.citiesEn || []).join(", "))}</span></div><div class="orange-ai-resonance"><b>\u5468\u8FB9 / Nearby</b><span>${d((c.nearbyCitiesZh || []).join("\u3001"))}<br>${d((c.nearbyCitiesEn || []).join(", "))}</span></div>` : ""}
          <small class="orange-ai-note">\u4F18\u5148\u8BFB\u53D6\u5F53\u524D\u4F1A\u8BDD\u9876\u90E8\u201C\u5BF9\u65B9\u53F7\u7801\u201D\u5B57\u6BB5\u3002\u533A\u53F7\u4EC5\u4EE3\u8868\u53F7\u7801\u53EF\u80FD\u5F52\u5C5E\u5730\u533A\uFF0C\u4E0D\u7B49\u4E8E\u5BA2\u6237\u5F53\u524D\u4F4F\u5740\uFF1B\u643A\u53F7\u8F6C\u7F51\u540E\u53EF\u80FD\u4E0D\u540C\u3002</small>
        </section>`
          : ""
      }

      ${
        l && E
          ? `
        <section class="orange-ai-card orange-ai-reflow-card">
          <div class="orange-ai-card-title">\u267B\uFE0F \u56DE\u6D41\u72B6\u6001</div>
          <div class="orange-ai-resonance primary"><b>\u672A\u56DE\u590D</b><span>${d(E.silenceLabel || "\u65F6\u957F\u672A\u77E5")}</span></div>
          <small class="orange-ai-note">\u56DE\u6D41\u4F18\u5148\u7528\u65E7\u8BDD\u9898\u3001\u5174\u8DA3\u3001\u5730\u533A\u751F\u6D3B\u6216 Kelly \u7684\u8F7B\u91CF\u751F\u6D3B\u5206\u4EAB\u91CD\u65B0\u6253\u5F00\u8BDD\u9898\uFF0C\u4E0D\u50AC\u3001\u4E0D\u8D23\u5907\u3001\u4E0D\u5236\u9020\u7D27\u8FEB\u611F\u3002</small>
        </section>`
          : ""
      }

      ${
        e?.relationshipStage || i?.signal !== "open"
          ? `
        <section class="orange-ai-card">
          <div class="orange-ai-card-title">\u{1F9ED} \u5BF9\u8BDD\u72B6\u6001</div>
          ${e?.relationshipStage ? `<div class="orange-ai-resonance"><b>\u9636\u6BB5</b><span>${d(e.relationshipStage)}</span></div>` : ""}
          ${i?.signal && i.signal !== "open" ? `<div class="orange-ai-resonance primary"><b>\u4FE1\u53F7</b><span>${d(i.signal === "polite_close" ? "\u793C\u8C8C\u6536\u5C3E\u4FE1\u53F7 \xB7 \u63A5\u4F4F\u540E\u7559\u94A9\u5B50" : i.signal === "temporary_busy" ? "\u6682\u65F6\u5FD9\u788C \xB7 \u4E0D\u50AC\u56DE\u590D\uFF0C\u8F7B\u91CF\u7559\u94A9\u5B50" : "\u660E\u786E\u505C\u6B62 \xB7 \u5C0A\u91CD\u8FB9\u754C")}</span></div>` : ""}
          ${i?.strategy ? `<small class="orange-ai-note">${d(i.strategy)}</small>` : ""}
        </section>`
          : ""
      }

      ${
        e?.reminder
          ? `
        <section class="orange-ai-card orange-ai-reminder">
          <div class="orange-ai-card-title">\u{1F4A1} \u73B0\u5728\u6700\u9002\u5408</div>
          <p>${d(e.reminder)}</p>
        </section>`
          : ""
      }

      <section class="orange-ai-card">
        <div class="orange-ai-card-title">\u{1F525} \u5171\u9E23\u70B9</div>
        ${e?.resonance?.primary ? `<div class="orange-ai-resonance primary"><b>\u4F18\u5148</b><span>${d(e.resonance.primary)}</span></div>` : ""}
        ${e?.resonance?.secondary ? `<div class="orange-ai-resonance"><b>\u5907\u7528</b><span>${d(e.resonance.secondary)}</span></div>` : ""}
        ${e?.resonance?.reason ? `<small class="orange-ai-note">${d(e.resonance.reason)}</small>` : ""}
      </section>

      ${
        o.length
          ? `
        <section class="orange-ai-card">
          <div class="orange-ai-card-title">\u{1F9E9} \u5BA2\u6237\u957F\u671F\u8BB0\u5FC6</div>
          <div class="orange-ai-profile-grid">
            ${o.map(([m, D]) => `<span><b>${d(m)}</b>${d(D)}</span>`).join("")}
          </div>
        </section>`
          : ""
      }

      ${
        s.length || e?.reciprocalDisclosure
          ? `
        <section class="orange-ai-card">
          <div class="orange-ai-card-title">\u{1F4AC} Kelly \u4FE1\u606F\u91CA\u653E</div>
          ${s.length ? `<p class="orange-ai-note">\u5DF2\u91CA\u653E\uFF1A${d(s.join(" \xB7 "))}</p>` : ""}
          ${e?.reciprocalDisclosure ? `<div class="orange-ai-resonance primary"><b>\u672C\u8F6E</b><span>${d(e.reciprocalDisclosure)}</span></div>` : ""}
        </section>`
          : ""
      }

      <section class="orange-ai-card orange-ai-replies-card">
        <div class="orange-ai-card-title">${l ? "\u267B\uFE0F \u56DE\u6D41\u65B9\u6848" : "\u270D\uFE0F \u56DE\u590D\u65B9\u6848"} <small>\u6B63\u6587\u4E0D\u5E26\u95EE\u53E5 \xB7 \u70B9\u51FB\u540E\u586B\u5165\u8F93\u5165\u6846</small></div>
        <div class="orange-ai-replies">
          ${r
            .map(
              (m, D) => `
            <button type="button" class="orange-ai-reply-option" data-orange-ai-option="${D}">
              <span class="orange-ai-option-label">${d(m.label || `\u65B9\u6848 ${D + 1}`)}</span>
              <span class="orange-ai-option-zh">${d(m.zh || "\u4E2D\u6587\u7FFB\u8BD1\u751F\u6210\u4E2D")}</span>
              <span class="orange-ai-option-text">${d(m.text || "")}</span>
            </button>`,
            )
            .join("")}
        </div>
      </section>

      <section class="orange-ai-card">
        <div class="orange-ai-card-title">\u{1F9ED} \u4E0B\u4E00\u6B65\u65B9\u5411 <small>\u7531\u4F60\u4EBA\u5DE5\u51B3\u5B9A\u662F\u5426\u63A8\u8FDB</small></div>
        <div class="orange-ai-directions">
          ${
            a.length
              ? a
                  .map(
                    (m) => `
            <div class="orange-ai-direction priority-${d(m.priority || "medium")}">
              <div><span>${d(We(m.priority))}</span><b>${d(m.label)}</b></div>
              <p>${d(m.reason || "")}</p>
            </div>`,
                  )
                  .join("")
              : '<p class="orange-ai-empty">\u8FD9\u4E00\u8F6E\u5148\u4FDD\u6301\u5171\u9E23\uFF0C\u4E0D\u6025\u7740\u63A8\u8FDB\u8D44\u6599\u3002</p>'
          }
        </div>
      </section>

      ${
        e?.avoid
          ? `
        <section class="orange-ai-avoid">
          <b>\u8FD9\u4E00\u8F6E\u907F\u514D\uFF1A</b> ${d(e.avoid)}
        </section>`
          : ""
      }

      <div class="orange-ai-copilot-foot">
        <span>${d(t || "Gemini")}</span>
        <button type="button" class="orange-ai-regenerate">\u21BB \u91CD\u65B0\u5206\u6790</button>
      </div>
    `),
      n.querySelector(".orange-ai-close")?.addEventListener("click", ee),
      n.querySelectorAll("[data-orange-ai-option]").forEach((m) => {
        m.addEventListener("click", () => {
          const D = Number(m.getAttribute("data-orange-ai-option")),
            x = String(r[D]?.text || "").trim(),
            $ = A?.isConnected && F(A) ? A : w();
          if (!$) {
            f(
              "\u6CA1\u6709\u627E\u5230\u804A\u5929\u8F93\u5165\u6846\uFF0C\u8BF7\u5148\u70B9\u4E00\u4E0B\u8F93\u5165\u6846",
              "error",
            );
            return;
          }
          if (!x || !ce($, x)) {
            f(
              "\u56DE\u590D\u586B\u5165\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u70B9\u51FB\u8F93\u5165\u6846",
              "error",
            );
            return;
          }
          ((A = $),
            n
              .querySelectorAll(".orange-ai-reply-option")
              .forEach((_) => _.classList.remove("selected")),
            m.classList.add("selected"),
            f(
              "\u5DF2\u586B\u5165\u56DE\u590D\u8349\u7A3F\uFF0C\u4F60\u53EF\u4EE5\u7EE7\u7EED\u4EBA\u5DE5\u6DFB\u52A0\u4E0B\u4E00\u6B65\u65B9\u5411",
              "success",
            ));
        });
      }),
      n.querySelector(".orange-ai-regenerate")?.addEventListener("click", () => {
        q(M, { forceEditor: A, mode: e?._mode || "reply" });
      }),
      document.documentElement.appendChild(n));
  }
  function me(e, t) {
    if (!(e instanceof HTMLButtonElement)) return;
    const n = e.hasAttribute(k);
    ((e.disabled = !!t), e.classList.toggle("orange-ai-is-busy", !!t));
    const u = e.querySelector("strong"),
      o = e.querySelector("small");
    (u &&
      (u.textContent = t
        ? n
          ? "\u56DE\u6D41\u5206\u6790\u4E2D\u2026"
          : "AI\u5206\u6790\u4E2D\u2026"
        : n
          ? "\u5BA2\u6237\u56DE\u6D41"
          : "AI\u667A\u80FD\u63D0\u9192"),
      o &&
        (o.textContent = t
          ? n
            ? "\u6B63\u5728\u5BFB\u627E\u81EA\u7136\u91CD\u65B0\u5F00\u573A\u70B9"
            : "\u6B63\u5728\u5BFB\u627E\u6700\u4F73\u5171\u9E23\u70B9"
          : n
            ? "\u6C89\u9ED8\u56DE\u6D41 \xB7 \u65E7\u8BDD\u9898\u56DE\u94A9 \xB7 3\u79CD\u65B9\u6848"
            : "\u5171\u9E23\u5206\u6790 \xB7 3\u79CD\u56DE\u590D \xB7 \u4E0B\u4E00\u6B65\u65B9\u5411"));
  }
  async function q(e, t = {}) {
    if (W) return;
    const n = t.mode === "reengage" ? "reengage" : "reply",
      u = t.forceEditor?.isConnected && F(t.forceEditor) ? t.forceEditor : w();
    if (!u) {
      f(
        "\u6CA1\u6709\u627E\u5230\u804A\u5929\u8F93\u5165\u6846\uFF0C\u8BF7\u5148\u70B9\u4E00\u4E0B\u8F93\u5165\u6846",
        "error",
      );
      return;
    }
    const o = L();
    if (!o) {
      f("\u6CA1\u6709\u8BFB\u53D6\u5230\u5F53\u524D\u4F1A\u8BDD\u5185\u5BB9", "error");
      return;
    }
    const r = T(o);
    let a = await ze(r);
    const s = J(a, o);
    a = { ...(a || {}), activity: s, areaCodeHint: r.areaLookup || a?.areaCodeHint || null };
    const i = je(a, o);
    if (n === "reengage") {
      if (i.explicitStop) {
        f(
          "\u5BA2\u6237\u5DF2\u660E\u786E\u8868\u793A\u505C\u6B62\u8054\u7CFB\uFF0C\u56DE\u6D41\u529F\u80FD\u5DF2\u7981\u7528",
          "error",
        );
        return;
      }
      if (i.latestSpeaker === "Them") {
        f(
          "\u5F53\u524D\u6700\u540E\u4E00\u6761\u662F\u5BA2\u6237\u56DE\u590D\uFF0C\u76F4\u63A5\u4F7F\u7528 AI\u667A\u80FD\u63D0\u9192 \u66F4\u5408\u9002",
          "info",
        );
        return;
      }
    }
    ((A = u),
      (M = e instanceof HTMLButtonElement ? e : M),
      (Ke = { context: o, draft: K(u), identity: r }),
      (W = !0),
      me(M, !0),
      f(
        n === "reengage"
          ? "\u6B63\u5728\u751F\u6210\u81EA\u7136\u56DE\u6D41\u65B9\u5F0F\u2026"
          : "\u6B63\u5728\u5206\u6790\u5BF9\u8BDD\u70ED\u5EA6\u548C\u5171\u9E23\u70B9\u2026",
        "info",
      ));
    try {
      const l = await chrome.runtime.sendMessage({
        type: "ORANGE_AI_GENERATE_ADVICE",
        context: o,
        draft: K(u),
        pageTitle: document.title,
        pageHost: location.hostname,
        localDate: new Date().toString(),
        contactMemory: a,
        mode: n,
        phoneRegionHint: r.areaLookup || a?.areaCodeHint || null,
        reengagementMeta: i,
      });
      if (!l?.ok || !l?.advice)
        throw new Error(l?.error || "AI \u667A\u80FD\u63D0\u9192\u751F\u6210\u5931\u8D25");
      const c = await Ze(r, l.advice, a, o);
      (c?.knownProfile && (l.advice.knownProfile = c.knownProfile),
        c?.kellyDisclosed && (l.advice.kellyDisclosed = c.kellyDisclosed),
        (l.advice.areaLookup = r.areaLookup || c?.areaCodeHint || null),
        (l.advice.reengagementMeta = i),
        (l.advice._mode = n),
        Ve(l.advice, l.model),
        f(
          n === "reengage"
            ? "\u56DE\u6D41\u65B9\u6848\u5DF2\u751F\u6210 \xB7 \u5BA2\u6237\u8BB0\u5FC6\u5DF2\u7ED3\u5408"
            : "\u667A\u80FD\u5171\u9E23\u63D0\u9192\u5DF2\u751F\u6210 \xB7 \u5BA2\u6237\u4FE1\u606F\u5DF2\u8BB0\u5F55",
          "success",
        ));
    } catch (l) {
      (console.error("[Orange AI Copilot] generation failed", l),
        f(l?.message || "AI \u667A\u80FD\u63D0\u9192\u751F\u6210\u5931\u8D25", "error"));
    } finally {
      ((W = !1), me(M, !1));
    }
  }
  function Xe() {
    const e = document.createElement("button");
    return (
      (e.type = "button"),
      e.setAttribute(Z, "true"),
      (e.innerHTML = `
      <span class="ai-bt-action-icon">\u2728</span>
      <span>
        <strong>AI\u667A\u80FD\u63D0\u9192</strong>
        <small>\u5171\u9E23\u5206\u6790 \xB7 3\u79CD\u56DE\u590D \xB7 \u4E0B\u4E00\u6B65\u65B9\u5411</small>
      </span>
    `),
      e.addEventListener("click", (t) => {
        (t.preventDefault(), t.stopPropagation(), q(e));
      }),
      e
    );
  }
  function Qe() {
    const e = document.createElement("button");
    return (
      (e.type = "button"),
      e.setAttribute(k, "true"),
      (e.innerHTML = `
      <span class="ai-bt-action-icon">\u267B\uFE0F</span>
      <span>
        <strong>\u5BA2\u6237\u56DE\u6D41</strong>
        <small>\u6C89\u9ED8\u56DE\u6D41 \xB7 \u65E7\u8BDD\u9898\u56DE\u94A9 \xB7 3\u79CD\u65B9\u6848</small>
      </span>
    `),
      e.addEventListener("click", (t) => {
        (t.preventDefault(), t.stopPropagation(), q(e, { mode: "reengage" }));
      }),
      e
    );
  }
  const ge = {
      California: "\u52A0\u5229\u798F\u5C3C\u4E9A\u5DDE",
      Texas: "\u5FB7\u514B\u8428\u65AF\u5DDE",
      Florida: "\u4F5B\u7F57\u91CC\u8FBE\u5DDE",
      Washington: "\u534E\u76DB\u987F\u5DDE",
      Arizona: "\u4E9A\u5229\u6851\u90A3\u5DDE",
      Nevada: "\u5185\u534E\u8FBE\u5DDE",
      Oregon: "\u4FC4\u52D2\u5188\u5DDE",
      "New York": "\u7EBD\u7EA6\u5DDE",
      "New Jersey": "\u65B0\u6CFD\u897F\u5DDE",
      Pennsylvania: "\u5BBE\u5915\u6CD5\u5C3C\u4E9A\u5DDE",
      Illinois: "\u4F0A\u5229\u8BFA\u4F0A\u5DDE",
      Georgia: "\u4E54\u6CBB\u4E9A\u5DDE",
      Massachusetts: "\u9A6C\u8428\u8BF8\u585E\u5DDE",
      Virginia: "\u5F17\u5409\u5C3C\u4E9A\u5DDE",
      Maryland: "\u9A6C\u91CC\u5170\u5DDE",
      Ohio: "\u4FC4\u4EA5\u4FC4\u5DDE",
      Michigan: "\u5BC6\u6B47\u6839\u5DDE",
      Colorado: "\u79D1\u7F57\u62C9\u591A\u5DDE",
      Hawaii: "\u590F\u5A01\u5937\u5DDE",
      Alaska: "\u963F\u62C9\u65AF\u52A0\u5DDE",
      Ontario: "\u5B89\u5927\u7565\u7701",
      "British Columbia": "\u4E0D\u5217\u98A0\u54E5\u4F26\u6BD4\u4E9A\u7701",
      Quebec: "\u9B41\u5317\u514B\u7701",
      Alberta: "\u963F\u5C14\u4F2F\u5854\u7701",
    },
    te = "orangeAreaWidgetPreference";
  let B = !0,
    b = null;
  function z() {
    chrome.storage.local.set({ [te]: { visible: B, position: b } }).catch(() => {});
  }
  function pe(e = document.getElementById("orange-area-pinned"), t = !0) {
    if (!e || e.hidden || !B) return !1;
    const n = e.getBoundingClientRect();
    if (!n.width || !n.height) return !1;
    const u = Math.max(8, Math.min(Math.max(8, innerWidth - n.width - 8), n.left)),
      o = Math.max(8, Math.min(Math.max(8, innerHeight - n.height - 8), n.top));
    return Math.abs(u - n.left) < 1 && Math.abs(o - n.top) < 1
      ? !1
      : ((e.style.left = `${u}px`),
        (e.style.top = `${o}px`),
        (e.style.right = "auto"),
        (b = { left: u, top: o }),
        t && z(),
        !0);
  }
  function he(e) {
    if (!e?.phoneDigits) return !1;
    const t = w();
    return !!(t && t.isConnected && p(t));
  }
  function Je() {
    const e = document.createElement("button");
    return (
      (e.type = "button"),
      (e.dataset.orangeAreaStatus = "true"),
      (e.innerHTML =
        '<span class="ai-bt-action-icon">\u{1F4CD}</span><span><strong>\u81EA\u52A8\u533A\u53F7\u67E5\u8BE2</strong><small>\u70B9\u51FB\u6216\u5207\u6362\u5BA2\u6237\u540E\u81EA\u52A8\u8BC6\u522B / Auto lookup</small></span>'),
      e.addEventListener("click", () => {
        const t = ne(e);
        ((B = !0), z(), C(), he(t) && ue(t));
      }),
      e
    );
  }
  function ne(e = document.querySelector("[data-orange-area-status]")) {
    if (!e) return null;
    const t = T(L()),
      n = t.areaLookup,
      u = e.querySelector("small");
    if (!u) return t;
    if (!n)
      return (
        (u.textContent = t.phoneDigits
          ? `${t.phoneDigits} \xB7 \u6682\u65E0\u7F8E\u56FD\u533A\u53F7\u8D44\u6599 / No US area match`
          : "\u672A\u8BC6\u522B\u5230\u5BA2\u6237\u53F7\u7801 / No customer number found"),
        t
      );
    const o = n.regionZh || ge[n.region] || n.region;
    return (
      (u.textContent = `${n.areaCode} \xB7 ${n.labelZh || o} / ${n.label || `${n.region}, USA`}`),
      t
    );
  }
  function ue(e) {
    document.getElementById("orange-ai-area-lookup-panel")?.remove();
    const t = e?.areaLookup || null,
      n = t ? t.regionZh || ge[t.region] || t.region : "\u672A\u8BC6\u522B",
      u = e?.phoneDigits
        ? `+1 ${e.phoneDigits.slice(0, 3)} ${e.phoneDigits.slice(3, 6)} ${e.phoneDigits.slice(6)}`
        : "\u672A\u8BC6\u522B / Not detected",
      o = document.createElement("section");
    o.id = "orange-ai-area-lookup-panel";
    const r = t
      ? [
          [
            "\u56FD\u5BB6 / Country",
            `${t.countryZh || "\u7F8E\u56FD"} / ${t.countryEn || "United States"}`,
          ],
          ["\u5DDE / State", `${n} / ${t.region}`],
          [
            "\u4E3B\u8981\u57CE\u5E02 / Main cities",
            `${(t.citiesZh || []).join("\u3001") || n} / ${(t.citiesEn || []).join(", ") || t.metroHint || t.region}`,
          ],
          [
            "\u5468\u8FB9\u57CE\u5E02 / Nearby cities",
            `${(t.nearbyCitiesZh || []).join("\u3001") || "\u6682\u65E0\u8BE6\u7EC6\u8D44\u6599"} / ${(t.nearbyCitiesEn || []).join(", ") || "No detailed nearby-city data"}`,
          ],
          [
            "\u65F6\u533A / Time zone",
            `${t.timezoneZh || "\u7F8E\u56FD\u5F53\u5730\u65F6\u533A"} / ${t.timezoneEn || "United States local time"}`,
          ],
        ]
      : [];
    ((o.innerHTML = `<header><div><strong>\u{1F4CD} \u81EA\u52A8\u533A\u53F7\u67E5\u8BE2</strong><small>Area Code Lookup</small></div><button type="button" aria-label="\u5173\u95ED">\xD7</button></header><div class="orange-area-phone"><span>\u8BC6\u522B\u53F7\u7801 / Phone</span><b>${d(u)}</b></div>${t ? `<div class="orange-area-code"><span>${d(t.areaCode)}</span><div><b>${d(t.labelZh || n)}</b><small>${d(t.label || `${t.region}, USA`)}</small></div></div><div class="orange-area-details">${r.map(([a, s]) => `<div><b>${d(a)}</b><span>${d(s)}</span></div>`).join("")}</div><button class="orange-area-refresh" type="button">\u21BB \u8054\u7F51\u91CD\u65B0\u67E5\u8BE2</button>` : '<div class="orange-area-empty">\u6CA1\u6709\u627E\u5230\u5F53\u524D\u5BA2\u6237\u7684\u7F8E\u56FD\u7535\u8BDD\u53F7\u7801<br><small>No U.S. customer number was found.</small></div>'}<p>\u533A\u53F7\u4EC5\u8868\u793A\u53F7\u7801\u53EF\u80FD\u7684\u539F\u59CB\u5F52\u5C5E\u5730\u533A\uFF0C\u4E0D\u4EE3\u8868\u5BA2\u6237\u5F53\u524D\u4F4F\u5740\u3002<br><small>Area code is only an approximate numbering-origin hint, not the customer's verified current location.</small></p>`),
      o.querySelector("header button").addEventListener("click", () => o.remove()),
      o.querySelector(".orange-area-refresh")?.addEventListener("click", async (a) => {
        const s = a.currentTarget;
        ((s.disabled = !0), (s.textContent = "\u67E5\u8BE2\u4E2D\u2026"));
        try {
          const i = await chrome.runtime.sendMessage({
            type: "AI_AREA_CODE_REQUERY",
            areaCode: t.areaCode,
            featureCode: "area_lookup",
          });
          if (!i?.ok || !i.area) throw new Error(i?.error || "\u67E5\u8BE2\u5931\u8D25");
          ((e.areaLookup = { ...t, ...i.area }), ue(e), ne());
        } catch (i) {
          ((s.disabled = !1),
            (s.textContent = `\u91CD\u8BD5\uFF1A${i?.message || "\u67E5\u8BE2\u5931\u8D25"}`));
        }
      }),
      document.documentElement.appendChild(o));
  }
  function C() {
    let e = document.getElementById("orange-area-pinned");
    if (!e) {
      ((e = document.createElement("div")),
        (e.id = "orange-area-pinned"),
        (e.hidden = !0),
        (e.innerHTML =
          '<button class="orange-area-drag" type="button" title="\u62D6\u52A8\u533A\u53F7\u6846" aria-label="\u62D6\u52A8\u533A\u53F7\u6846">\u283F</button><button class="orange-area-open" type="button"><b>\u{1F4CD} \u533A\u53F7</b><span>\u8BC6\u522B\u4E2D\u2026</span></button><button class="orange-area-close" type="button" title="\u5173\u95ED\u533A\u53F7\u6846" aria-label="\u5173\u95ED\u533A\u53F7\u6846">\xD7</button>'));
      const a = e.querySelector(".orange-area-drag"),
        s = e.querySelector(".orange-area-open"),
        i = e.querySelector(".orange-area-close"),
        l = () => {
          if (!P("area_lookup") || !G()) {
            alert(
              "\u5F53\u524D\u4F1A\u5458\u6682\u65E0\u6B64\u529F\u80FD\u6743\u9650\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5F00\u901A\u6216\u7EED\u8D39\u9AD8\u7EA7\u4F1A\u5458\u3002",
            );
            return;
          }
          try {
            ue(T(L()));
          } catch (c) {
            (console.error("Unable to open area lookup panel", c),
              alert(
                `\u533A\u53F7\u8BE6\u60C5\u6253\u5F00\u5931\u8D25\uFF1A${c?.message || "\u672A\u77E5\u9519\u8BEF"}`,
              ));
          }
        };
      (s.addEventListener("click", (c) => {
        (c.preventDefault(), c.stopPropagation(), l());
      }),
        i.addEventListener("click", (c) => {
          (c.preventDefault(),
            c.stopPropagation(),
            (B = !1),
            (e.hidden = !0),
            document.getElementById("orange-ai-area-lookup-panel")?.remove(),
            z());
        }),
        a.addEventListener("pointerdown", (c) => {
          if (c.button !== 0) return;
          (c.preventDefault(), c.stopPropagation());
          const E = e.getBoundingClientRect(),
            m = c.clientX,
            D = c.clientY;
          let x = !1;
          a.setPointerCapture?.(c.pointerId);
          const $ = (Ee) => {
              const Fe = Ee.clientX - m,
                De = Ee.clientY - D;
              if ((Math.abs(Fe) + Math.abs(De) > 5 && (x = !0), !x)) return;
              const nt = Math.max(8, Math.min(innerWidth - E.width - 8, E.left + Fe)),
                ut = Math.max(8, Math.min(innerHeight - E.height - 8, E.top + De));
              ((e.style.left = `${nt}px`), (e.style.top = `${ut}px`), (e.style.right = "auto"));
            },
            _ = () => {
              (a.removeEventListener("pointermove", $),
                a.removeEventListener("pointerup", _),
                a.removeEventListener("pointercancel", _),
                x &&
                  ((b = { left: parseFloat(e.style.left) || 8, top: parseFloat(e.style.top) || 8 }),
                  z()));
            };
          (a.addEventListener("pointermove", $),
            a.addEventListener("pointerup", _),
            a.addEventListener("pointercancel", _));
        }),
        document.documentElement.appendChild(e),
        b &&
          ((e.style.left = `${b.left}px`), (e.style.top = `${b.top}px`), (e.style.right = "auto")));
    }
    const t = T(L()),
      n = t.areaLookup,
      u = e.querySelector("span"),
      o = n
        ? `${n.areaCode} \xB7 ${n.regionZh || n.region}`
        : t.phoneDigits
          ? "\u6682\u65E0\u7F8E\u56FD\u533A\u53F7\u8D44\u6599"
          : "\u7B49\u5F85\u5BA2\u6237\u53F7\u7801";
    u && u.textContent !== o && (u.textContent = o);
    const r = P("area_lookup") && G();
    return (
      e.classList.contains("is-orange-locked") === r && e.classList.toggle("is-orange-locked", !r),
      (e.hidden = !B || !r || !he(t)),
      e.hidden || requestAnimationFrame(() => pe(e)),
      e
    );
  }
  function et() {
    if (!U.test(location.hostname)) return !0;
    const e = document.querySelector(be);
    if (!e) return !1;
    document.getElementById(S)?.remove();
    let t = e.querySelector(`[${Z}]`);
    if (!t) {
      t = Xe();
      const u = e.querySelector("[data-ai-bt-input-translator-toggle]");
      u?.nextSibling ? e.insertBefore(t, u.nextSibling) : e.appendChild(t);
    }
    if (!e.querySelector(`[${k}]`)) {
      const u = Qe();
      t?.nextSibling ? e.insertBefore(u, t.nextSibling) : e.appendChild(u);
    }
    (e.querySelector("[data-orange-area-status]") || e.insertBefore(Je(), t), ne());
    const n = (u, o) => {
      const r = P(o) && G();
      ((u.style.display = ""),
        (u.dataset.orangeLocked = r ? "false" : "true"),
        u.classList.toggle("is-orange-locked", !r));
    };
    return (
      e.querySelectorAll(`[${Z}]`).forEach((u) => n(u, "ai_reply")),
      e.querySelectorAll(`[${k}]`).forEach((u) => n(u, "reengage")),
      e.querySelectorAll("[data-orange-area-status]").forEach((u) => n(u, "area_lookup")),
      C(),
      !0
    );
  }
  function tt() {
    if (!U.test(location.hostname) || document.getElementById(S)) return;
    const e = document.createElement("div");
    e.id = S;
    const t = document.createElement("button");
    ((t.type = "button"),
      (t.className = "orange-ai-reply-fallback"),
      (t.textContent = "\u2728 AI\u63D0\u9192"),
      (t.title =
        "\u5206\u6790\u5F53\u524D\u5B8C\u6574\u4F1A\u8BDD\uFF0C\u7ED9\u51FA\u5171\u9E23\u63D0\u9192\u3001\u4E09\u79CD\u56DE\u590D\u65B9\u6848\u548C\u4E0B\u4E00\u6B65\u65B9\u5411"),
      t.addEventListener("click", (u) => {
        (u.preventDefault(), u.stopPropagation(), q(t));
      }));
    const n = document.createElement("button");
    ((n.type = "button"),
      (n.className = "orange-ai-reply-fallback orange-ai-reflow-fallback"),
      n.setAttribute(k, "true"),
      (n.textContent = "\u267B\uFE0F \u56DE\u6D41"),
      (n.title =
        "\u5BA2\u6237\u957F\u65F6\u95F4\u672A\u56DE\u590D\u65F6\uFF0C\u7ED3\u5408\u5BA2\u6237\u8BB0\u5FC6\u3001\u533A\u53F7\u5730\u533A\u548C\u65E7\u8BDD\u9898\u751F\u6210\u81EA\u7136\u56DE\u6D41\u65B9\u6848"),
      n.addEventListener("click", (u) => {
        (u.preventDefault(), u.stopPropagation(), q(n, { mode: "reengage" }));
      }),
      e.append(t, n),
      document.documentElement.appendChild(e));
  }
  function v() {
    Array.from(document.querySelectorAll('input[type="password"]')).some(
      (e) => e.offsetParent !== null,
    ) ||
      (O && clearTimeout(O),
      (O = setTimeout(() => {
        ((O = 0), et() || tt());
      }, 80)));
  }
  let ae = 0;
  (document.addEventListener(
    "focusin",
    (e) => {
      F(e.target) && (N = e.target);
    },
    !0,
  ),
    document.addEventListener(
      "keydown",
      (e) => {
        (e.key === "Enter" && !e.shiftKey && !e.isComposing && F(e.target) && V(),
          e.key === "Escape" && document.getElementById(I) && ee());
      },
      !0,
    ),
    document.addEventListener("submit", () => V(), !0),
    document.addEventListener(
      "pointerdown",
      (e) => {
        const t = e.target?.closest?.("button,[role='button']"),
          n = `${t?.textContent || ""} ${t?.getAttribute?.("aria-label") || ""}`.trim();
        t && /^(send|发送|发送消息)/i.test(n) && V();
      },
      !0,
    ),
    document.addEventListener(
      "click",
      (e) => {
        e.target?.closest?.("[data-orange-locked='true']") &&
          (e.preventDefault(),
          e.stopImmediatePropagation(),
          alert(
            "\u5F53\u524D\u4F1A\u5458\u6682\u65E0\u6B64\u529F\u80FD\u6743\u9650\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5F00\u901A\u6216\u7EED\u8D39\u9AD8\u7EA7\u4F1A\u5458\u3002",
          ));
      },
      !0,
    ),
    new MutationObserver(() => {
      document.hidden ||
        ae ||
        (ae = requestAnimationFrame(() => {
          ((ae = 0), v());
        }));
    }).observe(document.documentElement, { childList: !0, subtree: !0 }),
    v(),
    chrome.storage.local.get(["orangePermissions", "orangeIsAdmin", te]).then((e) => {
      ((re = e.orangePermissions || {}), (ie = e.orangeIsAdmin === !0));
      const t = e[te];
      (t &&
        typeof t == "object" &&
        ((B = t.visible !== !1),
        Number.isFinite(t.position?.left) && Number.isFinite(t.position?.top) && (b = t.position)),
        v(),
        C());
    }),
    setTimeout(v, 800),
    setTimeout(v, 2200),
    setTimeout(() => C(), 1200),
    setInterval(() => {
      document.hidden || C();
    }, 15e3),
    document.addEventListener("visibilitychange", () => {
      document.hidden || (v(), C());
    }));
  let fe = 0;
  addEventListener(
    "resize",
    () => {
      (cancelAnimationFrame(fe), (fe = requestAnimationFrame(() => pe())));
    },
    { passive: !0 },
  );
})();
