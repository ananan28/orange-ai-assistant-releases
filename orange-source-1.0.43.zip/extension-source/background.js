importScripts("ai_culture_knowledge.js", "ai_prompt.js", "ai_reply_background.js");
const translationCache = new Map();
async function permissionAllowedForSender(e, t) {
  const a = await chrome.storage.local.get(["orangePermissions", "orangeIsAdmin"]),
    r = a.orangePermissions || {},
    n = a.orangeIsAdmin === !0,
    o = (u) => n || r[u] === !0;
  let s = !1;
  try {
    s = /(^|\.)textnow\.com$/i.test(new URL(e?.url || "").hostname);
  } catch {}
  return s && !o("tn_assistant") ? !1 : o(t);
}
async function translateWithGroq(e, t, a, r = "", n = {}) {
  const o = await chrome.storage.local.get([
    "orangeSupabaseUrl",
    "orangeSupabasePublishableKey",
    "orangeSupabaseAccessToken",
  ]);
  if (!o.orangeSupabaseUrl || !o.orangeSupabasePublishableKey || !o.orangeSupabaseAccessToken)
    throw new Error("Groq gateway credentials unavailable");
  const s = /^zh/i.test(a) ? "Simplified Chinese" : "natural American English",
    u = /^zh/i.test(t) ? "Chinese" : t === "auto" ? "the detected language" : "English",
    i = await fetch(`${o.orangeSupabaseUrl}/functions/v1/ai-gateway`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: o.orangeSupabasePublishableKey,
        Authorization: `Bearer ${o.orangeSupabaseAccessToken}`,
      },
      body: JSON.stringify({
        action: "generate",
        messages: [
          {
            role: "system",
            content: `You are a precise conversational translation engine. Translate from ${u} to ${s}. Use context only to resolve slang, abbreviations, omitted subjects, references and spelling errors. Return only the translated text. Preserve names, phone numbers, punctuation and meaning. Do not answer the message.${n.alternative ? " This is a requested second translation: actively correct literal or awkward wording and, when equally accurate, choose a clearer natural phrasing." : ""}`,
          },
          ...(r
            ? [
                {
                  role: "user",
                  content: `Nearby conversation:
${String(r).slice(0, 5e3)}`,
                },
              ]
            : []),
          ...(n.previousTranslation
            ? [
                {
                  role: "user",
                  content: `Previous translation to review:
${String(n.previousTranslation).slice(0, 1800)}`,
                },
              ]
            : []),
          {
            role: "user",
            content: `Target message:
${e}`,
          },
        ],
        temperature: 0.1,
        maxTokens: 1800,
      }),
    }),
    c = await i.json().catch(() => null);
  if (!i.ok || !c?.ok || !String(c.content || "").trim())
    throw new Error(c?.message || `Groq translation HTTP ${i.status}`);
  return String(c.content)
    .trim()
    .replace(/^```(?:text)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
}
async function translateVariantsWithGroq(e) {
  const t = await chrome.storage.local.get([
    "orangeSupabaseUrl",
    "orangeSupabasePublishableKey",
    "orangeSupabaseAccessToken",
  ]);
  if (!t.orangeSupabaseUrl || !t.orangeSupabasePublishableKey || !t.orangeSupabaseAccessToken)
    throw new Error("AI\u7FFB\u8BD1\u51ED\u636E\u4E0D\u53EF\u7528");
  const a = await fetch(`${t.orangeSupabaseUrl}/functions/v1/ai-gateway`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: t.orangeSupabasePublishableKey,
        Authorization: `Bearer ${t.orangeSupabaseAccessToken}`,
      },
      body: JSON.stringify({
        action: "generate",
        messages: [
          {
            role: "system",
            content:
              "You translate Chinese customer-service chat into natural American English. Return ONLY strict JSON array with exactly 3 objects: {style:'natural'|'polite'|'concise', text:'...'}. Keep names, phone numbers, money, dates, URLs, emoji and meaning unchanged. The three options must be genuinely different, idiomatic, and not machine-literal. Do not add facts.",
          },
          { role: "user", content: String(e || "") },
        ],
        temperature: 0.45,
        maxTokens: 1e3,
      }),
    }),
    r = await a.json().catch(() => null);
  if (!a.ok || !r?.ok) throw new Error(r?.message || `AI translation HTTP ${a.status}`);
  const n = String(r.content || "")
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, ""),
    o = JSON.parse(n);
  if (!Array.isArray(o)) throw new Error("AI\u7FFB\u8BD1\u683C\u5F0F\u9519\u8BEF");
  return o
    .slice(0, 3)
    .map((s, u) => ({
      style: String(s?.style || ["natural", "polite", "concise"][u]),
      text: String(s?.text || "").trim(),
    }))
    .filter((s) => s.text);
}
async function requeryAreaCodeWithAi(e) {
  const t = String(e || "")
    .replace(/\D/g, "")
    .slice(0, 3);
  if (!/^\d{3}$/.test(t)) throw new Error("\u533A\u53F7\u683C\u5F0F\u4E0D\u6B63\u786E");
  const a = await chrome.storage.local.get([
    "orangeSupabaseUrl",
    "orangeSupabasePublishableKey",
    "orangeSupabaseAccessToken",
  ]);
  if (!a.orangeSupabaseUrl || !a.orangeSupabasePublishableKey || !a.orangeSupabaseAccessToken)
    throw new Error("\u8054\u7F51\u67E5\u8BE2\u51ED\u636E\u4E0D\u53EF\u7528");
  const r = await fetch(`${a.orangeSupabaseUrl}/functions/v1/ai-gateway`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: a.orangeSupabasePublishableKey,
        Authorization: `Bearer ${a.orangeSupabaseAccessToken}`,
      },
      body: JSON.stringify({
        action: "generate",
        messages: [
          {
            role: "system",
            content:
              "Return ONLY strict JSON for a North American telephone area code. Schema: {areaCode,region,regionZh,countryEn,countryZh,citiesEn,citiesZh,nearbyCitiesEn,nearbyCitiesZh,timezoneEn,timezoneZh,label,labelZh}. Arrays contain strings. Never infer a person's current address; report numbering-plan coverage only. If uncertain, use empty arrays rather than inventing cities.",
          },
          { role: "user", content: `Recheck NANP area code ${t} using your current knowledge.` },
        ],
        temperature: 0,
        maxTokens: 1e3,
      }),
    }),
    n = await r.json().catch(() => null);
  if (!r.ok || !n?.ok) throw new Error(n?.message || `\u8054\u7F51\u67E5\u8BE2 HTTP ${r.status}`);
  const o = String(n.content || "")
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, ""),
    s = JSON.parse(o);
  if (String(s?.areaCode || "") !== t)
    throw new Error("\u8054\u7F51\u7ED3\u679C\u533A\u53F7\u4E0D\u4E00\u81F4");
  return s;
}
function cacheKey(e, t, a) {
  return `${t}|${a}|${e}`;
}
async function translateText(e, t = "en", a = "zh-CN", r = {}) {
  const n = String(e || "").trim();
  if (!n) return "";
  const o = cacheKey(n, t, a);
  if (!r.forceAi && translationCache.has(o)) return translationCache.get(o);
  if (r.forceAi) return translateWithGroq(n, t, a, r.context || "", r);
  const s = `?client=gtx&sl=${encodeURIComponent(t)}&tl=${encodeURIComponent(a)}&dt=t&q=${encodeURIComponent(n)}`,
    u = [
      "https://translate.googleapis.com/translate_a/single",
      "https://translate.google.com/translate_a/single",
      "https://translate.google.co.th/translate_a/single",
    ];
  let i = "",
    c = null;
  for (const l of u)
    try {
      const g = new AbortController(),
        m = setTimeout(() => g.abort(), 8e3),
        h = await fetch(l + s, { method: "GET", cache: "no-store", signal: g.signal });
      if ((clearTimeout(m), !h.ok)) throw new Error(`HTTP ${h.status}`);
      const p = await h.json();
      if (
        ((i = Array.isArray(p?.[0])
          ? p[0]
              .map((y) => y?.[0] || "")
              .join("")
              .trim()
          : ""),
        i)
      )
        break;
    } catch (g) {
      c = g;
    }
  if (!i)
    try {
      i = await translateWithGroq(n, t, a);
    } catch (l) {
      throw new Error(
        `Google\u4E0E\u5907\u7528\u7FFB\u8BD1\u5747\u5931\u8D25\uFF1A${c?.message || "empty result"}; ${l?.message || l}`,
      );
    }
  if ((i && translationCache.set(o, i), translationCache.size > 2e3)) {
    const l = translationCache.keys().next().value;
    translationCache.delete(l);
  }
  return i;
}
chrome.runtime.onMessage.addListener((e, t, a) => {
  if (!["AI_TRANSLATE_TEXT", "AI_TRANSLATE_VARIANTS", "AI_AREA_CODE_REQUERY"].includes(e?.type))
    return !1;
  const r = ["chat_translate", "page_translate", "input_translate", "area_lookup"].includes(
    e.featureCode,
  )
    ? e.featureCode
    : "chat_translate";
  return (
    permissionAllowedForSender(t, r)
      .then(async (n) => {
        if (!n)
          throw new Error(
            "\u5F53\u524D\u4F1A\u5458\u6682\u65E0\u6B64\u529F\u80FD\u6743\u9650\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5F00\u901A\u6216\u7EED\u8D39\u9AD8\u7EA7\u4F1A\u5458",
          );
        return e.type === "AI_AREA_CODE_REQUERY"
          ? { area: await requeryAreaCodeWithAi(e.areaCode) }
          : e.type === "AI_TRANSLATE_VARIANTS"
            ? { variants: await translateVariantsWithGroq(e.text) }
            : {
                translated: await translateText(
                  e.text,
                  e.sourceLanguage || "en",
                  e.targetLanguage || "zh-CN",
                  {
                    forceAi: e.forceAi === !0,
                    alternative: e.alternative === !0,
                    previousTranslation: e.previousTranslation || "",
                    context: e.context || "",
                  },
                ),
              };
      })
      .then((n) => a({ ok: !0, ...n }))
      .catch((n) => {
        (console.error("[Bilingual Translator] Translation failed:", n),
          a({ ok: !1, translated: "", variants: [], error: n?.message || "Translation failed" }));
      }),
    !0
  );
});
