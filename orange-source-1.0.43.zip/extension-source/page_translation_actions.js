(() => {
  "use strict";
  const c = "ai-bt-page-translation",
    l = "ai-bt-page-translation-actions";
  function p(t) {
    const n = t.previousSibling;
    return n?.nodeType === Node.TEXT_NODE
      ? String(n.nodeValue || "")
          .replace(/\s+/g, " ")
          .trim()
      : "";
  }
  async function m(t) {
    try {
      return (await navigator.clipboard.writeText(t), !0);
    } catch {}
    const n = document.createElement("textarea");
    ((n.value = t),
      (n.style.cssText = "position:fixed;left:-9999px;top:0"),
      document.body.appendChild(n),
      n.select());
    const a = document.execCommand("copy");
    return (n.remove(), a);
  }
  function d(t) {
    if (!(t instanceof HTMLElement) || t.querySelector(`:scope > .${l}`)) return;
    const n = p(t),
      a = String(t.textContent || "").trim();
    if (!n || !a) return;
    t.textContent = "";
    const u = document.createElement("span");
    ((u.className = "ai-bt-page-translation-text"), (u.textContent = a));
    const r = document.createElement("span");
    ((r.className = l),
      (r.innerHTML =
        '<button type="button" data-page-copy title="\u590D\u5236\u82F1\u6587\u539F\u6587" aria-label="\u590D\u5236\u82F1\u6587\u539F\u6587">\u25A3</button><button type="button" data-page-retranslate title="AI\u91CD\u65B0\u7FFB\u8BD1" aria-label="AI\u91CD\u65B0\u7FFB\u8BD1">\u21BB</button>'),
      t.append(u, r),
      r.querySelector("[data-page-copy]").addEventListener("click", async (i) => {
        i.stopPropagation();
        const e = i.currentTarget;
        (await m(n),
          (e.textContent = "\u2713"),
          setTimeout(() => {
            e.isConnected && (e.textContent = "\u25A3");
          }, 900));
      }),
      r.querySelector("[data-page-retranslate]").addEventListener("click", async (i) => {
        i.stopPropagation();
        const e = i.currentTarget;
        if (!e.disabled) {
          ((e.disabled = !0), (e.textContent = "\u2026"));
          try {
            const o = await chrome.runtime.sendMessage({
              type: "AI_TRANSLATE_TEXT",
              text: n,
              sourceLanguage: "en",
              targetLanguage: "zh-CN",
              featureCode: "page_translate",
              forceAi: !0,
              alternative: !0,
              previousTranslation: u.textContent,
            });
            if (!o?.ok || !o.translated)
              throw new Error(o?.error || "AI\u6CA1\u6709\u8FD4\u56DE\u8BD1\u6587");
            ((u.textContent = o.translated),
              (e.textContent = "\u2713"),
              (e.title = "AI\u91CD\u65B0\u7FFB\u8BD1\u5B8C\u6210"));
          } catch (o) {
            ((e.textContent = "!"),
              (e.title = `AI\u91CD\u65B0\u7FFB\u8BD1\u5931\u8D25\uFF1A${o?.message || o}`));
          } finally {
            ((e.disabled = !1),
              setTimeout(() => {
                e.isConnected &&
                  ((e.textContent = "\u21BB"), (e.title = "AI\u91CD\u65B0\u7FFB\u8BD1"));
              }, 1800));
          }
        }
      }));
  }
  function s(t = document) {
    (t instanceof Element && t.classList.contains(c) && d(t),
      t.querySelectorAll?.(`.${c}`).forEach(d));
  }
  (s(),
    new MutationObserver((t) => {
      if (!document.hidden)
        for (const n of t) for (const a of n.addedNodes) a instanceof Element && s(a);
    }).observe(document.documentElement, { childList: !0, subtree: !0 }),
    document.addEventListener("visibilitychange", () => {
      document.hidden || s();
    }));
})();
