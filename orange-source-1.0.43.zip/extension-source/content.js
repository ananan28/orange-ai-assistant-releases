(() => {
  "use strict";
  const nt = "ai-bt-generated",
    at = "ai-bt-chat-translation",
    Yt = "ai-bt-page-translation",
    z = "ai-bt-root",
    C = "chat",
    K = "page",
    Qt = "pause",
    Le = `aiBtMode:${location.hostname}`,
    _e = "aiBtBallPosition",
    $e = `aiBtPhoneMask:${location.hostname}`,
    qe = `aiBtPhoneMaskText:${location.hostname}`,
    ke = `aiBtPhoneMaskColor:${location.hostname}`,
    Te = `aiBtInputTranslator:${location.hostname}`,
    wt = `aiBtCustomBackground:${location.hostname}`,
    it = `aiBtTranslationColor:${location.hostname}`,
    qt = `aiBtOriginalColor:${location.hostname}`,
    kt = `aiBtBubbleLightColor:${location.hostname}`,
    Tt = `aiBtBubbleLightWidth:${location.hostname}`,
    Mt = `aiBtBubbleLightEnabled:${location.hostname}`,
    ut = "ai-bt-custom-bg",
    Me = "ai-bt-custom-bg",
    te = "ai-bt-custom-bg-layer",
    Pa = "assets/panel-background.png",
    Bn = "ai-bt-bg-panel-light",
    Dn = "ai-bt-bg-panel-dark",
    Ln = "ai-bt-bg-surface",
    Pt = 8,
    _n = "ai-bt-opensms-transparent",
    $n = "ai-bt-opensms-main-clear",
    qn = "ai-bt-opensms-left-glass",
    kn = "ai-bt-opensms-right-glass",
    Tn = "ai-bt-opensms-exact-clear",
    Mn = "ai-bt-opensms-nav-glass",
    Pn = "ai-bt-opensms-chat-stage",
    Nn = "ai-bt-opensms-clear-surface",
    In = "ai-bt-opensms-history-glass",
    Rn = "ai-bt-opensms-contact-card",
    On = "ai-bt-phone-mask",
    Ct = "ai-bt-phone-mask-layer",
    Pe = "\u6A58\u5B50\u51FA\u54C1",
    Ne = "ai-bt-input-translate-button",
    Hn = "ai-bt-input-back-translation",
    Ie = [
      /(?<!\d)\+?\d{9,16}(?!\d)/g,
      /(?<!\d)\+?\d{1,3}[\s.-]?(?:\(\d{2,4}\)|\d{2,4})[\s.-]\d{3,4}[\s.-]\d{3,4}(?!\d)/g,
      /(?<!\d)\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}(?!\d)/g,
    ],
    Y = new Map(),
    St = "orangeTranslationCache:v1",
    zn = 7200 * 60 * 1e3,
    Nt = new WeakMap(),
    ee = new WeakMap(),
    Vn = new WeakMap(),
    Wn = [
      {
        name: "whatsapp-web",
        hostPattern: /(^|\.)web\.whatsapp\.com$/i,
        defaultMode: C,
        messageSelectors: [
          "#main [data-id] .selectable-text",
          "#main [data-pre-plain-text] .selectable-text",
          "#main [data-testid='msg-container'] .selectable-text",
          "#main [role='row'] [data-pre-plain-text]",
          "#main [data-id] [dir='ltr']",
          "#main [role='row'] .selectable-text",
          "#main [role='row'] [class*='copyable-text']",
          "#main [class*='message-in'] .selectable-text",
          "#main [class*='message-out'] .selectable-text",
        ],
        containerSelectors: [
          "#main [data-testid='conversation-panel-messages']",
          "#main [aria-label*='message' i]",
          "#main [role='application']",
          "#main",
        ],
      },
      {
        name: "textnow",
        hostPattern: /(^|\.)textnow\.com$/i,
        defaultMode: C,
        messageSelectors: [
          "li.chat-item.incoming .tn-chat-bubble-text",
          "li.chat-item.outgoing .tn-chat-bubble-text",
          "#messageView li.chat-item .tn-chat-bubble-text",
          "#messageView .tn-chat-bubble-text",
        ],
        containerSelectors: ["#messageView", "#messageView ul"],
      },
      {
        name: "opensms-legacy",
        hostPattern: /(^|\.)(?:opensms\.xin|opensms\.cc)$/i,
        defaultMode: C,
        messageSelectors: [
          ".im-chat-text .message-content",
          ".im-chat-other .im-chat-text",
          ".im-chat-user .im-chat-text",
          ".im-chat-self .im-chat-text",
          ".im-chat-mine .im-chat-text",
        ],
        containerSelectors: [
          ".im-chat-other",
          ".im-chat-user",
          ".im-chat-self",
          ".im-chat-mine",
          ".im-chat-other .im-chat-text",
          ".im-chat-text",
          ".chat-container",
          ".chat-content",
        ],
      },
      {
        name: "xinghan-sms",
        hostPattern: /(^|\.)xinghansms\.net$/i,
        defaultMode: C,
        messageSelectors: [
          ".chat_right_body .chat_message .el-scrollbar__view > *",
          ".chat_right_body .chat_message [class*='message-content']",
          ".chat_right_body .chat_message [class*='message-text']",
          ".chat_right_body .chat_message [class*='msg-content']",
          ".chat_right .chat_message .el-scrollbar__view > *",
        ],
        containerSelectors: [
          ".chat_right_body .chat_message .el-scrollbar__view",
          ".chat_right_body .chat_message",
          ".chat_right .chat_message .el-scrollbar__view",
          ".chat_right .chat_message",
        ],
      },
      {
        name: "xhsim",
        hostPattern: /(^|\.)client\.xhsim\.ai$/i,
        defaultMode: C,
        messageSelectors: [
          "#messageParent > [id^='chatMessage_']",
          "#messageParent [id^='chatMessage_'] [class*='message-content']",
          "#messageParent [id^='chatMessage_'] [class*='message-text']",
          "#messageParent [id^='chatMessage_'] [class*='text-break']",
        ],
        containerSelectors: ["#messageParent"],
      },
      {
        name: "c2csms",
        hostPattern: /(^|\.)c2csms\.com$/i,
        defaultMode: C,
        messageSelectors: [
          ".chat-content .messages-area .messages-list > *",
          ".messages-list > *",
          ".messages-area [class*='message-content']",
          ".messages-area [class*='message-text']",
          ".messages-area [class*='bubble']",
        ],
        containerSelectors: [
          ".chat-content .messages-area .messages-list",
          ".messages-area .messages-list",
          ".messages-list",
          ".messages-area",
        ],
      },
      {
        name: "skt1",
        hostPattern: /(^|\.)skt1\.net$/i,
        defaultMode: C,
        messageSelectors: [
          ".chat_right_body .chat_message .el-scrollbar__view > div",
          ".chat_right_body .chat_message [class*='message-content']",
          ".chat_right_body .chat_message [class*='message-text']",
          ".chat_right_body .chat_message [class*='msg-content']",
          ".chat_right .chat_message .el-scrollbar__view > div",
        ],
        containerSelectors: [
          ".chat_right_body .chat_message .el-scrollbar__view",
          ".chat_right_body .chat_message",
          ".chat_right .chat_message .el-scrollbar__view",
          ".chat_right .chat_message",
        ],
      },
    ];
  let M = null,
    w = se(),
    x = !1,
    j = Pe,
    Q = "#ffffff",
    k = !1,
    m = {
      schemaVersion: Pt,
      enabled: !1,
      imageDataUrl: "",
      imageOpacity: 1,
      panelOpacity: 0.22,
      groupPanelOpacity: 0.9,
      blur: 0,
      brightness: 100,
      glassBlur: 4,
    },
    G = null,
    S = "",
    P = "",
    R = "#a97bff",
    T = 7,
    V = !1,
    v = null,
    Re = !1,
    It = 0,
    Rt = null,
    Un = null,
    xt = null;
  const Na = 650;
  let ne = null,
    J = 0,
    Oe = !1,
    He = !1,
    ze = !1,
    W = null,
    ct = null,
    Ot = null,
    ae = 0,
    Kn = 0,
    oe = 0,
    N = {},
    lt = !1,
    Ve = null,
    We = "",
    I = {
      enabled: !0,
      active: !1,
      message:
        "\u7FFB\u8BD1IP\u9ED8\u8BA4\u5F00\u542F\uFF0C\u6B63\u5728\u83B7\u53D6\u53EF\u7528\u7EBF\u8DEF",
    };
  function dt(t) {
    return lt || N[String(t || "")] === !0;
  }
  function mt() {
    return !/(^|\.)textnow\.com$/i.test(location.hostname) || dt("tn_assistant");
  }
  function Ia() {
    return "\u5F53\u524D\u4F1A\u5458\u6682\u65E0\u6B64\u529F\u80FD\u6743\u9650\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5F00\u901A\u6216\u7EED\u8D39\u9AD8\u7EA7\u4F1A\u5458\u3002";
  }
  function Ra(t, e) {
    if (!t) return;
    const n = mt() && dt(e);
    ((t.style.display = ""),
      (t.dataset.orangePermissionCode = e),
      (t.dataset.orangeLocked = n ? "false" : "true"),
      t.classList.toggle("is-orange-locked", !n),
      t.setAttribute("aria-disabled", String(!n)));
  }
  function Ue() {
    const t = document.getElementById(z);
    if (!t) return;
    ((t.style.display = ""), mt() || Ze());
    const e = [
      ["[data-ai-bt-mode='chat']", "chat_translate"],
      ["[data-ai-bt-mode='page']", "page_translate"],
      ["[data-ai-bt-input-translator-toggle]", "input_translate"],
      ["[data-ai-bt-phone-mask-toggle]", "phone_mask"],
      ["[data-ai-bt-area-lookup]", "area_lookup"],
      ["[data-ai-bt-background-panel-toggle]", "custom_background"],
    ];
    for (const [s, r] of e) t.querySelectorAll(s).forEach((d) => Ra(d, r));
    const n = lt || N.phone_mask_custom_text === !0,
      a = lt || N.phone_mask_custom_color === !0;
    (t
      .querySelectorAll("[data-ai-bt-phone-mask-text-control]")
      .forEach((s) => (s.style.display = n ? "" : "none")),
      t
        .querySelectorAll("[data-ai-bt-phone-mask-color-control]")
        .forEach((s) => (s.style.display = a ? "" : "none")));
    const o = t.querySelector("[data-ai-bt-phone-mask-settings]");
    (o && (o.style.display = n || a ? "" : "none"),
      N.phone_mask === !1 ? Ze() : x && bt(),
      O(),
      H(),
      on());
  }
  function Ht() {
    const t =
      Wn.find((e) => e.hostPattern.test(location.hostname)) ||
      ($() ? Wn.find((e) => e.name === "opensms-legacy") : null) ||
      null;
    return M
      ? {
          name: t?.name || "admin-configured",
          defaultMode: C,
          messageSelectors: M.messageSelector ? [M.messageSelector] : t?.messageSelectors || [],
          containerSelectors: M.chatContainerSelector
            ? [M.chatContainerSelector]
            : t?.containerSelectors || [],
        }
      : t || {
          name: "generic-auto",
          defaultMode: C,
          messageSelectors: [
            "[data-message-id]",
            "[data-testid*='message' i]",
            "[role='listitem']",
            ".message-content",
            ".message-text",
            ".msg-content",
            ".chat-bubble",
            ".message-bubble",
            "[class*='message-content']",
            "[class*='message-text']",
            "[class*='chat-message']",
            "[class*='bubble']",
          ],
          containerSelectors: [
            "[role='log']",
            "[aria-live='polite']",
            "[aria-live='assertive']",
            ".chat_message",
            ".messages-list",
            ".messages-area",
            ".chat-content",
            ".conversation-content",
            "[class*='messages-list']",
            "[class*='conversation-content']",
          ],
        };
  }
  function se() {
    return Ht()?.defaultMode || C;
  }
  function Oa(t) {
    return new Promise((e) => setTimeout(e, t));
  }
  function jn(t, e = {}) {
    return new Promise((n) => {
      const a = `orange-proxy-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      let o = !1;
      const s = (i) => {
          o ||
            ((o = !0),
            clearTimeout(d),
            window.removeEventListener("message", r),
            n(i || { ok: !1, message: "\u684C\u9762\u7AEF\u672A\u54CD\u5E94" }));
        },
        r = (i) => {
          const c = i.data;
          i.source !== window || c?.source !== "orange-ai-app" || c.requestId !== a || s(c.result);
        },
        d = setTimeout(
          () =>
            s({
              ok: !1,
              message: "\u5F53\u524D\u73AF\u5883\u4E0D\u652F\u6301\u7FFB\u8BD1IP\u8BBE\u7F6E",
            }),
          1800,
        );
      (window.addEventListener("message", r),
        window.postMessage(
          { source: "orange-ai-extension", type: t, requestId: a, payload: e },
          "*",
        ));
    });
  }
  function Gn(t, e, n, a = "chat_translate", o = {}) {
    return new Promise((s) => {
      const r = `orange-translate-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      let d = !1;
      const i = (g) => {
          d ||
            ((d = !0),
            clearTimeout(l),
            window.removeEventListener("message", c),
            s(g || { ok: !1 }));
        },
        c = (g) => {
          const b = g.data;
          g.source !== window || b?.source !== "orange-ai-app" || b.requestId !== r || i(b.result);
        },
        l = setTimeout(() => i({ ok: !1, message: "\u684C\u9762\u7FFB\u8BD1\u8D85\u65F6" }), 12e3);
      (window.addEventListener("message", c),
        window.postMessage(
          {
            source: "orange-ai-extension",
            type: "translation:request",
            requestId: r,
            payload: { text: t, sourceLanguage: e, targetLanguage: n, featureCode: a, ...o },
          },
          "*",
        ));
    });
  }
  async function Ha() {
    const t = await jn("proxy:get");
    return (t && t.managed && (I = t), q(), t);
  }
  function Jn() {
    try {
      return !!chrome?.runtime?.id;
    } catch {
      return !1;
    }
  }
  function E(t) {
    return String(t || "")
      .replace(/\s+/g, " ")
      .trim();
  }
  function Xn(t) {
    let e = 2166136261;
    for (let n = 0; n < t.length; n += 1) ((e ^= t.charCodeAt(n)), (e = Math.imul(e, 16777619)));
    return `t${(e >>> 0).toString(36)}_${t.length}`;
  }
  async function za(t) {
    try {
      const e = ((await chrome.storage.local.get(St))?.[St] || {})[Xn(t)];
      return !e || e.key !== t || Date.now() - Number(e.at || 0) > zn ? "" : String(e.value || "");
    } catch {
      return "";
    }
  }
  async function Zn(t, e) {
    try {
      const n = (await chrome.storage.local.get(St))?.[St] || {},
        a = Date.now();
      for (const [s, r] of Object.entries(n)) (!r || a - Number(r.at || 0) > zn) && delete n[s];
      n[Xn(t)] = { key: t, value: String(e || ""), at: a };
      const o = Object.entries(n)
        .sort((s, r) => Number(r[1]?.at || 0) - Number(s[1]?.at || 0))
        .slice(0, 2e3);
      await chrome.storage.local.set({ [St]: Object.fromEntries(o) });
    } catch {}
  }
  async function Va() {
    Y.clear();
    try {
      await chrome.storage.local.remove(St);
    } catch {}
  }
  function Yn(t) {
    const e = E(t);
    return e
      ? !!(
          /^\d{1,2}:\d{2}(:\d{2})?$/.test(e) ||
          /^\d{4}-\d{1,2}-\d{1,2}(\s+\d{1,2}:\d{2}(:\d{2})?)?$/.test(e) ||
          /^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}(\s+\d{1,2}:\d{2}(:\d{2})?)?$/.test(e)
        )
      : !1;
  }
  function Ke(t) {
    const e = E(t).toLowerCase();
    return !!(
      !e ||
      Yn(e) ||
      /^(send|close|delete|remark|home|history|english|中文|search|reply|sent|delivered|read|copy|more|page\s*\d+|all|chat|message|messages)$/.test(
        e,
      )
    );
  }
  function At(t) {
    const e = E(t);
    if (
      !e ||
      e.length < 2 ||
      e.length > 1200 ||
      /^(https?:\/\/|www\.)\S+$/i.test(e) ||
      /^[\d\s\-+().,:/]+$/.test(e) ||
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)
    )
      return !1;
    const n = e.match(/[A-Za-z]/g)?.length || 0,
      a = e.match(/[㐀-鿿]/g)?.length || 0,
      o = e.replace(/\s/g, "").length || 1;
    return n >= 2 && n / o >= 0.35 && n >= a * 1.5;
  }
  function X(t) {
    if (!(t instanceof Element)) return !1;
    const e = getComputedStyle(t);
    if (e.display === "none" || e.visibility === "hidden" || e.opacity === "0") return !1;
    const n = t.getBoundingClientRect();
    return n.width > 0 && n.height > 0;
  }
  function ot(t) {
    return !!(t instanceof Element ? t : t?.parentElement)?.closest(
      `#${z}, #${ut}, #${te}, .${nt}`,
    );
  }
  function re(t) {
    return !!(
      !(t instanceof Element) ||
      ot(t) ||
      t.closest("script, style, noscript, svg, canvas, iframe, video, audio") ||
      t.closest("input, textarea, select, option") ||
      t.closest("pre, code, kbd, samp") ||
      t.closest("[contenteditable='true']")
    );
  }
  async function zt(t, e = "en", n = "zh-CN", a = "chat_translate", o = {}) {
    const s = (l) => {
        const g = String(
          l?.message || l?.error || l || "AI\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u7ED3\u679C",
        ).trim();
        typeof o.onError == "function" && o.onError(g);
      },
      r = { ...o };
    if ((delete r.onError, !mt() || !dt(a)))
      return (s("\u5F53\u524D\u8D26\u53F7\u6CA1\u6709AI\u7FFB\u8BD1\u6743\u9650"), "");
    const d = E(t);
    if (!d) return "";
    const i = `${e}|${n}|${d}`;
    if (!o.forceAi && Y.has(i)) return Y.get(i);
    if (!o.forceAi) {
      const l = await za(i);
      if (l) return (Y.set(i, l), l);
    }
    let c = "";
    if (o.forceAi || a === "input_translate" || /(^|\.)textnow\.com$/i.test(location.hostname))
      try {
        const l = await Gn(d, e, n, a, r);
        if (l?.ok && l.translated)
          return (Y.set(i, l.translated), await Zn(i, l.translated), l.translated);
        c =
          l?.message ||
          l?.error ||
          "\u684C\u9762AI\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u7ED3\u679C";
      } catch (l) {
        c = l?.message || "\u684C\u9762AI\u670D\u52A1\u8C03\u7528\u5931\u8D25";
      }
    if (!Jn())
      return (
        s(
          c ||
            "\u7FFB\u8BD1\u6269\u5C55\u8FDE\u63A5\u5DF2\u5931\u6548\uFF0C\u8BF7\u5237\u65B0\u9875\u9762",
        ),
        ""
      );
    try {
      const l = await chrome.runtime.sendMessage({
        type: "AI_TRANSLATE_TEXT",
        text: d,
        sourceLanguage: e,
        targetLanguage: n,
        featureCode: a,
        ...r,
      });
      if (!l?.ok || !l.translated)
        return (
          s(l?.error || l?.message || c || "AI\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u8BD1\u6587"),
          ""
        );
      if ((Y.set(i, l.translated), await Zn(i, l.translated), Y.size > 1500)) {
        const g = Y.keys().next().value;
        Y.delete(g);
      }
      return l.translated;
    } catch (l) {
      return (
        console.debug("[Bilingual Translator] sendMessage failed:", l),
        s(l?.message || c || "AI\u8BF7\u6C42\u5931\u8D25"),
        ""
      );
    }
  }
  async function hs(t) {
    const e = E(t);
    if (!e || !mt() || !dt("input_translate")) return [];
    const n = await Promise.race([
      Gn(e, "zh-CN", "en", "input_translate", { variants: !0 }),
      new Promise((a) =>
        setTimeout(() => a({ ok: !1, message: "\u7FFB\u8BD1\u8BF7\u6C42\u8D85\u65F6" }), 2e4),
      ),
    ]);
    if (n?.ok && Array.isArray(n.variants)) return n.variants;
    if (!Jn()) return [];
    try {
      const a = await chrome.runtime.sendMessage({
        type: "AI_TRANSLATE_VARIANTS",
        text: e,
        featureCode: "input_translate",
      });
      return a?.ok && Array.isArray(a.variants) ? a.variants : [];
    } catch {
      return [];
    }
  }
  function ie(t) {
    return /[\u3400-\u9FFF]/.test(String(t || ""));
  }
  function Qn(t) {
    let e = String(t || "");
    const n = [
      [/\bcolour\b/gi, "color"],
      [/\bcolours\b/gi, "colors"],
      [/\bfavourite\b/gi, "favorite"],
      [/\bfavourites\b/gi, "favorites"],
      [/\bcentre\b/gi, "center"],
      [/\bcentres\b/gi, "centers"],
      [/\borganise\b/gi, "organize"],
      [/\borganised\b/gi, "organized"],
      [/\borganising\b/gi, "organizing"],
      [/\brealise\b/gi, "realize"],
      [/\brealised\b/gi, "realized"],
      [/\btravelling\b/gi, "traveling"],
      [/\btravelled\b/gi, "traveled"],
      [/\bcancelled\b/gi, "canceled"],
      [/\blicence\b/gi, "license"],
      [/\bprogramme\b/gi, "program"],
    ];
    for (const [a, o] of n) e = e.replace(a, o);
    return e;
  }
  function U(t) {
    if (!(t instanceof Element) || ot(t)) return !1;
    if (M?.inputSelector)
      try {
        if (t.matches(M.inputSelector)) return !0;
      } catch {}
    if ($()) {
      const e = Ut();
      if (e && !e.contains(t)) return !1;
    }
    if (t instanceof HTMLTextAreaElement) return !t.disabled && !t.readOnly;
    if (t instanceof HTMLInputElement) {
      const e = (t.type || "text").toLowerCase();
      if (
        !["text", "search", "email", "url", "tel"].includes(e) ||
        t.disabled ||
        t.readOnly ||
        e === "search"
      )
        return !1;
      const n = `${t.placeholder || ""} ${t.className || ""}`.toLowerCase(),
        a = t.closest(
          ".chat_right,.chat_right_body,.chat-panel,.chat-content,.input-area,.chat_message_operates,[class*='chat-input'],[class*='message-input'],[class*='input-area']",
        ),
        o = t.getBoundingClientRect();
      return !!a || /message|chat|消息|短信|回复|输入/.test(n) || o.top > innerHeight * 0.55;
    }
    if (t.isContentEditable || t.getAttribute("contenteditable") === "plaintext-only")
      return !t.closest("[aria-disabled='true']");
    if (t.getAttribute("role") === "textbox") {
      const e = t.getBoundingClientRect(),
        n = `${t.getAttribute("aria-label") || ""} ${t.getAttribute("data-placeholder") || ""} ${t.className || ""}`;
      return (
        !t.closest("[aria-disabled='true']") &&
        (/message|chat|reply|send|消息|短信|回复|发送|输入/i.test(n) || e.top > innerHeight * 0.5)
      );
    }
    return !1;
  }
  function gt(t) {
    return t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement
      ? String(t.value || "")
      : String(t?.innerText || t?.textContent || "");
  }
  function ta(t) {
    return String(t || "")
      .replace(
        /\r\n?/g,
        `
`,
      )
      .replace(/[\u200B\uFEFF]/g, "")
      .replace(/\u00A0/g, " ")
      .replace(
        /[ \t]+\n/g,
        `
`,
      )
      .replace(
        /\n[ \t]+/g,
        `
`,
      )
      .replace(
        /\n{2,}/g,
        `
`,
      )
      .trim();
  }
  function Wa(t) {
    const e = localStorage.getItem("orangePreserveSendParagraphs") !== "false";
    let n = String(t || "")
      .replace(
        /\r\n?/g,
        `
`,
      )
      .replace(/[\u200B-\u200D\u2060\uFEFF]/g, "")
      .replace(/\u00A0/g, " ")
      .replace(
        /[ \t]+\n/g,
        `
`,
      )
      .replace(
        /\n[ \t]+/g,
        `
`,
      );
    return e
      ? n
          .split(/\n\s*\n+/)
          .map((a) =>
            a
              .replace(/\s*\n\s*/g, " ")
              .replace(/[ \t]{2,}/g, " ")
              .trim(),
          )
          .filter(Boolean).join(`

`)
      : n
          .replace(/\s*\n+\s*/g, " ")
          .replace(/[ \t]{2,}/g, " ")
          .trim();
  }
  function ea() {
    if (localStorage.getItem("orangeAutoCleanSendBreaks") === "false") return;
    const t = document.activeElement,
      e = U(t) ? t : v;
    if (!e?.isConnected || !U(e)) return;
    const n = gt(e),
      a = Wa(n);
    a && a !== n && ue(e, a);
  }
  function Ua() {
    (document.addEventListener(
      "keydown",
      (t) => {
        t.key === "Enter" && !t.shiftKey && !t.ctrlKey && !t.altKey && !t.isComposing && ea();
      },
      !0,
    ),
      document.addEventListener(
        "pointerdown",
        (t) => {
          const e = t.target instanceof Element ? t.target.closest("button,[role='button']") : null;
          if (!e) return;
          const n =
            `${e.textContent || ""} ${e.getAttribute("aria-label") || ""} ${e.getAttribute("title") || ""}`.trim();
          /send|发送/i.test(n) && ea();
        },
        !0,
      ));
  }
  function je(t) {
    if (t?.isConnected) {
      if (
        (t.focus({ preventScroll: !0 }),
        t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement)
      ) {
        const e = String(t.value || "").length;
        try {
          t.setSelectionRange(e, e);
        } catch {}
        return;
      }
      if (t.isContentEditable) {
        const e = window.getSelection(),
          n = document.createRange();
        (n.selectNodeContents(t), n.collapse(!1), e?.removeAllRanges(), e?.addRange(n));
      }
    }
  }
  function ue(t, e) {
    const n = ta(e);
    let a = !1;
    if (t instanceof HTMLInputElement) {
      const o = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      o ? o.call(t, n) : (t.value = n);
    } else if (t instanceof HTMLTextAreaElement) {
      const o = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      o ? o.call(t, n) : (t.value = n);
    } else if (t?.isContentEditable) {
      t.focus({ preventScroll: !0 });
      const o = window.getSelection(),
        s = document.createRange();
      (s.selectNodeContents(t), o?.removeAllRanges(), o?.addRange(s));
      try {
        a = document.execCommand("insertText", !1, n);
      } catch {}
      (!a || ta(gt(t)) !== n) && (t.textContent = n);
    } else return;
    (a ||
      t.dispatchEvent(
        new InputEvent("input", {
          bubbles: !0,
          composed: !0,
          inputType: "insertReplacementText",
          data: null,
        }),
      ),
      je(t),
      requestAnimationFrame(() => je(t)),
      setTimeout(() => je(t), 0));
  }
  function ce() {
    return document.querySelector(`#${z} .${Ne}`);
  }
  function Vt() {
    return document.querySelector(`#${z} .${Hn}`);
  }
  function Ge() {
    const t = Vt();
    if (!t) return;
    t.classList.remove("is-visible");
    const e = t.querySelector(".ai-bt-input-hint");
    e && (e.textContent = "");
  }
  function Je() {
    const t = Vt();
    if (!t || !v?.isConnected) return;
    const e = v.getBoundingClientRect(),
      n = Math.min(560, innerWidth - 16),
      a = Math.max(8, Math.min(e.left, innerWidth - n - 8)),
      o = Math.max(54, t.offsetHeight || 54),
      s = e.top - o - 8 >= 8 ? e.top - o - 8 : Math.min(innerHeight - o - 8, e.bottom + 8);
    ((t.style.left = `${a}px`), (t.style.top = `${Math.max(8, s)}px`), (t.style.width = `${n}px`));
  }
  async function Xe(t, e = "") {
    const n = Vt();
    if (!n) return;
    ((n.querySelector(".ai-bt-input-hint").textContent =
      e || "\u6B63\u5728\u56DE\u8BD1\u4E2D\u6587\u2026"),
      n.classList.add("is-visible"),
      Je());
    const a = await zt(t, "en", "zh-CN");
    n.isConnected &&
      gt(v).trim() === t.trim() &&
      ((n.querySelector(".ai-bt-input-hint").textContent = a || e || "\u56DE\u8BD1\u5931\u8D25"),
      Je());
  }
  function pt() {
    const t = ce();
    if (!t) return;
    if (!k || !v?.isConnected || !U(v)) {
      t.classList.remove("is-visible");
      return;
    }
    const e = v.getBoundingClientRect();
    if (e.width < 40 || e.height < 18 || e.bottom < 0 || e.top > innerHeight) {
      t.classList.remove("is-visible");
      return;
    }
    const n = t.offsetWidth || 70,
      a = t.offsetHeight || 28,
      o = 6;
    let s = e.right - n - o,
      r = e.top + o;
    ((s = Math.max(8, Math.min(s, innerWidth - n - 8))),
      (r = Math.max(8, Math.min(r, innerHeight - a - 8))),
      (t.style.left = `${s}px`),
      (t.style.top = `${r}px`),
      t.classList.add("is-visible"));
  }
  function Bt() {
    const t = ce();
    if (!t) return;
    const e = gt(v);
    (t.classList.toggle("has-chinese", ie(e)),
      (t.title = ie(e)
        ? "\u628A\u8F93\u5165\u6846\u4E2D\u6587\u7FFB\u8BD1\u4E3A\u7F8E\u5F0F\u82F1\u8BED"
        : "\u8F93\u5165\u4E2D\u6587\u540E\u70B9\u51FB\u7FFB\u8BD1"));
  }
  function fs(t, e) {
    const n = Vt();
    if (!n || !Array.isArray(e) || !e.length) return !1;
    const a = n.querySelector(".ai-bt-input-variant-list");
    if (!a) return !1;
    const o = {
      direct: "\u82F1\u6587",
      natural: "\u81EA\u7136\u8868\u8FBE",
      business: "\u5546\u52A1\u8868\u8FBE",
      chat: "\u7F8E\u56FD\u804A\u5929\u8868\u8FBE",
    };
    return (
      (a.innerHTML = e
        .slice(0, 4)
        .map((s, r) => {
          const d = E(s?.text || s),
            i = E(s?.chinese || t),
            c = String(s?.style || ["direct", "natural", "business", "chat"][r] || "natural"),
            l = (g) => g.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
          return `<div role="button" tabindex="0" class="ai-bt-input-choice" data-input-variant="${r}"><b>${o[c] || o.natural}</b><span><strong>${l(d)}</strong><small>${l(i)}</small></span></div>`;
        })
        .join("")),
      (n.querySelector(".ai-bt-input-hint").textContent =
        "\u70B9\u51FB\u53EA\u4F1A\u5199\u5165\u82F1\u6587\uFF1B\u53D1\u9001\u3001\u5207\u6362\u5BF9\u8BDD\u6216\u7EE7\u7EED\u8F93\u5165\u540E\u81EA\u52A8\u6536\u8D77\u3002"),
      n.classList.add("is-visible"),
      Je(),
      a.querySelectorAll("[data-input-variant]").forEach((s, r) =>
        s.addEventListener("click", () => {
          const d = e[r],
            i = Qn(d?.text || d);
          !i ||
            !v?.isConnected ||
            ((xt = { target: v, before: t, after: i, at: Date.now() }),
            ue(v, i),
            (a.innerHTML = ""),
            Xe(i, t),
            v.focus({ preventScroll: !0 }));
        }),
      ),
      !0
    );
  }
  async function na() {
    if (!mt() || !dt("input_translate") || Re || !k || !U(v)) return;
    const t = E(gt(v)),
      e = ce();
    if (!t || !ie(t)) {
      e &&
        ((e.textContent = "\u5148\u8F93\u5165\u4E2D\u6587"),
        setTimeout(() => {
          e && (e.textContent = "\u4E2D\u2192EN");
        }, 900));
      return;
    }
    ((Re = !0), e && (e.classList.add("is-busy"), (e.textContent = "\u7FFB\u8BD1\u4E2D\u2026")));
    try {
      const n = await zt(t, "zh-CN", "en", "input_translate");
      if (!n || !v?.isConnected) return;
      const a = Qn(n);
      ((xt = { target: v, before: t, after: a, at: Date.now() }),
        ue(v, a),
        Xe(a, t),
        v.focus({ preventScroll: !0 }),
        Bt());
    } finally {
      ((Re = !1), e && (e.classList.remove("is-busy"), (e.textContent = "\u4E2D\u2192EN")));
    }
  }
  function Ka() {
    (document.addEventListener(
      "focusin",
      (t) => {
        const e = t.target;
        U(e) && ((v = e), pt(), Bt());
      },
      !0,
    ),
      document.addEventListener(
        "input",
        (t) => {
          if (t.target !== v) return;
          (Bt(), pt());
          const e = E(gt(v));
          !e || ie(e)
            ? Ge()
            : Vt()?.classList.contains("is-visible") &&
              (clearTimeout(Un), (Un = setTimeout(() => Xe(e), 450)));
        },
        !0,
      ),
      document.addEventListener(
        "keydown",
        (t) => {
          if (
            (t.ctrlKey || t.metaKey) &&
            !t.altKey &&
            String(t.key).toLowerCase() === "z" &&
            xt?.target === document.activeElement &&
            E(gt(document.activeElement)) === E(xt.after)
          ) {
            (t.preventDefault(), ue(document.activeElement, xt.before), (xt = null), Ge());
            return;
          }
          if (((t.ctrlKey || t.metaKey) && !t.altKey) || !k || t.repeat || t.isComposing) return;
          const e = document.activeElement;
          if (!U(e)) {
            ((It = 0), (Rt = null));
            return;
          }
          if (
            (t.key === "Enter" && !t.shiftKey && setTimeout(() => Ge(), 120),
            t.key !== " " || t.ctrlKey || t.altKey || t.metaKey)
          ) {
            ((It = 0), (Rt = null));
            return;
          }
          const n = Date.now();
          if (Rt === e && n - It <= Na) {
            ((v = e), (It = 0), (Rt = null), t.preventDefault(), t.stopPropagation(), na());
            return;
          }
          ((It = n), (Rt = e));
        },
        !0,
      ),
      document.addEventListener("scroll", pt, !0),
      window.addEventListener("resize", pt));
  }
  async function ja(t) {
    try {
      await chrome.storage.local.set({ [Te]: !!t });
    } catch (e) {
      console.debug("[Bilingual Translator] Failed to save input translator state:", e);
    }
  }
  async function Ga() {
    try {
      k = !!(await chrome.storage.local.get(Te))?.[Te];
    } catch {
      k = !1;
    }
  }
  async function aa(t, { persist: e = !0 } = {}) {
    if (((k = !!t), e && (await ja(k)), !k)) ce()?.classList.remove("is-visible");
    else {
      const n = U(v) ? v : document.activeElement;
      U(n) && ((v = n), pt(), Bt());
    }
    q();
  }
  function Ja(t) {
    const e = E(t);
    if (!e || Yn(e)) return !1;
    const n = (e.match(/\d/g) || []).length;
    return !(n < 9 || n > 16 || /^20\d{6}$/.test(e));
  }
  function Xa(t) {
    const e = String(t || "");
    return (
      Ie.forEach((n) => {
        n.lastIndex = 0;
      }),
      Ie.some((n) => ((n.lastIndex = 0), n.test(e)))
    );
  }
  function oa(t) {
    if (!(t instanceof Element)) return null;
    const e = t.closest(
      ".im-chat-other, .im-chat-user, .chat-message, .chat_message, .message-item, .message-row, [class*='message-item'], [class*='message-row']",
    );
    if (e) return e;
    let n = t.parentElement,
      a = 0;
    for (; n && n !== document.body && a < 7; ) {
      const o = n.getBoundingClientRect(),
        s = n.innerText || n.textContent || "";
      if (
        Xa(s) &&
        o.width > 20 &&
        o.height > 15 &&
        o.height < Math.min(320, window.innerHeight * 0.48)
      )
        return n;
      ((n = n.parentElement), (a += 1));
    }
    return t.closest(".im-chat-text")?.parentElement || t.parentElement || t;
  }
  function Za() {
    const t = Ht();
    if (!t) return [document.body];
    const e = [];
    if (M?.phoneSelector)
      try {
        e.push(...document.querySelectorAll(M.phoneSelector));
      } catch {}
    if (t.name === "opensms-legacy") {
      const a = Array.from(document.querySelectorAll(".im-chat-other")).filter(
        (o) => o instanceof Element && X(o),
      );
      if (a.length) return a;
    }
    for (const a of t.containerSelectors || []) e.push(...document.querySelectorAll(a));
    for (const a of t.messageSelectors || [])
      for (const o of document.querySelectorAll(a)) e.push(oa(o));
    for (const a of [
      ".conversation-title__name[data-number]",
      ".conversation-title_name[data-number]",
      ".chat-header",
      ".chat_right_header",
      ".chat_right_body .header",
      "#kt_chat_messenger_header",
      "[class*='chat-header']",
      "[class*='conversation-header']",
      "[class*='recipient-info']",
      "[aria-selected='true']",
      "[aria-current='true']",
      "[data-selected='true']",
    ])
      e.push(...document.querySelectorAll(a));
    const n = Array.from(new Set(e)).filter((a) => a instanceof Element && X(a));
    if (t.name === "opensms-legacy") {
      const a = [];
      for (const s of document.querySelectorAll(".im-chat-text, .message-content")) {
        const r = oa(s);
        r && a.push(r);
      }
      const o = Array.from(new Set(a)).filter((s) => s instanceof Element && X(s));
      if (o.length) return o;
    }
    return n.length ? n : [document.body];
  }
  function sa() {
    const t = document.getElementById(z);
    if (!t) return null;
    let e = t.querySelector(`.${Ct}`);
    return (
      e ||
        ((e = document.createElement("div")),
        (e.className = Ct),
        e.setAttribute("aria-hidden", "true"),
        t.appendChild(e)),
      e
    );
  }
  function Ze() {
    sa()?.replaceChildren();
  }
  function Ya(t) {
    const e = [],
      n = new Set();
    for (const s of Ie) {
      s.lastIndex = 0;
      let r;
      for (; (r = s.exec(t)); ) {
        const d = r[0];
        if (!Ja(d)) continue;
        const i = `${r.index}:${d.length}`;
        n.has(i) || (n.add(i), e.push({ index: r.index, value: d }));
      }
    }
    const a = e.sort((s, r) => s.index - r.index || r.value.length - s.value.length),
      o = [];
    for (const s of a) {
      const r = s.index,
        d = r + s.value.length;
      o.some((i) => {
        const c = i.index,
          l = c + i.value.length;
        return r < l && d > c;
      }) || o.push(s);
    }
    return o;
  }
  function Qa(t) {
    if (!(t instanceof Text) || !t.parentElement) return !1;
    const e = t.nodeValue || "";
    if (!/\d{3}/.test(e) || ot(t)) return !1;
    const n = t.parentElement;
    return !(
      n.closest(`.${nt}, .${Ct}`) ||
      n.closest(
        "input, textarea, select, option, script, style, noscript, svg, canvas, form, [contenteditable], .input-area, .composer, .editor, .chat_message_operates, .el-input, [class*='chat-input'], [class*='message-input'], [class*='composer'], [class*='editor'], [class*='footer']",
      ) ||
      !X(n) ||
      (Ht()?.name === "opensms-legacy" &&
        (n.closest(
          ".contact-list, .contacts, .sidebar, .left, [class*='contact-list'], [class*='sidebar']",
        ) ||
          n.closest(".im-chat-user") ||
          (document.querySelector(".im-chat-other") && !n.closest(".im-chat-other"))))
    );
  }
  function Ye(t, { ignoreOpenSmsDirectionFilter: e = !1 } = {}) {
    const n = [];
    if (!(t instanceof Element)) return n;
    const a = document.createTreeWalker(t, NodeFilter.SHOW_TEXT, {
      acceptNode(s) {
        if (e && s instanceof Text && s.parentElement) {
          const r = s.nodeValue || "";
          if (!/\d{3}/.test(r) || ot(s)) return NodeFilter.FILTER_REJECT;
          const d = s.parentElement;
          return d.closest(`.${nt}, .${Ct}`) ||
            d.closest(
              "input, textarea, select, option, script, style, noscript, svg, canvas, form, [contenteditable], .input-area, .composer, .editor, .chat_message_operates, .el-input, [class*='chat-input'], [class*='message-input'], [class*='composer'], [class*='editor'], [class*='footer']",
            ) ||
            !X(d)
            ? NodeFilter.FILTER_REJECT
            : NodeFilter.FILTER_ACCEPT;
        }
        return Qa(s) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      },
    });
    let o;
    for (; (o = a.nextNode()); ) n.push(o);
    return n;
  }
  function to(t, e = 3) {
    let n = t,
      a = 0;
    for (; n && n !== document.body && a <= e; ) {
      const o = E(n.innerText || n.textContent || ""),
        s = n.getBoundingClientRect?.();
      if (
        o &&
        s &&
        s.height <= 110 &&
        s.width <= Math.max(900, window.innerWidth * 0.9) &&
        /对方号码|我方号码|搜索收信人号码|发信人|收信人/.test(o)
      )
        return o;
      ((n = n.parentElement), (a += 1));
    }
    return "";
  }
  function eo() {
    const t = [],
      e = rn();
    for (const n of e) {
      if (!(n instanceof Element) || !X(n)) continue;
      const a = n.getBoundingClientRect();
      Qe(a) && (a.width < 35 || a.height < 15 || a.height > 360 || t.push(a));
    }
    return t;
  }
  function no(t, e, n) {
    if (!(t instanceof Text) || !t.parentElement || !Qe(e)) return !1;
    const a = t.parentElement,
      o = to(a, 4);
    if (
      /对方号码|我方号码|搜索收信人号码/.test(o) ||
      a.closest(
        ".contact-list, .contacts, .sidebar, .left, nav, header, aside, [class*='contact-list'], [class*='contact_item'], [class*='contact-item'], [class*='sidebar'], [class*='menu'], [class*='nav'], [class*='toolbar']",
      )
    )
      return !1;
    let s = 1 / 0,
      r = !1;
    for (const d of n) {
      const i = d.top - e.bottom;
      if (i < -10 || i > 64) continue;
      const c = Math.abs(e.left - d.left);
      (!(e.right >= d.left - 26 && e.left <= d.right + 26) && c > 115) ||
        (i < s && ((s = i), (r = !0)));
    }
    return r;
  }
  function Qe(t) {
    return !(
      !t ||
      t.width <= 1 ||
      t.height <= 1 ||
      t.bottom < 0 ||
      t.right < 0 ||
      t.top > window.innerHeight ||
      t.left > window.innerWidth
    );
  }
  function ao(t, e, n) {
    if (
      document
        .elementFromPoint(
          Math.max(0, Math.min(window.innerWidth - 1, t.left + t.width / 2)),
          Math.max(0, Math.min(window.innerHeight - 1, t.top + t.height / 2)),
        )
        ?.closest?.(
          "input, textarea, form, [contenteditable], .input-area, .composer, .editor, .el-input, [class*='chat-input'], [class*='message-input'], [class*='composer'], [class*='editor'], [class*='footer']",
        )
    )
      return null;
    const o = document.createElement("div");
    ((o.className = On), (o.textContent = j), (o.dataset.aiBtOriginal = e));
    const s = Math.max(1, Math.min(window.innerWidth, t.width + 6)),
      r = Math.max(1, Math.min(window.innerHeight, t.height + 4));
    return (
      (o.style.left = `${Math.max(0, Math.min(window.innerWidth - s, t.left - 3))}px`),
      (o.style.top = `${Math.max(0, Math.min(window.innerHeight - r, t.top - 2))}px`),
      (o.style.width = `${s}px`),
      (o.style.height = `${r}px`),
      (o.style.fontSize = `${Math.max(8, Math.min(13, s / Math.max(4.5, j.length * 1.15)))}px`),
      n.appendChild(o),
      o
    );
  }
  function tn(t, e, { opensmsMessageRects: n = null, allowedPhoneDigits: a = null } = {}) {
    const o = t.nodeValue || "",
      s = Ya(o);
    if (!s.length) return 0;
    let r = 0;
    for (const d of s) {
      const i = String(d.value || "").replace(/\D/g, "");
      if (a instanceof Set && !a.has(i)) continue;
      const c = document.createRange();
      try {
        (c.setStart(t, d.index), c.setEnd(t, d.index + d.value.length));
      } catch {
        continue;
      }
      const l = Array.from(c.getClientRects()).filter(Qe);
      c.detach?.();
      for (const g of l) (Array.isArray(n) && !no(t, g, n)) || (ao(g, d.value, e), (r += 1));
    }
    return r;
  }
  function bt() {
    if (!x) return;
    const t = sa();
    if (!t) return;
    t.replaceChildren();
    const e = Ht();
    let n = 0;
    if (e?.name === "opensms-legacy") {
      const a = eo(),
        o = Ut();
      if (!o) {
        ((oe = 0), q());
        return;
      }
      const s = Ye(o, { ignoreOpenSmsDirectionFilter: !0 }),
        r = new Set();
      for (const i of s)
        r.has(i) || (r.add(i), (n += tn(i, t, a.length ? { opensmsMessageRects: a } : {})));
      const d = new Set(
        Array.from(t.querySelectorAll(`.${On}`))
          .map((i) => String(i.dataset.aiBtOriginal || "").replace(/\D/g, ""))
          .filter((i) => i.length >= 7),
      );
      if (d.size) {
        (t.replaceChildren(), (n = 0));
        const i = Ye(o, { ignoreOpenSmsDirectionFilter: !0 }),
          c = new Set();
        for (const l of i) c.has(l) || (c.add(l), (n += tn(l, t, { allowedPhoneDigits: d })));
      }
    } else {
      const a = Za(),
        o = new Set();
      for (const s of a) for (const r of Ye(s)) o.has(r) || (o.add(r), (n += tn(r, t)));
    }
    ((oe = n), q());
  }
  function Wt() {
    x &&
      (ae && cancelAnimationFrame(ae),
      (ae = requestAnimationFrame(() => {
        ((ae = 0), bt());
      })));
  }
  function _(t) {
    const e = String(t || "").trim();
    return /^#[0-9a-f]{6}$/i.test(e) ? e.toLowerCase() : "";
  }
  async function oo() {
    try {
      const t = await chrome.storage.local.get([it, qt]);
      ((S = _(t?.[it])), (P = _(t?.[qt])));
    } catch {
      ((S = ""), (P = ""));
    }
  }
  async function ra() {
    try {
      await chrome.storage.local.set({ [it]: S });
    } catch (t) {
      console.debug("[Bilingual Translator] Failed to save translation color:", t);
    }
  }
  function ia(t = document) {
    const e = t?.querySelectorAll?.(`.${at}`) || [],
      n = /(^|\.)textnow\.com$/i.test(location.hostname);
    for (const a of e)
      if (a instanceof HTMLElement)
        if (S) {
          if ((a.style.setProperty("color", S, "important"), n)) {
            const o = parseInt(S.slice(1, 3), 16),
              s = parseInt(S.slice(3, 5), 16),
              r = parseInt(S.slice(5, 7), 16),
              d = (0.2126 * o + 0.7152 * s + 0.0722 * r) / 255 < 0.48;
            (a.style.setProperty(
              "background",
              d ? "rgba(255,255,255,.90)" : "rgba(16,8,35,.58)",
              "important",
            ),
              a.style.setProperty(
                "text-shadow",
                d ? "none" : "0 1px 2px rgba(0,0,0,.82)",
                "important",
              ),
              a.style.setProperty(
                "box-shadow",
                d ? "0 1px 3px rgba(0,0,0,.18)" : "0 1px 3px rgba(0,0,0,.32)",
                "important",
              ));
          }
        } else
          (a.style.removeProperty("color"),
            n &&
              (a.style.removeProperty("background"),
              a.style.removeProperty("text-shadow"),
              a.style.removeProperty("box-shadow")));
  }
  function ht() {
    const t = !!S;
    (document.documentElement.classList.toggle("ai-bt-custom-translation-color", t),
      t
        ? document.documentElement.style.setProperty("--ai-bt-chat-translation-color", S)
        : document.documentElement.style.removeProperty("--ai-bt-chat-translation-color"),
      ia(document),
      q());
  }
  function le(t = document) {
    const e = t?.querySelectorAll?.(".ai-bt-generic-message") || [];
    for (const n of e)
      n instanceof HTMLElement &&
        (P
          ? (n.style.setProperty("color", P, "important"),
            n.style.setProperty("-webkit-text-fill-color", P, "important"))
          : (n.style.removeProperty("color"), n.style.removeProperty("-webkit-text-fill-color")));
    (document.documentElement.classList.toggle("ai-bt-custom-original-color", !!P),
      P
        ? document.documentElement.style.setProperty("--ai-bt-original-color", P)
        : document.documentElement.style.removeProperty("--ai-bt-original-color"));
  }
  async function ua(t) {
    ((S = _(t)), await ra(), ht());
  }
  async function so() {
    ((S = ""), await ra(), ht());
  }
  async function ro() {
    try {
      const t = await chrome.storage.local.get([kt, Tt, Mt]);
      ((R = _(t?.[kt]) || "#a97bff"), (T = L(t?.[Tt], 4, 10, 7)), (V = t?.[Mt] === !0));
    } catch {
      ((R = "#a97bff"), (T = 7), (V = !1));
    }
  }
  function O() {
    (document.documentElement.style.setProperty("--ai-bt-bubble-light-color", R),
      document.documentElement.style.setProperty("--ai-bt-bubble-light-width", `${T}px`),
      document.documentElement.classList.toggle(
        "ai-bt-bubble-light-off",
        !V || N.bubble_effect === !1,
      ));
    const t = document.querySelector("[data-ai-bt-bubble-light-color]");
    t && (t.value = R);
    const e = document.querySelector("[data-ai-bt-bubble-light-width]"),
      n = document.querySelector("[data-ai-bt-bubble-light-width-value]");
    (e && (e.value = String(T)), n && (n.textContent = `${T}px`));
  }
  async function ca(t, { persist: e = !0 } = {}) {
    ((V = t === !0), e && (await chrome.storage.local.set({ [Mt]: V })), O(), q());
  }
  async function en(t) {
    R = _(t) || "#a97bff";
    try {
      await chrome.storage.local.set({ [kt]: R });
    } catch (e) {
      console.debug("[Bilingual Translator] Failed to save bubble light color:", e);
    }
    (O(), q());
  }
  async function io(t) {
    T = L(t, 4, 10, 7);
    try {
      await chrome.storage.local.set({ [Tt]: T });
    } catch (e) {
      console.debug("[Bilingual Translator] Failed to save bubble light width:", e);
    }
    O();
  }
  function L(t, e, n, a) {
    const o = Number(t);
    return Number.isFinite(o) ? Math.min(n, Math.max(e, o)) : a;
  }
  function ys() {
    try {
      return chrome.runtime.getURL(Pa);
    } catch {
      return "";
    }
  }
  function la() {
    return m.imageDataUrl || "";
  }
  function ft() {
    return !!la();
  }
  async function nn() {
    try {
      const t = (await chrome.storage.local.get(wt))?.[wt],
        e = /(^|\.)(?:opensms\.xin|opensms\.cc)$/i.test(location.hostname);
      if (t && typeof t == "object") {
        const n = Number(t.schemaVersion || 0) < Pt;
        if (
          ((m = {
            schemaVersion: Pt,
            enabled: n ? !1 : !!t.enabled,
            imageDataUrl: typeof t.imageDataUrl == "string" ? t.imageDataUrl : "",
            imageOpacity: L(t.imageOpacity, 0.15, 1, 1),
            panelOpacity: L(t.panelOpacity, 0.06, 0.72, 0.22),
            groupPanelOpacity: L(t.groupPanelOpacity, 0.35, 0.98, 0.9),
            blur: L(t.blur, 0, 12, 0),
            brightness: L(t.brightness, 55, 145, 100),
            glassBlur: L(t.glassBlur, 0, 10, 4),
          }),
          n)
        )
          try {
            await chrome.storage.local.set({ [wt]: m });
          } catch {}
      } else m.enabled = !1;
    } catch (t) {
      console.debug("[Bilingual Translator] Failed to load custom background:", t);
    }
  }
  async function de() {
    try {
      ((m.schemaVersion = Pt), await chrome.storage.local.set({ [wt]: m }));
    } catch (t) {
      throw (console.debug("[Bilingual Translator] Failed to save custom background:", t), t);
    }
  }
  function uo() {
    const t = document.getElementById(te);
    t && t.id !== ut && t.remove();
    let e = document.getElementById(ut);
    return (
      e
        ? e.classList.contains(Me) || e.classList.add(Me)
        : ((e = document.createElement("div")),
          (e.id = ut),
          (e.className = Me),
          e.setAttribute("aria-hidden", "true"),
          e.setAttribute("data-ai-bt-background-layer", "true"),
          document.body.insertBefore(e, document.body.firstChild)),
      e
    );
  }
  function co() {
    document
      .querySelectorAll(
        [
          `.${Bn}`,
          `.${Dn}`,
          `.${Ln}`,
          `.${_n}`,
          `.${$n}`,
          `.${qn}`,
          `.${kn}`,
          `.${Tn}`,
          `.${Mn}`,
          `.${Pn}`,
          `.${Nn}`,
          `.${In}`,
          `.${Rn}`,
        ].join(","),
      )
      .forEach((t) => {
        t.classList.remove(Bn, Dn, Ln, _n, $n, qn, kn, Tn, Mn, Pn, Nn, In, Rn);
      });
  }
  function Es(t) {
    const e = String(t || "").match(/rgba?\((\d+)[,\s]+(\d+)[,\s]+(\d+)(?:[,\s/]+([\d.]+))?\)/i);
    return e
      ? { r: Number(e[1]), g: Number(e[2]), b: Number(e[3]), a: e[4] == null ? 1 : Number(e[4]) }
      : null;
  }
  function Fs(t) {
    if (!(t instanceof Element)) return !0;
    const e = `${t.className || ""} ${t.id || ""}`.toLowerCase();
    return !!(
      /message[-_ ]?(bubble|text|content)|chat[-_ ]?(bubble|message)|toast|tooltip|popover|modal|dialog/.test(
        e,
      ) ||
      t.matches(
        "button, input, textarea, select, option, img, svg, canvas, video, audio, table, tr, td, th",
      ) ||
      t.closest(`#${z}, #${ut}, #${te}`) ||
      t.closest("[role='dialog'], [role='menu'], [role='tooltip']")
    );
  }
  function $() {
    return /(^|\.)(?:opensms\.xin|opensms\.cc)$/i.test(location.hostname)
      ? !0
      : !!document.querySelector(
          "#div-im-app .main-content .right, #div-im-app .main.content .right, #v-im-app .main-content .right, #v-im-app .main.content .right, #im-app .main_content .right, #im-app .main-content .right",
        );
  }
  function da() {
    return $() || /(^|\.)client\.xhsim\.ai$/i.test(location.hostname);
  }
  function lo() {
    if (!document.documentElement) return;
    const t = !!document.querySelector(
        ".chat_right_body, .chat_message, .chat_message_operates, .inputchat_message_operate_text",
      ),
      e = !!document.querySelector("#messageParent, #kt_chat_messenger_footer"),
      n = !!document.querySelector(
        ".chat-panel .messages-area, .messages-list, .chat-panel .input-area",
      );
    (document.documentElement.classList.toggle("ai-bt-host-opensms", $()),
      document.documentElement.classList.toggle(
        "ai-bt-host-textnow",
        /(^|\.)textnow\.com$/i.test(location.hostname),
      ),
      document.documentElement.classList.toggle(
        "ai-bt-host-skt1",
        /(^|\.)skt1\.net$/i.test(location.hostname) || t,
      ),
      document.documentElement.classList.toggle(
        "ai-bt-host-xhsim",
        /(^|\.)client\.xhsim\.ai$/i.test(location.hostname) || e,
      ),
      document.documentElement.classList.toggle(
        "ai-bt-host-xinghan",
        /(^|\.)xinghansms\.net$/i.test(location.hostname) || t,
      ),
      document.documentElement.classList.toggle(
        "ai-bt-host-c2c",
        /(^|\.)c2csms\.com$/i.test(location.hostname) || n,
      ),
      document.documentElement.classList.add("ai-bt-host-generic"));
  }
  function Ut() {
    return $()
      ? document.querySelector("#div-im-app > .v-im > .main.content > .right") ||
          document.querySelector("#div-im-app .main-content .right") ||
          document.querySelector("#v-im-app > .v-im > .main.content > .right") ||
          document.querySelector("#v-im-app .main-content .right") ||
          document.querySelector("#im-app > .im > .main_content > .right") ||
          document.querySelector("#im-app .main-content .right") ||
          document.querySelector("#div-im-app .right, #v-im-app .right, #im-app .right")
      : null;
  }
  function mo() {
    return $()
      ? document.querySelector("#div-im-app > .v-im > .main.content") ||
          document.querySelector("#v-im-app > .v-im > .main.content") ||
          document.querySelector("#im-app > .im > .main_content") ||
          document.querySelector(
            "#div-im-app .main.content, #v-im-app .main.content, #im-app .main_content",
          )
      : null;
  }
  function vs(t) {
    return t instanceof Element ? !!t.closest(`#${z}, #${ut}, #${te}, .${Ct}`) : !0;
  }
  function an() {
    !$() || N.custom_background === !1 || !m.enabled || !ft() || Ut();
  }
  function ws() {
    $() && an();
  }
  function on() {
    if (N.custom_background === !1 || !m.enabled || !ft()) {
      (G && clearTimeout(G), (G = null));
      return;
    }
    (G && clearTimeout(G),
      (G = setTimeout(() => {
        ((G = null), an());
      }, 300)));
  }
  function B(t, e, n) {
    t.style.setProperty(e, n, "important");
  }
  function H() {
    if (!document.body) return;
    const t = la(),
      e = !!(N.custom_background !== !1 && m.enabled && t),
      n = e ? uo() : document.getElementById(ut);
    (document.documentElement.classList.toggle("ai-bt-custom-bg-on", e),
      document.body.classList.toggle("ai-bt-custom-bg-on", e),
      document.documentElement.style.setProperty(
        "--ai-bt-bg-panel-opacity",
        String(m.panelOpacity),
      ),
      document.documentElement.style.setProperty(
        "--ai-bt-group-panel-opacity",
        String(m.groupPanelOpacity),
      ),
      document.documentElement.style.setProperty("--ai-bt-bg-blur", `${m.blur}px`),
      document.documentElement.style.setProperty(
        "--ai-bt-bg-image-opacity",
        String(m.imageOpacity),
      ),
      document.documentElement.style.setProperty("--ai-bt-bg-brightness", `${m.brightness}%`),
      document.documentElement.style.setProperty(
        "--ai-bt-bg-scale",
        m.blur > 0 ? "1.015" : "1.002",
      ),
      document.documentElement.style.setProperty("--ai-bt-glass-blur", `${m.glassBlur}px`));
    const a = L(m.panelOpacity, 0.06, 0.72, 0.22);
    if (
      (document.documentElement.style.setProperty(
        "--ai-bt-left-alpha",
        String(Math.min(0.78, a + 0.1)),
      ),
      document.documentElement.style.setProperty(
        "--ai-bt-left-alpha-2",
        String(Math.min(0.68, a + 0.02)),
      ),
      document.documentElement.style.setProperty(
        "--ai-bt-nav-alpha",
        String(Math.min(0.92, a + 0.5)),
      ),
      document.documentElement.style.setProperty(
        "--ai-bt-nav-alpha-2",
        String(Math.min(0.86, a + 0.38)),
      ),
      document.documentElement.style.setProperty(
        "--ai-bt-history-alpha",
        String(Math.min(0.9, a + 0.42)),
      ),
      document.documentElement.style.setProperty(
        "--ai-bt-history-alpha-2",
        String(Math.min(0.84, a + 0.3)),
      ),
      document.documentElement.style.setProperty(
        "--ai-bt-contact-alpha",
        String(Math.min(0.78, a + 0.25)),
      ),
      document.documentElement.style.setProperty(
        "--ai-bt-contact-alpha-2",
        String(Math.min(0.68, a + 0.12)),
      ),
      document.documentElement.style.setProperty(
        "--ai-bt-input-alpha",
        String(Math.min(0.78, a + 0.26)),
      ),
      !e)
    ) {
      (G && clearTimeout(G),
        (G = null),
        n?.remove(),
        document.documentElement.style.removeProperty("background-image"),
        document.documentElement.style.removeProperty("background-repeat"),
        document.documentElement.style.removeProperty("background-position"),
        document.documentElement.style.removeProperty("background-size"),
        document.documentElement.style.removeProperty("background-attachment"),
        document.documentElement.style.removeProperty("background-color"),
        document.documentElement.style.removeProperty("--ai-bt-bg-image"),
        co(),
        q());
      return;
    }
    const o = `url(${JSON.stringify(t)})`;
    (document.documentElement.style.setProperty("--ai-bt-bg-image", o),
      B(n, "position", "fixed"),
      B(n, "inset", "0"),
      B(n, "width", "100vw"),
      B(n, "height", "100vh"),
      B(n, "min-width", "100vw"),
      B(n, "min-height", "100vh"),
      B(n, "background-image", o),
      B(n, "background-repeat", "no-repeat"),
      B(n, "background-position", "center center"),
      B(n, "background-size", "cover"),
      B(n, "background-attachment", "fixed"),
      B(n, "background-color", "#08111f"),
      B(n, "opacity", $() ? "0" : String(m.imageOpacity)),
      B(n, "visibility", $() ? "hidden" : "visible"));
    const s = m.blur > 0 || m.brightness !== 100;
    (B(n, "filter", s ? `blur(${m.blur}px) brightness(${m.brightness}%)` : "none"),
      B(n, "transform", m.blur > 0 ? "translateZ(0) scale(1.015)" : "none"),
      B(n, "transform-origin", "center center"),
      B(n, "pointer-events", "none"),
      B(n, "z-index", "0"),
      document.documentElement.style.removeProperty("background-image"),
      document.documentElement.style.removeProperty("background-repeat"),
      document.documentElement.style.removeProperty("background-position"),
      document.documentElement.style.removeProperty("background-size"),
      document.documentElement.style.removeProperty("background-attachment"),
      document.documentElement.style.removeProperty("background-color"),
      an(),
      q());
  }
  async function go(t) {
    if (!(t instanceof File) || !t.type.startsWith("image/"))
      throw new Error("\u8BF7\u9009\u62E9\u56FE\u7247\u6587\u4EF6");
    const e = await new Promise((i, c) => {
        const l = new FileReader();
        ((l.onload = () => i(String(l.result || ""))),
          (l.onerror = () => c(new Error("\u8BFB\u53D6\u56FE\u7247\u5931\u8D25"))),
          l.readAsDataURL(t));
      }),
      n = await new Promise((i, c) => {
        const l = new Image();
        ((l.onload = () => i(l)),
          (l.onerror = () => c(new Error("\u65E0\u6CD5\u89E3\u6790\u8FD9\u5F20\u56FE\u7247"))),
          (l.src = e));
      }),
      a = Math.min(1, 2560 / Math.max(n.naturalWidth || 1, n.naturalHeight || 1)),
      o = Math.max(1, Math.round((n.naturalWidth || 1) * a)),
      s = Math.max(1, Math.round((n.naturalHeight || 1) * a)),
      r = document.createElement("canvas");
    ((r.width = o), (r.height = s));
    const d = r.getContext("2d", { alpha: !0 });
    if (!d) return e;
    d.drawImage(n, 0, 0, o, s);
    try {
      const i = r.toDataURL("image/webp", 0.9);
      if (i && i.startsWith("data:image/webp")) return i;
    } catch {}
    return r.toDataURL("image/jpeg", 0.9);
  }
  async function po(t) {
    const e = await go(t);
    ((m.imageDataUrl = e), (m.enabled = !0), await de(), H());
  }
  async function me(t, e) {
    (t === "imageOpacity" && (m.imageOpacity = L(e, 0.15, 1, 1)),
      t === "panelOpacity" && (m.panelOpacity = L(e, 0.06, 0.72, 0.22)),
      t === "groupPanelOpacity" && (m.groupPanelOpacity = L(e, 0.35, 0.98, 0.9)),
      t === "blur" && (m.blur = L(e, 0, 12, 0)),
      t === "brightness" && (m.brightness = L(e, 55, 145, 100)),
      t === "glassBlur" && (m.glassBlur = L(e, 0, 10, 4)),
      await de(),
      H());
  }
  async function bo() {
    return ft() ? ((m.enabled = !m.enabled), await de(), H(), !0) : !1;
  }
  async function ho() {
    ((m = {
      schemaVersion: Pt,
      enabled: !1,
      imageDataUrl: "",
      imageOpacity: 1,
      panelOpacity: 0.22,
      groupPanelOpacity: 0.9,
      blur: 0,
      brightness: 100,
      glassBlur: 4,
    }),
      await de(),
      H());
  }
  function st(t) {
    const e = t.cloneNode(!0);
    return (
      e.querySelectorAll(`.${nt}`).forEach((n) => n.remove()),
      E(e.innerText || e.textContent || "")
    );
  }
  function ge(t) {
    t.querySelectorAll(`:scope > .${at}`).forEach((e) => e.remove());
  }
  function ma(t) {
    let e = 0,
      n = t;
    for (; n?.parentElement; ) ((e += 1), (n = n.parentElement));
    return e;
  }
  function ga(t, e = null) {
    if (
      !(t instanceof Element) ||
      re(t) ||
      !X(t) ||
      t.classList.contains(at) ||
      t.matches("button, a, label, input, textarea, select, option, img, svg, time") ||
      t.closest(
        "[class*='avatar' i], [class*='profile' i], [class*='portrait' i], [class*='operation' i], [class*='operate' i], [class*='action' i], [class*='toolbar' i], [role='button']",
      ) ||
      t.closest("button, a[href], label, form, nav, header, footer, aside") ||
      (!(
        /(^|\.)textnow\.com$/i.test(location.hostname) &&
        t.matches(".tn-chat-bubble-text") &&
        t.closest("#messageView li.chat-item.incoming, #messageView li.chat-item.outgoing")
      ) &&
        t.closest(
          "[class*='sidebar'], [class*='header'], [class*='footer'], [class*='toolbar'], [class*='pagination'], [class*='search'], [class*='operate'], [class*='menu'], [class*='nav']",
        ))
    )
      return !1;
    const n = st(t);
    if (!At(n) || Ke(n) || t.querySelector("button, input, textarea, select")) return !1;
    const a = t.getBoundingClientRect();
    if (a.height > 320 || a.width < 10) return !1;
    const o = e?.getBoundingClientRect?.();
    return !(o?.width && a.width > o.width * 0.98 && n.length < 12);
  }
  function pa(t) {
    const e = Array.from(new Set(t))
        .filter(Boolean)
        .sort((a, o) => ma(o) - ma(a)),
      n = [];
    for (const a of e) {
      const o = st(a);
      n.some((s) => {
        if (!a.contains(s)) return !1;
        const r = a.getBoundingClientRect(),
          d = s.getBoundingClientRect();
        if (
          Math.abs(r.left - d.left) < 32 &&
          Math.abs(r.top - d.top) < 32 &&
          Math.abs(r.right - d.right) < 48 &&
          Math.abs(r.bottom - d.bottom) < 64
        )
          return !0;
        const i = st(s);
        return i && i.length >= Math.max(8, o.length * 0.6);
      }) || n.push(a);
    }
    return n.sort((a, o) => {
      const s = a.getBoundingClientRect(),
        r = o.getBoundingClientRect();
      return Math.abs(s.top - r.top) > 4 ? s.top - r.top : s.left - r.left;
    });
  }
  function fo(t) {
    if (!(t instanceof Element)) return [];
    const e = Array.from(t.querySelectorAll("div, p, span, li")).filter((n) => ga(n, t));
    return pa(e);
  }
  function sn() {
    if (M?.chatContainerSelector)
      try {
        const t = document.querySelector(M.chatContainerSelector);
        if (t) return t;
      } catch {}
    return $()
      ? document.querySelector("#v-im-app > .v-im > .main.content > .right") ||
          document.querySelector("#im-app > .im > .main_content > .right") ||
          document.querySelector("#v-im-app .right, #im-app .right") ||
          document.body
      : document;
  }
  function rn() {
    const t = Ht(),
      e = [],
      n = sn();
    if (/(^|\.)client\.xhsim\.ai$/i.test(location.hostname)) {
      const s = document.querySelector("#messageParent");
      if (s) {
        const r = Array.from(s.querySelectorAll(":scope > [id^='chatMessage_'], :scope > div"));
        for (const d of r) {
          const i = [d, ...d.querySelectorAll("p,span,div")].filter((c) => {
            if (!(c instanceof Element) || !X(c) || re(c)) return !1;
            const l = st(c);
            return !At(l) ||
              Ke(l) ||
              l.length > 1600 ||
              /^(已发送|已送达|发送中|送达|加载失败|sent|delivered)$/i.test(l) ||
              /^20\d{2}[-/]\d{1,2}[-/]\d{1,2}/.test(l) ||
              /^\d{1,2}:\d{2}/.test(l)
              ? !1
              : Array.from(c.children).filter((g) => At(st(g))).length === 0;
          });
          (i.sort((c, l) => {
            const g = /message|text|content|bubble/i.test(String(c.className || "")) ? -1e5 : 0,
              b = /message|text|content|bubble/i.test(String(l.className || "")) ? -1e5 : 0,
              p = c.getBoundingClientRect(),
              y = l.getBoundingClientRect();
            return g + p.width * p.height - (b + y.width * y.height);
          }),
            i[0] && e.push(i[0]));
        }
      }
    }
    const a = new Set([
      ...(t?.messageSelectors || []).filter(Boolean),
      ".im-chat-text",
      ".message-content",
      ".message-text",
      ".msg-content",
      ".chat-bubble",
      ".message-bubble",
      "[data-message-id]",
      "[data-msg-id]",
      "[class*='message-content']",
      "[class*='message-text']",
      "[class*='message-item']",
      "[class*='chat-message']",
      "[class*='bubble']",
    ]);
    for (const s of a) for (const r of n.querySelectorAll(s)) ga(r) && e.push(r);
    const o = Array.from(
      new Set([
        ...(t?.containerSelectors || []).filter(Boolean),
        ".chat_message",
        ".messages-list",
        ".messages-area",
        ".chat-content",
        ".conversation-content",
        "[data-testid*='conversation' i]",
        "[role='log']",
        "[class*='chat-message']",
        "[class*='messages-list']",
        "[class*='conversation-content']",
      ]),
    );
    for (const s of o) for (const r of n.querySelectorAll(s)) e.push(...fo(r));
    return pa(e).filter(X);
  }
  async function yo(t, e) {
    if (!mt() || !dt("chat_translate") || !(t instanceof Element)) return;
    (t.classList.add("ai-bt-generic-message"), le(t.parentElement || document));
    const n = sn()?.getBoundingClientRect?.(),
      a = t.getBoundingClientRect(),
      o = t.closest("li.chat-item.incoming, li.chat-item.outgoing");
    if (
      (o?.classList.contains("incoming")
        ? (t.dataset.aiBtSide = "incoming")
        : o?.classList.contains("outgoing")
          ? (t.dataset.aiBtSide = "outgoing")
          : n &&
            (t.dataset.aiBtSide =
              a.left + a.width / 2 >= n.left + n.width / 2 ? "outgoing" : "incoming"),
      t.closest(
        "[class*='avatar' i], [class*='profile' i], [class*='portrait' i], [class*='operation' i], [class*='operate' i], [class*='action' i], [class*='toolbar' i], [role='button']",
      ))
    ) {
      (ge(t), Nt.delete(t), t.classList.remove("ai-bt-generic-message"));
      return;
    }
    if (re(t)) return;
    const s = st(t);
    if (!At(s) || Ke(s)) {
      (ge(t), Nt.delete(t));
      return;
    }
    const r =
        t.closest(
          ".im-chat-other, .im-chat-user, .im-chat-self, .im-chat-mine, li.chat-item.incoming, li.chat-item.outgoing, [data-message-id], [data-msg-id], [class*='message-row'], [class*='message-item']",
        ) || t,
      d = ee.get(r);
    if (d?.target?.isConnected && d.target !== t && d.text === s) {
      (ge(t), t.classList.remove("ai-bt-generic-message"), Nt.delete(t));
      return;
    }
    if (Nt.get(t) === s && t.querySelector(`:scope > .${at}`)) return;
    (ge(t), Nt.set(t, s), ee.set(r, { target: t, text: s, pending: !0 }));
    const i = await zt(s, "en", "zh-CN", "chat_translate");
    if (e !== J || w !== C || !t.isConnected || !i || st(t) !== s || ee.get(r)?.target !== t)
      return;
    r.querySelectorAll(`.${at}`).forEach((p) => {
      t.contains(p) || p.remove();
    });
    const c = document.createElement(
      /(^|\.)textnow\.com$/i.test(location.hostname) ? "span" : "div",
    );
    c.className = `${nt} ${at}`;
    const l = document.createElement("span");
    ((l.className = "ai-bt-chat-translation-text"), (l.textContent = i));
    const g = document.createElement("span");
    ((g.className = "ai-bt-chat-translation-actions"),
      (g.innerHTML =
        '<button type="button" data-ai-bt-copy-translation title="\u590D\u5236\u8BD1\u6587" aria-label="\u590D\u5236\u8BD1\u6587">\u25A3</button><button type="button" data-ai-bt-retranslate title="AI\u91CD\u65B0\u7FFB\u8BD1" aria-label="AI\u91CD\u65B0\u7FFB\u8BD1">\u21BB</button>'),
      c.append(l, g));
    const b = document.createElement("span");
    ((b.className = "ai-bt-retranslate-status"),
      (b.hidden = !0),
      c.appendChild(b),
      c.setAttribute("aria-label", "\u4E2D\u6587\u7FFB\u8BD1"),
      g.querySelector("[data-ai-bt-copy-translation]")?.addEventListener("click", async (p) => {
        p.stopPropagation();
        const y = l.textContent || "";
        try {
          await navigator.clipboard.writeText(y);
        } catch {
          const A = document.createRange();
          A.selectNodeContents(l);
          const h = getSelection();
          (h.removeAllRanges(), h.addRange(A), document.execCommand("copy"), h.removeAllRanges());
        }
        ((p.currentTarget.textContent = "\u2713"),
          setTimeout(() => {
            p.currentTarget?.isConnected && (p.currentTarget.textContent = "\u25A3");
          }, 900));
      }),
      g.querySelector("[data-ai-bt-retranslate]")?.addEventListener("click", async (p) => {
        p.stopPropagation();
        const y = p.currentTarget;
        if (y.disabled) return;
        ((y.disabled = !0), (y.textContent = "\u2026"));
        const A = rn(),
          h = A.indexOf(t),
          D = A.slice(Math.max(0, h - 5), h < 0 ? 8 : h + 4).map(
            (rt) => `${rt.dataset.aiBtSide === "outgoing" ? "Me" : "Customer"}: ${st(rt)}`,
          ).join(`
`),
          $t = String(l.textContent || "").trim();
        ((b.hidden = !0), (b.textContent = ""));
        let vt = "";
        const et = await zt(s, "en", "zh-CN", "chat_translate", {
          forceAi: !0,
          alternative: !0,
          previousTranslation: $t,
          context: D,
          onError: (rt) => {
            vt = rt;
          },
        });
        (et && (l.textContent = et),
          (y.disabled = !1),
          et
            ? et.trim() === $t
              ? ((y.textContent = "="),
                (y.title =
                  "AI\u5DF2\u91CD\u65B0\u7FFB\u8BD1\uFF0C\u7ED3\u679C\u4E0E\u539F\u8BD1\u6587\u76F8\u540C"),
                (b.textContent =
                  "AI\u5DF2\u91CD\u65B0\u7FFB\u8BD1\uFF0C\u7ED3\u679C\u4E0E\u5F53\u524D\u8BD1\u6587\u76F8\u540C"),
                (b.hidden = !1))
              : ((y.textContent = "\u2713"),
                (y.title = "\u5DF2\u4F7F\u7528AI\u91CD\u65B0\u7FFB\u8BD1"),
                (b.textContent = "AI\u91CD\u65B0\u7FFB\u8BD1\u5B8C\u6210"),
                (b.hidden = !1))
            : ((y.textContent = "!"),
              (y.title =
                "AI\u91CD\u65B0\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u6A21\u578B\u548CKey"),
              (b.textContent = `AI\u91CD\u8BD1\u5931\u8D25\uFF1A${vt || "\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u7ED3\u679C"}`),
              (b.hidden = !1)),
          setTimeout(() => {
            y.isConnected && ((y.textContent = "\u21BB"), (y.title = "AI\u91CD\u65B0\u7FFB\u8BD1"));
          }, 1800),
          setTimeout(
            () => {
              b.isConnected && (b.hidden = !0);
            },
            et ? 2600 : 8e3,
          ));
      }),
      t.appendChild(c),
      ee.set(r, { target: t, text: s, pending: !1 }),
      ia(t));
  }
  async function un(t = J) {
    if (w === C) {
      if (He) {
        ze = !0;
        return;
      }
      He = !0;
      try {
        const e = rn();
        for (const n of e) {
          if (t !== J || w !== C) return;
          await yo(n, t);
        }
      } finally {
        ((He = !1), ze && w === C && ((ze = !1), setTimeout(() => un(J), 120)));
      }
    }
  }
  function Eo() {
    document.querySelectorAll(`.${at}`).forEach((t) => t.remove());
  }
  function Fo(t) {
    if (!(t instanceof Text) || !t.parentElement || ot(t)) return !1;
    const e = t.parentElement;
    if (re(e) || !X(e)) return !1;
    const n = E(t.nodeValue);
    return !(!At(n) || e.closest(`.${at}, .${Yt}`));
  }
  function vo() {
    const t = [],
      e = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(a) {
          return Fo(a) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        },
      });
    let n;
    for (; (n = e.nextNode()); ) t.push(n);
    return t;
  }
  function wo(t) {
    const e = t.nextSibling;
    return e instanceof Element && e.classList.contains(Yt) ? e : null;
  }
  async function Co(t, e) {
    if (!mt() || !dt("page_translate") || !t?.isConnected || w !== K) return;
    const n = E(t.nodeValue);
    if (!At(n)) return;
    const a = wo(t);
    if (Vn.get(t) === n && a) return;
    (a && a.remove(), Vn.set(t, n));
    const o = await zt(n, "en", "zh-CN", "page_translate");
    if (e !== J || w !== K || !t.isConnected || !o || E(t.nodeValue) !== n) return;
    const s = document.createElement("span");
    ((s.className = `${nt} ${Yt}`),
      (s.textContent = o),
      s.setAttribute("aria-label", "\u4E2D\u6587\u7FFB\u8BD1"),
      t.parentNode.insertBefore(s, t.nextSibling));
  }
  async function So(t, e, n) {
    let a = 0;
    async function o() {
      for (; a < t.length; ) {
        const r = a++;
        await e(t[r]);
      }
    }
    const s = Array.from({ length: Math.min(n, t.length) }, () => o());
    await Promise.all(s);
  }
  async function ba(t = J) {
    if (!(w !== K || Oe)) {
      Oe = !0;
      try {
        const e = vo();
        for (let n = 0; n < e.length; n += 80) {
          if (t !== J || w !== K) return;
          const a = e.slice(n, n + 80);
          (await So(a, (o) => Co(o, t), 4), await Oa(30));
        }
      } finally {
        Oe = !1;
      }
    }
  }
  function xo() {
    document.querySelectorAll(`.${Yt}`).forEach((t) => t.remove());
  }
  function Ao() {
    (Eo(), xo());
  }
  async function pe(t) {
    try {
      await chrome.storage.local.set({ [$e]: !!t });
    } catch (e) {
      console.debug("[Bilingual Translator] Failed to save phone mask state:", e);
    }
  }
  async function Bo() {
    try {
      x = !!(await chrome.storage.local.get($e))?.[$e];
    } catch {
      x = !1;
    }
  }
  function ha(t) {
    return (
      String(t || "")
        .replace(/[<>\r\n]/g, "")
        .trim()
        .slice(0, 12) || Pe
    );
  }
  async function Do() {
    try {
      const t = await chrome.storage.local.get([qe, ke]);
      ((j = ha(t?.[qe])), (Q = _(t?.[ke]) || "#ffffff"));
    } catch {
      ((j = Pe), (Q = "#ffffff"));
    }
    document.documentElement.style.setProperty("--ai-bt-phone-mask-color", Q);
  }
  async function fa() {
    (await chrome.storage.local.set({ [qe]: j, [ke]: Q }),
      document.documentElement.style.setProperty("--ai-bt-phone-mask-color", Q),
      x && bt(),
      q());
  }
  async function ya(t, { persist: e = !0 } = {}) {
    ((x = !!t), e && (await pe(x)), x ? bt() : (Ze(), (oe = 0)), q());
  }
  async function Lo(t) {
    try {
      await chrome.storage.local.set({ [Le]: t });
    } catch (e) {
      console.debug("[Bilingual Translator] Failed to save mode:", e);
    }
  }
  async function cn(t, { persist: e = !0 } = {}) {
    if (![C, K, Qt].includes(t)) return;
    ((w = t), (J += 1), Ao(), q(), document.body && dn(), e && (await Lo(t)));
    const n = J;
    (t === C ? un(n) : t === K && ba(n),
      x && bt(),
      /(^|\.)textnow\.com$/i.test(location.hostname) &&
        !Kn &&
        (Kn = setInterval(() => {
          x && Wt();
        }, 1200)));
  }
  async function _o() {
    try {
      const t = (await chrome.storage.local.get(Le))?.[Le];
      ((w = [C, K, Qt].includes(t) ? t : se()), w === Qt && (w = se()));
    } catch {
      w = se();
    }
  }
  function Dt() {
    document.hidden ||
      (ne && clearTimeout(ne),
      (ne = setTimeout(() => {
        ne = null;
        const t = J;
        (w === C ? un(t) : w === K && ba(t), x && Wt());
      }, 160)));
  }
  function ln(t) {
    if (ot(t.target)) return !0;
    const e = [...Array.from(t.addedNodes || []), ...Array.from(t.removedNodes || [])];
    return (
      e.length > 0 &&
      e.every((n) =>
        n.nodeType === Node.TEXT_NODE
          ? ot(n)
          : n instanceof Element && (n.classList.contains(nt) || ot(n)),
      )
    );
  }
  function Ea() {
    const t = Ut();
    (t === Ot && W) ||
      (W?.disconnect(),
      (W = null),
      (Ot = t || null),
      t &&
        ((W = new MutationObserver((e) => {
          e.every(ln) || Dt();
        })),
        W.observe(t, { childList: !0, subtree: !0, characterData: !0 })));
  }
  function $o() {
    (ct?.disconnect(), (ct = null));
    const t = mo();
    if (!t) return;
    ct = new MutationObserver(() => {
      Ut() !== Ot && (Ea(), w === C && Dt());
    });
    const e = t.parentElement;
    (e && ct.observe(e, { childList: !0, subtree: !1 }),
      ct.observe(t, { childList: !0, subtree: !1 }));
  }
  function dn() {
    if ((W?.disconnect(), ct?.disconnect(), (W = null), (ct = null), (Ot = null), $() && w === C)) {
      (Ea(), $o());
      return;
    }
    const t = /(^|\.)textnow\.com$/i.test(location.hostname)
      ? document.querySelector("#messageView")
      : null;
    if (t && w === C) {
      ((Ot = t),
        (W = new MutationObserver((e) => {
          e.every(ln) || Dt();
        })),
        W.observe(t, { childList: !0, subtree: !0, characterData: !0 }));
      return;
    }
    ((W = new MutationObserver((e) => {
      e.every(ln) || Dt();
    })),
      W.observe(document.body, { childList: !0, subtree: !0, characterData: !0 }));
  }
  function Fa() {
    const t = sn(),
      e = document.querySelector(
        "[aria-selected='true'], [aria-current='true'], .active, .selected",
      ),
      n = document.querySelector(
        ".chat-header, .conversation-header, [class*='chat-header'], [class*='conversation-header']",
      );
    return [
      location.href,
      t?.childElementCount || 0,
      E(e?.textContent).slice(0, 80),
      E(n?.textContent).slice(0, 80),
    ].join("|");
  }
  function qo() {
    (Ve && clearInterval(Ve),
      (We = Fa()),
      (Ve = setInterval(() => {
        if (!document.body || document.hidden || w !== C) return;
        const t = Fa();
        t !== We && ((We = t), dn(), Dt());
      }, 1500)));
  }
  document.addEventListener("visibilitychange", () => {
    document.hidden || (dn(), Dt(), x && Wt());
  });
  function ko(t) {
    return t === C ? "\u804A\u5929" : t === K ? "\u7F51\u9875" : "\u6682\u505C";
  }
  function To(t) {
    return t === C
      ? "\u53EA\u7FFB\u8BD1\u804A\u5929\u6C14\u6CE1"
      : t === K
        ? "\u7FFB\u8BD1\u5F53\u524D\u7F51\u9875\u82F1\u6587"
        : "\u7FFB\u8BD1\u5DF2\u6682\u505C";
  }
  function q() {
    const t = document.getElementById(z);
    if (!t) return;
    const e = t.querySelector(".ai-bt-ball"),
      n = t.querySelector(".ai-bt-current-status"),
      a = t.querySelector(".ai-bt-ball-mode"),
      o = t.querySelector("[data-ai-bt-phone-mask-toggle]"),
      s = t.querySelector("[data-ai-bt-phone-mask-text]"),
      r = t.querySelector("[data-ai-bt-phone-mask-color]"),
      d = t.querySelector("[data-ai-bt-input-translator-toggle]"),
      i = t.querySelector("[data-ai-bt-background-panel-toggle]"),
      c = t.querySelector("[data-ai-bt-background-toggle]"),
      l = t.querySelector("[data-ai-bt-translation-color-panel-toggle]"),
      g = t.querySelector("[data-ai-bt-translation-color]"),
      b = t.querySelector("[data-ai-bt-bubble-light-color]"),
      p = t.querySelector("[data-ai-bt-bubble-light-width]"),
      y = t.querySelector("[data-ai-bt-bubble-light-enabled]"),
      A = t.querySelector("[data-ai-bt-proxy-toggle]");
    if ((e && (e.dataset.mode = w), n)) {
      const h = x ? "\u906E\u53F7\uFF1A\u5F00" : "\u906E\u53F7\uFF1A\u5173",
        D = k ? "\u4E2D\u2192\u82F1\uFF1A\u5F00" : "\u4E2D\u2192\u82F1\uFF1A\u5173",
        $t = m.enabled && ft() ? "\u80CC\u666F\uFF1A\u5F00" : "\u80CC\u666F\uFF1A\u5173",
        vt = S ? "\u8BD1\u8272\uFF1A\u81EA\u5B9A" : "\u8BD1\u8272\uFF1A\u9ED8\u8BA4",
        et = I.siteProxyEnabled
          ? I.active
            ? "\u7F51\u7AD9IP\uFF1A\u5DF2\u8FDE\u63A5"
            : "\u7F51\u7AD9IP\uFF1A\u7B49\u5F85\u7EBF\u8DEF"
          : I.enabled
            ? I.active
              ? "\u7FFB\u8BD1IP\uFF1A\u5DF2\u8FDE\u63A5"
              : "\u7FFB\u8BD1IP\uFF1A\u7B49\u5F85\u7EBF\u8DEF"
            : "\u7FFB\u8BD1IP\uFF1A\u5173";
      n.textContent = `\u5F53\u524D\uFF1A${To(w)}\uFF5C${h}\uFF5C${D}\uFF5C${et}\uFF5C${$t}\uFF5C${vt}`;
    }
    if (
      (a && (a.textContent = ko(w)),
      t.querySelectorAll("[data-ai-bt-mode]").forEach((h) => {
        const D = h.dataset.aiBtMode === w;
        (h.classList.toggle("is-active", D), h.setAttribute("aria-pressed", String(D)));
      }),
      o)
    ) {
      (o.classList.toggle("is-active", x), o.setAttribute("aria-pressed", String(x)));
      const h = o.querySelector("small");
      h &&
        (h.textContent = x
          ? `\u5DF2\u8986\u76D6 ${oe} \u4E2A\u5BF9\u65B9\u53F7\u7801\uFF5C\u201C${j}\u201D\u6D6E\u5C42`
          : `\u70B9\u51FB\u540E\u7528\u201C${j}\u201D\u6D6E\u5C42\u8986\u76D6\u53F7\u7801`);
    }
    if ((s && (s.value = j), r && (r.value = Q), d)) {
      (d.classList.toggle("is-active", k), d.setAttribute("aria-pressed", String(k)));
      const h = d.querySelector("small");
      h &&
        (h.textContent = k
          ? "\u8F93\u5165\u4E2D\u6587\u540E\u70B9\u201C\u4E2D\u2192EN\u201D\u5373\u53EF\u66FF\u6362"
          : "\u5728\u804A\u5929\u8F93\u5165\u6846\u542F\u7528\u4E2D\u6587\u2192\u7F8E\u5F0F\u82F1\u8BED");
    }
    if (A) {
      (A.classList.toggle("is-active", I.enabled === !0),
        A.setAttribute("aria-pressed", String(I.enabled === !0)));
      const h = A.querySelector("small");
      h &&
        (h.textContent =
          I.message ||
          (I.active
            ? "\u5DF2\u8FDE\u63A5\u7BA1\u7406\u5458\u4EE3\u7406\u6C60"
            : "\u5F53\u524D\u5173\u95ED\uFF0C\u4F7F\u7528\u672C\u673A\u7F51\u7EDC"));
    }
    if (i) {
      const h = !!(m.enabled && ft());
      (i.classList.toggle("is-active", h), i.setAttribute("aria-pressed", String(h)));
      const D = i.querySelector("small");
      D &&
        (D.textContent = m.imageDataUrl
          ? h
            ? "\u81EA\u5B9A\u4E49\u80CC\u666F\u5DF2\u542F\u7528\uFF08\u5168\u5C4F\u6BDB\u73BB\u7483\uFF09"
            : "\u5DF2\u4FDD\u5B58\u81EA\u5B9A\u4E49\u80CC\u666F\uFF0C\u5F53\u524D\u5173\u95ED"
          : h
            ? "\u9ED8\u8BA4\u80CC\u666F\u5DF2\u542F\u7528\uFF08\u53EF\u4E0A\u4F20\u66FF\u6362\uFF09"
            : "\u9ED8\u8BA4\u80CC\u666F\u53EF\u968F\u65F6\u5F00\u542F\u6216\u66FF\u6362");
    }
    if (l) {
      const h = !!S;
      (l.classList.toggle("is-active", h), l.setAttribute("aria-pressed", String(h)));
      const D = l.querySelector("small");
      D &&
        (D.textContent = h
          ? `\u5F53\u524D\u989C\u8272 ${S.toUpperCase()}`
          : "\u81EA\u5B9A\u4E49\u82F1\u6587\u4E0B\u65B9\u4E2D\u6587\u8BD1\u6587\u989C\u8272");
    }
    if ((g && (g.value = S || "#ffd166"), b && (b.value = R), p && (p.value = String(T)), y)) {
      (y.classList.toggle("is-active", V), y.setAttribute("aria-pressed", String(V)));
      const h = y.querySelector("small");
      h &&
        (h.textContent = V
          ? "\u5F53\u524D\u5F00\u542F\uFF1B\u5173\u95ED\u540E\u6062\u590D\u5E73\u53F0\u539F\u751F\u6C14\u6CE1"
          : "\u5F53\u524D\u5173\u95ED\uFF1B\u7FFB\u8BD1\u3001\u80CC\u666F\u548C\u8D34\u56FE\u4FDD\u6301\u4E0D\u53D8");
    }
    c &&
      ((c.textContent = m.enabled ? "\u5173\u95ED\u80CC\u666F" : "\u5F00\u542F\u80CC\u666F"),
      (c.disabled = !ft()));
  }
  function yt(t, e) {
    if (!t || !e) return;
    const n = t.getBoundingClientRect(),
      a = e.offsetWidth || 282,
      o = e.offsetHeight || 320,
      s = 10,
      r = 8;
    let d = n.right - a;
    d = Math.min(Math.max(d, r), window.innerWidth - a - r);
    let i = n.top - o - s;
    (i < r && (i = n.bottom + s),
      (i = Math.min(Math.max(i, r), window.innerHeight - o - r)),
      (e.style.left = `${d}px`),
      (e.style.top = `${i}px`),
      (e.style.right = "auto"),
      (e.style.bottom = "auto"));
  }
  async function Mo(t) {
    try {
      const e = (await chrome.storage.local.get(_e))?.[_e];
      if (!e || typeof e.x != "number" || typeof e.y != "number") return;
      const n = Math.max(8, window.innerWidth - t.offsetWidth - 8),
        a = Math.max(8, window.innerHeight - t.offsetHeight - 8);
      (t.style.setProperty("left", `${Math.min(Math.max(e.x, 8), n)}px`, "important"),
        t.style.setProperty("top", `${Math.min(Math.max(e.y, 8), a)}px`, "important"),
        t.style.setProperty("right", "auto", "important"),
        t.style.setProperty("bottom", "auto", "important"),
        t.classList.toggle("is-docked-left", e.dock === "left"),
        t.classList.toggle("is-docked-right", e.dock === "right"));
    } catch {}
  }
  function Po(t, e) {
    let n = !1,
      a = !1,
      o = 0,
      s = 0,
      r = 0,
      d = 0;
    (t.addEventListener("pointerdown", (i) => {
      if (i.button !== 0) return;
      const c = t.getBoundingClientRect();
      ((n = !0),
        (a = !1),
        (o = i.clientX),
        (s = i.clientY),
        (r = c.left),
        (d = c.top),
        t.setPointerCapture(i.pointerId),
        t.classList.remove("is-docked-left", "is-docked-right"),
        t.classList.add("is-dragging"),
        i.preventDefault());
    }),
      t.addEventListener("pointermove", (i) => {
        if (!n) return;
        const c = i.clientX - o,
          l = i.clientY - s;
        Math.abs(c) + Math.abs(l) > 5 && (a = !0);
        const g = Math.max(8, window.innerWidth - t.offsetWidth - 8),
          b = Math.max(8, window.innerHeight - t.offsetHeight - 8),
          p = Math.min(Math.max(r + c, 8), g),
          y = Math.min(Math.max(d + l, 8), b);
        (t.style.setProperty("left", `${p}px`, "important"),
          t.style.setProperty("top", `${y}px`, "important"),
          t.style.setProperty("right", "auto", "important"),
          t.style.setProperty("bottom", "auto", "important"),
          e.classList.contains("is-open") && yt(t, e));
      }),
      t.addEventListener("pointerup", async (i) => {
        if (!n) return;
        ((n = !1), t.classList.remove("is-dragging"));
        try {
          t.releasePointerCapture(i.pointerId);
        } catch {}
        const c = t.getBoundingClientRect(),
          l = c.left <= 32 ? "left" : window.innerWidth - c.right <= 32 ? "right" : "";
        (t.classList.toggle("is-docked-left", l === "left"),
          t.classList.toggle("is-docked-right", l === "right"));
        try {
          await chrome.storage.local.set({ [_e]: { x: c.left, y: c.top, dock: l } });
        } catch {}
        a
          ? e.classList.contains("is-open") && yt(t, e)
          : (yt(t, e),
            e.classList.toggle("is-open"),
            t.classList.toggle("is-menu-open", e.classList.contains("is-open")));
      }));
  }
  function No() {
    if (document.getElementById(z)) return;
    const t = document.createElement("div");
    t.id = z;
    const e = chrome.runtime.getURL("assets/translator-logo.png"),
      n = chrome.runtime.getURL("assets/panel-background.png");
    (t.style.setProperty("--ai-bt-menu-bg", `url("${n}")`),
      (t.innerHTML = `
      <button class="ai-bt-ball" type="button" aria-label="\u6253\u5F00\u7FFB\u8BD1\u52A9\u624B" title="\u7FFB\u8BD1\u52A9\u624B">
        <img class="ai-bt-ball-logo" src="${e}" alt="" draggable="false">
        <span class="ai-bt-ball-mode">\u6682\u505C</span>
        <span class="ai-bt-ball-dot" aria-hidden="true"></span>
      </button>

      <button class="${Ne}" type="button" aria-label="\u4E2D\u6587\u7FFB\u8BD1\u7F8E\u5F0F\u82F1\u8BED" title="\u628A\u8F93\u5165\u6846\u4E2D\u6587\u7FFB\u8BD1\u4E3A\u7F8E\u5F0F\u82F1\u8BED">\u4E2D\u2192EN</button>
      <div class="${Hn}" role="status"><div class="ai-bt-input-variant-list"></div><p class="ai-bt-input-hint"></p></div>

      <div class="ai-bt-menu" role="dialog" aria-label="\u7FFB\u8BD1\u52A9\u624B">
        <div class="ai-bt-menu-header">
          <div>
            <div class="ai-bt-title">\u7FFB\u8BD1\u52A9\u624B</div>
            <div class="ai-bt-current-status">\u5F53\u524D\uFF1A\u7FFB\u8BD1\u5DF2\u6682\u505C</div>
          </div>
          <button class="ai-bt-menu-close" type="button" aria-label="\u5173\u95ED\u83DC\u5355">\xD7</button>
        </div>

        <div class="ai-bt-actions">
          <button type="button" data-ai-bt-mode="chat">
            <span class="ai-bt-action-icon">\u{1F4AC}</span>
            <span>
              <strong>\u804A\u5929\u7FFB\u8BD1</strong>
              <small>\u53EA\u7FFB\u8BD1\u6D88\u606F\u6C14\u6CE1</small>
            </span>
            <span class="ai-bt-mode-switch" aria-hidden="true"><i></i></span>
          </button>

          <button type="button" data-ai-bt-mode="page">
            <span class="ai-bt-action-icon">\u{1F310}</span>
            <span>
              <strong>\u7F51\u9875\u7FFB\u8BD1</strong>
              <small>\u7FFB\u8BD1\u5F53\u524D\u7F51\u9875\u82F1\u6587</small>
            </span>
            <span class="ai-bt-mode-switch" aria-hidden="true"><i></i></span>
          </button>

          <button type="button" data-ai-bt-phone-mask-toggle="true">
            <span class="ai-bt-action-icon">\u{1F004}</span>
            <span>
              <strong>\u53F7\u7801\u906E\u6321</strong>
              <small>\u70B9\u51FB\u540E\u7528\u201C\u6A58\u5B50\u51FA\u54C1\u201D\u6D6E\u5C42\u8986\u76D6\u53F7\u7801</small>
            </span>
          </button>

          <button type="button" data-ai-bt-input-translator-toggle="true">
            <span class="ai-bt-action-icon">\u{1F1FA}\u{1F1F8}</span>
            <span>
              <strong>\u8F93\u5165\u6846\u4E2D\u2192\u7F8E</strong>
              <small>\u5728\u804A\u5929\u8F93\u5165\u6846\u542F\u7528\u4E2D\u6587\u2192\u7F8E\u5F0F\u82F1\u8BED</small>
            </span>
          </button>

          <button type="button" data-ai-bt-proxy-toggle="true">
            <span class="ai-bt-action-icon">\u{1F30D}</span>
            <span>
              <strong>\u4F7F\u7528\u7FFB\u8BD1IP</strong>
              <small>\u9ED8\u8BA4\u5F00\u542F\uFF0C\u81EA\u52A8\u83B7\u53D6\u53EF\u7528\u7EBF\u8DEF</small>
            </span>
            <span class="ai-bt-mode-switch" aria-hidden="true"><i></i></span>
          </button>

          <button type="button" data-ai-bt-translation-color-panel-toggle="true">
            <span class="ai-bt-action-icon">\u{1F3A8}</span>
            <span>
              <strong>\u8BD1\u6587\u5B57\u4F53\u989C\u8272</strong>
              <small>\u81EA\u5B9A\u4E49\u82F1\u6587\u4E0B\u65B9\u4E2D\u6587\u8BD1\u6587\u989C\u8272</small>
            </span>
          </button>

          <button type="button" data-ai-bt-bubble-light-enabled="true">
            <span class="ai-bt-action-icon">\u{1F308}</span>
            <span><strong>\u6C14\u6CE1\u6846\u7279\u6548 / \u8DD1\u9A6C\u706F</strong><small>\u5F53\u524D\u5F00\u542F\uFF1B\u5173\u95ED\u540E\u6062\u590D\u5E73\u53F0\u539F\u751F\u6C14\u6CE1</small></span>
            <span class="ai-bt-mode-switch" aria-hidden="true"><i></i></span>
          </button>

          <button type="button" data-ai-bt-background-panel-toggle="true">
            <span class="ai-bt-action-icon">\u{1F5BC}\uFE0F</span>
            <span>
              <strong>\u81EA\u5B9A\u4E49\u80CC\u666F</strong>
              <small>\u4E0A\u4F20\u4EFB\u610F\u56FE\u7247\u4F5C\u4E3A\u804A\u5929\u80CC\u666F</small>
            </span>
          </button>

          <button type="button" data-ai-bt-send-clean-panel-toggle="true">
            <span class="ai-bt-action-icon">\u{1F9F9}</span>
            <span>
              <strong>\u53D1\u9001\u5185\u5BB9\u6E05\u7406</strong>
              <small>\u6E05\u9664\u9690\u85CF\u7A7A\u683C\u548C\u590D\u5236\u4EA7\u751F\u7684\u5F02\u5E38\u9694\u884C</small>
            </span>
          </button>
        </div>

        <div class="ai-bt-mask-settings" data-ai-bt-phone-mask-settings>
          <label class="ai-bt-color-row" data-ai-bt-phone-mask-text-control>
            <span>\u906E\u6321\u663E\u793A\u6587\u5B57</span>
            <input data-ai-bt-phone-mask-text type="text" maxlength="12" value="" aria-label="\u53F7\u7801\u906E\u6321\u6587\u5B57">
          </label>
          <label class="ai-bt-color-row" data-ai-bt-phone-mask-color-control>
            <span>\u906E\u6321\u4E3B\u9898\u989C\u8272</span>
            <input data-ai-bt-phone-mask-color type="color" value="${Q}" aria-label="\u53F7\u7801\u906E\u6321\u989C\u8272">
          </label>
          <div class="ai-bt-bg-note">\u6B64\u5904\u7531\u7BA1\u7406\u5458\u5728\u9AD8\u7EA7\u4F1A\u5458\u6743\u9650\u4E2D\u5F00\u653E\uFF1B\u8BBE\u7F6E\u53EA\u4FDD\u5B58\u5728\u5F53\u524D\u5458\u5DE5\u8BBE\u5907\u3002</div>
        </div>

        <div class="ai-bt-color-settings" data-ai-bt-translation-color-settings>
          <label class="ai-bt-color-row">
            <span>\u82F1\u6587\u539F\u6587\u989C\u8272</span>
            <input data-ai-bt-original-color type="color" value="${P || "#ffffff"}" aria-label="\u9009\u62E9\u82F1\u6587\u539F\u6587\u5B57\u4F53\u989C\u8272">
          </label>
          <button class="ai-bt-color-reset" type="button" data-ai-bt-original-color-reset>\u6062\u590D\u539F\u6587\u9ED8\u8BA4\u989C\u8272</button>
          <label class="ai-bt-color-row">
            <span>\u4E2D\u6587\u8BD1\u6587\u989C\u8272</span>
            <input data-ai-bt-translation-color type="color" value="${S || "#ffd166"}" aria-label="\u9009\u62E9\u4E2D\u6587\u8BD1\u6587\u5B57\u4F53\u989C\u8272">
          </label>
          <div class="ai-bt-color-presets">
            <button type="button" data-ai-bt-color-preset="#ffffff">\u767D\u8272</button>
            <button type="button" data-ai-bt-color-preset="#ffd166">\u91D1\u8272</button>
            <button type="button" data-ai-bt-color-preset="#7ee787">\u7EFF\u8272</button>
            <button type="button" data-ai-bt-color-preset="#79c0ff">\u84DD\u8272</button>
            <button type="button" data-ai-bt-color-preset="#ff9bd5">\u7C89\u8272</button>
          </div>
          <button class="ai-bt-color-reset" type="button" data-ai-bt-translation-color-reset>\u6062\u590D\u9ED8\u8BA4\u989C\u8272</button>
          <div class="ai-bt-bg-note">\u53EA\u6539\u53D8\u82F1\u6587\u6D88\u606F\u4E0B\u9762\u7531\u63D2\u4EF6\u751F\u6210\u7684\u4E2D\u6587\u8BD1\u6587\uFF0C\u4E0D\u6539\u53D8\u82F1\u6587\u539F\u6587\u3002</div>
          <label class="ai-bt-color-row">
            <span>\u5F69\u8679\u6D41\u5149\u4E3B\u8272</span>
            <input data-ai-bt-bubble-light-color type="color" value="${R}" aria-label="\u9009\u62E9\u6D88\u606F\u6C14\u6CE1\u6D41\u5149\u989C\u8272">
          </label>
          <label class="ai-bt-bg-control">
            <span>\u6D41\u5149\u7C97\u7EC6 <b data-ai-bt-bubble-light-width-value>${T}px</b></span>
            <input data-ai-bt-bubble-light-width type="range" min="4" max="10" step="1" value="${T}">
          </label>
          <div class="ai-bt-color-presets">
            <button type="button" data-ai-bt-light-preset="#a97bff">\u7D2B\u8272</button>
            <button type="button" data-ai-bt-light-preset="#51e3ff">\u84DD\u8272</button>
            <button type="button" data-ai-bt-light-preset="#ff62ad">\u7C89\u8272</button>
            <button type="button" data-ai-bt-light-preset="#ffad5c">\u6A59\u8272</button>
            <button type="button" data-ai-bt-light-preset="#70ffd1">\u7EFF\u8272</button>
          </div>
          <button class="ai-bt-color-reset" type="button" data-ai-bt-bubble-light-reset>\u6062\u590D\u9ED8\u8BA4\u6D41\u5149</button>
        </div>

        <div class="ai-bt-bg-settings" data-ai-bt-background-settings>
          <input class="ai-bt-bg-file" data-ai-bt-background-file type="file" accept="image/*">
          <div class="ai-bt-bg-buttons">
            <button type="button" data-ai-bt-background-upload>\u9009\u62E9\u56FE\u7247</button>
            <button type="button" data-ai-bt-background-toggle>\u5F00\u542F\u80CC\u666F</button>
            <button type="button" data-ai-bt-background-reset>\u6062\u590D\u9ED8\u8BA4</button>
          </div>
          <label class="ai-bt-bg-control">
            <span>\u80CC\u666F\u4EAE\u5EA6 <b data-ai-bt-bg-brightness-value>${m.brightness}%</b></span>
            <input data-ai-bt-bg-brightness type="range" min="55" max="145" step="5" value="${m.brightness}">
          </label>
          <label class="ai-bt-bg-control">
            <span>\u80CC\u666F\u6A21\u7CCA <b data-ai-bt-bg-blur-value>${m.blur}px</b></span>
            <input data-ai-bt-bg-blur type="range" min="0" max="12" step="1" value="${m.blur}">
          </label>
          <label class="ai-bt-bg-control">
            <span>\u9875\u9762\u9762\u677F\u900F\u660E\u5EA6 <b data-ai-bt-bg-panel-value>${Math.round(m.panelOpacity * 100)}%</b></span>
            <input data-ai-bt-bg-panel-opacity type="range" min="6" max="72" step="2" value="${Math.round(m.panelOpacity * 100)}">
          </label>
          <label class="ai-bt-bg-control">
            <span>\u7FA4\u53D1\u7A97\u53E3\u4E0D\u900F\u660E\u5EA6 <b data-ai-bt-bg-group-panel-value>${Math.round(m.groupPanelOpacity * 100)}%</b></span>
            <input data-ai-bt-bg-group-panel-opacity type="range" min="35" max="98" step="1" value="${Math.round(m.groupPanelOpacity * 100)}">
          </label>
          <div class="ai-bt-bg-note">\u6574\u9875\u751F\u6548\uFF1A\u5DE6\u4FA7\u8054\u7CFB\u4EBA\u3001\u9876\u90E8\u548C\u804A\u5929\u533A\u90FD\u4F1A\u663E\u793A\u540C\u4E00\u5F20\u80CC\u666F\u56FE\u3002</div>
        </div>

        <div class="ai-bt-send-clean-settings" data-ai-bt-send-clean-settings>
          <label class="ai-bt-color-row"><span>\u53D1\u9001\u524D\u81EA\u52A8\u6E05\u9664\u5F02\u5E38\u6362\u884C</span><input data-ai-bt-clean-send type="checkbox" checked></label>
          <label class="ai-bt-color-row"><span>\u4FDD\u7559\u539F\u59CB\u6BB5\u843D</span><input data-ai-bt-preserve-paragraphs type="checkbox" checked></label>
          <div class="ai-bt-bg-note">\u540C\u65F6\u6E05\u9664\u9690\u85CF\u7A7A\u683C\u3001\u96F6\u5BBD\u5B57\u7B26\u548C\u590D\u5236\u4EA7\u751F\u7684\u591A\u4F59\u9694\u884C\u3002</div>
          <button class="ai-bt-color-reset" type="button" data-ai-bt-clear-translation-cache>\u6E05\u7A7A5\u5929\u7FFB\u8BD1\u7F13\u5B58</button>
        </div>

        <div class="ai-bt-tip">\u8F93\u5165\u6846\u7FFB\u8BD1\uFF1A\u4E2D\u6587\u540E\u5FEB\u901F\u8FDE\u6309\u4E24\u6B21\u7A7A\u683C\uFF1B\u80CC\u666F\u652F\u6301\u672C\u5730\u4EFB\u610F\u56FE\u7247</div>
      </div>
    `),
      document.documentElement.appendChild(t),
      chrome.storage.local.get(["orangePermissions", "orangeIsAdmin"]).then((u) => {
        ((N = u.orangePermissions || {}), (lt = u.orangeIsAdmin === !0), Ue());
      }));
    const a = t.querySelector(".ai-bt-ball"),
      o = t.querySelector(".ai-bt-menu"),
      s = t.querySelector(".ai-bt-menu-close");
    (new MutationObserver(() => {
      a.classList.toggle("is-menu-open", o.classList.contains("is-open"));
    }).observe(o, { attributes: !0, attributeFilter: ["class"] }),
      Mo(a).then(() => {
        yt(a, o);
      }),
      Po(a, o),
      s.addEventListener("click", (u) => {
        (u.stopPropagation(), o.classList.remove("is-open"), a.classList.remove("is-menu-open"));
      }),
      t.querySelectorAll("[data-ai-bt-mode]").forEach((u) => {
        u.addEventListener("click", async (f) => {
          f.stopPropagation();
          const F = u.dataset.aiBtMode;
          (await cn(w === F ? Qt : F), o.classList.remove("is-open"));
        });
      }));
    const r = t.querySelector("[data-ai-bt-phone-mask-toggle]");
    r?.addEventListener("click", async (u) => {
      (u.stopPropagation(), await ya(!x), Zt(r, b));
    });
    const d = t.querySelector("[data-ai-bt-phone-mask-text]"),
      i = t.querySelector("[data-ai-bt-phone-mask-color]");
    (d?.addEventListener("change", async (u) => {
      ((j = ha(u.target.value)), (u.target.value = j), await fa());
    }),
      i?.addEventListener("input", (u) => {
        ((Q = _(u.target.value) || "#ffffff"),
          document.documentElement.style.setProperty("--ai-bt-phone-mask-color", Q));
      }),
      i?.addEventListener("change", async () => fa()),
      t
        .querySelector("[data-ai-bt-input-translator-toggle]")
        ?.addEventListener("click", async (u) => {
          (u.stopPropagation(), await aa(!k), o.classList.remove("is-open"));
        }));
    const c = t.querySelector("[data-ai-bt-proxy-toggle]");
    (c?.addEventListener("click", async (u) => {
      (u.stopPropagation(), (c.disabled = !0));
      const f = await jn("proxy:set", { enabled: I.enabled !== !0 });
      ((c.disabled = !1),
        f?.managed
          ? (I = f)
          : (I = { ...I, message: f?.message || "\u7FFB\u8BD1IP\u8BBE\u7F6E\u5931\u8D25" }),
        q());
    }),
      Ha());
    const l = t.querySelector("[data-ai-bt-translation-color-panel-toggle]"),
      g = t.querySelector("[data-ai-bt-translation-color-settings]"),
      b = t.querySelector("[data-ai-bt-phone-mask-settings]"),
      p = t.querySelector("[data-ai-bt-translation-color]"),
      y = t.querySelector("[data-ai-bt-translation-color-reset]"),
      A = t.querySelector("[data-ai-bt-original-color]"),
      h = t.querySelector("[data-ai-bt-original-color-reset]"),
      D = t.querySelector("[data-ai-bt-bubble-light-color]"),
      $t = t.querySelector("[data-ai-bt-bubble-light-reset]"),
      vt = t.querySelector("[data-ai-bt-bubble-light-width]"),
      et = t.querySelector("[data-ai-bt-bubble-light-enabled]"),
      rt = t.querySelector("[data-ai-bt-background-panel-toggle]"),
      vn = t.querySelector("[data-ai-bt-background-settings]"),
      wn = t.querySelector("[data-ai-bt-background-file]"),
      Z = t.querySelector("[data-ai-bt-background-upload]"),
      gs = t.querySelector("[data-ai-bt-background-toggle]"),
      ps = t.querySelector("[data-ai-bt-background-reset]"),
      we = t.querySelector("[data-ai-bt-bg-brightness]"),
      Ce = t.querySelector("[data-ai-bt-bg-blur]"),
      Se = t.querySelector("[data-ai-bt-bg-panel-opacity]"),
      xe = t.querySelector("[data-ai-bt-bg-group-panel-opacity]"),
      Cn = t.querySelector("[data-ai-bt-send-clean-panel-toggle]"),
      Sn = t.querySelector("[data-ai-bt-send-clean-settings]"),
      xn = t.querySelector("[data-ai-bt-clean-send]"),
      An = t.querySelector("[data-ai-bt-preserve-paragraphs]"),
      Ae = t.querySelector("[data-ai-bt-clear-translation-cache]"),
      Be = (u, f) => {
        u && f && u.parentElement && u.insertAdjacentElement("afterend", f);
      };
    (Be(r, b),
      Be(l, g),
      Be(rt, vn),
      Be(Cn, Sn),
      xn && (xn.checked = localStorage.getItem("orangeAutoCleanSendBreaks") !== "false"),
      An && (An.checked = localStorage.getItem("orangePreserveSendParagraphs") !== "false"),
      xn?.addEventListener("change", (u) =>
        localStorage.setItem("orangeAutoCleanSendBreaks", String(u.target.checked)),
      ),
      An?.addEventListener("change", (u) =>
        localStorage.setItem("orangePreserveSendParagraphs", String(u.target.checked)),
      ),
      Ae?.addEventListener("click", async (u) => {
        (u.stopPropagation(),
          await Va(),
          (Ae.textContent = "\u7F13\u5B58\u5DF2\u6E05\u7A7A"),
          setTimeout(() => {
            Ae.isConnected && (Ae.textContent = "\u6E05\u7A7A5\u5929\u7FFB\u8BD1\u7F13\u5B58");
          }, 1200));
      }));
    const bs = (u) => {
        [b, g, vn, Sn].forEach((f) => {
          f && f !== u && f.classList.remove("is-open");
        });
      },
      Zt = (u, f) => {
        if (!f) return;
        const F = !f.classList.contains("is-open");
        (bs(f),
          f.classList.toggle("is-open", F),
          u?.setAttribute("aria-expanded", String(F)),
          F && f.scrollIntoView({ block: "nearest", behavior: "smooth" }),
          yt(a, o));
      };
    (l?.addEventListener("click", (u) => {
      (u.stopPropagation(), Zt(l, g));
    }),
      A?.addEventListener("input", (u) => {
        ((P = _(u.target.value)), le(document));
      }),
      A?.addEventListener("change", async (u) => {
        await pe(u.target.value);
      }),
      h?.addEventListener("click", async (u) => {
        (u.stopPropagation(), await pe(""), A && (A.value = "#ffffff"));
      }),
      p?.addEventListener("input", (u) => {
        ((S = _(u.target.value)), ht());
      }),
      p?.addEventListener("change", async (u) => {
        await ua(u.target.value);
      }),
      t.querySelectorAll("[data-ai-bt-color-preset]").forEach((u) => {
        u.addEventListener("click", async (f) => {
          f.stopPropagation();
          const F = u.getAttribute("data-ai-bt-color-preset");
          (p && F && (p.value = F), await ua(F));
        });
      }),
      y?.addEventListener("click", async (u) => {
        (u.stopPropagation(), await so(), p && (p.value = "#ffd166"));
      }),
      D?.addEventListener("input", (u) => {
        ((R = _(u.target.value) || "#a97bff"), O());
      }),
      D?.addEventListener("change", async (u) => {
        await en(u.target.value);
      }),
      t.querySelectorAll("[data-ai-bt-light-preset]").forEach((u) => {
        u.addEventListener("click", async (f) => {
          f.stopPropagation();
          const F = u.getAttribute("data-ai-bt-light-preset");
          (D && F && (D.value = F), await en(F));
        });
      }),
      $t?.addEventListener("click", async (u) => {
        (u.stopPropagation(), await en("#a97bff"));
      }),
      vt?.addEventListener("input", (u) => {
        ((T = L(u.target.value, 4, 10, 7)), O());
      }),
      vt?.addEventListener("change", async (u) => {
        await io(u.target.value);
      }),
      et?.addEventListener("click", async (u) => {
        (u.stopPropagation(), await ca(!V), g?.classList.contains("is-open") || Zt(l, g));
      }),
      rt?.addEventListener("click", (u) => {
        (u.stopPropagation(), Zt(rt, vn));
      }),
      Cn?.addEventListener("click", (u) => {
        (u.stopPropagation(), Zt(Cn, Sn));
      }),
      Z?.addEventListener("click", (u) => {
        (u.stopPropagation(), wn?.click());
      }),
      wn?.addEventListener("change", async (u) => {
        const f = u.target.files?.[0];
        if (!f) return;
        const F = Z?.textContent || "\u9009\u62E9\u56FE\u7247";
        Z && (Z.textContent = "\u5904\u7406\u4E2D\u2026");
        try {
          (await po(f), Z && (Z.textContent = "\u66F4\u6362\u56FE\u7247"));
        } catch (De) {
          (console.error("[Bilingual Translator] Background upload failed:", De),
            Z && (Z.textContent = "\u56FE\u7247\u5931\u8D25\uFF0C\u91CD\u8BD5"),
            setTimeout(() => {
              Z && (Z.textContent = F);
            }, 1800));
        } finally {
          ((u.target.value = ""), yt(a, o));
        }
      }),
      gs?.addEventListener("click", async (u) => {
        if ((u.stopPropagation(), !ft())) {
          wn?.click();
          return;
        }
        await bo();
      }),
      ps?.addEventListener("click", async (u) => {
        (u.stopPropagation(),
          await ho(),
          we && (we.value = "100"),
          Ce && (Ce.value = "0"),
          Se && (Se.value = "22"),
          xe && (xe.value = "90"));
        const f = t.querySelector("[data-ai-bt-bg-brightness-value]"),
          F = t.querySelector("[data-ai-bt-bg-blur-value]"),
          De = t.querySelector("[data-ai-bt-bg-panel-value]"),
          Ma = t.querySelector("[data-ai-bt-bg-group-panel-value]");
        (f && (f.textContent = "100%"),
          F && (F.textContent = "0px"),
          De && (De.textContent = "22%"),
          Ma && (Ma.textContent = "90%"));
      }),
      we?.addEventListener("input", (u) => {
        const f = Number(u.target.value),
          F = t.querySelector("[data-ai-bt-bg-brightness-value]");
        (F && (F.textContent = `${f}%`), (m.brightness = f), H());
      }),
      we?.addEventListener("change", (u) => me("brightness", Number(u.target.value))),
      Ce?.addEventListener("input", (u) => {
        const f = Number(u.target.value),
          F = t.querySelector("[data-ai-bt-bg-blur-value]");
        (F && (F.textContent = `${f}px`), (m.blur = f), H());
      }),
      Ce?.addEventListener("change", (u) => me("blur", Number(u.target.value))),
      Se?.addEventListener("input", (u) => {
        const f = Number(u.target.value),
          F = t.querySelector("[data-ai-bt-bg-panel-value]");
        (F && (F.textContent = `${f}%`), (m.panelOpacity = f / 100), H());
      }),
      Se?.addEventListener("change", (u) => me("panelOpacity", Number(u.target.value) / 100)),
      xe?.addEventListener("input", (u) => {
        const f = Number(u.target.value);
        ((t.querySelector("[data-ai-bt-bg-group-panel-value]").textContent = `${f}%`),
          (m.groupPanelOpacity = f / 100),
          H());
      }),
      xe?.addEventListener("change", (u) => me("groupPanelOpacity", Number(u.target.value) / 100)));
    const Ta = t.querySelector(`.${Ne}`);
    (Ta?.addEventListener("pointerdown", (u) => {
      (u.preventDefault(), u.stopPropagation());
    }),
      Ta?.addEventListener("click", (u) => {
        (u.preventDefault(), u.stopPropagation(), na());
      }),
      t.addEventListener(
        "click",
        (u) => {
          u.target?.closest?.("[data-orange-locked='true']") &&
            (u.preventDefault(), u.stopImmediatePropagation(), alert(Ia()));
        },
        !0,
      ),
      document.addEventListener(
        "pointerdown",
        (u) => {
          t.contains(u.target) || o.classList.remove("is-open");
        },
        !0,
      ),
      window.addEventListener("resize", () => {
        const u = a.getBoundingClientRect(),
          f = Math.max(8, window.innerWidth - a.offsetWidth - 8),
          F = Math.max(8, window.innerHeight - a.offsetHeight - 8);
        ((u.left > f || u.top > F) &&
          ((a.style.left = `${Math.min(u.left, f)}px`),
          (a.style.top = `${Math.min(u.top, F)}px`),
          (a.style.right = "auto"),
          (a.style.bottom = "auto")),
          yt(a, o),
          Wt());
      }),
      window.addEventListener("scroll", Wt, !0),
      q());
  }
  (chrome.storage.onChanged.addListener((t, e) => {
    if (e !== "local") return;
    let n = !1;
    if (
      (t.orangePermissions && ((N = t.orangePermissions.newValue || {}), (n = !0)),
      t.orangeIsAdmin && ((lt = t.orangeIsAdmin.newValue === !0), (n = !0)),
      t[it] && ((S = _(t[it].newValue)), ht()),
      t[qt] && ((P = _(t[qt].newValue)), le(document)),
      n && (Ue(), x && (lt || N.phone_mask === !0) && bt(), k && (lt || N.input_translate === !0)))
    ) {
      const a = U(document.activeElement) ? document.activeElement : v;
      U(a) && ((v = a), pt(), Bt());
    }
  }),
    /(^|\.)textnow\.com$/i.test(location.hostname) &&
      chrome.storage.onChanged.addListener((t, e) => {
        e === "local" &&
          (t.orangePermissions && ((N = t.orangePermissions.newValue || {}), Ue()),
          t[wt] &&
            (nn().then(() => {
              (H(), on());
            }),
            window.postMessage(
              {
                source: "orange-ai-extension",
                type: "tn:appearance-changed",
                payload: { kind: "background", value: t[wt].newValue },
              },
              "*",
            )),
          t[it] &&
            ((S = _(t[it].newValue)),
            ht(),
            window.postMessage(
              {
                source: "orange-ai-extension",
                type: "tn:appearance-changed",
                payload: { kind: "translationColor", value: S },
              },
              "*",
            )),
          t[kt] &&
            ((R = _(t[kt].newValue) || "#a97bff"),
            O(),
            window.postMessage(
              {
                source: "orange-ai-extension",
                type: "tn:appearance-changed",
                payload: { kind: "bubbleLightColor", value: R },
              },
              "*",
            )),
          t[Tt] &&
            ((T = L(t[Tt].newValue, 4, 10, 7)),
            O(),
            window.postMessage(
              {
                source: "orange-ai-extension",
                type: "tn:appearance-changed",
                payload: { kind: "bubbleLightWidth", value: T },
              },
              "*",
            )),
          t[Mt] &&
            ((V = t[Mt].newValue === !0),
            O(),
            q(),
            window.postMessage(
              {
                source: "orange-ai-extension",
                type: "tn:appearance-changed",
                payload: { kind: "bubbleLightEnabled", value: V },
              },
              "*",
            )));
      }),
    chrome.runtime.onMessage.addListener((t, e, n) => {
      const a = t?.type;
      return a === "AI_BT_GET_PAGE_STATE"
        ? (n({
            ok: !0,
            hostname: location.hostname,
            isOpenSms: $(),
            backgroundEnabled: !!m.enabled,
            openSmsDomDetected: !!document.querySelector("#v-im-app, #im-app"),
          }),
          !1)
        : a === "AI_BT_BACKGROUND_CHANGED"
          ? (nn()
              .then(() => {
                (H(), on(), n({ ok: !0 }));
              })
              .catch((o) => n({ ok: !1, error: o?.message || "Background refresh failed" })),
            !0)
          : a === "AI_BT_MODE_CHANGED"
            ? (cn(t.mode, { persist: !1 })
                .then(() => n({ ok: !0 }))
                .catch((o) => n({ ok: !1, error: o?.message || "Mode update failed" })),
              !0)
            : a === "AI_BT_PHONE_MASK_CHANGED"
              ? (ya(!!t.enabled, { persist: !1 })
                  .then(() => n({ ok: !0 }))
                  .catch((o) => n({ ok: !1, error: o?.message || "Phone mask update failed" })),
                !0)
              : a === "AI_BT_INPUT_TRANSLATOR_CHANGED"
                ? (aa(!!t.enabled, { persist: !1 })
                    .then(() => n({ ok: !0 }))
                    .catch((o) =>
                      n({ ok: !1, error: o?.message || "Input translator update failed" }),
                    ),
                  !0)
                : a === "AI_BT_TRANSLATION_COLOR_CHANGED"
                  ? ((S = _(t.color)), ht(), n({ ok: !0 }), !1)
                  : a === "AI_BT_BUBBLE_LIGHT_COLOR_CHANGED"
                    ? ((R = _(t.color) || "#a97bff"), O(), n({ ok: !0 }), !1)
                    : a === "AI_BT_BUBBLE_LIGHT_WIDTH_CHANGED"
                      ? ((T = L(t.width, 4, 10, 7)), O(), n({ ok: !0 }), !1)
                      : (a === "AI_BT_BUBBLE_LIGHT_ENABLED_CHANGED" &&
                          (ca(t.enabled, { persist: !1 }), n({ ok: !0 })),
                        !1);
    }));
  async function va() {
    if (!document.body) return;
    try {
      M =
        ((await chrome.storage.local.get("orangeSiteAdapters"))?.orangeSiteAdapters || {})[
          String(location.hostname || "").toLowerCase()
        ] || null;
    } catch {
      M = null;
    }
    const t = Array.from(document.querySelectorAll('input[type="password"]')).some(
        (n) => n.offsetParent !== null,
      ),
      e = !!document.querySelector(
        "textarea, [contenteditable='true'], [contenteditable='plaintext-only'], [role='textbox'], .im-chat-text, .messages-list, .chat_message, #messageParent",
      );
    if (t) {
      const n = new MutationObserver(() => {
        const a = Array.from(document.querySelectorAll('input[type="password"]')).some(
            (s) => s.offsetParent !== null,
          ),
          o = !!document.querySelector(
            "textarea, [contenteditable='true'], [contenteditable='plaintext-only'], [role='textbox'], .im-chat-text, .messages-list, .chat_message, #messageParent",
          );
        !a && o && (n.disconnect(), va());
      });
      n.observe(document.documentElement, { childList: !0, subtree: !0 });
      return;
    }
    (lo(),
      await _o(),
      await Bo(),
      await Do(),
      await Ga(),
      await nn(),
      await oo(),
      await ro(),
      No(),
      ht(),
      O(),
      H(),
      Ka(),
      Ua(),
      await cn(w, { persist: !1 }),
      qo(),
      x && bt(),
      k && U(document.activeElement) && ((v = document.activeElement), pt(), Bt()));
  }
  const Kt = "oz-contact-card",
    wa = "oz-pinned",
    mn = "oz-selected",
    Ca = "oz-unread",
    be = "oz-unread-badge",
    gn = "oz-contact-number",
    Sa = `ozLocalPinnedContacts:${location.hostname}`;
  let jt = null,
    pn = null,
    he = 0,
    Gt = "",
    Lt = new Set();
  function Jt() {
    return (
      (/client\.xhsim\.ai$/i.test(location.hostname)
        ? document.querySelector(
            "#kt_chat_contacts_body, [data-kt-element='contacts'], [data-kt-drawer='true'] [class*='contact'], aside [class*='contact'], [class*='conversation-list'], [class*='contact-list']",
          )
        : $() &&
          (document.querySelector("#div-im-app .main-content .left[data-v-912c4421]") ||
            document.querySelector("#div-im-app .main-content .left") ||
            document.querySelector("#div-im-app .main.content .left") ||
            document.querySelector("#v-im-app .main-content .left[data-v-912c4421]") ||
            document.querySelector("#v-im-app .main-content .left") ||
            document.querySelector("#v-im-app .main.content .left[data-v-912c4421]") ||
            document.querySelector("#v-im-app .main.content .left") ||
            document.querySelector("#im-app .main-content .left[data-v-912c4421]") ||
            document.querySelector("#im-app .main-content .left") ||
            document.querySelector("#im-app .main_content .left[data-v-912c4421]") ||
            document.querySelector("#im-app .main_content .left") ||
            document.querySelector("div.main-content div.left[data-v-912c4421]") ||
            document.querySelector("div.main-content div.left"))) || null
    );
  }
  function bn(t) {
    if (!(t instanceof Element)) return null;
    const e = t.getBoundingClientRect();
    return e.width < 2 ||
      e.height < 2 ||
      e.bottom < 0 ||
      e.right < 0 ||
      e.top > innerHeight ||
      e.left > innerWidth
      ? null
      : e;
  }
  function xa(t) {
    return t instanceof Element
      ? Array.from(t.classList || [])
          .filter((e) => !e.startsWith("oz-"))
          .join(" ")
          .toLowerCase()
      : "";
  }
  function hn(t) {
    if (!(t instanceof Element)) return "";
    const e = E(t.innerText || t.textContent || ""),
      n = e.match(/\d{5,16}/g) || [];
    return n.length ? n.slice(0, 2).join("|") : e.slice(0, 90);
  }
  function Io() {
    try {
      const t = JSON.parse(localStorage.getItem(Sa) || "[]");
      Lt = new Set(Array.isArray(t) ? t.filter(Boolean) : []);
    } catch {
      Lt = new Set();
    }
  }
  function Ro() {
    try {
      localStorage.setItem(Sa, JSON.stringify(Array.from(Lt).slice(0, 250)));
    } catch {}
  }
  function Aa(t, e) {
    if (
      !(t instanceof HTMLElement) ||
      !(e instanceof Element) ||
      t === e ||
      t.matches("input, textarea, button, form, svg, path, img") ||
      t.closest(`#${z}, .${Ct}`)
    )
      return !1;
    const n = bn(t),
      a = e.getBoundingClientRect();
    if (
      !n ||
      !a.width ||
      n.width < Math.max(110, a.width * 0.56) ||
      n.height < 48 ||
      n.height > 240
    )
      return !1;
    const o = E(t.innerText || t.textContent || "");
    if (!o || o.length > 520 || (/群发短信|搜索收信人号码/.test(o) && !/发信人|收信人/.test(o)))
      return !1;
    const s = /\d{5,16}/.test(o),
      r = /发信人|收信人|未读|回复|发送/.test(o);
    return s || r;
  }
  function Ba(t, e) {
    if (!(t instanceof Element)) return null;
    let n = t,
      a = Aa(n, e) ? n : null,
      o = 0;
    for (; n.parentElement && n.parentElement !== e && o < 7; ) {
      const s = n.parentElement;
      if (s.matches(".el-scrollbar__view, .el-scrollbar, ul, ol")) break;
      const r = bn(s);
      if (!r || r.height > 250) break;
      (Aa(s, e) && (a = s), (n = s), (o += 1));
    }
    return a;
  }
  function Oo(t) {
    const e = new Set(),
      n = [
        ".contact-item",
        ".conversation-item",
        ".session-item",
        ".chat-item",
        ".user-item",
        "[class*='contact-item']",
        "[class*='contact_item']",
        "[class*='conversation-item']",
        "[class*='session-item']",
        "[class*='chat-item']",
        "[class*='chat_item']",
        ".el-scrollbar__view > div",
        ".el-scrollbar__view > li",
      ];
    for (const s of n) for (const r of t.querySelectorAll(s)) e.add(r);
    if (e.size < 2)
      for (const s of t.querySelectorAll("div, li")) {
        const r = E(s.innerText || s.textContent || "");
        /\d{5,16}/.test(r) && r.length < 360 && e.add(s);
      }
    const a = new Set();
    for (const s of e) {
      const r = Ba(s, t);
      r && a.add(r);
    }
    const o = Array.from(a);
    return o.filter((s) => !o.some((r) => r !== s && r.contains(s) && bn(r)?.height <= 240));
  }
  function Ho(t) {
    const e = xa(t);
    return /(^|\s|[-_])(is[-_]?top|pinned|pin[-_]?active|sticky)(\s|[-_]|$)/i.test(e) ||
      t.matches(
        "[data-pinned='true'], [data-top='true'], [aria-label*='\u5DF2\u7F6E\u9876'], [title*='\u5DF2\u7F6E\u9876']",
      ) ||
      t.querySelector(
        ".is-top, .pinned, [class*='is-top'], [class*='is_top'], [class*='pinned'], [data-pinned='true'], [title*='\u53D6\u6D88\u7F6E\u9876'], [aria-label*='\u53D6\u6D88\u7F6E\u9876']",
      )
      ? !0
      : /取消置顶/.test(E(t.innerText || ""));
  }
  function zo(t) {
    const e = xa(t);
    return !!(
      /(^|\s|[-_])(active|selected|current|is[-_]?active|is[-_]?selected|is[-_]?current)(\s|[-_]|$)/i.test(
        e,
      ) ||
      t.matches(
        "[aria-current='true'], [aria-current='page'], [aria-selected='true'], [data-active='true'], [data-selected='true']",
      )
    );
  }
  function Vo(t) {
    const e = String(t || "")
      .trim()
      .match(/^(?:\+)?(\d{1,4})$/);
    if (!e) return 0;
    const n = Number(e[1]);
    return Number.isFinite(n) && n > 0 ? n : 0;
  }
  function Da(t) {
    const e = String(t || "").match(/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i);
    if (!e) return !1;
    const n = Number(e[1]),
      a = Number(e[2]),
      o = Number(e[3]);
    return n >= 170 && n > a * 1.35 && n > o * 1.18;
  }
  function Wo(t) {
    let e = !1;
    t.querySelectorAll(`.${be}`).forEach((a) => a.classList.remove(be));
    const n = t.querySelectorAll(
      ".el-badge__content, [class*='unread'], [class*='badge'], [data-unread], [aria-label*='\u672A\u8BFB'], [title*='\u672A\u8BFB']",
    );
    for (const a of n) {
      const o = E(a.textContent || "");
      Number((o.match(/\d{1,4}/) || [0])[0]) > 0 && ((e = !0), a.classList.add(be));
    }
    if (e) return !0;
    for (const a of t.querySelectorAll("span, em, i, b, strong, div")) {
      if (!(a instanceof HTMLElement) || a.children.length > 3 || !Vo(a.textContent)) continue;
      const o = E(a.parentElement?.innerText || ""),
        s = getComputedStyle(a),
        r = /未读/.test(o),
        d = Da(s.color) || Da(s.backgroundColor);
      if (r || d) {
        ((e = !0), a.classList.add(be));
        break;
      }
    }
    return e;
  }
  function Uo(t) {
    t.querySelectorAll(`.${gn}`).forEach((e) => e.classList.remove(gn));
    for (const e of t.querySelectorAll("span, em, i, b, strong, div")) {
      if (!(e instanceof HTMLElement)) continue;
      const n = Array.from(e.childNodes)
        .filter((s) => s.nodeType === Node.TEXT_NODE)
        .map((s) => s.nodeValue || "")
        .join("")
        .trim();
      if (!n) continue;
      const a = /\d{5,16}/.test(n),
        o = /^\s*\d{1,4}\s*$/.test(n);
      (a || o) && e.classList.add(gn);
    }
  }
  function Ko() {
    if (((he = 0), !da())) return;
    const t = Jt();
    if (!t) {
      fn();
      return;
    }
    const e = Oo(t);
    if (!e.length) return;
    let n = !1;
    for (const a of e) {
      (a.classList.add(Kt), Uo(a));
      const o = hn(a),
        s = Ho(a) || (o && Lt.has(o)),
        r = zo(a);
      r && ((Gt = o || Gt), (n = !0));
      const d = r || (!n && o && o === Gt),
        i = Wo(a);
      (a.classList.toggle(wa, !!s), a.classList.toggle(mn, !!d), a.classList.toggle(Ca, !!i));
    }
    t.querySelectorAll(`.${Kt}`).forEach((a) => {
      e.includes(a) || a.classList.remove(Kt, wa, mn, Ca);
    });
  }
  function tt(t = 60) {
    (he && clearTimeout(he), (he = setTimeout(Ko, t)));
  }
  function jo(t) {
    const e = Jt();
    if (!e || !(t instanceof Element) || !e.contains(t)) return null;
    const n = t.closest(`.${Kt}`);
    return n && e.contains(n) ? n : Ba(t, e);
  }
  function Go(t) {
    const e = t.target instanceof Element ? t.target : null;
    if (!e) return;
    const n = jo(e);
    if (n) {
      ((Gt = hn(n)), tt(0), tt(140));
      return;
    }
    const a = E(e.closest("button, li, div, span")?.innerText || e.textContent || "");
    if (a === "\u7F6E\u9876" || a === "\u53D6\u6D88\u7F6E\u9876") {
      const o = Jt()?.querySelector(`.${Kt}.${mn}`),
        s = o ? hn(o) : Gt;
      s && (a === "\u53D6\u6D88\u7F6E\u9876" ? Lt.delete(s) : Lt.add(s), Ro(), tt(100));
    }
  }
  function fn() {
    const t = Jt();
    (t === pn && jt) ||
      (jt?.disconnect(),
      (jt = null),
      (pn = t || null),
      t &&
        ((jt = new MutationObserver((e) => {
          e.length && tt(70);
        })),
        jt.observe(t, {
          childList: !0,
          subtree: !0,
          characterData: !0,
          attributes: !0,
          attributeFilter: [
            "class",
            "aria-current",
            "aria-selected",
            "data-unread",
            "data-pinned",
            "data-active",
          ],
        }),
        tt(0)));
  }
  function Jo() {
    if (!da()) return;
    (Io(), document.addEventListener("click", Go, !0), fn());
    const t = new MutationObserver(() => {
        Jt() !== pn && fn();
      }),
      e =
        document.querySelector(
          "#v-im-app, #im-app, #kt_chat_contacts_body, [data-kt-element='contacts']",
        ) || document.body;
    (t.observe(e, { childList: !0, subtree: !0 }),
      window.addEventListener("resize", () => tt(90), { passive: !0 }),
      tt(0),
      setTimeout(() => tt(0), 700),
      setTimeout(() => tt(0), 1800));
  }
  const La = "oz-crystal-bubble",
    Xo = "oz-chat-row",
    Zo = "oz-chat-incoming",
    Yo = "oz-chat-outgoing",
    Et = "oz-bubble-character",
    _a = chrome.runtime.getURL("assets/orange-chibi-sticker.png");
  let Xt = null,
    yn = null,
    fe = 0;
  function En() {
    return (
      ($() &&
        (document.querySelector("#div-im-app .main-content .right") ||
          document.querySelector("#div-im-app .main.content .right") ||
          document.querySelector("#v-im-app .main-content .right") ||
          document.querySelector("#v-im-app .main.content .right") ||
          document.querySelector("#im-app .main-content .right") ||
          document.querySelector("#im-app .main_content .right") ||
          document.querySelector("div.main-content div.right") ||
          document.querySelector("#div-im-app .right, #v-im-app .right, #im-app .right"))) ||
      null
    );
  }
  function Qo(t, e) {
    if (!(t instanceof Element)) return null;
    let n = t.matches(".message-content")
      ? t
      : t.querySelector(":scope > .message-content") ||
        t.closest(".message-content") ||
        t.closest(".im-chat-text") ||
        t;
    if (!e?.contains(n)) return null;
    const a = n.getBoundingClientRect();
    return a.width < 24 || a.height < 16 || a.height > 360 ? null : n;
  }
  function ts(t, e) {
    if (!(t instanceof Element)) return null;
    const n = t.closest(
      ".im-chat-other, .im-chat-user, .im-chat-self, .im-chat-mine, .chat-message, .chat_message, .message-item, .message_item, [class*='chat-message'], [class*='message-item']",
    );
    if (n && e?.contains(n)) return n;
    let a = t.parentElement,
      o = t.parentElement,
      s = 0;
    for (; a && a !== e && s < 5; ) {
      const r = a.getBoundingClientRect();
      if (
        (r.height > 16 && r.height < 420 && (o = a),
        r.width > e.getBoundingClientRect().width * 0.88)
      )
        break;
      ((a = a.parentElement), (s += 1));
    }
    return o || t.parentElement || t;
  }
  function es(t, e, n) {
    const a = `${t?.className || ""} ${e?.className || ""}`.toLowerCase();
    if (/im-chat-other|incoming|receive|received|opponent|customer/.test(a)) return "incoming";
    if (/im-chat-user|im-chat-self|im-chat-mine|outgoing|sent|mine|self/.test(a)) return "outgoing";
    const o = n.getBoundingClientRect(),
      s = e.getBoundingClientRect(),
      r = s.left + s.width / 2,
      d = o.left + o.width / 2;
    return r >= d ? "outgoing" : "incoming";
  }
  function ns(t, e) {
    if (!(t instanceof HTMLElement)) return;
    (t.classList.add(La), (t.dataset.ozDirection = e));
    let n = t.querySelector(`:scope > .${Et}`);
    (n instanceof HTMLImageElement ||
      (t.querySelectorAll(`:scope > .${Et}`).forEach((a) => a.remove()),
      (n = document.createElement("img")),
      (n.className = Et),
      (n.src = _a),
      (n.alt = ""),
      (n.draggable = !1),
      n.setAttribute("aria-hidden", "true"),
      t.appendChild(n)),
      (n.dataset.ozDirection = e),
      n.classList.toggle("oz-sticker-mirror", e === "outgoing"));
  }
  const ye = "oz-time-character",
    Cs = "oz-time-character-img",
    _t = "oz-time-target",
    Ss = _a;
  function as(t) {
    if (!(t instanceof Element)) return "";
    let e = "";
    for (const n of t.childNodes) n.nodeType === Node.TEXT_NODE && (e += ` ${n.nodeValue || ""}`);
    return E(e);
  }
  function $a(t) {
    const e = E(t || "");
    return !e || e.length > 40
      ? !1
      : /(?:19|20)\d{2}[-\/.]\d{1,2}[-\/.]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?/.test(e);
  }
  function xs(t, e, n) {
    if (!(t instanceof Element) || !(n instanceof Element)) return null;
    const a = [t];
    t.parentElement && n.contains(t.parentElement) && a.push(t.parentElement);
    const o = e.getBoundingClientRect();
    let s = null,
      r = 1 / 0;
    for (const d of a) {
      const i = d.querySelectorAll("time, span, small, label, p, div");
      for (const c of i) {
        if (
          !(c instanceof HTMLElement) ||
          c === e ||
          e.contains(c) ||
          c.closest(`.${ye}`) ||
          !n.contains(c)
        )
          continue;
        const l = as(c),
          g = E(c.textContent || ""),
          b = E(c.getAttribute("datetime") || "");
        if (!($a(l) || (c.matches("time") && ($a(g) || /T\d{1,2}:\d{2}/.test(b))))) continue;
        const p = c.getBoundingClientRect();
        if (p.width < 18 || p.height < 8 || p.width > 260 || p.height > 70) continue;
        const y = Math.abs(p.top + p.height / 2 - o.top),
          A = Math.abs(p.left + p.width / 2 - (o.left + o.width / 2)) * 0.08,
          h = y + A;
        h < r && ((r = h), (s = c));
      }
    }
    return s;
  }
  function os(t, e, n, a) {
    t instanceof HTMLElement &&
      (t.querySelectorAll(`.${_t}`).forEach((o) => o.classList.remove(_t)),
      t.querySelectorAll(`:scope > .${ye}`).forEach((o) => o.remove()));
  }
  const Ee = "oz-time-character-fixed",
    Fe = "oz-own-avatar-fix",
    ve = "oz-own-avatar",
    qa = /(?:19|20)\d{2}[-\/.]\d{1,2}[-\/.]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?/g,
    ka = /^(?:(?:昨天|今天|前天)\s*)?(\d{1,2}:\d{2}(?::\d{2})?)$/;
  function ss(t) {
    return !!t?.closest?.(".im-chat-text, .message-content, .oz-crystal-bubble");
  }
  function As(t) {
    const e = [];
    if (!(t instanceof HTMLElement)) return e;
    const n = t.getBoundingClientRect(),
      a = document.createTreeWalker(t, NodeFilter.SHOW_TEXT, {
        acceptNode(s) {
          const r = s.parentElement;
          if (
            !r ||
            r.closest(`.${Ee}, .${Et}, .${ye}`) ||
            r.closest('script,style,textarea,input,[contenteditable="true"]') ||
            ss(r)
          )
            return NodeFilter.FILTER_REJECT;
          const d = s.nodeValue || "";
          if (!d.trim()) return NodeFilter.FILTER_REJECT;
          if (/(?:19|20)\d{2}[-\/.]\d{1,2}[-\/.]\d{1,2}\s+\d{1,2}:\d{2}/.test(d))
            return NodeFilter.FILTER_ACCEPT;
          const i = d.replace(/\s+/g, " ").trim();
          return i.length <= 16 && ka.test(i) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        },
      });
    let o;
    for (; (o = a.nextNode()); ) {
      const s = o.nodeValue || "",
        r = o.parentElement;
      if (!r) continue;
      const d = [];
      qa.lastIndex = 0;
      let i;
      for (; (i = qa.exec(s)); ) d.push({ index: i.index, text: i[0] });
      if (!d.length) {
        const c = s.replace(/\s+/g, " ").trim();
        if (c.length <= 16 && ka.test(c)) {
          const l = s.indexOf(c);
          l >= 0 && d.push({ index: l, text: c });
        }
      }
      for (const c of d)
        try {
          const l = document.createRange();
          (l.setStart(o, c.index), l.setEnd(o, c.index + c.text.length));
          const g = Array.from(l.getClientRects()).filter((p) => p.width > 8 && p.height > 6);
          if ((l.detach?.(), !g.length)) continue;
          const b = g[0];
          if (
            b.right < n.left ||
            b.left > n.right ||
            b.bottom < n.top ||
            b.top > n.bottom ||
            b.width > 230 ||
            b.height > 46
          )
            continue;
          e.push({ parent: r, rect: b, text: c.text });
        } catch {}
    }
    return e.slice(-120);
  }
  function rs(t) {
    (document.querySelectorAll(`.${Ee}`).forEach((e) => e.remove()),
      t instanceof HTMLElement &&
        t.querySelectorAll(`.${_t}`).forEach((e) => e.classList.remove(_t)));
  }
  function Bs(t, e, n) {
    if (!(t instanceof HTMLElement) || !(e instanceof HTMLElement) || !(n instanceof HTMLElement))
      return null;
    const a = e.getBoundingClientRect(),
      o = n.getBoundingClientRect(),
      s = Array.from(t.querySelectorAll('.el-avatar, [class*="avatar"], div, span, label'));
    let r = null,
      d = 1 / 0;
    for (const i of s) {
      if (
        !(i instanceof HTMLElement) ||
        i === e ||
        e.contains(i) ||
        i.closest(`.${Ee}, .${Et}, .${ye}`)
      )
        continue;
      const c = i.getBoundingClientRect();
      if (c.width < 24 || c.width > 62 || c.height < 24 || c.height > 62) continue;
      const l = c.width / Math.max(1, c.height);
      if (l < 0.68 || l > 1.45 || c.right < o.left || c.left > o.right) continue;
      const g = E(i.textContent || ""),
        b = String(i.className || "").toLowerCase();
      if (!(/avatar/.test(b) || /^[A-Za-z]{1,3}$/.test(g) || /^[A-Za-z_]{1,6}$/.test(g))) continue;
      let p = Math.abs(c.top + c.height / 2 - (a.top + Math.min(a.height, 44) / 2));
      ((p += Math.abs(c.right - a.left) * 0.12),
        /^AA(?:_\d+)?$/i.test(g) ? (p -= 120) : /^[A-Za-z]{1,3}$/.test(g) && (p -= 55),
        /avatar/.test(b) && (p -= 50),
        c.left < a.left && (p -= 35),
        p < d && ((d = p), (r = i)));
    }
    return r;
  }
  function is(t, e, n, a) {
    t instanceof HTMLElement &&
      t.querySelectorAll(`.${Fe}, .${ve}`).forEach((o) => {
        (o.classList.remove(Fe, ve), o.style.removeProperty("--oz-avatar-shift-x"));
      });
  }
  function us(t, e) {
    if (((t = Qo(t, e)), !t)) return;
    const n = ts(t, e),
      a = es(n, t, e);
    (n instanceof HTMLElement &&
      (n.classList.add(Xo),
      n.classList.toggle(Zo, a === "incoming"),
      n.classList.toggle(Yo, a === "outgoing"),
      (n.dataset.ozDirection = a)),
      ns(t, a),
      os(n, t, a, e),
      is(n, t, a, e));
  }
  function cs() {
    fe = 0;
    const t = En();
    if (!t) {
      Fn();
      return;
    }
    const e = new Set();
    (t.querySelectorAll(".im-chat-text.oz-crystal-bubble:has(> .message-content)").forEach((n) => {
      (n.classList.remove(La),
        delete n.dataset.ozDirection,
        n.querySelectorAll(`:scope > .${Et}`).forEach((a) => a.remove()));
    }),
      t
        .querySelectorAll(
          ".im-chat-other .im-chat-text, .im-chat-user .im-chat-text, .im-chat-self .im-chat-text, .im-chat-mine .im-chat-text",
        )
        .forEach((n) => e.add(n)),
      t.querySelectorAll(".im-chat-text").forEach((n) => e.add(n)),
      e.size ||
        t.querySelectorAll(".message-content, [class*='message-content']").forEach((n) => {
          const a = E(n.textContent || "");
          a && a.length < 5e3 && e.add(n);
        }),
      t.querySelectorAll(`.${Fe}, .${ve}`).forEach((n) => {
        (n.classList.remove(Fe, ve), n.style.removeProperty("--oz-avatar-shift-x"));
      }),
      t.querySelectorAll(`.${_t}`).forEach((n) => n.classList.remove(_t)),
      document.querySelectorAll(`.${Ee}`).forEach((n) => n.remove()),
      Array.from(e)
        .slice(-220)
        .forEach((n) => us(n, t)),
      rs(t));
  }
  function Ft(t = 45) {
    (fe && clearTimeout(fe), (fe = setTimeout(cs, t)));
  }
  function Fn() {
    const t = En();
    (t === yn && Xt) ||
      (Xt?.disconnect(),
      (Xt = null),
      (yn = t || null),
      t &&
        ((Xt = new MutationObserver((e) => {
          e.some((n) =>
            n.type === "characterData"
              ? !0
              : Array.from(n.addedNodes || []).some(
                  (a) => !(a instanceof Element) || !a.classList?.contains(Et),
                ),
          ) && Ft(55);
        })),
        Xt.observe(t, {
          childList: !0,
          subtree: !0,
          characterData: !0,
          attributes: !0,
          attributeFilter: ["class"],
        }),
        Ft(0)));
  }
  function ls() {
    if (!$()) return;
    Fn();
    const t = document.querySelector("#v-im-app, #im-app") || document.body;
    (new MutationObserver(() => {
      En() !== yn && Fn();
    }).observe(t, { childList: !0, subtree: !0 }),
      window.addEventListener("resize", () => Ft(60), { passive: !0 }),
      document.addEventListener("scroll", () => Ft(35), { passive: !0, capture: !0 }),
      Ft(0),
      setTimeout(() => Ft(0), 500),
      setTimeout(() => Ft(0), 1400));
  }
  function ds() {
    if (!/(^|\.)textnow\.com$/i.test(location.hostname)) return;
    let t = "";
    const e = new Map(),
      n = () => {
        const r = Array.from(
            document.querySelectorAll("#messageView li.chat-item.incoming .tn-chat-bubble-text"),
          ),
          d = r[r.length - 1];
        if (!d) return;
        const i = document.querySelector(
            ".conversation-title__name[data-number], .conversation-title_name[data-number]",
          ),
          c = i?.getAttribute("data-number") || i?.textContent?.trim() || "",
          l = d.cloneNode(!0);
        l.querySelectorAll(`.${nt}`).forEach((h) => h.remove());
        const g = String(l.textContent || "")
            .trim()
            .slice(0, 180),
          b = d.closest("li.chat-item.incoming"),
          p = b?.getAttribute("data-message-id") || b?.id || "",
          y = `${c}|${p}|${g}`;
        if (!g || !t) {
          t = y;
          return;
        }
        if (y === t) return;
        t = y;
        const A = Date.now();
        for (const [h, D] of e) A - D > 600 * 1e3 && e.delete(h);
        e.has(y) ||
          (e.set(y, A),
          window.postMessage(
            {
              source: "orange-ai-extension",
              type: "tn:new-message",
              payload: { phone: c, text: g, title: "TextNow \u65B0\u6D88\u606F" },
            },
            "*",
          ));
      };
    let a = null,
      o = null;
    const s = () => {
      const r = document.querySelector("#messageView");
      r !== a &&
        (o?.disconnect(),
        (a = r),
        a &&
          ((o = new MutationObserver(() => {
            (n(), setTimeout(n, 120));
          })),
          o.observe(a, { childList: !0, subtree: !0 }),
          n()));
    };
    (new MutationObserver(s).observe(document.body || document.documentElement, {
      childList: !0,
      subtree: !0,
    }),
      s());
  }
  function ms() {
    if (!/(^|\.)textnow\.com$/i.test(location.hostname)) return;
    const t = () => {
      document.querySelectorAll("#messageView li.chat-item .tn-chat-bubble-text").forEach((r) => {
        const d = r.closest("li.chat-item");
        let i = r.closest(
          ".tn-chat-bubble, [class*='message-bubble'], [class*='chat-bubble']:not(.tn-chat-bubble-text)",
        );
        ((!i || i === d) && (i = r.parentElement),
          i && i !== d && i.classList.add("ai-bt-tn-light-bubble"));
      });
    };
    let e = 0;
    const n = () => {
      (clearTimeout(e), (e = setTimeout(t, 45)));
    };
    let a = null,
      o = null;
    const s = () => {
      const r = document.querySelector("#messageView");
      r !== a &&
        (o?.disconnect(),
        (a = r),
        a && ((o = new MutationObserver(n)), o.observe(a, { childList: !0, subtree: !0 }), t()));
    };
    (new MutationObserver(s).observe(document.body || document.documentElement, {
      childList: !0,
      subtree: !0,
    }),
      s());
  }
  (Array.from(document.querySelectorAll('input[type="password"]')).some(
    (t) => t.offsetParent !== null,
  ) || (Jo(), ls()),
    ds(),
    ms(),
    va());
})();
