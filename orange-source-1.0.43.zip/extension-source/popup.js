(() => {
  "use strict";
  const B = Object.freeze({
      schemaVersion: 6,
      enabled: !0,
      imageDataUrl: "",
      imageOpacity: 1,
      panelOpacity: 0.22,
      groupPanelOpacity: 0.9,
      blur: 0,
      brightness: 100,
      glassBlur: 4,
    }),
    A = "orangeGeminiApiKey",
    f = "orangeGeminiModel",
    D = "gemini-3.5-flash-lite",
    a = (t) => document.querySelector(t),
    I = (t) => Array.from(document.querySelectorAll(t));
  let y = null,
    c = "",
    C = !1,
    l = { ...B },
    k = null;
  const M = a("#site-name"),
    m = a("#site-status"),
    N = a("#save-state"),
    G = a("#background-panel"),
    _ = a("#background-preview"),
    P = a("#preview-badge");
  function s(t, e, u, o) {
    const n = Number(t);
    return Number.isFinite(n) ? Math.min(u, Math.max(e, n)) : o;
  }
  function L(t) {
    const e = String(t || "").trim();
    return /^#[0-9a-f]{6}$/i.test(e) ? e.toLowerCase() : "";
  }
  function i(t) {
    return `${t}:${c}`;
  }
  function r(t, e = "") {
    ((N.textContent = t), (N.className = e));
  }
  async function g(t, e = {}) {
    if (!y?.id) return !1;
    try {
      return (await chrome.tabs.sendMessage(y.id, { type: t, ...e }), !0);
    } catch {
      return !1;
    }
  }
  function v() {
    return i("aiBtCustomBackground");
  }
  function S(t) {
    const e = t && typeof t == "object" ? t : {};
    return {
      schemaVersion: 6,
      enabled: typeof e.enabled == "boolean" ? e.enabled : !0,
      imageDataUrl: typeof e.imageDataUrl == "string" ? e.imageDataUrl : "",
      imageOpacity: s(e.imageOpacity, 0.15, 1, B.imageOpacity),
      panelOpacity: s(e.panelOpacity, 0.06, 0.72, B.panelOpacity),
      groupPanelOpacity: s(e.groupPanelOpacity, 0.35, 0.98, B.groupPanelOpacity),
      blur: s(e.blur, 0, 12, B.blur),
      brightness: s(e.brightness, 55, 145, B.brightness),
      glassBlur: s(e.glassBlur, 0, 10, B.glassBlur),
    };
  }
  async function w({ immediate: t = !1 } = {}) {
    if (!c) return;
    const e = async () => {
      k = null;
      try {
        (r("\u6B63\u5728\u540C\u6B65\u2026", "busy"),
          (l.schemaVersion = 6),
          await chrome.storage.local.set({ [v()]: l }),
          await g("AI_BT_BACKGROUND_CHANGED"),
          r("\u8BBE\u7F6E\u5DF2\u540C\u6B65", "ok"));
      } catch (u) {
        (console.error("[Orange Popup] background save failed", u),
          r("\u4FDD\u5B58\u5931\u8D25", "error"));
      }
    };
    (k && clearTimeout(k), t ? await e() : (k = setTimeout(e, 90)));
  }
  function p(t, e, u) {
    const o = a(`#${t}`),
      n = a(`#${t}-output`);
    !o || !n || ((o.value = String(e)), (n.textContent = `${e}${u}`));
  }
  function E() {
    ((a("#background-enabled").checked = !!l.enabled),
      p("brightness", Math.round(l.brightness), "%"),
      p("blur", Math.round(l.blur), "px"),
      p("glass-blur", Math.round(l.glassBlur), "px"),
      p("panel-opacity", Math.round(l.panelOpacity * 100), "%"),
      p("group-panel-opacity", Math.round(l.groupPanelOpacity * 100), "%"),
      p("image-opacity", Math.round(l.imageOpacity * 100), "%"));
    const t = l.imageDataUrl || chrome.runtime.getURL("assets/panel-background.png");
    ((_.style.backgroundImage = `url(${JSON.stringify(t)})`),
      (_.style.filter = `brightness(${l.brightness}%)`),
      (_.style.opacity = String(Math.max(0.35, l.imageOpacity))),
      (P.textContent = l.imageDataUrl
        ? "\u81EA\u5B9A\u4E49\u80CC\u666F"
        : "\u9ED8\u8BA4\u80CC\u666F"));
    const e = !!c;
    (G.classList.toggle("disabled", !e),
      (a("#background-enabled").disabled = !e),
      (a("#background-note").textContent = e
        ? "\u80CC\u666F\u5B9E\u65F6\u5E94\u7528\u5230\u5F53\u524D\u5E73\u53F0\uFF1A\u4E3B\u804A\u5929\u533A\u89C6\u89C9\u7A7F\u900F\uFF0C\u8054\u7CFB\u4EBA\u5217\u8868\u4E0E\u4FA7\u680F\u4F7F\u7528\u5206\u5C42\u6BDB\u73BB\u7483\uFF1B\u4EC5\u672C\u673A\u53EF\u89C1\u3002"
        : "\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u7F51\u7AD9\u6807\u7B7E\u9875\u3002"));
  }
  function O(t) {
    I("[data-mode]").forEach((e) => {
      e.classList.toggle("active", e.dataset.mode === t);
    });
  }
  async function $() {
    y = (await chrome.tabs.query({ active: !0, currentWindow: !0 }))[0] || null;
    let t = null;
    try {
      t = y?.url ? new URL(y.url) : null;
    } catch {}
    ((c = t?.hostname || ""),
      (C = /(^|\.)(?:opensms\.xin|opensms\.cc)$/i.test(c)),
      (M.textContent = c || "Chrome \u5185\u90E8\u9875\u9762"),
      (m.textContent = C
        ? "OpenSMS \u5DF2\u8BC6\u522B"
        : c
          ? "\u7FFB\u8BD1\u53EF\u7528"
          : "\u53D7\u9650\u9875\u9762"),
      (m.className = `status-pill ${C ? "ok" : "warn"}`));
  }
  async function H() {
    if (!c) {
      (O("pause"), E());
      return;
    }
    const t = [
        i("aiBtMode"),
        i("aiBtPhoneMask"),
        i("aiBtInputTranslator"),
        i("aiBtTranslationColor"),
        i("aiBtBubbleLightColor"),
        i("aiBtBubbleLightWidth"),
        i("aiBtBubbleLightEnabled"),
        v(),
      ],
      e = await chrome.storage.local.get(t),
      u = C ? "chat" : "pause",
      o = ["chat", "page", "pause"].includes(e[i("aiBtMode")]) ? e[i("aiBtMode")] : u;
    (O(o),
      (a("#phone-mask").checked = !!e[i("aiBtPhoneMask")]),
      (a("#input-translator").checked = !!e[i("aiBtInputTranslator")]));
    const n = L(e[i("aiBtTranslationColor")]);
    a("#translation-color").value = n || "#ffd166";
    const d = L(e[i("aiBtBubbleLightColor")]);
    a("#bubble-light-color").value = d || "#a97bff";
    const b = Math.min(10, Math.max(4, Number(e[i("aiBtBubbleLightWidth")]) || 7));
    ((a("#bubble-light-width").value = String(b)),
      (a("#bubble-light-width-value").textContent = `${b}px`),
      (a("#bubble-light-enabled").checked = e[i("aiBtBubbleLightEnabled")] !== !1),
      (l = S(e[v()])),
      !e[v()] && c && (l.enabled = !0),
      E());
  }
  async function T() {
    const t = await chrome.storage.local.get([A, f]),
      e = String(t?.[A] || "").trim(),
      u = String(t?.[f] || D).trim() || D,
      o = a("#ai-api-key"),
      n = a("#ai-model"),
      d = a("#ai-config-status");
    (o &&
      ((o.value = ""),
      (o.placeholder = e
        ? "\u5DF2\u4FDD\u5B58 \xB7 \u8F93\u5165\u65B0 Key \u53EF\u66FF\u6362"
        : "\u7C98\u8D34 Gemini API Key")),
      n && (n.value = u),
      d &&
        ((d.textContent = e ? "\u5DF2\u914D\u7F6E" : "\u672A\u914D\u7F6E"),
        (d.className = `status-pill ${e ? "ok" : "warn"}`)));
  }
  async function U() {
    const t = a("#ai-api-key"),
      e = a("#ai-model"),
      u = String(t?.value || "").trim(),
      o = String(e?.value || D).trim() || D,
      n = { [f]: o };
    (u && (n[A] = u),
      await chrome.storage.local.set(n),
      t && (t.value = ""),
      await T(),
      r("Google AI \u8BBE\u7F6E\u5DF2\u4FDD\u5B58", "ok"));
  }
  async function R() {
    (await chrome.storage.local.remove(A), await T(), r("Gemini Key \u5DF2\u6E05\u9664", "ok"));
  }
  async function W(t) {
    if (!(t instanceof File) || !t.type.startsWith("image/"))
      throw new Error("\u8BF7\u9009\u62E9\u56FE\u7247\u6587\u4EF6");
    const e = await new Promise((b, x) => {
        const h = new FileReader();
        ((h.onload = () => b(String(h.result || ""))),
          (h.onerror = () => x(new Error("\u65E0\u6CD5\u8BFB\u53D6\u56FE\u7247"))),
          h.readAsDataURL(t));
      }),
      u = await new Promise((b, x) => {
        const h = new Image();
        ((h.onload = () => b(h)),
          (h.onerror = () => x(new Error("\u65E0\u6CD5\u89E3\u6790\u56FE\u7247"))),
          (h.src = e));
      }),
      o = Math.min(1, 2560 / Math.max(u.naturalWidth || 1, u.naturalHeight || 1)),
      n = document.createElement("canvas");
    ((n.width = Math.max(1, Math.round((u.naturalWidth || 1) * o))),
      (n.height = Math.max(1, Math.round((u.naturalHeight || 1) * o))));
    const d = n.getContext("2d", { alpha: !1 });
    if (!d) return e;
    d.drawImage(u, 0, 0, n.width, n.height);
    try {
      const b = n.toDataURL("image/webp", 0.9);
      if (b.startsWith("data:image/webp")) return b;
    } catch {}
    return n.toDataURL("image/jpeg", 0.9);
  }
  function F(t, e, u = Number) {
    const o = a(`#${t}`),
      n = a(`#${t}-output`);
    (o.addEventListener("input", () => {
      const d = Number(o.value);
      l[e] = u(d);
      const b = t.includes("opacity") || t === "brightness" ? "%" : "px";
      ((n.textContent = `${d}${b}`), E(), w());
    }),
      o.addEventListener("change", () => w({ immediate: !0 })));
  }
  function K() {
    (I("[data-mode]").forEach((t) => {
      t.addEventListener("click", async () => {
        if (!c) return;
        const e = t.dataset.mode;
        (O(e),
          await chrome.storage.local.set({ [i("aiBtMode")]: e }),
          await g("AI_BT_MODE_CHANGED", { mode: e }),
          r("\u7FFB\u8BD1\u6A21\u5F0F\u5DF2\u66F4\u65B0", "ok"));
      });
    }),
      a("#input-translator").addEventListener("change", async (t) => {
        const e = t.target.checked;
        (await chrome.storage.local.set({ [i("aiBtInputTranslator")]: e }),
          await g("AI_BT_INPUT_TRANSLATOR_CHANGED", { enabled: e }),
          r("\u8F93\u5165\u7FFB\u8BD1\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#phone-mask").addEventListener("change", async (t) => {
        const e = t.target.checked;
        (await chrome.storage.local.set({ [i("aiBtPhoneMask")]: e }),
          await g("AI_BT_PHONE_MASK_CHANGED", { enabled: e }),
          r("\u9690\u79C1\u906E\u6321\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#translation-color").addEventListener("input", async (t) => {
        const e = L(t.target.value);
        (await chrome.storage.local.set({ [i("aiBtTranslationColor")]: e }),
          await g("AI_BT_TRANSLATION_COLOR_CHANGED", { color: e }),
          r("\u8BD1\u6587\u989C\u8272\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#color-reset").addEventListener("click", async () => {
        ((a("#translation-color").value = "#ffd166"),
          await chrome.storage.local.set({ [i("aiBtTranslationColor")]: "" }),
          await g("AI_BT_TRANSLATION_COLOR_CHANGED", { color: "" }),
          r("\u5DF2\u6062\u590D\u9ED8\u8BA4\u989C\u8272", "ok"));
      }),
      a("#bubble-light-color").addEventListener("input", async (t) => {
        const e = L(t.target.value) || "#a97bff";
        (await chrome.storage.local.set({ [i("aiBtBubbleLightColor")]: e }),
          await g("AI_BT_BUBBLE_LIGHT_COLOR_CHANGED", { color: e }),
          r("\u6C14\u6CE1\u6D41\u5149\u989C\u8272\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#bubble-light-enabled").addEventListener("change", async (t) => {
        const e = t.target.checked;
        (await chrome.storage.local.set({ [i("aiBtBubbleLightEnabled")]: e }),
          await g("AI_BT_BUBBLE_LIGHT_ENABLED_CHANGED", { enabled: e }),
          r(
            e
              ? "\u6C14\u6CE1\u6846\u7279\u6548\u5DF2\u5F00\u542F"
              : "\u6C14\u6CE1\u6846\u7279\u6548\u5DF2\u5173\u95ED",
            "ok",
          ));
      }),
      a("#bubble-light-reset").addEventListener("click", async () => {
        const t = "#a97bff";
        ((a("#bubble-light-color").value = t),
          await chrome.storage.local.set({ [i("aiBtBubbleLightColor")]: t }),
          await g("AI_BT_BUBBLE_LIGHT_COLOR_CHANGED", { color: t }),
          r("\u5DF2\u6062\u590D\u9ED8\u8BA4\u6D41\u5149", "ok"));
      }),
      a("#bubble-light-width").addEventListener("input", async (t) => {
        const e = Math.min(10, Math.max(4, Number(t.target.value) || 7));
        ((a("#bubble-light-width-value").textContent = `${e}px`),
          await chrome.storage.local.set({ [i("aiBtBubbleLightWidth")]: e }),
          await g("AI_BT_BUBBLE_LIGHT_WIDTH_CHANGED", { width: e }),
          r(`\u6D41\u5149\u7C97\u7EC6\u5DF2\u8C03\u6574\u4E3A ${e}px`, "ok"));
      }),
      a("#ai-save")?.addEventListener("click", async () => {
        try {
          (r("\u6B63\u5728\u4FDD\u5B58 Google AI \u8BBE\u7F6E\u2026", "busy"), await U());
        } catch (t) {
          (console.error("[Orange Popup] AI settings save failed", t),
            r("Google AI \u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25", "error"));
        }
      }),
      a("#ai-clear")?.addEventListener("click", async () => {
        try {
          await R();
        } catch (t) {
          (console.error("[Orange Popup] AI key clear failed", t),
            r("\u6E05\u9664 Gemini Key \u5931\u8D25", "error"));
        }
      }),
      a("#ai-model")?.addEventListener("change", async (t) => {
        (await chrome.storage.local.set({ [f]: String(t.target.value || D) }),
          r("AI \u6A21\u578B\u5DF2\u66F4\u65B0", "ok"));
      }),
      a("#background-enabled").addEventListener("change", async (t) => {
        ((l.enabled = t.target.checked), await w({ immediate: !0 }), E());
      }),
      a("#upload-background").addEventListener("click", () => a("#background-file").click()),
      a("#background-file").addEventListener("change", async (t) => {
        const e = t.target.files?.[0];
        if (!e) return;
        const u = a("#upload-background"),
          o = u.textContent;
        ((u.disabled = !0), (u.textContent = "\u6B63\u5728\u5904\u7406\u56FE\u7247\u2026"));
        try {
          ((l.imageDataUrl = await W(e)),
            (l.enabled = !0),
            E(),
            await w({ immediate: !0 }),
            (u.textContent = "\u56FE\u7247\u5DF2\u5E94\u7528"));
        } catch (n) {
          (console.error("[Orange Popup] image error", n),
            (u.textContent = "\u56FE\u7247\u5904\u7406\u5931\u8D25"),
            r(n.message || "\u56FE\u7247\u5904\u7406\u5931\u8D25", "error"));
        } finally {
          (setTimeout(() => {
            ((u.disabled = !1), (u.textContent = o));
          }, 900),
            (t.target.value = ""));
        }
      }),
      a("#reset-background").addEventListener("click", async () => {
        ((l = { ...B, enabled: C }),
          E(),
          await w({ immediate: !0 }),
          r("\u5DF2\u6062\u590D\u9ED8\u8BA4\u80CC\u666F", "ok"));
      }),
      F("brightness", "brightness", (t) => s(t, 55, 145, 100)),
      F("blur", "blur", (t) => s(t, 0, 12, 0)),
      F("glass-blur", "glassBlur", (t) => s(t, 0, 10, 4)),
      F("panel-opacity", "panelOpacity", (t) => s(t / 100, 0.06, 0.72, 0.22)),
      F("group-panel-opacity", "groupPanelOpacity", (t) => s(t / 100, 0.35, 0.98, 0.9)),
      F("image-opacity", "imageOpacity", (t) => s(t / 100, 0.15, 1, 1)));
  }
  async function V() {
    K();
    try {
      (await $(), await H(), await T());
      const t = await g("AI_BT_GET_PAGE_STATE");
      c &&
        !t &&
        ((m.textContent = "\u5237\u65B0\u9875\u9762\u540E\u751F\u6548"),
        (m.className = "status-pill warn"));
    } catch (t) {
      (console.error("[Orange Popup] init failed", t),
        (M.textContent = "\u65E0\u6CD5\u8BFB\u53D6\u5F53\u524D\u6807\u7B7E\u9875"),
        (m.textContent = "\u9700\u8981\u5237\u65B0"),
        (m.className = "status-pill warn"),
        r("\u521D\u59CB\u5316\u5931\u8D25", "error"));
    }
  }
  V();
})();
