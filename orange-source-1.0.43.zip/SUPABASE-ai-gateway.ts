// Deploy as Supabase Edge Function: ai-gateway
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { withSupabase } from "jsr:@supabase/server@^1";

type Provider = "deepl" | "groq" | "gemini" | "openai_compatible";
type Payload = {
  action: "settings" | "save_settings" | "list_keys" | "add_key" | "update_key" | "delete_key" | "generate" | "translate";
  keyId?: string; apiKey?: string; displayName?: string; provider?: Provider;
  endpointUrl?: string; useProxyPool?: boolean; model?: string; makePublic?: boolean;
  enabled?: boolean; priority?: number; employeePriority?: number; adminPriority?: number; dailyRequestLimit?: number | null;
  allowEmployeeKeys?: boolean; personalKeyFirst?: boolean; allowPublicFallback?: boolean;
  messages?: Array<{ role:"system" | "user" | "assistant"; content:string }>;
  temperature?: number; maxTokens?: number;
  text?: string; sourceLanguage?: string; targetLanguage?: string; preferredProvider?: Provider;
};

const DEFAULT_MODEL = "groq/compound-mini";
const PROVIDER_ENDPOINTS:Record<Provider,string> = {
  deepl:"https://api.deepl.com/v2/translate",
  groq:"https://api.groq.com/openai/v1/chat/completions",
  gemini:"https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
  openai_compatible:"",
};

function json(body:Record<string,unknown>, status = 200) { return Response.json(body, { status }); }
function fail(message:string, status = 400) { return json({ ok:false, message }, status); }
function bytesToBase64(bytes:Uint8Array) { let binary = ""; for (const byte of bytes) binary += String.fromCharCode(byte); return btoa(binary); }
function base64ToBytes(value:string) { const binary = atob(value); return Uint8Array.from(binary, char => char.charCodeAt(0)); }

async function keyFromSecret(secretName:string, usages:KeyUsage[]) {
  const secret = Deno.env.get(secretName) || "";
  if (secret.length < 32) throw new Error(`${secretName}至少需要32个字符`);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return crypto.subtle.importKey("raw", digest, { name:"AES-GCM" }, false, usages);
}
async function encryptAiKey(value:string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name:"AES-GCM", iv }, await keyFromSecret("AI_KEY_ENCRYPTION_SECRET", ["encrypt"]), new TextEncoder().encode(value));
  return { encryptedKey:bytesToBase64(new Uint8Array(encrypted)), encryptionIv:bytesToBase64(iv) };
}
async function decryptAiKey(value:string, iv:string) {
  const plain = await crypto.subtle.decrypt({ name:"AES-GCM", iv:base64ToBytes(iv) }, await keyFromSecret("AI_KEY_ENCRYPTION_SECRET", ["decrypt"]), base64ToBytes(value));
  return new TextDecoder().decode(plain);
}
async function decryptProxyValue(value:string, iv:string) {
  if (!value) return "";
  const plain = await crypto.subtle.decrypt({ name:"AES-GCM", iv:base64ToBytes(iv) }, await keyFromSecret("PROXY_POOL_ENCRYPTION_SECRET", ["decrypt"]), base64ToBytes(value));
  return new TextDecoder().decode(plain);
}

function validateProvider(value:unknown):Provider {
  if (value === "deepl" || value === "gemini" || value === "openai_compatible") return value;
  return "groq";
}
function endpointFor(provider:Provider, value:unknown) {
  const endpoint = String(value || "").trim() || PROVIDER_ENDPOINTS[provider];
  if (!endpoint) throw new Error("自定义AI必须填写API地址");
  let parsed:URL;
  try { parsed = new URL(endpoint); } catch { throw new Error("AI API地址格式不正确"); }
  if (parsed.protocol !== "https:") throw new Error("AI API地址必须使用HTTPS");
  return parsed.toString();
}
function safeMessages(value:unknown) {
  if (!Array.isArray(value) || !value.length || value.length > 40) throw new Error("消息内容不正确");
  let remaining = 220000;
  const selected = value.slice(-30);
  const prepared:Array<{ role:"system" | "user" | "assistant"; content:string }> = [];
  for (let index = selected.length - 1; index >= 0 && remaining > 0; index -= 1) {
    const item = selected[index] as any;
    const raw = String(item?.content || "");
    const content = raw.length <= remaining ? raw : raw.slice(raw.length - remaining);
    remaining -= content.length;
    const role = (["system", "user", "assistant"].includes(String(item?.role)) ? item.role : "user") as "system" | "user" | "assistant";
    prepared.unshift({ role, content });
  }
  return prepared.filter(item => item.content);
}
function uniqueModels(...values:unknown[]) {
  return [...new Set(values.flatMap(value => Array.isArray(value) ? value : [value]).map(value => String(value || "").trim()).filter(Boolean))];
}
function retryAfterSeconds(response:Response, message:string) {
  const header = Number(response.headers.get("retry-after") || 0);
  if (Number.isFinite(header) && header > 0) return Math.ceil(header);
  const match = message.match(/(?:try again in|retry after)\s*([\d.]+)s/i);
  return match ? Math.ceil(Number(match[1])) : 0;
}
async function logProxy(admin:any, values:Record<string,unknown>) {
  try { await admin.from("proxy_activity_logs").insert(values); } catch {}
}

async function chooseProxy(admin:any, excluded:Set<string>) {
  const { data:poolSettings, error:settingsError } = await admin.from("translation_proxy_settings").select("enabled").eq("singleton", true).maybeSingle();
  if (settingsError) throw settingsError;
  if (poolSettings?.enabled === false) return null;
  const { data, error } = await admin.from("translation_proxy_pool")
    .select("id,label,protocol,host,port,encrypted_username,username_iv,encrypted_password,password_iv,health_status,failure_count,last_used_at")
    .eq("enabled", true).in("health_status", ["healthy", "unknown"])
    .order("last_used_at", { ascending:true, nullsFirst:true });
  if (error) throw error;
  const row = (data || []).find((item:any) => ["http", "https"].includes(String(item.protocol || "http")) && !excluded.has(item.id));
  if (!row) return null;
  return { ...row,
    username:await decryptProxyValue(row.encrypted_username, row.username_iv),
    password:await decryptProxyValue(row.encrypted_password, row.password_iv),
  };
}

async function providerFetch(endpoint:string, apiKey:string, body:Record<string,unknown>, proxy:any, timeoutMs:number) {
  let client:Deno.HttpClient | null = null;
  try {
    if (proxy) {
      if (proxy.protocol === "socks5") throw new Error("服务端AI暂不支持SOCKS5线路，请使用HTTP/HTTPS代理");
      client = Deno.createHttpClient({ proxy:{
        url:`${proxy.protocol || "http"}://${proxy.host}:${proxy.port}`,
        ...(proxy.username ? { basicAuth:{ username:proxy.username, password:proxy.password || "" } } : {}),
      }});
    }
    const response = await fetch(endpoint, {
      method:"POST", signal:AbortSignal.timeout(timeoutMs),
      headers:{ "Content-Type":"application/json", Authorization:`Bearer ${apiKey}` },
      body:JSON.stringify(body), ...(client ? { client } : {}),
    } as RequestInit & { client?:Deno.HttpClient });
    const result = await response.json().catch(() => null);
    return { response, result };
  } finally { client?.close(); }
}

function deeplLanguage(value:unknown, target = false) {
  const language = String(value || "").toLowerCase();
  if (/^zh/.test(language)) return "ZH-HANS";
  if (/^en/.test(language)) return target ? "EN-US" : "EN";
  return "";
}
async function deeplTranslate(endpoint:string, apiKey:string, text:string, sourceLanguage:string, targetLanguage:string, proxy:any, timeoutMs:number) {
  let client:Deno.HttpClient | null = null;
  try {
    if (proxy) {
      if (proxy.protocol === "socks5") throw new Error("服务端DeepL暂不支持SOCKS5线路，请使用HTTP/HTTPS代理");
      client = Deno.createHttpClient({ proxy:{ url:`${proxy.protocol || "http"}://${proxy.host}:${proxy.port}`, ...(proxy.username ? { basicAuth:{ username:proxy.username, password:proxy.password || "" } } : {}) }});
    }
    const body:Record<string,unknown> = { text:[text], target_lang:deeplLanguage(targetLanguage, true) || "EN-US", preserve_formatting:true };
    const source = deeplLanguage(sourceLanguage, false);
    if (source) body.source_lang = source;
    const response = await fetch(endpoint, { method:"POST", signal:AbortSignal.timeout(timeoutMs), headers:{"Content-Type":"application/json",Authorization:`DeepL-Auth-Key ${apiKey}`}, body:JSON.stringify(body), ...(client ? {client} : {}) } as RequestInit & {client?:Deno.HttpClient});
    const result = await response.json().catch(() => null);
    return {response,result};
  } finally { client?.close(); }
}

export default {
  fetch:withSupabase({
    auth:"user",
    env:{ url:Deno.env.get("SUPABASE_URL")!, publishableKeys:{ default:Deno.env.get("SUPABASE_ANON_KEY")! }, secretKeys:{ default:Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")! } },
  }, async (req, ctx) => {
    try {
      const userId = String(ctx.jwtClaims?.sub ?? ctx.userClaims?.id ?? "");
      if (!userId) return fail("登录状态无效", 401);
      const admin = ctx.supabaseAdmin;
      const { data:profile, error:profileError } = await admin.from("profiles").select("role,account_status,plan").eq("id", userId).single();
      if (profileError || !profile || profile.account_status !== "active") return fail("账号不可用", 403);
      const isAdmin = profile.role === "admin";
      let permissions:Record<string,boolean> = {};
      if (!isAdmin) {
        const [{ data:planRows, error:planError }, { data:overrideRows, error:overrideError }] = await Promise.all([
          admin.from("plan_permissions").select("feature_code,enabled").eq("plan", profile.plan),
          admin.from("user_permission_overrides").select("feature_code,enabled").eq("user_id", userId),
        ]);
        if (planError) throw planError;
        if (overrideError) throw overrideError;
        for (const row of planRows || []) permissions[row.feature_code] = Boolean(row.enabled);
        for (const row of overrideRows || []) permissions[row.feature_code] = Boolean(row.enabled);
      }
      const body = await req.json() as Payload;
      const { data:settings, error:settingsError } = await admin.from("ai_settings").select("*").eq("singleton", true).single();
      if (settingsError) throw settingsError;

      if (body.action === "settings") return json({ ok:true, settings:{ allowEmployeeKeys:settings.allow_employee_keys, personalKeyFirst:settings.personal_key_first, allowPublicFallback:settings.allow_public_fallback, defaultProvider:settings.default_provider, defaultModel:settings.default_model } });

      if (body.action === "save_settings") {
        if (!isAdmin) return fail("只有管理员能修改AI池设置", 403);
        const { error } = await admin.from("ai_settings").update({ allow_employee_keys:body.allowEmployeeKeys !== false, personal_key_first:body.personalKeyFirst !== false, allow_public_fallback:body.allowPublicFallback !== false, default_model:String(body.model || settings.default_model || DEFAULT_MODEL).trim(), updated_at:new Date().toISOString() }).eq("singleton", true);
        if (error) throw error;
        return json({ ok:true });
      }

      if (body.action === "list_keys") {
        let query = admin.from("ai_api_keys").select("id,owner_user_id,provider,display_name,model,endpoint_url,use_proxy_pool,enabled,priority,employee_priority,admin_priority,daily_request_limit,cooldown_until,last_used_at,last_error,created_at").order("priority", { ascending:true });
        if (!isAdmin) query = query.eq("owner_user_id", userId);
        const { data, error } = await query;
        if (error) throw error;
        if (!isAdmin) return json({ ok:true, keys:data });
        const { data:preferenceRows, error:preferenceError } = await admin.from("ai_admin_model_preferences").select("api_key_id,priority,enabled").eq("admin_user_id", userId);
        if (preferenceError) throw preferenceError;
        const preferences = new Map((preferenceRows || []).map((row:any) => [row.api_key_id, row]));
        const keys = (data || []).map((row:any) => ({ ...row, my_admin_priority:Number(preferences.get(row.id)?.priority ?? row.admin_priority ?? row.priority ?? 100) }))
          .sort((a:any, b:any) => a.my_admin_priority - b.my_admin_priority || Number(a.employee_priority || 100) - Number(b.employee_priority || 100));
        return json({ ok:true, keys });
      }

      if (body.action === "add_key") {
        if (!isAdmin && permissions.personal_groq_key !== true) return fail("当前会员没有添加个人AI Key的权限", 403);
        if (!settings.allow_employee_keys && !isAdmin) return fail("管理员未开放员工个人Key", 403);
        if (body.makePublic && !isAdmin) return fail("只有管理员能添加公共Key", 403);
        const provider = validateProvider(body.provider);
        const rawKey = String(body.apiKey || "").trim();
        if (rawKey.length < 20 || (provider === "groq" && !rawKey.startsWith("gsk_"))) return fail(`${provider === "groq" ? "Groq" : "AI"} API Key格式不正确`);
        const model = String(body.model || (provider === "groq" ? settings.default_model : "")).trim();
        if (!model) return fail("必须填写模型名称");
        const encrypted = await encryptAiKey(rawKey);
        const { data, error } = await admin.from("ai_api_keys").insert({ owner_user_id:body.makePublic ? null : userId, provider, display_name:String(body.displayName || `${provider} Key`).trim().slice(0, 60), encrypted_key:encrypted.encryptedKey, encryption_iv:encrypted.encryptionIv, model, endpoint_url:endpointFor(provider, body.endpointUrl), use_proxy_pool:body.useProxyPool === true, enabled:true }).select("id,owner_user_id,provider,display_name,model,endpoint_url,use_proxy_pool,enabled,priority,created_at").single();
        if (error) throw error;
        return json({ ok:true, key:data }, 201);
      }

      if (body.action === "delete_key") {
        if (!body.keyId) return fail("缺少keyId");
        let query = admin.from("ai_api_keys").delete().eq("id", body.keyId);
        if (!isAdmin) query = query.eq("owner_user_id", userId);
        const { error } = await query;
        if (error) throw error;
        return json({ ok:true });
      }

      if (body.action === "update_key") {
        if (!body.keyId) return fail("缺少keyId");
        const employeePriority = Math.max(1, Math.min(9999, Math.trunc(Number(body.employeePriority ?? body.priority ?? 100))));
        const adminPriority = Math.max(1, Math.min(9999, Math.trunc(Number(body.adminPriority ?? body.priority ?? 100))));
        const limitValue = body.dailyRequestLimit ? Math.max(1, Math.min(1000000, Math.trunc(Number(body.dailyRequestLimit)))) : null;
        let query = admin.from("ai_api_keys").update({ enabled:body.enabled !== false, priority:employeePriority, employee_priority:employeePriority, daily_request_limit:limitValue, model:String(body.model || DEFAULT_MODEL).trim(), use_proxy_pool:body.useProxyPool === true, cooldown_until:null, updated_at:new Date().toISOString() }).eq("id", body.keyId);
        if (!isAdmin) query = query.eq("owner_user_id", userId);
        const { data, error } = await query.select("id").maybeSingle();
        if (error) throw error;
        if (!data) return fail("Key不存在或无权修改", 404);
        if (isAdmin) {
          const { error:preferenceError } = await admin.from("ai_admin_model_preferences").upsert({ admin_user_id:userId, api_key_id:body.keyId, priority:adminPriority, enabled:true, updated_at:new Date().toISOString() }, { onConflict:"admin_user_id,api_key_id" });
          if (preferenceError) throw preferenceError;
        }
        return json({ ok:true });
      }

      if (body.action !== "generate" && body.action !== "translate") return fail("不支持的操作");
      if (!isAdmin && permissions.ai_reply !== true && permissions.reengage !== true) return fail("当前会员没有AI功能权限", 403);
      const translating = body.action === "translate";
      const translationText = String(body.text || "").trim().slice(0,12000);
      if (translating && !translationText) return fail("没有可翻译文字");
      const sourceLanguage = String(body.sourceLanguage || "auto");
      const targetLanguage = String(body.targetLanguage || "en");
      const messages = translating ? [
        {role:"system" as const,content:`Translate from ${/^zh/i.test(sourceLanguage) ? "Chinese" : sourceLanguage === "auto" ? "the detected language" : "English"} to ${/^zh/i.test(targetLanguage) ? "Simplified Chinese" : "natural American English"}. Return only the translation. Preserve names, phone numbers, dates, amounts and intent.`},
        {role:"user" as const,content:translationText}
      ] : safeMessages(body.messages);
      const { data:available, error:keyError } = await admin.from("ai_api_keys").select("*").eq("enabled", true).order("priority", { ascending:true });
      if (keyError) throw keyError;
      let adminPreferences = new Map<string,any>();
      if (isAdmin) {
        const { data:preferenceRows, error:preferenceError } = await admin.from("ai_admin_model_preferences").select("api_key_id,priority,enabled").eq("admin_user_id", userId);
        if (preferenceError) throw preferenceError;
        adminPreferences = new Map((preferenceRows || []).map((row:any) => [String(row.api_key_id), row]));
      }
      const now = Date.now();
      const accessible = (available || []).filter((row:any) =>
        (row.owner_user_id === userId || (row.owner_user_id === null && (isAdmin || permissions.public_groq_pool === true))) &&
        (!isAdmin || adminPreferences.get(String(row.id))?.enabled !== false)
      );
      if (!accessible.length) return fail("当前账号没有可用的个人Key或公共Key；个人Key仅限创建它的账号使用", 503);
      const usable = accessible.filter((row:any) => !row.cooldown_until || new Date(row.cooldown_until).getTime() <= now);
      const personal = usable.filter((row:any) => row.owner_user_id === userId);
      const publicKeys = usable.filter((row:any) => row.owner_user_id === null && (isAdmin || permissions.public_groq_pool === true));
      const preferredProvider = translating ? validateProvider(body.preferredProvider) : null;
      const candidates = (settings.personal_key_first ? [...personal, ...(settings.allow_public_fallback ? publicKeys : [])] : [...publicKeys, ...personal])
        .filter((row:any) => translating || validateProvider(row.provider) !== "deepl")
        .sort((a:any, b:any) => {
          const preferred = Number(validateProvider(b.provider) === preferredProvider) - Number(validateProvider(a.provider) === preferredProvider);
          return preferred || Number(isAdmin ? (adminPreferences.get(String(a.id))?.priority ?? a.admin_priority) : a.employee_priority) - Number(isAdmin ? (adminPreferences.get(String(b.id))?.priority ?? b.admin_priority) : b.employee_priority);
        });
      if (!candidates.length) {
        if (usable.length) return fail("当前账号没有个人Key，并且AI池规则未允许使用公共池备用", 503);
        const nextReadyAt = Math.min(...accessible.map((row:any) => new Date(row.cooldown_until || 0).getTime()).filter((value:number) => value > now));
        const retryAfter = Number.isFinite(nextReadyAt) ? Math.max(1, Math.ceil((nextReadyAt - now) / 1000)) : 30;
        return json({ ok:false, code:"ALL_KEYS_COOLDOWN", message:`全部AI Key正在冷却，约 ${retryAfter} 秒后自动恢复`, retryAfter }, 429);
      }

      let lastError = "AI服务暂时不可用", lastStatus = 503, retryAfter = 0, totalAttempts = 0;
      const deadline = Date.now() + 45000;
      const maxAttempts = Math.min(36, Math.max(12, candidates.length * 3));
      const attempts:Array<{ provider:string; model:string; status:number }> = [];
      for (const keyRow of candidates) {
        if (Date.now() >= deadline || totalAttempts >= maxAttempts) break;
        const { data:usage } = await admin.from("ai_usage_daily").select("request_count,input_tokens,output_tokens,error_count").eq("usage_date", new Date().toISOString().slice(0, 10)).eq("api_key_id", keyRow.id).eq("user_id", userId).maybeSingle();
        if (keyRow.daily_request_limit && Number(usage?.request_count || 0) >= keyRow.daily_request_limit) {
          lastError = `${keyRow.display_name || "当前Key"}已达到每日上限`;
          lastStatus = 429;
          attempts.push({ provider:validateProvider(keyRow.provider), model:String(keyRow.model || ""), status:429 });
          continue;
        }
        const provider = validateProvider(keyRow.provider);
        const apiKey = await decryptAiKey(keyRow.encrypted_key, keyRow.encryption_iv);
        const endpoint = endpointFor(provider, keyRow.endpoint_url);
        // Every configured row represents one explicit model. Failover moves to
        // the next row by priority; it never silently grants employees another model.
        const models = uniqueModels(keyRow.model);

        for (const model of models) {
          if (Date.now() >= deadline || totalAttempts >= maxAttempts) break;
          const excludedProxies = new Set<string>();
          const proxyAttempts = keyRow.use_proxy_pool ? 3 : 1;
          for (let proxyAttempt = 0; proxyAttempt < proxyAttempts; proxyAttempt += 1) {
            if (Date.now() >= deadline || totalAttempts >= maxAttempts) break;
            const proxy = keyRow.use_proxy_pool ? await chooseProxy(admin, excludedProxies) : null;
            if (keyRow.use_proxy_pool && !proxy) { lastError = "翻译IP池暂时没有可用于AI的HTTP/HTTPS线路"; break; }
            if (proxy) excludedProxies.add(proxy.id);
            totalAttempts += 1;
            try {
              const timeoutMs = Math.max(1200, Math.min(12000, deadline - Date.now()));
              const { response:apiResponse, result } = provider === "deepl"
                ? await deeplTranslate(endpoint, apiKey, translationText, sourceLanguage, targetLanguage, proxy, timeoutMs)
                : await providerFetch(endpoint, apiKey, { model, messages, temperature:Math.max(0, Math.min(2, Number(body.temperature ?? 0.7))), max_tokens:Math.max(64, Math.min(4096, Number(body.maxTokens ?? 1200))) }, proxy, timeoutMs);
              if (!apiResponse.ok) {
                const message = String(result?.error?.message || `${provider} HTTP ${apiResponse.status}`);
                lastStatus = apiResponse.status;
                retryAfter = Math.max(retryAfter, retryAfterSeconds(apiResponse, message));
                attempts.push({ provider, model, status:apiResponse.status });
                if (apiResponse.status === 429) {
                  const cooldownSeconds = Math.max(30, retryAfter || 60);
                  await admin.from("ai_api_keys").update({ cooldown_until:new Date(Date.now() + cooldownSeconds * 1000).toISOString(), last_error:message, failure_count:Number(keyRow.failure_count || 0) + 1 }).eq("id", keyRow.id);
                  lastError = message;
                  break;
                }
                if (proxy && [403, 407].includes(apiResponse.status)) {
                  await logProxy(admin, { user_id:userId, proxy_id:proxy.id, source:"ai-gateway", event_type:"ai_proxy_rejected", target:`${provider}:${model}`, status_code:apiResponse.status, message:message.slice(0, 500) });
                  // 403 can be specific to one AI provider/region. Keep the
                  // shared line globally healthy for websites and translation.
                  // 407 is definitive proxy-auth failure and remains global.
                  if (apiResponse.status === 407) await admin.from("translation_proxy_pool").update({ health_status:"failing", failure_count:Number(proxy.failure_count || 0) + 1, last_error:message, last_checked_at:new Date().toISOString() }).eq("id", proxy.id);
                  lastError = message;
                  continue;
                }
                await admin.from("ai_api_keys").update({ last_error:message, failure_count:Number(keyRow.failure_count || 0) + 1 }).eq("id", keyRow.id);
                lastError = message;
                break;
              }
              const content = String(provider === "deepl" ? result?.translations?.[0]?.text : result?.choices?.[0]?.message?.content || "");
              if (!content.trim()) throw new Error(`${provider} 返回了空内容`);
              const promptTokens = Number(result?.usage?.prompt_tokens || 0), completionTokens = Number(result?.usage?.completion_tokens || 0);
              const old = usage || { request_count:0 };
              await admin.from("ai_usage_daily").upsert({ usage_date:new Date().toISOString().slice(0, 10), api_key_id:keyRow.id, user_id:userId, request_count:Number(old.request_count || 0) + 1, input_tokens:Number(old.input_tokens || 0) + promptTokens, output_tokens:Number(old.output_tokens || 0) + completionTokens }, { onConflict:"usage_date,api_key_id,user_id" });
              await admin.from("ai_api_keys").update({ last_used_at:new Date().toISOString(), last_error:null, failure_count:0, cooldown_until:null }).eq("id", keyRow.id);
              if (proxy) {
                await admin.from("translation_proxy_pool").update({ health_status:"healthy", failure_count:0, last_used_at:new Date().toISOString(), last_checked_at:new Date().toISOString() }).eq("id", proxy.id);
                await logProxy(admin, { user_id:userId, proxy_id:proxy.id, source:"ai-gateway", event_type:"ai_request_success", target:`${provider}:${model}`, status_code:200, message:"AI请求已通过翻译IP池完成" });
              }
              return json({ ok:true, provider, model, content, usage:result?.usage || null, proxied:Boolean(proxy) });
            } catch (error) {
              lastError = error instanceof Error ? error.message : String(error);
              lastStatus = 503;
              await admin.from("ai_api_keys").update({ last_error:lastError, failure_count:Number(keyRow.failure_count || 0) + 1 }).eq("id", keyRow.id);
              const routeFailure = /(?:timed?\s*out|timeout|connection|tunnel|network|fetch|dns|certificate|socket|error sending request)/i.test(lastError);
              if (proxy && routeFailure) {
                // An AI-provider request failure is target-specific. Never
                // poison the shared website/translation pool from here; the
                // dedicated multi-endpoint health checker owns global status.
                await logProxy(admin, { user_id:userId, proxy_id:proxy.id, source:"ai-gateway", event_type:"ai_route_failed", target:`${provider}:${model}`, message:lastError.slice(0, 500) });
                continue;
              }
              break;
            }
          }
        }
      }
      const rateLimited = attempts.length > 0 && attempts.every(item => item.status === 429) && lastStatus === 429;
      return json({ ok:false, code:rateLimited ? "RATE_LIMITED" : "AI_UNAVAILABLE", message:rateLimited ? "当前模型额度暂时不可用，已自动尝试其他Key和AI模型" : lastError, retryAfter, attempts }, rateLimited ? 429 : (lastStatus >= 400 ? lastStatus : 503));
    } catch (error) {
      console.error("ai-gateway error", error);
      return fail(error instanceof Error ? error.message : String(error), 500);
    }
  }),
};
